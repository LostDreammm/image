# 激活eMTC eDRX模式

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本操作指导介绍在运行网络中激活eMTC eDRX特性的操作过程。

适用于SGW-U、PGW-U。

## 必备事项

前提条件

* 请仔细阅读GWFD-110641 eMTC eDRX模式。
* 完成加载License（如果有需求，请联系华为技术支持工程师处理）。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD APN** | APN名称（APN） | apnemtc | 本端规划 | eDRX模式所使用的APN。 |
| **SET GLBDLBUFTIME** | 普通用户下行数据缓存时长（NORMALUSER） | 10 | 本端规划 | - |
| **SET APNDLBUFTIME** | APN（APN） | apnemtc | 已配置数据中获取 | 已通过**ADD APN**命令配置，可以使用**LST APN**命令查询。 |
|  | 普通用户下行数据缓存时长（NORMALUSER） | 12 | 本端规划 | - |
| **SET GLBDLLTBUFFER** | 最大缓存个数（MAXBUFFERNUM） | 16 | 本端规划 | 该参数与DDN Ack消息携带的缓存个数取最小值作为系统实际缓存的最大个数; 如果DDN Ack消息没有携带缓存个数，使用该参数配置作为系统实际缓存的最大个数。 |
|  | 储存方式（BUFFERMODE） | BUFF\_MODE\_RING | 本端规划 | - |
| **SET APNDLLTBUFFER** | APN（APN） | apnemtc | 已配置数据中获取 | 已通过**ADD APN**命令配置，可以使用**LST APN**命令查询。 |
|  | 最大缓存个数（MAXBUFFERNUM） | 4 | 本端规划 | - |
|  | 储存方式（BUFFERMODE） | BUFF\_MODE\_CHAIN | 本端规划 |  |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**
2. 配置eDRX模式所使用的APN。

   **ADD APN**
3. **可选：**配置APN下的eMTC eDRX参数。
   1. 配置APN的下行数据缓存时长。

      **SET APNDLBUFTIME**
   2. 配置APN的下行数据长时间缓存配置。

      **SET APNDLLTBUFFER**
4. **可选：**配置全局的eMTC eDRX参数。
   1. 配置全局下行数据缓存时长。

      **SET GLBDLBUFTIME**
   2. 配置全局下行数据长时间缓存配置。

      **SET GLBDLLTBUFFER**

      对于缓存时常和长时间缓存配置：

      * 如果SGW-U/PGW-U和MME上都配置了缓存时常和长时间缓存配置参数，当MME通过DDN ACK下发这些参数时，最大缓存个数取两者最小值，eMTC用户下行数据缓存时长取MME下发值。
      * 配置APN后，会生成基于APN的缓存时常和长时间缓存配置参数，且生效优先级APN>全局，如果需要修改全局缓存时常和长时间缓存配置参数，需要同步修改APN下的缓存时常和长时间缓存配置参数，避免全局修改不生效。

## 任务示例

任务描述

在UDG上配置eMTC eDRX模式功能。对于APN接入场景，使用APN下的eMTC eDRX配置，否则使用全局配置。

脚本

//打开本特性License配置开关。

```
SET LICENSESWITCH: LICITEM="LKV3G5MDRX01", SWITCH=ENABLE;
```

//配置eDRX模式所使用的APN。

```
ADD APN: APN="apn_emtc";
```

//配置APN的下行数据缓存时长。

```
SET APNDLBUFTIME: APN="apnemtc", NORMALUSER=10;
```

//配置APN的下行数据长时间缓存配置。

```
SET APNDLLTBUFFER: APN="apnemtc", MAXBUFFERNUM=4, BUFFERMODE=BUFF_MODE_CHAIN;
```

//配置全局下行数据缓存时长。

```
SET GLBDLBUFTIME: NORMALUSER=12;
```

//配置全局下行数据长时间缓存配置。

```
SET GLBDLLTBUFFER: MAXBUFFERNUM=16, BUFFERMODE=BUFF_MODE_RING;
```

版权所有 © 华为技术有限公司
