# 激活用户面负载信息上报

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

当SGW-C/PGW-C/SMF需要基于网元负载信息选择SGW-U/PGW-U/UPF时，可激活本特性。

适用于SGW-U、PGW-U、UPF。

## 必备事项

前提条件

请仔细阅读GWFD-020154 用户面负载信息上报。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET PFCPLOADRPT** | 负荷上报开关（LOADRPTSW） | ENABLE | 固定取值 | 用户面负载信息上报功能开关。 |
|  | 上报阈值（RPTTHD） | 50 | 本端规划 | 设置负载信息上报和停止上报的阈值。 |
|  | 停止上报阈值（STOPTHD） | 45 | 本端规划 |  |
|  | 变化范围阈值（RANGETHD） | 5 | 本端规划 | 设置上报变化范围阈值。 |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**
2. 开启用户面负载信息上报的功能开关，并设置上报阈值。

   **SET PFCPLOADRPT**

## 任务示例

任务描述

SGW-U/PGW-U/UPF开启用户面负载信息上报的功能，上报阈值设置为50%，变化范围阈值配置为5%，当负载超过50%时上报。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5UPLR01",SWITCH=ENABLE;
```

//打开本特性的开关，上报阈值设置为50%，变化范围阈值配置为5%。

```
SET PFCPLOADRPT:LOADRPTSW=ENABLE,RPTTHD=50,STOPTHD=45,RANGETHD=5;
```

版权所有 © 华为技术有限公司
