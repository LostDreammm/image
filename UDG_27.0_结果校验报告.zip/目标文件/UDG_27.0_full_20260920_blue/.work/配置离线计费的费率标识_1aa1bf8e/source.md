# 配置离线计费的费率标识

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本操作描述离线计费使用的费率标识的配置过程。

离线计费中，UNC收集计费信息时需要用到费率标识。UNC支持用户级离线计费，也支持更细粒度的按用户使用的业务进行离线计费，即内容计费。这两种方式下都以费率组（Rating Group，缩写为RG）和业务ID（Service ID，缩写为SID）作为费率标识，其中RG是必须的，SID是可选的，同时使用RG和SID进行标识，使CG生成更丰富的话单信息。

## 必备事项

前提条件

* 请仔细阅读Ga/Gy接口离线/在线计费。

* 完成加载license。
* 本操作任务涉及的APN/DNN、User Profile、User Profile group已经创建完成，并完成User Profile group与APN/DNN的绑定。

数据

**表1** 业务套餐规划

| 条件 | 计费类型 | RG | URR ID | Rule Name | User Profile Name |
| --- | --- | --- | --- | --- | --- |
| 访问网址是www.huawei.com的网站 | offline | 1100 | 12500 | Rule001\_url | userprofile001 |
| 访问IMS业务 | offline | 1200 | 13500 | Rule002\_IMS | userprofile002 |
| any to any的业务流 | offline | 1300 | 11500 | Rule003\_any  Rule003\_any\_IPv6 | userprofile001 |

**表2** 内容计费配置数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_offline\_URL  urr\_offline\_IMS  urr\_offline\_any | 本端规划 | 配置使用量上报规则，从而配置使用的费率标识。  说明：  参数“USAGERPTMODE”取值“OFFLINE”时，参数“OFFCOMPOUNDTYPE”、“RG”、“SID”组合配置要求唯一。 |
|  | URR标识（URRID） | 12500  13500  11500 |  |  |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE |  |  |
|  | 离线计费标识组成类型（OFFCOMPOUNDTYPE） | ONLYRG |  |  |
|  | 离线计费组（RG） | 1100  1200  1300 |  |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | EVENT\_VOLUME\_TIME |  |  |
| **SET GLBURRGROUP** | 上行发起离线URR名称（UPOFFURRNAME） | urr\_offline\_URL | 已配置数据中获取 | 将URR绑定到全局URR组上。如果上下行使用不同的URR，则两者必须同时为在线计费或离线计费。 |
|  | 下行发起离线URR名称（DOWNOFFURRNAME） | urr\_offline\_URL | 已配置数据中获取 |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | UrrGp\_URL  UrrGp\_IMS  UrrGp\_any | 本端规划 | 配置URR组，将上下行URR绑定到URR组上。  如果上下行使用不同的URR，则两者必须同时为在线计费或离线计费。 |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_offline\_URL  urr\_offline\_IMS  urr\_offline\_any | 已配置数据中获取 |  |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_offline\_URL  urr\_offline\_IMS  urr\_offline\_any | 已配置数据中获取 |  |
| **SET URRGRPBINDING** | 用户模板名称（USERPROFILENAME） | userprofile001  userprofile002 | 已配置数据中获取 | 将URR组绑定到User Profile上。 |
|  | 缺省URR组名称（DFTURRGRPNAME） | UrrGp\_any | 已配置数据中获取 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | PPG\_URL  PPG\_IMS  PPG\_any | 本端规划 | 配置内容计费使用的Rule。 |
|  | 使用量上报规则组名称（URRGROUPNAME） | UrrGp\_URL  UrrGp\_IMS  UrrGp\_any | 已配置数据中获取 |  |
| **ADD RULE** | 规则名称（RULENAME） | Rule001\_url  Rule002\_IMS  Rule003\_any  Rule003\_any\_IPv6 | 本端规划 |  |
|  | 策略类型（POLICYTYPE） | PCC | 固定取值 |  |
|  | 策略名称（POLICYNAME） | PPG\_URL  PPG\_IMS  PPG\_any | 已配置数据中获取 |  |
|  | 优先级（PRIORITY） | 100  110  65000 | 本端规划 |  |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | userprofile001 | 已配置数据中获取 | 将Rule绑定到User Profile上。 |
|  | 规则名称（RULENAME） | Rule001\_url  Rule003\_any  Rule003\_any\_IPv6 | 已配置数据中获取 |  |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | userprofile002 | 已配置数据中获取 |  |
|  | 规则名称（RULENAME） | Rule002\_IMS | 已配置数据中获取 |  |

## 操作步骤

* 配置全局粒度的Session级计费费率标识。
  1. 配置全局URR，从而配置相应的计费费率标识，包括必须配置的RG和可选配置的SID。

     **ADD URR**
  2. 将全局URR绑定到全局URR组上，上下行可以使用不同的URR。

     **SET GLBURRGROUP**
* 配置User Profile粒度的Session级计费费率标识。
  1. 配置User Profile下绑定的缺省URR组及相应URR。

     1. 配置URR，从而配置相应的计费费率标识，包括必须配置的RG和可选配置的SID。

        **ADD URR**
     2. 配置URR组，将上下行URR绑定到URR组上。上下行可以使用不同的URR。

        **ADD URRGROUP**
  2. 为User Profile配置缺省URR组。

     **SET URRGRPBINDING**
* 配置内容计费费率标识。
  1. 打开内容计费的License配置开关。

     配置内容计费费率标识不依赖于内容计费License，但内容计费费率标识需在打开内容计费License后生效。因此，仅在激活内容计费时，执行本步骤。

     **SET LICENSESWITCH**
  2. 配置内容计费使用的URR组及相应URR，从而配置相应的计费费率标识。

     1. 配置URR，从而配置相应的计费费率标识，包括必须配置的RG和可选配置的SID。

        **ADD URR**
     2. 配置URR组，将上下行URR绑定到URR组上。上下行可以使用不同的URR。

        **ADD URRGROUP**
  3. 配置内容计费使用的Rule，将URR组绑定到对应的Rule上。

     1. 配置Rule绑定的PCC策略组，将URR组绑定到PCC策略组。

        **ADD PCCPOLICYGRP**
     2. 配置Rule，将PCC策略组绑定到Rule上。

        **ADD RULE**
  4. 为User Profile绑定Rule。

     **ADD RULEBINDING**

## 任务示例

任务描述

任务一：配置全局粒度的Session级计费费率标识，具体内容为：上下行均使用相同的URR，URR内容为：离线计费，费率标识RG 1100。

任务二：配置User Profile粒度的Session级计费费率标识，具体内容为：上下行均使用相同的URR，URR内容为：离线计费，费率标识RG 1100。URR Group绑定在名为"userprofile001"的User Profile实例上。

任务三：配置内容计费的费率标识，具体内容参考表1。

假设APN/DNN实例apn-test已创建，并且绑定了User Profile group upg-test；User Profile group upg-test中绑定了User Profile实例userprofile001和userprofile002。

脚本

1. 任务一：配置离线计费、且费率标识为RG 1100的URR，并将该URR设置为全局上下行URR。

   ```
   ADD URR: URRNAME="urr_offline_URL", URRID=12500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1100, OFFMETERINGTYPE=VOLUME;
   SET GLBURRGROUP:UPOFFURRNAME="urr_offline_URL", DOWNOFFURRNAME="urr_offline_URL";
   ```
2. 任务二：配置User Profile粒度的Session级计费费率标识，具体内容为：上下行均使用相同的URR，URR内容为：离线计费，费率标识RG 1100。URR Group绑定在名为"userprofile001"的User Profile实例上。

   //配置离线计费、且费率标识为RG 1100的URR，并将该URR作为上下行URR绑定到URR组上。

   ```
   ADD URR: URRNAME="urr_offline_URL", URRID=12500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1100, OFFMETERINGTYPE=VOLUME;
   ADD URRGROUP: URRGROUPNAME="UrrGp_URL", UPURRNAME1="urr_offline_URL", DOWNURRNAME1="urr_offline_URL";
   ```

   //为User Profile配置缺省URR组。

   ```
   SET URRGRPBINDING:USERPROFILENAME="userprofile001",DFTURRGRPNAME="UrrGp_any";
   ```
3. 任务三：配置内容计费的费率标识，具体内容参考表1。APN/DNN实例apn-test下绑定User Profile group实例upg\_test，upg\_test中绑定有User Profile实例userprofile001和userprofile002。

   //打开内容计费的License配置开关。

   ```
   SET LICENSESWITCH: LICITEM="LKV3W9BCC12", SWITCH=ENABLE;
   ```

   //配置URR。URRID、USAGERPTMODE、OFFMETERINGTYPE、ONLMETERINGTYPE在UNC和UPF上的配置需要保持一致。

   ```
   ADD URR: URRNAME="urr_offline_URL", URRID=12500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1100, OFFMETERINGTYPE=VOLUME;
   ADD URR: URRNAME="urr_offline_IMS", URRID=13500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1200, OFFMETERINGTYPE=VOLUME;
   ADD URR: URRNAME="urr_offline_any", URRID=11500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1300, OFFMETERINGTYPE=VOLUME;
   ```

   //配置URRGROUP。

   ```
   ADD URRGROUP: URRGROUPNAME="UrrGp_URL", UPURRNAME2="urr_offline_URL", DOWNURRNAME2="urr_offline_URL";
   ADD URRGROUP: URRGROUPNAME="UrrGp_IMS", UPURRNAME2="urr_offline_IMS", DOWNURRNAME2="urr_offline_IMS";
   ADD URRGROUP: URRGROUPNAME="UrrGp_any", UPURRNAME2="urr_offline_any", DOWNURRNAME2="urr_offline_any";
   ```

   //配置PCC策略组数据。

   ```
   ADD PCCPOLICYGRP: PCCPOLICYGRPNM="PPG_URL", URRGROUPNAME="UrrGp_URL";
   ADD PCCPOLICYGRP: PCCPOLICYGRPNM="PPG_IMS", URRGROUPNAME="UrrGp_IMS";
   ADD PCCPOLICYGRP: PCCPOLICYGRPNM="PPG_any", URRGROUPNAME="UrrGp_any";
   ```

   //配置规则，并绑定已配置的PCC策略组。UNC、UPF上RULENAME以及RULE下配置的POLICYTYPE、POLICYNAME需要保持一致。

   ```
   ADD RULE: RULENAME="Rule001_url", POLICYTYPE=PCC, PRIORITY=100, POLICYNAME="PPG_URL";
   ADD RULE: RULENAME="Rule002_IMS", POLICYTYPE=PCC, PRIORITY=110, POLICYNAME="PPG_IMS";
   ADD RULE: RULENAME="Rule003_any", POLICYTYPE=PCC, PRIORITY=65000, POLICYNAME="PPG_any";
   ADD RULE: RULENAME="Rule003_any_IPv6", POLICYTYPE=PCC, PRIORITY=65010, POLICYNAME="PPG_any";
   ```

   //将Rule绑定到User Profile上。User Profile的名称统一规划，保证在PCF、UNC、UPF间名称一致。不一致时PCF下发的策略无法生效。

   ```
   ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule001_url";
   ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule003_any";
   ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule003_any_IPv6";
   ADD RULEBINDING: USERPROFILENAME="userprofile002", RULENAME="Rule002_IMS";
   ```

版权所有 © 华为技术有限公司
