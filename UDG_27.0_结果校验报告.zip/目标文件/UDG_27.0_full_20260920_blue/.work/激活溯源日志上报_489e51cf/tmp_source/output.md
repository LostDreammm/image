---
id: ''
name: 激活溯源日志上报
ne_type: UDG
type: feature
description: UDG支持将NAT上报至日志服务器，其中日志服务器可以为CloudUDN产品，也可以是其他Log Server，UDG与CloudUDN之间基于Natlog协议传输NAT日志，与其他Log Server间基于Syslog协议传输NAT日志。
risk_level: ''
doc_source: ["特性部署","业务专题","UDG NAT功能专题","数据配置与调测","数据配置","配置NAT溯源日志","激活溯源日志上报"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UDG支持将NAT上报至日志服务器，其中日志服务器可以为CloudUDN产品，也可以是其他Log Server，UDG与CloudUDN之间基于Natlog协议传输NAT日志，与其他Log Server间基于Syslog协议传输NAT日志。

## 必备事项
前提条件

* 已完成NAT基本功能的数据配置，UDG能够正常进行NAT转换。
* 已配置完成UDG到CloudUDN或其他Log Server的路由数据。
* 已登录OM Portal。
* 已完成配置NAT基本功能License开关。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    set_licenseswitch_list:
      type: items
      properties:
        LICITEM:
          name: 'License项'
          type: string
          minLength: 0
          maxLength: 255
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SWITCH:
          name: '开关'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - set_licenseswitch_list:
    - LICITEM: 'LKV4NATLOG01'
      SWITCH: ENABLE
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 全部展开

### 配置溯源日志上报功能License开关

#### 1.1 打开本特性的License配置开关。

```jinja2
{%- for item in set_licenseswitch_list -%}
    SET LICENSESWITCH:
    {#- --- 必选参数 --- -#}
    LICITEM="{{item.LICITEM}}",
    SWITCH={{item.SWITCH}},
    ;
{%- endfor -%}
```

### 2 配置溯源日志上报至CloudUDN

#### 2.1 选择“应用管理 > NAT”，进入NAT的CLI执行界面。

#### 2.2 进入natlog-view视图。

#### **nap-view**

#### **natlog-view**

#### 2.3 配置natlog-client，日志上报的客户端IP地址和名称。

#### **natlog-client address *xxx* clientname *xxx***

#### 2.4 配置natlog-server，日志上报服务器。

#### **natlog-server**

#### 此处IP地址CloudUDN IP地址，端口配置为CloudUDN的通信端口，请以CloudUDN配套版本的通信矩阵中端口描述为准。

#### 如果需要配置日志主备抄送，则需要配置两个server服务器，同时使用natlog-carbon-copy命令打开主备抄送的开关。

#### 2.5 打开natlog日志上报给CloudUDN的开关。

#### **natlog-switch global binary allocate default**

### 3 配置溯源日志上报至其他Log Server

#### 3.1 选择“应用管理 > NAT”，进入NAT的CLI执行界面。

#### 3.2 配置自定义日志上报内容。

##### 3.2.1 进入natlog-view视图。

##### **nap-view**

##### **natlog-view**

##### 3.2.2 配置自定义日志上报内容。

###### 3.2.2.1 日志格式为syslog：

###### **natlog-syslog template syslog format**

###### 3.2.2.2 日志格式为netflow：

###### **natlog-netflow template ipv4**（NAT44场景）

#### 3.3 将激活源地址的NAT44转换中已经配置的策略绑定到syslog template，全局natlog开关。

#### **nat-policy** *xxx* **nap-filter-group** *xxx* **vpn-instance** *xxx* **action source-nat nat-address-pool** *xxx* **priority** *x* **syslog-template** *xxx*

#### 3.4 配置natlog-client，日志上报的客户端IP。

#### **natlog-client**

##### 3.4.1 该命令中配置的VPN需要根据网络规划，与UDG配置用来和其他Log Server通信的VPN保持一致。

##### 3.4.2 此处IP地址为NAT本端的IP地址。

#### 3.5 配置natlog-server，日志上报服务器。

#### **natlog-server**

##### 3.5.1 此处IP地址为Log Server IP地址，端口配置为Log Server的通信端口，请以Log Server配套版本的通信矩阵中端口描述为准。

##### 3.5.2 如果需要配置日志主备抄送，则需要配置两个server服务器，同时使用natlog-carbon-copy命令打开主备抄送的开关。

#### 3.6 配置步骤2中对应策略的natlog开关。

#### **natlog-switch**

