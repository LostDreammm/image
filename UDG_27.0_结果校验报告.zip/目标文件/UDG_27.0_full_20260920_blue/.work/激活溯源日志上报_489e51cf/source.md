# 激活溯源日志上报

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

UDG支持将NAT上报至日志服务器，其中日志服务器可以为CloudUDN产品，也可以是其他Log Server，UDG与CloudUDN之间基于Natlog协议传输NAT日志，与其他Log Server间基于Syslog协议传输NAT日志。

## 必备事项

前提条件

* 已完成NAT基本功能的数据配置，UDG能够正常进行NAT转换。
* 已配置完成UDG到CloudUDN或其他Log Server的路由数据。
* 已登录OM Portal。
* 已完成配置NAT基本功能License开关。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| natlog-client | address | 192.168.10.2 | 全网规划 | 日志客户端的IP地址，即NAT自身的IP地址。 |
| natlog-server | server-name | udn1 | 本端规划 | 主用日志服务器名称，此处取值样例为主用CloudUDN的名称。 |
|  |  | udn2 | 本端规划 | 备用日志服务器名称，此处取值样例为备用CloudUDN的名称。 |
|  | address | 192.168.15.10 | 全网规划 | 主用日志服务器的IP地址，此处取值样例为主用CloudUDN的IP地址。 |
|  |  | 192.168.15.11 | 全网规划 | 备用日志服务器的IP地址，此处取值样例为备用CloudUDN的IP地址。 |
|  | server-name | srv1 | 本端规划 | 主用日志服务器名称，此处取值样例为主用其他Log Server的名称。 |
|  |  | srv2 | 本端规划 | 备用日志服务器名称，此处取值样例为备用其他Log Server的名称。 |
|  | address | 192.168.15.12 | 全网规划 | 主用日志服务器的IP地址，此处取值样例为主用其他Log Server的IP地址。 |
|  |  | 192.168.15.13 | 全网规划 | 备用日志服务器的IP地址，此处取值样例为备用其他Log Server的IP地址。 |

## 操作步骤

全部展开


配置溯源日志上报功能License开关

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**

配置溯源日志上报至CloudUDN

2. 选择“应用管理 > NAT”，进入NAT的CLI执行界面。
3. 进入natlog-view视图。

   **nap-view**

   **natlog-view**
4. 配置natlog-client，日志上报的客户端IP地址和名称。

   **natlog-client address *xxx* clientname *xxx***
5. 配置natlog-server，日志上报服务器。

   **natlog-server**

   此处IP地址CloudUDN IP地址，端口配置为CloudUDN的通信端口，请以CloudUDN配套版本的通信矩阵中端口描述为准。

   如果需要配置日志主备抄送，则需要配置两个server服务器，同时使用natlog-carbon-copy命令打开主备抄送的开关。
6. 打开natlog日志上报给CloudUDN的开关。

   **natlog-switch global binary allocate default**

配置溯源日志上报至其他Log Server

1. 选择“应用管理 > NAT”，进入NAT的CLI执行界面。
2. 配置自定义日志上报内容。
   1. 进入natlog-view视图。

      **nap-view**

      **natlog-view**
   2. 配置自定义日志上报内容。
      + 日志格式为syslog：

        **natlog-syslog template syslog format**
      + 日志格式为netflow：

        **natlog-netflow template ipv4**（NAT44场景）
3. 将激活源地址的NAT44转换中已经配置的策略绑定到syslog template，全局natlog开关。

   **nat-policy** *xxx* **nap-filter-group** *xxx* **vpn-instance** *xxx* **action source-nat nat-address-pool** *xxx* **priority** *x* **syslog-template** *xxx*
4. 配置natlog-client，日志上报的客户端IP。

   **natlog-client**

   + 该命令中配置的VPN需要根据网络规划，与UDG配置用来和其他Log Server通信的VPN保持一致。
   + 此处IP地址为NAT本端的IP地址。
5. 配置natlog-server，日志上报服务器。

   **natlog-server**

   + 此处IP地址为Log Server IP地址，端口配置为Log Server的通信端口，请以Log Server配套版本的通信矩阵中端口描述为准。
   + 如果需要配置日志主备抄送，则需要配置两个server服务器，同时使用natlog-carbon-copy命令打开主备抄送的开关。
6. 配置步骤2中对应策略的natlog开关。

   **natlog-switch**

## 任务示例

任务描述

任务一：配置将NAT溯源日志上报至主备CloudUDN。

任务二：配置将NAT溯源日志上报至其他的主备Log Server。

脚本

打开本特性的License配置开关。

```
SET LICENSESWITCH: LICITEM="LKV4NATLOG01", SWITCH=ENABLE;
```

任务一：

```
[NAT]nap-view
[NAT-nap]natlog-view
[NAT-nap-natlog]natlog-client address 192.168.10.2 vpn-instance _vpnname_ clientname nattocloududn
[NAT-nap-natlog]natlog-server udn1 address 192.168.15.10 port 2450 master-group
[NAT-nap-natlog]natlog-server udn2 address 192.168.15.11 port 2450 slave-group
[NAT-nap-natlog]natlog-carbon-copy enable
[NAT-nap-natlog]natlog-switch global binary allocate default
```

任务二：

```
[NAT]nap-view
[NAT-nap]natlog-view
[NAT-nap-natlog]natlog-syslog template syslogtext format "$date_utc $time_utc $rcd_type source=$src_ip source_nat=$src_nat_ip:$src_nat_port dest=$dest_ip:$dest_port imsi=$imsi msisdn=$msisdn vpn=$vpn_id"
[NAT-nap-natlog]q
[NAT-nap]nat-policy policyname nap-filter-group filtergroupname vpn-instance srvvpn action source-nat nat-address-pool poolname priority 5 syslog-templat syslogtext
[NAT-nap]natlog-view
[NAT-nap-natlog]natlog-client address 192.168.10.2 vpn-instance _vpnname_ clientname nattocloududn
[NAT-nap-natlog]natlog-server srv1 address 192.168.15.12 port 514 master-group
[NAT-nap-natlog]natlog-server srv2 address 192.168.15.13 port 514 slave-group
[NAT-nap-natlog]natlog-carbon-copy enable
[NAT-nap-natlog]natlog-switch policyname allocate enable release enable
```

版权所有 © 华为技术有限公司
