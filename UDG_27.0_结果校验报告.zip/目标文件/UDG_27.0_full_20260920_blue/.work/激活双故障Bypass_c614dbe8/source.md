# 激活双故障Bypass

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在UDG上激活双故障Bypass功能，降低PCF/PCRF双故障对用户业务的影响。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-112000 双故障Bypass。
* 依赖的特性已完成配置，相关特性参见与其他特性的交互。
* 已完成APN、User Profile、User Profile group创建，以及三者之间的关系绑定。
* 完成**加载license**，对应的License项见License支持。

数据

* 下面数据表格中的URRID、USAGERPTMODE、PCCPOLICYGRPNM、 RULENAME、POLICYTYPE、POLICYNAME、USERPROFILENAME要与SMF保持一致。
* 语音承载的静态PCC规则中的RG与PCF下发的动态规则中的RG相同。
* PCF下发的用于创建语音专有QoS Flow/专有承载的规则的优先级高于本地配置的用于创建语音专有QoS Flow/专有承载的规则；本地配置的用于创建语音专有QoS Flow/专有承载的规则优先级高于PCF下发的any to any的动态规则和本地配置的any to any的预定义规则。

**表1** 语音缺省QoS Flow/缺省承载静态PCC策略数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD FILTER** | 过滤器名字 （FILTERNAME） | filter\_test | 本端规划 | 配置any to any过滤器名字。UPF通过将用户上下行报文匹配filter，实现报文的过滤。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 | 字符串类型。 |
|  | 三四层协议类型（L34PROTOCOL） | ANY | 本端规划 | 任意三四层协议。 |
| **ADD FILTERIPV6** | 过滤器名字（FILTERNAME） | filter\_testV6 | 本端规划 | 配置IPv6 any to any过滤器名字。UPF通过将用户上下行报文匹配filter，实现报文的过滤。 |
|  | 三四层IPv6协议输入类型（L34PROTTYPEV6） | STRING | 本端规划 | 字符串类型。 |
|  | 三四层协议类型（L34PROTOCOL） | ANY | 本端规划 | 任意三四层协议。 |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test | 本端规划 | 不同流过滤器之间，该参数不能重复。 |
| **ADD FLTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 过滤器名称（FILTERNAME） | * filter\_test * filter\_testV6 | 已配置数据中获取 | 使用**ADD FILTER**、**ADD FILTERIPV6**命令定义的过滤器名称。 |
| **ADD URR** | 使用量上报规则名称（URRNAME） | * urr\_signaling\_offline * urr\_signaling\_online | 本端规划 | 增加使用量上报规则信息。存在多条记录时，使用量上报规则名称不能重复。  “URRID”在所有URR内唯一。  使用量上报模式、计费标识组成类型、计费组以及计费统计类型请根据业务规划进行配置。 |
|  | URR标识（URRID） | * 2005 * 2015 | 本端规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | * OFFLINE * ONLINE | 本端规划 |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | VOLUME | 本端规划 |  |
|  | 在线计费统计类型（ONLMETERINGTYPE） | VOLUME | 本端规划 |  |
|  | 计费组（RG） | * 20 * 25 | 本端规划 | 该参数用于设置计费组。报表功能开启，软参bit1557开启，则需要配置此参数，同时参数值需要与SMF保持一致，否则报表上报的RG与实际计费的RG不一致。 |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | urrg\_signaling\_01 | 本端规划 | 增加使用量上报规则组。 |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_signaling\_offline | 本端规划 |  |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_signaling\_offline | 本端规划 |  |
|  | 上行发起URR名称2（UPURRNAME2） | urr\_signaling\_online | 本端规划 |  |
|  | 下行发起URR名称2（DOWNURRNAME2） | urr\_signaling\_online | 本端规划 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | pccpolicygrp\_signaling | 本端规划 | 存在多条数据时，该参数不能相同。 |
|  | 使用量上报规则组名称（URRGROUPNAME） | urrg\_signaling\_01 | 已配置数据中获取 | 使用**ADD URRGROUP**定义的使用量上报规则组。 |
| **ADD RULE** | 规则名称（RULENAME） | rule\_ims\_signaling | 与对端协商 | 存在多条数据时，该参数+策略类型不能完全相同。  与SMF上配置的规则名称相同。 |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | 使用样例值。 |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 策略名称（POLICYNAME） | pccpolicygrp\_signaling | 已配置数据中获取 | 使用**ADD PCCPOLICYGRP**命令定义的PCC策略组名称。 |
|  | 全局优先级（PRIORITY） | 241 | 与对端协商 | * 仅对PCC用户生效。优先级值越小，优先级越高。 * PCF下发的用于创建语音专有QoS Flow/专有承载的规则的优先级高于本地配置的用于创建语音专有QoS Flow/专有承载的规则；本地配置的用于创建语音专有QoS Flow/专有承载的规则优先级高于PCF下发的any to any的动态规则和本地配置的any to any的预定义规则。 * 以实际规划为准。 |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | up\_ims | 与对端协商 | 与SMF上配置的用户模板名称保持一致。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | up\_ims | 已配置数据中获取 | 使用**ADD USERPROFILE**命令定义的用户模板名称。 |
|  | 规则名称（RULENAME） | rule\_ims\_signaling | 已配置数据中获取 | 使用**ADD RULE**命令定义的规则名称。 |
| **SET REFRESHSRV** | 刷新类型（REFRESHTYPE） | ALL | 与对端协商 | 刷新Filter。 |

**表2** 静态PCC策略数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD FILTER** | 过滤器名字 （FILTERNAME） | filter\_bypass | 本端规划 | UDG通过将用户上下行报文匹配Filter，实现三四层报文的分析，从而过滤出会触发的数据报文。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 |  |
|  | 三四层协议类型（L34PROTOCOL） | ANY | 本端规划 |  |
|  | 服务器IP地址（SVRIPMODE） | 192.168.10.67 | 本端规划 | SVRIP的取值需和现网SBC-Uip（媒体面IP）地址规划一致。SBC-Uip（媒体面IP）地址有多个时需要配置多条。 |
|  | 手机起始端口号（MSSTARTPORT） | 0 | 本端规划 | 设置手机起始端口号。该参数不大于手机结束端口号。 |
|  | 手机结束端口号（MSENDPORT） | 65535 | 本端规划 | 设置手机结束端口号。该参数不小于手机起始端口号。 |
|  | 服务器起始端口号（SVRSTARTPORT） | 0 | 本端规划 | 设置服务器起始端口号。该参数不大于服务器结束端口号。 |
|  | 服务器结束端口号（SVRENDPORT） | 65535 | 本端规划 | 设置服务器结束端口号。该参数不小于服务器起始端口号。 |
| **ADD FILTERIPV6** | 过滤器名字（FILTERNAME） | filterV6\_bypass | 本端规划 | 配置过滤器名字。UPF通过将用户上下行报文匹配filter，实现报文的过滤。 |
|  | 三四层IPv6协议输入类型（L34PROTTYPEV6） | STRING | 本端规划 | 字符串类型。 |
|  | 三四层协议类型（L34PROTOCOL） | ANY | 本端规划 | 任意三四层协议。 |
|  | 服务器IPv6地址（SVRIPV6） | fc00:8028:5002:10D::181 | 本端规划 | SVRIP的取值需和现网SBC-Uip（媒体面IP）地址规划一致。SBC-Uip（媒体面IP）地址有多个时需要配置多条。 |
|  | 手机起始端口号（MSSTARTPORT） | 0 | 本端规划 | 设置手机起始端口号。该参数不大于手机结束端口号。 |
|  | 手机结束端口号（MSENDPORT） | 65535 | 本端规划 | 设置手机结束端口号。该参数不小于手机起始端口号。 |
|  | 服务器起始端口号（SVRSTARTPORT） | 0 | 本端规划 | 设置服务器起始端口号。该参数不大于服务器结束端口号。 |
|  | 服务器结束端口号（SVRENDPORT） | 65535 | 本端规划 | 设置服务器结束端口号。该参数不小于服务器起始端口号。 |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_bypass | 本端规划 | 流过滤器。 |
| **ADD FLTBINDFLOWF** | 过滤器名字 （FILTERNAME） | flowfilter\_bypass | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER** 、**ADD FILTERIPV6**命令配置。 |
|  | 流过滤器名称（FLOWFILTERNAME） | * filter\_bypass * filterV6\_bypass | 已配置数据中获取 | 已通过**ADD FLOWFILTER**命令配置。 |
| **ADD URR** | 使用量上报规则名称（URRNAME） | * urr\_voice\_offline * urr\_voice\_online * urr\_qos\_01 | 本端规划 | 增加使用量上报规则信息。存在多条记录时，使用量上报规则名称不能重复。  “URRID”在所有URR内唯一。  使用量上报模式、计费标识组成类型、计费组以及计费统计类型请根据业务规划进行配置。 |
|  | URR标识（URRID） | * 1005 * 1015 * 1006 | 本端规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | * OFFLINE * ONLINE * QOS | 本端规划 |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | VOLUME | 本端规划 |  |
|  | 在线计费统计类型（ONLMETERINGTYPE） | VOLUME | 本端规划 |  |
|  | 计费组（RG） | * 10 * 15 | 本端规划 | 该参数用于设置计费组。报表功能开启，软参bit1557开启，则需要配置此参数，同时参数值需要与SMF保持一致，否则报表上报的RG与实际计费的RG不一致。 |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | urrg\_voice\_01 | 本端规划 | 增加使用量上报规则组。 |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_voice\_offline | 本端规划 |  |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_voice\_offline | 本端规划 |  |
|  | 上行发起URR名称2（UPURRNAME2） | urr\_voice\_online | 本端规划 |  |
|  | 下行发起URR名称2（DOWNURRNAME2） | urr\_voice\_online | 本端规划 |  |
| **ADD QOSPROP** | Qos属性名称（QOSPROPNAME） | qosprop\_voice | 本端规划 | 配置静态PCC策略的QoS参数。存在多条记录时，QoS属性名称不能重复。 |
|  | QoS使用量上报规则名称（QOSURRNAME） | urr\_qos\_01 | 本端规划 | 该业务可以抢占已经分配给其他低优先级业务流的资源时，设置为ENABLE。此处以抢占为例。 |
|  | 保证的上行比特率（GBRUPLKVALUE） | 64 | 固定取值 | - |
|  | 保证的下行比特率（GBRDNLKVALUE） | 64 | 固定取值 | - |
|  | 最大上行比特率（MBRUPLKVALUE） | 64 | 本端规划 | PCF正常时，MBR\GBR是由UE携带给SBC网元，然后由SBC网元根据UE请求的带宽以及和UE协商的音频编解码方式的带宽要求等下发，并且GBR和MBR的UL/DL带宽按照相同值下发。  PCF故障bypass期间，创建专有QoSFlow/专有承载时，使用SMF上配置的MBR\GBR。参考IMS音频编解码带宽要求，建议按照64Kbit/s，不影响语音业务体验。 |
|  | 最大下行比特率（MBRDNLKVALUE） | 64 | 本端规划 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | pccpolicygrp\_voice | 本端规划 | PCC策略组。 |
|  | 使用量上报规则组名称（URRGROUPNAME） | urrg\_voice\_01 | 已配置数据中获取 | 使用**ADD URRGROUP**定义的使用量上报规则组。 |
|  | Qos属性名称（QOSPROPNAME） | qosprop\_voice | 已配置数据中获取 | QoS参数，已通过**ADD QOSPROP**命令配置完成。 |
| **ADD RULE** | 规则名称（RULENAME） | rule\_ims\_voice | 本端规划 | - |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | - |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_bypass | 已配置数据中获取 | 绑定的FlowFilter已通过**ADD FLOWFILTER**命令配置，可以通过**LST FLOWFILTER**命令查询。 |
|  | 策略名称（POLICYNAME） | pccpolicygrp\_voice | 本端规划 | 绑定的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置，可以通过**ADD PCCPOLICYGRP**命令查询。 |
|  | 全局优先级（PRIORITY） | 240 | 与对端协商 | * PCF下发的用于创建语音专有QoS Flow/专有承载的规则的优先级高于本地配置的用于创建语音专有QoS Flow/专有承载的规则；本地配置的用于创建语音专有QoS Flow/专有承载的规则优先级高于PCF下发的any to any的动态规则和本地配置的any to any的预定义规则。 * 以实际规划为准。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | up\_ims | 本端规划 | - |
|  | 规则名称（RULENAME） | rule\_ims\_voice | 已配置数据中获取 | UserProfile绑定的业务规则，已通过**ADD RULE**  命令配置完成。 |
| **ADD APNIMSSIGFLTR** | APN名称（APN） | ims | 已配置数据中获取 | 已通过命令**ADD APN**进行配置，可以使用命令查询APN配置（LST APN）查询。 |
|  | 优先级（PRIORITY） | 1 | 本端规划 | * IMS信令专用上下文的Filter。 * 若动态规则所关联的APN已配置IMS业务（可通过**LST APNIMSSIGFLTR**命令查询），则需要配置该命令，否则无需该命令。 |
|  | IP地址版本（IPVERSION） | * IPV4 * IPV6 | 本端规划 |  |
|  | 源IPv4地址（SRCIPV4ADDR） | 192.168.10.67 | 本端规划 |  |
|  | 源IPv4地址掩码长度（SRCIPV4MASKLEN） | 24 | 本端规划 |  |
|  | 目的IPv4地址指定方式（DSTIPV4SPECTYPE） | ANY | 本端规划 |  |
|  | 源端口指定方式（SRCPORTSPECTYPE） | ANY | 本端规划 |  |
|  | 源IPv4地址指定方式（SRCIPV4SPECTYPE） | SPECIFY | 本端规划 |  |
|  | 目的端口指定方式（DSTPORTSPECTYPE） | ANY | 本端规划 |  |
|  | 协议指定方式（PROSPECTYPE） | ANY | 本端规划 |  |
|  | 源IPv6地址（SRCIPV6ADDR） | fc00:8028:5002:10D::181 | 本端规划 |  |
|  | 源IPv6地址指定方式（SRCIPV6SPECTYPE） | SPECIFY | 本端规划 |  |
|  | 目的IPv6地址指定方式（DSTIPV6SPECTYPE） | ANY | 本端规划 |  |
|  | 源端口指定方式（SRCPORTSPECTYPE） | ANY | 本端规划 |  |
|  | 目的端口指定方式（DSTPORTSPECTYPE） | ANY | 本端规划 |  |
|  | 协议指定方式（PROSPECTYPE） | ANY | 本端规划 |  |
|  | 源IPv6地址前缀长度（SRCIPV6PREFLEN） | 120 | 本端规划 |  |

**表3** UPF bypass条件数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET SOFTPARA** | 软参记录数据类型（DT） | BYTE | 本端规划 | - |
|  | Byte索引（BYTENUM） | 1124 | 本端规划 | - |
|  | Byte值（BYTEVALUE） | 3 | 本端规划 | - |
| **SET IMSBYPASS** | IMS Bypass开关（IMSBYPASSSW） | ENABLE | 固定取值 | 该参数用于设置IMS Bypass开关。 |
|  | QoSURR上报流信息方式（QOSURRFLOWRPT） | FLOW | 本端规划 | 该参数用于设置IMS业务触发QoSURR时流信息的填充方式。 |
|  | QoSURR的迟滞时间（秒）（QOSURRHYSTIMER） | 0 | 本端规划 | 该参数用于配置QoS类型URR Stop上报迟滞时间。  整机老化时间是APN老化时长和QoSURR的迟滞时间之和。APN老化时间通过****LST APNFLOWAGETIME****或****LST FLOWAGETIME****查询**。** |

## 操作步骤

1. 配置语音缺省QoS Flow/缺省承载静态PCC策略。配置三四层过滤条件。

   仅当局点未配置语音缺省QoS Flow/缺省承载静态PCC策略时，执行本步骤。否则，跳过本步骤。

   1. 配置三四层过滤条件。

      **ADD FILTER**

      **ADD FILTERIPV6**
   2. 配置流过滤器。

      **ADD FLOWFILTER**

      流过滤器必须至少绑定一个filter或一个l7filter，否则所有报文都匹配不上该流过滤器。
   3. 配置三四层过滤条件与流过滤器的绑定关系。

      **ADD FLTBINDFLOWF**
   4. 增加使用量上报规则信息。

      **ADD URR**
   5. 配置上行和下行业务对应的URR。

      **ADD URRGROUP**
   6. 配置PCC策略组。

      **ADD PCCPOLICYGRP**
   7. 配置规则。

      **ADD RULE**
   8. 创建UserProfile。

      如果已配置了APN ims使用的用户模板，则跳过本步骤。

      **ADD USERPROFILE**
   9. 将已配置的rule绑定到UserProfile。

      **ADD RULEBINDING**
   10. 将新配置的Filter跟UserProfile置为生效。

       **SET REFRESHSRV**
2. 配置语音专有QoS Flow/专有承载静态PCC策略。
   1. 配置三四层过滤条件。

      **ADD FILTER**

      **ADD FILTERIPV6**
   2. 配置流过滤器。

      **ADD FLOWFILTER**
   3. 配置三四层过滤条件与流过滤器的绑定关系。

      **ADD FLTBINDFLOWF**
   4. 将新配置的Filter置为生效。

      **SET REFRESHSRV**
   5. 增加使用量上报规则信息。

      **ADD URR**
   6. 增加使用量上报规则组。

      **ADD URRGROUP**
   7. 配置静态PCC策略的QoS参数。

      **ADD QOSPROP**
   8. 配置PCC策略组。

      **ADD PCCPOLICYGRP**
   9. 配置业务策略规则。

      **ADD RULE**
   10. 将已配置的Rule绑定到UserProfile。

       **ADD RULEBINDING**
   11. 将新配置的Filter和UserProfile置为生效。

       **SET REFRESHSRV**
   12. 基于APN配置IMS业务。

       **ADD APNIMSSIGFLTR**
3. 配置PCF bypas条件。

   **SET SOFTPARA**

   **SET IMSBYPASS**

## 任务示例

任务描述

激活双故障Bypass功能。

任务一：没有配置语音缺省QoS Flow/缺省承载静态PCC策略，在UPF上激活语音PCF故障bypass功能。

任务二：已配置语音缺省QoS Flow/缺省承载静态PCC策略，在当前配置基础上激活语音PCF故障bypass功能。

脚本

* **任务一：没有配置语音缺省QoS Flow/缺省承载静态PCC策略，在UPF上激活语音PCF故障bypass功能。**
  1. 配置语音缺省QoS Flow/缺省承载静态PCC策略。

     //配置流过滤器和三四层过滤条件。

     ```
     ADD FILTER: FILTERNAME="filter_test", L34PROTTYPE=STRING, L34PROTOCOL=ANY;
     ADD FILTERIPV6: FILTERNAME="filter_testV6", L34PROTTYPEV6=STRING, L34PROTOCOL=ANY;
     ADD FLOWFILTER:FLOWFILTERNAME="flowfilter_test";
     ADD FLTBINDFLOWF:FLOWFILTERNAME="flowfilter_test",FILTERNAME="filter_test";
     ADD FLTBINDFLOWF: FLOWFILTERNAME="flowfilter_test", FILTERNAME="filter_testV6";
     ```

     //增加使用量上报规则信息。

     ```
     ADD URR: URRNAME="urr_signaling_offline", URRID=2005, USAGERPTMODE=OFFLINE, OFFMETERINGTYPE=VOLUME, RG=20;
     ADD URR: URRNAME="urr_signaling_online", URRID=2015, USAGERPTMODE=ONLINE, ONLMETERINGTYPE=VOLUME, DFTQUOTAPARA=Byte, RG=25;
     ```

     //增加使用量上报规则组。

     ```
     ADD URRGROUP:URRGROUPNAME="urrg_signaling_01", UPURRNAME1="urr_signaling_offline", DOWNURRNAME1="urr_signaling_offline", UPURRNAME2="urr_signaling_online", DOWNURRNAME2="urr_signaling_online";
     ```

     //配置PCC策略组。

     ```
     ADD PCCPOLICYGRP: PCCPOLICYGRPNM="pccpolicygrp_signaling", FUPSESSIONEXC=DISABLE, TOKENFUNCFLAG=DISABLE, SIGNALASSOCIATE=ENABLE, ADCMUTEFLAG=ENABLE, HTTP2DEGRADESW=INHERIT, URRGROUPNAME="urrg_signaling_01", EVENTCHARGEFLAG=DISABLE, EVENTCHGPOINT=RESPONSE, MMSCHARGETYPE=SINGLE;
     ```

     //配置规则。

     ```
     ADD RULE: RULENAME="rule_ims_signaling", POLICYTYPE=PCC, FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="flowfilter_test", PRIORITY=241, POLICYNAME="pccpolicygrp_signaling";
     ```

     //配置用户模板。

     ```
     ADD USERPROFILE: USERPROFILENAME="up_ims", ALIASMARKFLAG=DISABLE, DDOSCHECK=DISABLE, LOCRPTSWITCH=INHERIT;
     ```

     //配置规则与用户模板的绑定关系。

     ```
     ADD RULEBINDING:USERPROFILENAME="up_ims",RULENAME="rule_ims_signaling";
     ```

     //将新配置的Filter和UserProfile置为生效。

     ```
     SET REFRESHSRV:REFRESHTYPE=ALL;
     ```
  2. 配置语音专有QoS Flow/专有承载静态PCC策略。业务触发的专有QoS Flow/专有承载的规则需要与PCF/PCRF下发的动态规则对应的计费策略保持一致。

     //配置流过滤器和三四层过滤条件。SVRIP的取值需和现网SBC-Uip（媒体面IP）地址规划一致。SBC-Uip（媒体面IP）地址有多个时需要配置多条。

     ```
     ADD FILTER: FILTERNAME="filter_bypass", L34PROTTYPE=STRING, L34PROTOCOL=ANY, SVRIPMODE=IP, SVRIP="192.168.10.67", SVRIPMASKTYPE=LENGTHTYPE, SVRIPMASKLEN=32, MSSTARTPORT=0, MSENDPORT=65535, SVRSTARTPORT=0, SVRENDPORT=65535;
     ADD FILTERIPV6:FILTERNAME="filterV6_bypass", L34PROTTYPEV6=STRING, L34PROTOCOL=ANY, SVRIPMODE=IP, MSSTARTPORT=0, MSENDPORT=65535, SVRSTARTPORT=0, SVRENDPORT=65535, SVRIPV6="fc00:8028:5002:10D::181", SVRIPV6MASKTYPE=LENGTHTYPE, SVRIPV6MASKLEN=128; 
     ADD FLOWFILTER: FLOWFILTERNAME="flowfilter_bypass", TETHERDETFLAG=NONE; 
     ADD FLTBINDFLOWF: FLOWFILTERNAME="flowfilter_bypass", FILTERNAME="filter_bypass";
     ADD FLTBINDFLOWF: FLOWFILTERNAME="flowfilter_bypass", FILTERNAME="filterV6_bypass";
     SET REFRESHSRV: REFRESHTYPE=USERPROFILE;
     ```

     //增加使用量上报规则信息。

     ```
     ADD URR: URRNAME="urr_qos_01", URRID=1006, USAGERPTMODE=QOS;
     ADD URR: URRNAME="urr_voice_offline", URRID=1005, USAGERPTMODE=OFFLINE, OFFMETERINGTYPE=VOLUME, RG=10;
     ADD URR: URRNAME="urr_voice_online", URRID=1015, USAGERPTMODE=ONLINE, ONLMETERINGTYPE=VOLUME, DFTQUOTAPARA=Byte, RG=15;
     ```

     //增加使用量上报规则组。

     ```
     ADD URRGROUP:URRGROUPNAME="urrg_voice_01",UPURRNAME1="urr_voice_offline",DOWNURRNAME1="urr_voice_offline",UPURRNAME2="urr_voice_online",DOWNURRNAME2="urr_voice_online";
     ```

     //配置语音专有QoS Flow/专有承载的QoS参数。

     //UPF的URRID必须和SMF的URRID相同。

     ```
     ADD QOSPROP: QOSPROPNAME="qosprop_voice", GBRUPLKVALUE=64, GBRDNLKVALUE=64, MBRUPLKVALUE=64, MBRDNLKVALUE=64, QOSURRNAME="urr_qos_01", DECOUPLINGSW=DISABLE, KEYFLOWDETECTSW=DISABLE;
     ```

     //配置PCC策略组。

     ```
     ADD PCCPOLICYGRP: PCCPOLICYGRPNM="pccpolicygrp_voice", FUPSESSIONEXC=DISABLE, TOKENFUNCFLAG=DISABLE, SIGNALASSOCIATE=ENABLE, ADCMUTEFLAG=ENABLE, QOSPROPNAME="qosprop_voice", HTTP2DEGRADESW=INHERIT, URRGROUPNAME="urrg_voice_01", EVENTCHARGEFLAG=DISABLE, EVENTCHGPOINT=RESPONSE, MMSCHARGETYPE=SINGLE;
     ```

     //配置规则。本地配置静态规则优先级要低于PCF下发的动态规则的优先级。

     ```
     ADD RULE: RULENAME="rule_ims_voice", POLICYTYPE=PCC, FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="flowfilter_bypass", PRIORITY=240, POLICYNAME="pccpolicygrp_voice";
     ```

     //配置规则与用户模板的绑定关系。

     ```
     ADD RULEBINDING: USERPROFILENAME="up_ims", RULENAME="rule_ims_voice", POLICYTYPE=PCC;
     ```

     //将新配置的Filter和UserProfile置为生效。

     ```
     SET REFRESHSRV: REFRESHTYPE=ALL;
     ```

     //基于APN配置IMS业务。若动态规则所关联的APN已配置IMS业务（可通过**LST APNIMSSIGFLTR**命令查询），则需要配置该步骤，否则请跳过该步骤。

     ```
     ADD APNIMSSIGFLTR: APN="ims", PRIORITY=1, IPVERSION=IPV4, SRCIPV4SPECTYPE=SPECIFY, SRCIPV4ADDR="192.168.10.67", SRCIPV4MASKLEN=24, SRCPORTSPECTYPE=ANY, DSTIPV4SPECTYPE=ANY, DSTPORTSPECTYPE=ANY, PROSPECTYPE=ANY;
     ADD APNIMSSIGFLTR: APN="ims", PRIORITY=1, IPVERSION=IPV6, SRCIPV6SPECTYPE=SPECIFY, DSTIPV6SPECTYPE=ANY, SRCPORTSPECTYPE=ANY, DSTPORTSPECTYPE=ANY, SRCIPV6ADDR="fc00:8028:5002:10D::181", SRCIPV6PREFLEN=120, PROSPECTYPE=ANY;
     ```
  3. 开启PCF Bypass功能。

     //配置BYTE1124软参。

     ```
     SET SOFTPARA:DT=BYTE,BYTENUM=1124,BYTEVALUE=3;
     ```

     //开启PCF Bypass功能，并设置流上报模式和迟滞时间。

     ```
     SET IMSBYPASS: IMSBYPASSSW=ENABLE, QOSURRFLOWRPT=FLOW, QOSURRHYSTIMER=0;
     ```

* **任务二：已配置语音缺省QoS Flow/缺省承载静态PCC策略，在当前配置基础上激活语音PCF故障bypass功能。**

1. 配置语音专有QoS Flow/专有承载静态PCC策略。业务触发的专有QoS Flow/专有承载的规则需要与PCF/PCRF下发的动态规则对应的计费策略保持一致。

   //配置流过滤器和三四层过滤条件。SVRIP的取值需和现网SBC-Uip（媒体面IP）地址规划一致。SBC-Uip（媒体面IP）地址有多个时需要配置多条。

   ```
   ADD FILTER: FILTERNAME="filter_bypass", L34PROTTYPE=STRING, L34PROTOCOL=ANY, SVRIPMODE=IP, SVRIP="192.168.10.67", SVRIPMASKTYPE=LENGTHTYPE, SVRIPMASKLEN=32, MSSTARTPORT=0, MSENDPORT=65535, SVRSTARTPORT=0, SVRENDPORT=65535;
   ADD FILTERIPV6:FILTERNAME="filterV6_bypass", L34PROTTYPEV6=STRING, L34PROTOCOL=ANY, SVRIPMODE=IP, MSSTARTPORT=0, MSENDPORT=65535, SVRSTARTPORT=0, SVRENDPORT=65535, SVRIPV6="fc00:8028:5002:10D::181", SVRIPV6MASKTYPE=LENGTHTYPE, SVRIPV6MASKLEN=128; 
   ADD FLOWFILTER: FLOWFILTERNAME="flowfilter_bypass", TETHERDETFLAG=NONE; 
   ADD FLTBINDFLOWF: FLOWFILTERNAME="flowfilter_bypass", FILTERNAME="filter_bypass";
   ADD FLTBINDFLOWF: FLOWFILTERNAME="flowfilter_bypass", FILTERNAME="filterV6_bypass";
   SET REFRESHSRV: REFRESHTYPE=USERPROFILE;
   ```

   //增加使用量上报规则信息。

   ```
   ADD URR: URRNAME="urr_qos_01", URRID=1006, USAGERPTMODE=QOS;
   ADD URR: URRNAME="urr_voice_offline", URRID=1005, USAGERPTMODE=OFFLINE, OFFMETERINGTYPE=VOLUME, RG=10;
   ADD URR: URRNAME="urr_voice_online", URRID=1015, USAGERPTMODE=ONLINE, ONLMETERINGTYPE=VOLUME, DFTQUOTAPARA=Byte, RG=15;
   ```

   //增加使用量上报规则组。

   ```
   ADD URRGROUP:URRGROUPNAME="urrg_voice_01",UPURRNAME1="urr_voice_offline",DOWNURRNAME1="urr_voice_offline",UPURRNAME2="urr_voice_online",DOWNURRNAME2="urr_voice_online";
   ```

   //配置语音专有QoS Flow/专有承载的QoS参数。

   //UPF的URRID必须和SMF的URRID相同。

   ```
   ADD QOSPROP: QOSPROPNAME="qosprop_voice", GBRUPLKVALUE=64, GBRDNLKVALUE=64, MBRUPLKVALUE=64, MBRDNLKVALUE=64, QOSURRNAME="urr_qos_01", DECOUPLINGSW=DISABLE, KEYFLOWDETECTSW=DISABLE;
   ```

   //配置PCC策略组。

   ```
   ADD PCCPOLICYGRP: PCCPOLICYGRPNM="pccpolicygrp_voice", FUPSESSIONEXC=DISABLE, TOKENFUNCFLAG=DISABLE, SIGNALASSOCIATE=ENABLE, ADCMUTEFLAG=ENABLE, QOSPROPNAME="qosprop_voice", HTTP2DEGRADESW=INHERIT, URRGROUPNAME="urrg_voice_01", EVENTCHARGEFLAG=DISABLE, EVENTCHGPOINT=RESPONSE, MMSCHARGETYPE=SINGLE;
   ```

   //配置规则。本地配置静态规则优先级要低于PCF下发的动态规则的优先级。

   ```
   ADD RULE: RULENAME="rule_ims_voice", POLICYTYPE=PCC, FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="flowfilter_bypass", PRIORITY=240, POLICYNAME="pccpolicygrp_voice";
   ```

   //配置规则与用户模板的绑定关系。

   ```
   ADD RULEBINDING: USERPROFILENAME="up_ims", RULENAME="rule_ims_voice", POLICYTYPE=PCC;
   ```

   //将新配置的Filter和UserProfile置为生效。

   ```
   SET REFRESHSRV: REFRESHTYPE=ALL;
   ```

   //基于APN配置IMS业务。若动态规则所关联的APN已配置IMS业务（可通过**LST APNIMSSIGFLTR**命令查询），则需要配置该步骤，否则请跳过该步骤。

   ```
   ADD APNIMSSIGFLTR: APN="ims", PRIORITY=1, IPVERSION=IPV4, SRCIPV4SPECTYPE=SPECIFY, SRCIPV4ADDR="192.168.10.67", SRCIPV4MASKLEN=24, SRCPORTSPECTYPE=ANY, DSTIPV4SPECTYPE=ANY, DSTPORTSPECTYPE=ANY, PROSPECTYPE=ANY;
   ADD APNIMSSIGFLTR: APN="ims", PRIORITY=1, IPVERSION=IPV6, SRCIPV6SPECTYPE=SPECIFY, DSTIPV6SPECTYPE=ANY, SRCPORTSPECTYPE=ANY, DSTPORTSPECTYPE=ANY, SRCIPV6ADDR="fc00:8028:5002:10D::181", SRCIPV6PREFLEN=120, PROSPECTYPE=ANY;
   ```
2. 开启PCF Bypass功能。

   //配置BYTE1124软参。

   ```
   SET SOFTPARA:DT=BYTE,BYTENUM=1124,BYTEVALUE=3;
   ```

   //开启PCF Bypass功能，并设置流上报模式和迟滞时间。

   ```
   SET IMSBYPASS: IMSBYPASSSW=ENABLE, QOSURRFLOWRPT=FLOW, QOSURRHYSTIMER=0;
   ```

版权所有 © 华为技术有限公司
