# 配置Ga接口离线计费

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

离线计费中，UDG支持按用户使用的业务进行离线计费，UDG与UNC消息交互时需要用到URR ID，上报计费信息。

适用于SGW-U、PGW-U。

## 必备事项

前提条件

请仔细阅读Ga/Gy接口离线/在线计费。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | offlineURR | 本端规划 | 使用量上报规则信息。  URRID、USAGERPTMODE、OFFMETERINGTYPE在SGW-C/PGW-C和SGW-U/PGW-U上的配置需要保持一致。 |
|  | URR标识（URRID） | 1000 | 全网规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE | 全网规划 |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | EVENT\_VOLUME\_TIME | 全网规划 |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | urrgroup1 | 本端规划 | 配置URRGROUP。 |
|  | 上行发起URR名称1（UPURRNAME1） | offlineURR | 已配置数据中获取 | 已在该配置任务中通过命令**ADD URR**配置。 |
|  | 下行发起URR名称1（DOWNURRNAME1） | offlineURR | 已配置数据中获取 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | cg-test | 本端规划 | PCC策略组。 |
|  | URR组名称(URRGROUPNAME) | urrgroup1 | 已配置数据中获取 | PCC策略组绑定的URR组，已通过**ADD URRGROUP**命令配置完成。 |
| **ADD FILTER** | 过滤器名字（FILTERNAME） | filter\_red | 本端规划 | UDG通过将用户上下行报文匹配filter，实现报文的过滤。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 |  |
|  | 三四层协议类型（L34PROTOCOL） | TCP | 本端规划 |  |
|  | 服务器起始端口号（SVRSTARTPORT） | 80 | 本端规划 |  |
|  | 服务器结束端口号（SVRENDPORT） | 80 | 本端规划 |  |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | fg\_red | 本端规划 | 流过滤器。 |
| **ADD FLTBINDFLOWF** | 过滤器名字（FILTERNAME） | filter\_red | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER**命令配置。 |
| **ADD RULE** | 规则名称（RULENAME） | Rule001 | 本端规划 | 使用的内容计费规则。SGW-C/PGW-C和SGW-U/PGW-U上RuleName以及RULE下配置的POLICYTYPE、POLICYNAME需要保持一致。 |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | fg\_red | 已配置数据中获取 | 绑定的FlowFilter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | - |
|  | 策略名称（POLICYNAME） | cg-test | 本端规划 | 绑定的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置。 |
|  | 优先级（PRIORITY） | 110 | 本端规划 | 数字越小优先级越高。只绑定三四层filter的RULE的优先级应该低于绑定7层filter的RULE的优先级。 |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | up\_test | 本端规划 | USERPROFILE的名称统一规划，保证在PCRF、SGW-C/PGW-C和SGW-U/PGW-U间名称一致。不一致时PCRF下发的策略无法生效。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | up\_test | 已配置数据中获取 | 已通过**ADD USERPROFILE**命令配置。 |
|  | 规则名称（RULENAME） | Rule001 |  | 已通过**ADD RULE**命令配置。  SGW-C/PGW-C和SGW-U/PGW-U上USERPROFILE下绑定的RULENAME、POLICYTYPE需要保持一致。不一致策略无法按照预期生效。 |
|  | 策略类型（POLICYTYPE） | PCC |  |  |

## 操作步骤

配置业务级离线计费的费率标识。

1. 配置内容计费使用的URR Group。

   1. 配置URR。

      **ADD URR**
   2. 配置上行和下行发起的业务对应的URR。

      **ADD URRGROUP**
2. 配置内容计费使用的PCC策略组。

   **ADD PCCPOLICYGRP**
3. 配置过滤条件。

   1. 配置三四层过滤条件。

      **ADD FILTER**
   2. 配置流过滤器。

      **ADD FLOWFILTER**
   3. 绑定三四层过滤条件。

      **ADD FLTBINDFLOWF**
4. 配置内容计费使用的规则。

   **ADD RULE**
5. 配置内容计费规则绑定用户模板。

   1. 创建UserProfile实例。

      **ADD USERPROFILE**
   2. 将已配置的内容计费规则绑定到UserProfile。

      **ADD RULEBINDING**
6. **可选**：设置URR上报失败后的动作处理参数。

   ****SET URRFAILACTION****

   + 该命令在离线计费新业务场景下生效。
   + 当业务部署调整导致SGW-U/PGW-U的URR ID在SGW-C/PGW-C上不存在时(比如，先添加SGW-U/PGW-U上**ADD URR**，后添加SGW-C/PGW-C上**ADD URR**)，会导致SGW-C/PGW-C无法处理SGW-U/PGW-U的计费用量上报。为减小该场景下对用户业务的影响，可通过该命令设置SGW-U/PGW-U向SGW-C/PGW-C进行计费用量上报失败时的处理动作。
   + 当计费URR上报失败，业务被阻塞时，如果想要放通业务，可以执行**SET URRFAILACTION**命令，配置“RETRYFAILACT”参数为“CONTINUE”，则URR对应的业务将不计费。在SGW-U/PGW-U向SGW-C/PGW-C进行用量上报恢复后，将恢复对该URR的计费。

## 任务示例

任务描述

用户进行离线计费，统计到URR ID为1000的URR中。

脚本

//配置离线计费的费率标识

```
ADD URR:URRNAME="offlineURR",URRID=1000,USAGERPTMODE=OFFLINE,OFFMETERINGTYPE=EVENT_VOLUME_TIME;
ADD URRGROUP:URRGROUPNAME="urrgroup1",UPURRNAME1="offlineURR",DOWNURRNAME1="offlineURR";
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="cg-test",URRGROUPNAME="urrgroup1";
```

//配置三四层信息

```
ADD FILTER:FILTERNAME="filter_red",L34PROTTYPE=STRING,L34PROTOCOL=TCP,SVRSTARTPORT=80,SVRENDPORT=80;
ADD FLOWFILTER:FLOWFILTERNAME="fg_red";
ADD FLTBINDFLOWF:FLOWFILTERNAME="fg_red",FILTERNAME="filter_red";
```

//配置内容计费规则

```
ADD RULE:RULENAME="Rule001",POLICYTYPE=PCC,FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="fg_red",POLICYNAME="cg-test",PRIORITY=110;
SET REFRESHSRV:REFRESHTYPE=USERPROFILE;
```

//配置内容计费规则绑定用户模板

```
ADD USERPROFILE:USERPROFILENAME="up_test";
ADD RULEBINDING:USERPROFILENAME="up_test",RULENAME="Rule001",POLICYTYPE=PCC;
```

版权所有 © 华为技术有限公司
