# 激活IPsec功能（多Sequence的IPsec策略）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

## 操作场景

为了节省隧道接口和IP地址，本端在IPsec策略下配置多sequence，每个sequence下可以配置不同的peer，实现单个隧道接口对接多个IKE peer的功能，即一个隧道口下可以协商多个IKE SA。

如图1所示，网络A和网络B/网络C之间采用网关对网关组网模式进行资源传输。网络A和网络B/网络C分别通过Device A和Device B/Device C连接到Internet。要求通过配置IPsec隧道，实现PCA与PCB/PCC之间可以安全地互访。

**图1** 采用安全策略方式建立IPsec隧道组网图

网络环境描述如下，以IPv4网络为例：

* 网络A属于10.1.1.0/24子网，通过接口interface2与Device A连接。
* 网络B属于10.1.2.0/24子网，通过接口interface2与Device B连接。
* 网络C属于10.1.3.0/24子网，通过接口interface2与Device C连接。
* Device A和Device B/Device C路由可达，假设Device A往Device B/Device C方向下一跳地址为172.16.163.2/24，Device B往Device A方向下一跳地址为172.16.169.2/24，Device C往Device A方向下一跳地址为172.16.170.2/24。

本端设备A配置多sequence，本端隧道口Tunnel10分别于对端设备B和C的Tunnel10建立协商，协商成功后，有两条IKE SA：192.168.1.1至192.168.1.2和192.168.1.1至192.168.1.3。

**表1** 设备接口IP地址（多Sequence的IPsec策略）

| 设备名称 | 接口 | IP地址 |
| --- | --- | --- |
| Device A VNRS微服务 | Ethernet66/0/5 | 10.1.1.1/24 |
| Device A VNRS微服务 | Ethernet66/0/6 | 172.16.163.1/24（IPsec报文的本端物理出接口） |
| Device A VNRS微服务 | Tunnel10 | 192.168.1.1/32（需要双配） |
| Device B VNRS微服务 | Ethernet66/0/5 | 10.1.2.1/24 |
| Device B VNRS微服务 | Ethernet66/0/6 | 172.16.169.1/24（IPsec报文的本端物理出接口） |
| Device B VNRS微服务 | Tunnel10 | 192.168.1.2/32（需要双配） |
| Device C VNRS微服务 | Ethernet66/0/5 | 10.1.3.1/24 |
| Device C VNRS微服务 | Ethernet66/0/6 | 172.16.170.1/24（IPsec报文的本端物理出接口） |
| Device C VNRS微服务 | Tunnel10 | 192.168.1.3/32（需要双配） |
| Device A IPsec微服务 | Tunnel10 | 192.168.1.1/32（IKE协商本端IP地址） |
| Device B IPsec微服务 | Tunnel10 | 192.168.1.2/32（IKE协商本端IP地址） |
| Device C IPsec微服务 | Tunnel10 | 192.168.1.3/32（IKE协商本端IP地址） |
| PCA | - | 10.1.1.2/24 |
| PCB | - | 10.1.2.2/24 |
| PCC | - | 10.1.3.2/24 |
| - | Device A侧网关接口 | 172.16.163.2 /24 |
| - | Device B侧网关接口 | 172.16.169.2 /24 |
| - | Device C侧网关接口 | 172.16.170.2 /24 |

## 对系统的影响

本特性对系统无影响。

## 必备事项

前提条件

* 操作人员已经登录网管。
* 配置接口的IP地址。
* 配置路由，使隧道两端路由可达。
* IPSec功能由IPSec服务承载，请完成IPSec安装，参见**软件安装**章节中的“安装可选服务 > 安装IPSec服务”。

数据

需要准备的数据如表2所示。

**表2** IPsec安全参数（多Sequence的IPsec策略）

| 类别 | 参数 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD ACLGROUPIPSEC** | ACL规则组标识（ACLNAME） | * Device A: 3000、3001 * Device B: 3000 * Device C: 3001 | 本端规划 | - |
| **ADD ACLRULEADV4IPSEC** | ACL规则组标识（ACLNAME） | * Device A: 3000、3001 * Device B: 3000 * Device C: 3001 | 本端规划 | - |
|  | 规则名称（ACLRULENAME） | rule\_1 | 本端规划 | - |
|  | 规则ID（ACLRULEID） | 1 | 本端规划 | - |
|  | 规则行为（ACLACTION） | Permit | 本端规划 | - |
|  | 协议类型值（ACLPROTOCOL） | 0 | 本端规划 | - |
|  | 源IP地址（ACLSOURCEIP） | * Device A: 10.1.1.2 * Device B: 10.1.2.2 * Device C: 10.1.3.2 | 全网规划 | - |
|  | 源IP地址反掩码（ACLSRCWILD） | 0.0.0.0 | 全网规划 | - |
|  | 目的IP地址（ACLDESTIP） | * Device A（3000）: 10.1.2.2 * Device A（3001）: 10.1.3.2 * Device B: 10.1.1.2 * Device C: 10.1.1.2 | 全网规划 | - |
|  | 目的IP地址反掩码（ACLDESTWILD） | 0.0.0.0 | 全网规划 | - |
|  | VPN实例名称（VRFNAME） | vrf1 | 本端规划 | - |
| **ADD IPSECPROPOSALIPSEC** | Proposal名称（PROPOSALNAME） | tran1 | 本端规划 | - |
|  | IPsec安全协议（IPSECPROTOCOL） | Esp | 对端协商 | - |
|  | ESP认证算法（ESPAUTHALGO） | Sha2\_256 | 对端协商 | - |
|  | ESP加密算法（ESPENCRYPTALGO） | Aes\_256 | 对端协商 | - |
|  | 封装模式（ENCAPMODE） | Tunnel | 对端协商 | - |
| **ADD IKEPROPOSAL** | 安全提议号（PROPOSALNUMBER） | 10 | 本端规划 | - |
|  | 认证方法（AUTHMETHOD） | Pre\_share | 对端协商 | - |
|  | 认证算法（AUTHALGORITHM） | Sha2\_256 | 对端协商 | - |
|  | 加密算法（ENCRALGORITHM） | Aes\_cbc\_256 | 对端协商 | - |
|  | 完整性算法（INTEGALGORITHM） | Hmac\_sha2\_256 | 对端协商 | - |
|  | DH组（DHGROUP） | Dh\_group19 | 对端协商 | - |
| **ADD IKEPEER** | 对等体名称（PEERNAME） | * Device A: b、c * Device B: a * Device C: a | 对端规划 | - |
|  | 预共享密钥（PRESHAREDKEY） | abcde | 对端协商 | - |
|  | 安全提议（PROPOSAL） | 10 | 本端规划 | - |
|  | 远程地址（LOWREMOTEADDR） | * a: 192.168.1.1 * b: 192.168.1.2 * c: 192.168.1.3 | 全网规划 | - |
|  | SA绑定VPN名称（INVRFNAME） | vrf1 | 本端规划 | - |
|  | 远程地址VPN名称（OUTVRFNAME） | vrf1 | 全网规划 | - |
| **ADD IPSECPOLICY** | 策略名称（POLICYNAME） | map1 | 本端规划 | - |
|  | 序列号（SEQUENCENUMBER） | * Device A: 10、20 * Device B: 10 * Device C: 20 | 对端协商 | - |
|  | 策略模式（POLICYMODE） | Isakmp | 对端协商 | - |
|  | 模板模式（TEMPLATEMODE） | None | 对端协商 | - |
|  | ACL编号（ACLNUMBER） | * 10: 3000 * 20: 3001 | 本端规划 | 如果**ADD ACLGROUPIPSEC**中的“ACL规则组标识（ACLNAME）”配置为规则组编号，则IPsec策略中使用“ACL编号（ACLNUMBER）”；如果**ADD ACLGROUPIPSEC**中的“ACL规则组标识（ACLNAME）”配置为规则组名称，则IPsec策略中使用“ACL名称（ACLNAME）”。此处以ACL规则组编号为例。 |
| **ADD PROPATTACHIPSECPROPOSAL** | 策略名称（POLICYNAME） | map1 | 本端规划 | - |
|  | 序列号（SEQUENCENUMBER） | * Device A: 10、20 * Device B: 10 * Device C: 20 | 对端协商 | - |
|  | 策略模式（POLICYMODE） | Isakmp | 对端协商 | - |
|  | 模板模式（TEMPLATEMODE） | None | 对端协商 | - |
|  | IPsec安全提议名称（IPSECPROPNAME） | tran1 | 本端规划 | - |
| **ADD ATTACHIKEPEER** | 策略名称（POLICYNAME） | map1 | 本端规划 | - |
|  | 序列号（SEQUENCENUMBER） | * Device A: 10、20 * Device B: 10 * Device C: 20 | 对端协商 | - |
|  | 策略模式（POLICYMODE） | Isakmp | 对端协商 | - |
|  | 模板模式（TEMPLATEMODE） | None | 对端协商 | - |
|  | IKE对等体名称（IKEPEERNAME） | * Device A:   + 10: b   + 20: c * Device B: a * Device C: a | 本端规划 | - |
|  | 优先级（PEERPRIORITY） | 1 | 本端规划 | - |
| **ADD IPSECINTFCFGIPSEC** | 接口名称（INTERFACENAME） | Tunnel10 | 本端规划 | - |
|  | Tunnel口协议类型（TNLTYPE） | IPSEC | 本端规划 | - |
|  | 策略名称（POLICYNAME） | map1 | 本端规划 | - |
| **SET IKEGLOBALCONFIG** | DPD检查间隔（s）（DPDINTERVAL） | 10 | 本端规划 | - |
|  | DPD类型（DPDTYPE） | Periodic | 本端规划 | - |
|  | DPD重试间隔（s）（DPDRETRYINTRVL） | 3 | 本端规划 | - |

## 操作流程

IPsec功能通过VNRS微服务和IPsec微服务实现：

* VNRS微服务：负责与外部网络通信，将需要保护的流量引到IPsec微服务做加解密，并将加解密后的流量转发出去。
  + 待加密的流量在VNRS微服务查找路由，当出接口是IPsec隧道接口时，根据VNRS微服务中的明文引流表和密文引流表，将报文送到IPsec微服务做加密处理。报文加密完后，IPsec微服务将报文返回给VNRS微服务，VNRS微服务将报文转发出去。
  + 当VNRS微服务收到IKE协商报文或者加密的AH/ESP报文，根据报文的源、目的地址，查找VNRS微服务中的明文引流表和密文引流表，将报文送到IPsec微服务进行解密或者协商。解密后的报文，IPsec微服务将报文返回给VNRS微服务，VNRS微服务将报文转发出去。
* IPsec微服务：负责IKE协商以及加解密。IPsec微服务采用IKE方式建立IPsec隧道需要配置好IKE协商安全策略的信息，由IKE自动协商来创建和维护安全联盟。

* VNRS微服务和IPsec微服务需要遵循双配原则，即：IPsec协商用到的隧道接口、隧道接口IP、隧道类型、VPN以及指定本端接口建立IPsec隧道的接口需要在VNRS微服务和IPsec微服务上一对一的配置。若未遵循双配原则，会导致业务不通，配置过程中，请保证VNRS微服务和IPsec微服务的配置一致。如需删除隧道接口和VPN，也请同时删除VNRS微服务和IPsec微服务的相关数据。
* 在建立IPsec隧道时，如果不指定本端其他接口，则默认使用本端隧道接口作为本端IKE协商IP地址。如果指定本端其他接口，则使用本端被指定的接口作为本端IKE协商IP地址。

IPsec功能配置流程如图2所示。

**图2** IPsec功能配置流程

## 操作步骤

1. 创建VNRS微服务的VPN和IPsec隧道接口，并配置到达目的网络的静态路由。

   1. 创建VPN实例。

      **ADD L3VPNINST**

      **ADD VPNINSTAF**
   2. 将与VPN网络连接的接口与VPN实例绑定，并配置接口IP地址。

      **ADD IPBINDVPN**

      **ADD IFIPV4ADDRESS**
   3. 创建IPsec隧道接口，并将IPsec隧道接口与VPN实例绑定。

      **ADD INTERFACE**

      **ADD IPSECINTFCFG**

      **ADD IPBINDVPN**

      **ADD IFIPV4ADDRESS**
   4. 配置到达目的网络的静态路由，并与VPN实例绑定。

      **ADD SRROUTE**
2. 创建IPsec微服务的VPN和IPsec隧道接口。

   1. 创建VPN实例。

      **ADD L3VPNINSTIPSEC**

      **ADD VPNINSTAFIPSEC**
   2. 创建IPsec隧道接口，并将IPsec隧道接口与VPN实例绑定。

      **ADD INTERFACEIPSEC**

      **ADD IPBINDVPNIPSEC**

      **ADD IFIPV4ADDRESSIPSEC**
3. 定义需要保护的数据流。由用户根据ACL规则来定义，根据不同的数据流特征，定义不同的ACL规则。

   **ADD ACLGROUPIPSEC**

   **ADD ACLRULEADV4IPSEC**

   ACL只支持源IP和目的IP的配置，如果配置了端口，不会对端口配置生效。
4. 配置IPsec安全提议。

   **ADD IPSECPROPOSALIPSEC**
5. 配置IKE安全提议。

   **ADD IKEPROPOSAL**

   * 缺省情况下的认证方法为预共享密钥认证（PSK），需要通过**ADD IKEPEER**配置“预共享密钥（PRESHAREDKEY）”，否则建立SA不成功。
   * DHGROUP参数不能配置为**None**或者不配置，建议配置为**Dh\_group19**。
6. 配置IKE对等体。

   **ADD IKEPEER**

   * 当配置的认证方式为预共享密钥验证时，必须配置预共享密钥，预共享密钥的配置需要与对端设备相同。此处安全提议为IKE安全提议，IKE对等体被IPsec安全策略引用时，必须配置对端地址。对端地址不能配置为地址段。
   * 设备同时开启IKEv1和IKEv2，缺省情况下采用IKEv2进行协商。若对端不支持IKEv2，请禁用IKEv2，采用IKEv1进行协商。
7. 配置IPsec安全策略。
   1. 增加IPsec安全策略

      **ADD IPSECPOLICY**
   2. 在安全策略中引用安全提议

      **ADD PROPATTACHIPSECPROPOSAL**
   3. 绑定IKE对等体

      **ADD ATTACHIKEPEER**
8. 应用IPsec安全策略。

   **ADD IPSECINTFCFGIPSEC**
9. 当需要配置DPD功能。

   **SET IKEGLOBALCONFIG**

## 任务示例

任务描述

按照图1所示，配置IPsec隧道实现PCA与PCB/PCC之间可以安全地互访。

脚本

**Device A的配置脚本：**

//创建VNRS微服务的VPN实例。

```
ADD L3VPNINST:VRFNAME="vrf1";
```

```
ADD VPNINSTAF:VRFNAME="vrf1", AFTYPE=ipv4uni;
```

//绑定VNRS微服务与VPN实例，并配置接口IP地址。

```
MOD INTERFACE:IFNAME="Ethernet66/0/5", IFADMINSTATUS=up;
```

```
MOD INTERFACE:IFNAME="Ethernet66/0/6", IFADMINSTATUS=up;
```

```
ADD IPBINDVPN:IFNAME="Ethernet66/0/5", VRFNAME="vrf1";
```

```
ADD IPBINDVPN:IFNAME="Ethernet66/0/6", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESS:IFNAME="Ethernet66/0/5", IFIPADDR="10.1.1.1", SUBNETMASK="255.255.255.0";
```

```
ADD IFIPV4ADDRESS:IFNAME="Ethernet66/0/6", IFIPADDR="172.16.163.1", SUBNETMASK="255.255.255.0";
```

//创建VNRS微服务的IPsec隧道接口，绑定VPN并配置IP地址，隧道协议配置为IPSEC。

```
ADD INTERFACE:IFNAME="Tunnel10", IFADMINSTATUS=up;
```

```
ADD IPSECINTFCFG:INTERFACENAME="Tunnel10",TNLTYPE=IPSEC;
```

```
ADD IPBINDVPN:IFNAME="Tunnel10", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESS:IFNAME="Tunnel10", IFIPADDR="192.168.1.1", SUBNETMASK="255.255.255.255";
```

//配置到达目的网络B的静态路由，到达网络B的出接口为Tunnel10下一跳地址为192.168.1.2。假设Device A的下一跳地址为172.16.163.2/24。

```
ADD SRROUTE:VRFNAME="vrf1",AFTYPE=ipv4unicast,PREFIX="10.1.2.0",MASKLENGTH=24,DESTVRFNAME="vrf1",NEXTHOP="192.168.1.2",IFNAME="Tunnel10";
```

```
ADD SRROUTE:VRFNAME="vrf1",AFTYPE=ipv4unicast,PREFIX="192.168.1.2",MASKLENGTH=32,DESTVRFNAME="vrf1",NEXTHOP="172.16.163.2",IFNAME="Invalid0";
```

//配置到达目的网络C的静态路由，到达网络C的出接口为Tunnel10下一跳地址为192.168.1.3。假设Device A的下一跳地址为172.16.163.2/24。

```
ADD SRROUTE:VRFNAME="vrf1",AFTYPE=ipv4unicast,PREFIX="10.1.3.0",MASKLENGTH=24,DESTVRFNAME="vrf1",NEXTHOP="192.168.1.3",IFNAME="Tunnel10";
```

```
ADD SRROUTE:VRFNAME="vrf1",AFTYPE=ipv4unicast,PREFIX="192.168.1.3",MASKLENGTH=32,DESTVRFNAME="vrf1",NEXTHOP="172.16.163.2",IFNAME="Invalid0";
```

//创建IPsec微服务的VPN实例。

```
ADD L3VPNINSTIPSEC:VRFNAME="vrf1";
```

```
ADD VPNINSTAFIPSEC:VRFNAME="vrf1", AFTYPE=Ipv4uni;
```

//创建IPsec微服务的IPsec隧道接口，绑定VPN并配置IP地址。

```
ADD INTERFACEIPSEC:IFNAME="Tunnel10", IFADMINSTATUS=Up;
```

```
ADD IPBINDVPNIPSEC:IFNAME="Tunnel10", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESSIPSEC:IFNAME="Tunnel10", IFIPADDR="192.168.1.1", SUBNETMASK="255.255.255.255";
```

//配置高级ACL 3000，允许PCA访问PCB。

```
ADD ACLGROUPIPSEC:ACLNAME ="3000";
```

```
ADD ACLRULEADV4IPSEC:ACLNAME="3000",ACLRULENAME="rule_1",ACLACTION=Permit,VRFNAME="vrf1",ACLPROTOCOL=0,ACLSOURCEIP="10.1.1.2",ACLSRCWILD="0.0.0.0",ACLDESTIP="10.1.2.2",ACLDESTWILD="0.0.0.0";
```

上述**ADD ACLRULEADV4IPSEC**命令中“ACLSRCWILD”、“ACLDESTWILD”分别用于设置IPv4场景下源地址和目的地址反掩码，在反掩码中：二进制的0表示精确匹配，1表示任意，如0.0.0.0表示IP地址每一位需精确匹配。

//配置高级ACL 3001，允许PCA访问PCC。

```
ADD ACLGROUPIPSEC: ACLNAME ="3001";
```

```
ADD ACLRULEADV4IPSEC: ACLNAME="3001",ACLRULENAME="rule_1",ACLACTION=Permit,VRFNAME="vrf1",ACLPROTOCOL=0,ACLSOURCEIP="10.1.1.2",ACLSRCWILD="0.0.0.0",ACLDESTIP="10.1.3.2",ACLDESTWILD="0.0.0.0";
```

//配置名称为tran1的IPsec安全提议。

```
ADD IPSECPROPOSALIPSEC:PROPOSALNAME="tran1",ESPAUTHALGO=Sha2_256,ESPENCRYPTALGO=Aes_256,IPSECPROTOCOL=Esp,ENCAPMODE=Tunnel;
```

//配置序号为10的IKE安全提议。

```
ADD IKEPROPOSAL:PROPOSALNUMBER=10,AUTHMETHOD=Pre_share, AUTHALGORITHM=Sha2_256,DHGROUP=Dh_group19;
```

此处“PROPOSALNUMBER”参数取值为“10”仅表示本端的一条配置记录，无实际含义，也无需与对端保持一致，该参数支持的配置范围为1~100，其中101为系统默认配置，仅支持查询。

//配置名称为b的IKE peer。

```
ADD IKEPEER:PEERNAME="b",PRESHAREDKEY="abcde",NATTRAVERSAL=TRUE,PROPOSAL=10,LOWREMOTEADDR="192.168.1.2",INVRFNAME="vrf1",OUTVRFNAME="vrf1";
```

//配置名称为c的IKE peer

```
ADD IKEPEER:PEERNAME="c",PRESHAREDKEY="abcde",PROPOSAL=10,LOWREMOTEADDR="192.168.1.3",INVRFNAME="vrf1",OUTVRFNAME="vrf1";
```

//配置名称为map1、序号为10的IPsec安全策略。

```
ADD IPSECPOLICY:POLICYNAME="map1",SEQUENCENUMBER=10,POLICYMODE=Isakmp,TEMPLATEMODE=None,ACLNUMBER=3000;
```

//配置名称为map1、序号为20的IPsec安全策略

```
ADD IPSECPOLICY:POLICYNAME="map1",SEQUENCENUMBER=20,POLICYMODE=Isakmp,TEMPLATEMODE=None,ACLNUMBER=3001;
```

//在安全策略中引用安全提议

```
ADD PROPATTACHIPSECPROPOSAL:POLICYNAME="map1",SEQUENCENUMBER=10,POLICYMODE=Isakmp,TEMPLATEMODE=None,IPSECPROPNAME="tran1";
```

```
ADD PROPATTACHIPSECPROPOSAL:POLICYNAME="map1",SEQUENCENUMBER=20,POLICYMODE=Isakmp,TEMPLATEMODE=None,IPSECPROPNAME="tran1";
```

//在安全策略中引用IKE Peer

```
ADD ATTACHIKEPEER: POLICYNAME="map1",SEQUENCENUMBER=10,POLICYMODE=Isakmp,TEMPLATEMODE=None,IKEPEERNAME="b",PEERPRIORITY=1;
```

```
ADD ATTACHIKEPEER: POLICYNAME="map1",SEQUENCENUMBER=20,POLICYMODE=Isakmp,TEMPLATEMODE=None,IKEPEERNAME="c",PEERPRIORITY=1;
```

//在IPsec隧道接口上应用安全策略map1。

```
ADD IPSECINTFCFGIPSEC:INTERFACENAME="Tunnel10",TNLTYPE=IPSEC,POLICYNAME="map1";
```

//当需要配置DPD功能。

```
SET IKEGLOBALCONFIG:DPDINTERVAL=10,DPDTYPE=Periodic,DPDRETRYINTRVL=3,NATKLI=30;
```

**Device B的配置脚本：**

//创建VNRS微服务的VPN实例。

```
ADD L3VPNINST:VRFNAME="vrf1";
```

```
ADD VPNINSTAF:VRFNAME="vrf1", AFTYPE=ipv4uni;
```

//绑定VNRS微服务与VPN实例，并配置接口IP地址。

```
MOD INTERFACE:IFNAME="Ethernet66/0/5", IFADMINSTATUS=up;
```

```
MOD INTERFACE:IFNAME="Ethernet66/0/6", IFADMINSTATUS=up;
```

```
ADD IPBINDVPN:IFNAME="Ethernet66/0/5", VRFNAME="vrf1";
```

```
ADD IPBINDVPN:IFNAME="Ethernet66/0/6", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESS:IFNAME="Ethernet66/0/5", IFIPADDR="10.1.2.1", SUBNETMASK="255.255.255.0";
```

```
ADD IFIPV4ADDRESS:IFNAME="Ethernet66/0/6", IFIPADDR="172.16.169.1", SUBNETMASK="255.255.255.0";
```

//创建VNRS微服务的IPsec隧道接口，绑定VPN并配置IP地址，隧道协议配置为IPSEC。

```
ADD INTERFACE:IFNAME="Tunnel10", IFADMINSTATUS=up;
```

```
ADD IPSECINTFCFG:INTERFACENAME="Tunnel10",TNLTYPE=IPSEC;
```

```
ADD IPBINDVPN:IFNAME="Tunnel10", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESS:IFNAME="Tunnel10", IFIPADDR="192.168.1.2", SUBNETMASK="255.255.255.255";
```

//配置到达目的网络A的静态路由，到达网络A的出接口为Tunnel10下一跳地址为192.168.1.1。假设Device B的下一跳地址为172.16.163.2/24。

```
ADD SRROUTE:VRFNAME="vrf1",AFTYPE=ipv4unicast,PREFIX="10.1.1.0",MASKLENGTH=24,DESTVRFNAME="vrf1",NEXTHOP="192.168.1.1",IFNAME="Tunnel10";
```

```
ADD SRROUTE:VRFNAME="vrf1",AFTYPE=ipv4unicast,PREFIX="192.168.1.1",MASKLENGTH=32,DESTVRFNAME="vrf1",NEXTHOP="172.16.163.2",IFNAME="Invalid0";
```

//创建IPsec微服务的VPN实例。

```
ADD L3VPNINSTIPSEC:VRFNAME="vrf1";
```

```
ADD VPNINSTAFIPSEC:VRFNAME="vrf1", AFTYPE=Ipv4uni;
```

//创建IPsec微服务的IPsec隧道接口，绑定VPN并配置IP地址。

```
ADD INTERFACEIPSEC:IFNAME="Tunnel10", IFADMINSTATUS=Up;
```

```
ADD IPBINDVPNIPSEC:IFNAME="Tunnel10", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESSIPSEC:IFNAME="Tunnel10", IFIPADDR="192.168.1.2", SUBNETMASK="255.255.255.255";
```

//配置高级ACL 3000，允许PCA访问PCB。

```
ADD ACLGROUPIPSEC:ACLNAME="3000";
```

```
ADD ACLRULEADV4IPSEC:ACLNAME="3000",ACLRULENAME="rule_1",ACLACTION=Permit,VRFNAME="vrf1",ACLPROTOCOL=0,ACLSOURCEIP="10.1.2.2",ACLSRCWILD="0.0.0.0",ACLDESTIP="10.1.1.2",ACLDESTWILD="0.0.0.0";
```

上述**ADD ACLRULEADV4IPSEC**命令中“ACLSRCWILD”、“ACLDESTWILD”分别用于设置IPv4场景下源地址和目的地址反掩码，在反掩码中：二进制的0表示精确匹配，1表示任意，如0.0.0.0表示IP地址每一位需精确匹配。

//配置名称为tran1的IPsec安全提议。

```
ADD IPSECPROPOSALIPSEC:PROPOSALNAME="tran1",ESPAUTHALGO=Sha2_256,ESPENCRYPTALGO=Aes_256,IPSECPROTOCOL=Esp,ENCAPMODE=Tunnel;
```

//配置序号为10的IKE安全提议。

```
ADD IKEPROPOSAL:PROPOSALNUMBER=10,AUTHMETHOD=Pre_share, AUTHALGORITHM=Sha2_256,DHGROUP=Dh_group19;
```

此处“PROPOSALNUMBER”参数取值为“10”仅表示本端的一条配置记录，无实际含义，也无需与对端保持一致，该参数支持的配置范围为1~100，其中101为系统默认配置，仅支持查询。

//配置名称为a的IKE peer。

```
ADD IKEPEER:PEERNAME="a",PRESHAREDKEY="abcde",NATTRAVERSAL=TRUE,PROPOSAL=10,LOWREMOTEADDR="192.168.1.1",INVRFNAME="vrf1",OUTVRFNAME="vrf1";
```

//配置名称为map1、序号为10的IPsec安全策略。

```
ADD IPSECPOLICY:POLICYNAME="map1",SEQUENCENUMBER=10,POLICYMODE=Isakmp,TEMPLATEMODE=None,ACLNUMBER=3000;
```

//在安全策略中引用安全提议

```
ADD PROPATTACHIPSECPROPOSAL:POLICYNAME="map1",SEQUENCENUMBER=10,POLICYMODE=Isakmp,TEMPLATEMODE=None,IPSECPROPNAME="tran1";
```

//在安全策略中引用IKE Peer

```
ADD ATTACHIKEPEER:POLICYNAME="map1",SEQUENCENUMBER=10,POLICYMODE=Isakmp,TEMPLATEMODE=None,IKEPEERNAME="a",PEERPRIORITY=1;
```

//在Tunnel接口上应用安全策略map1。

```
ADD IPSECINTFCFGIPSEC:INTERFACENAME="Tunnel10",TNLTYPE=IPSEC,POLICYNAME="map1";
```

//当需要配置DPD功能。

```
SET IKEGLOBALCONFIG:DPDINTERVAL=10,DPDTYPE=Periodic,DPDRETRYINTRVL=3,NATKLI=30;
```

**Device C的配置脚本：**

//创建VNRS微服务的VPN实例。

```
ADD L3VPNINST:VRFNAME="vrf1";
```

```
ADD VPNINSTAF:VRFNAME="vrf1", AFTYPE=ipv4uni;
```

//绑定VNRS微服务与VPN实例，并配置接口IP地址。

```
MOD INTERFACE:IFNAME="Ethernet66/0/5", IFADMINSTATUS=up;
```

```
MOD INTERFACE:IFNAME="Ethernet66/0/6", IFADMINSTATUS=up;
```

```
ADD IPBINDVPN:IFNAME="Ethernet66/0/5", VRFNAME="vrf1";
```

```
ADD IPBINDVPN:IFNAME="Ethernet66/0/6", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESS:IFNAME="Ethernet66/0/5", IFIPADDR="10.1.3.1", SUBNETMASK="255.255.255.0";
```

```
ADD IFIPV4ADDRESS:IFNAME="Ethernet66/0/6", IFIPADDR="172.16.170.1", SUBNETMASK="255.255.255.0";
```

//创建VNRS微服务的IPsec隧道接口，绑定VPN并配置IP地址，隧道协议配置为IPSEC。

```
ADD INTERFACE:IFNAME="Tunnel10", IFADMINSTATUS=up;
```

```
ADD IPSECINTFCFG:INTERFACENAME="Tunnel10",TNLTYPE=IPSEC;
```

```
ADD IPBINDVPN:IFNAME="Tunnel10", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESS:IFNAME="Tunnel10", IFIPADDR="192.168.1.3", SUBNETMASK="255.255.255.255";
```

//配置到达目的网络A的静态路由，到达网络A的出接口为Tunnel10下一跳地址为192.168.1.1。假设Device C的下一跳地址为172.16.170.2/24。

```
ADD SRROUTE:VRFNAME="vrf1",AFTYPE=ipv4unicast,PREFIX="10.1.1.0",MASKLENGTH=24,DESTVRFNAME="vrf1",NEXTHOP="192.168.1.1",IFNAME="Tunnel10";
```

```
ADD SRROUTE:VRFNAME="vrf1",AFTYPE=ipv4unicast,PREFIX="192.168.1.1",MASKLENGTH=32,DESTVRFNAME="vrf1",NEXTHOP="172.16.170.2",IFNAME="Invalid0";
```

//创建IPsec微服务的VPN实例。

```
ADD L3VPNINSTIPSEC:VRFNAME="vrf1";
```

```
ADD VPNINSTAFIPSEC:VRFNAME="vrf1", AFTYPE=Ipv4uni;
```

//创建IPsec微服务的IPsec隧道接口，绑定VPN并配置IP地址。

```
ADD INTERFACEIPSEC:IFNAME="Tunnel10", IFADMINSTATUS=Up;
```

```
ADD IPBINDVPNIPSEC:IFNAME="Tunnel10", VRFNAME="vrf1";
```

```
ADD IFIPV4ADDRESSIPSEC:IFNAME="Tunnel10", IFIPADDR="192.168.1.3", SUBNETMASK="255.255.255.255";
```

//配置高级ACL 3001，允许PCA访问PCC。

```
ADD ACLGROUPIPSEC: ACLNAME="3001";
```

```
ADD ACLRULEADV4IPSEC: ACLNAME="3001",ACLRULENAME="rule_1",ACLACTION=Permit,VRFNAME="vrf1",ACLPROTOCOL=0,ACLSOURCEIP="10.1.3.2",ACLSRCWILD="0.0.0.0",ACLDESTIP="10.1.1.2",ACLDESTWILD="0.0.0.0";
```

//配置名称为tran1的IPsec安全提议。

```
ADD IPSECPROPOSALIPSEC:PROPOSALNAME="tran1",ESPAUTHALGO=Sha2_256,ESPENCRYPTALGO=Aes_256,IPSECPROTOCOL=Esp,ENCAPMODE=Tunnel;
```

//配置序号为10的IKE安全提议。

```
ADD IKEPROPOSAL:PROPOSALNUMBER=10,AUTHMETHOD=Pre_share, AUTHALGORITHM=Sha2_256,DHGROUP=Dh_group19;
```

此处“PROPOSALNUMBER”参数取值为“10”仅表示本端的一条配置记录，无实际含义，也无需与对端保持一致，该参数支持的配置范围为1~100，其中101为系统默认配置，仅支持查询。

//配置名称为a的IKE peer。

```
ADD IKEPEER:PEERNAME="a",PRESHAREDKEY="abcde",NATTRAVERSAL=TRUE,PROPOSAL=10,LOWREMOTEADDR="192.168.1.1",INVRFNAME="vrf1",OUTVRFNAME="vrf1";
```

//配置名称为map1、序号为20的IPsec安全策略

```
ADD IPSECPOLICY:POLICYNAME="map1",SEQUENCENUMBER=20,POLICYMODE=Isakmp,TEMPLATEMODE=None,ACLNUMBER=3001;
```

//在安全策略中引用安全提议

```
ADD PROPATTACHIPSECPROPOSAL:POLICYNAME="map1",SEQUENCENUMBER=20,POLICYMODE=Isakmp,TEMPLATEMODE=None,IPSECPROPNAME="tran1";
```

//在安全策略中引用IKE Peer

```
ADD ATTACHIKEPEER:POLICYNAME="map1",SEQUENCENUMBER=20,POLICYMODE=Isakmp,TEMPLATEMODE=None,IKEPEERNAME="a",PEERPRIORITY=1;
```

//在IPsec隧道接口上应用安全策略map1。

```
ADD IPSECINTFCFGIPSEC:INTERFACENAME="Tunnel10",TNLTYPE=IPSEC,POLICYNAME="map1";
```

//当需要配置DPD功能。

```
SET IKEGLOBALCONFIG:DPDINTERVAL=10,DPDTYPE=Periodic,DPDRETRYINTRVL=3,NATKLI=30;
```

版权所有 © 华为技术有限公司
