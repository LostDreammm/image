# 配置会话级累计流量策略控制

* 操作场景
* 必备事项
* 任务示例

## 操作场景

为了保证用户公平使用流量，配置基于会话级的累计流量的策略控制。

## 必备事项

前提条件

* 完成PCC相关基本功能配置。
* 完成加载License（如果有需求，请联系华为技术支持工程师处理）。

数据

**表1** UNC侧数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **（必选）**打开本特性的License配置开关。  **SET LICENSESWITCH** | License项（LICITEM） | LKV3W9PCBT12 | 固定取值 | **必选**，会话级累计流量策略控制的License项。 |
|  | 开关（SWITCH） | ENABLE | 固定取值 | **必选**，开启会话级累计流量策略控制功能。 |
| **（可选）**设置Monitoring-Key的解析方式和N7接口特性列表。  **SET PCCFUNC** | Monitoring-Key的解析方式（MKPARSEFORMAT） | UNSIGNED32 | 与对端协商 | **可选**，对PCRF下发的Monitoring-Key值的解析方式选择，PCF不适用。  该参数需要与PCRF保持一致。 |
|  | N7接口特性列表（N7FEATURELIST） | UMC | 本端规划 | **可选**，支持使用情况监视控制，最终以PCF下发的能力为准。 |
| **（可选）**使能流量监控拥塞处理（UMCH）功能。  **MOD PCRF** | PCRF主机名（HOSTNAME） | pcrf\_01 | 已配置数据中获取 | 使用**ADD PCRF**定义的PCRF主机名。 |
|  | Supported-Features动态协商开关（SUPFEANEGOSW） | ENABLE | 与对端协商 | **可选**，在进行配额重置时，为了避免Gx接口的Usage Monitoring信令拥塞，可开启UMCH功能。PCRF需要支持UMCH功能。 |
|  | Feature列表（FEATURELIST） | UMCH | 与对端协商 |  |
| **（可选）**配置将某类业务/应用的流量不统计到会话级流量。  **MOD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM ） | pccpolicygrp\_01 | 已配置数据中获取 | 使用**ADD PCCPOLICYGRP**定义的PCC策略组名称。 |
|  | Session级FUP累计标识（FUPSESSIONEXC ） | ENABLE | 本端规划 | **可选**，如果某些业务/应用的流量不统计到用户级流量中，则需要将**FUPSESSIONEXC**参数设置为“ENABLE”。 |

**表2** UDG侧数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **（必选）**打开本特性的License配置开关。  **SET LICENSESWITCH** | License项（LICITEM） | LKV3G5PCBT01 | 固定取值 | **必选**，会话级累计流量策略控制的License项。 |
|  | 开关（SWITCH） | ENABLE | 固定取值 | **必选**，开启会话级累计流量策略控制功能。 |
| **（可选）**设置用户的重定向流量是否统计到累计流量中。  ****SET SRVCOMMONPARA**** | 重定向报文FUP流量统计标识（REDIRECTFUP） | ENABLE | 本端规划 | **可选**，缺省情况下，对于用户的重定向流量，一般要求免费，并且相应的重定向流量不能统计到累计流量中。 |

## 任务示例

任务描述

本处以基于N7接口策略控制为例，采用动态规则实现会话级累计流量策略控制，PCF上配置配额和动态规则，UNC和UDG上仅需开启会话级累计流量策略控制功能，其他可选配置不配置时默认使用缺省值。

脚本

* UNC侧配置

  //打开本特性的License配置开关。

  ```
  SET LICENSESWITCH:LICITEM="LKV3W9PCBT12",SWITCH=ENABLE;
  ```

* UDG侧配置

  //打开本特性的License配置开关。

  ```
  SET LICENSESWITCH:LICITEM="LKV3G5PCBT01",SWITCH=ENABLE;
  ```

版权所有 © 华为技术有限公司
