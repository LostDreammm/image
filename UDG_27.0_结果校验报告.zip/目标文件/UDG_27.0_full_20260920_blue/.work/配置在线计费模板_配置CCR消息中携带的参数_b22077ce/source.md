# 配置CCR消息中携带的参数

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本指导描述UNC上支持配置CCR消息中是否携带某些参数的相关配置操作。

## 必备事项

前提条件

* 请仔细阅读Ga/Gy接口离线/在线计费。
* 完成加载license。
* 已完成计费属性、APN、User Profile创建。
* 已根据配置在线计费模板完成在线计费模板创建和绑定，根据配置在线计费的费率标识完成在线计费费率标识配置。

数据

如下示例参数值为举例，请根据业务实际需要进行配置。

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD DIAMDICTPATH**  **MOD DIAMDICTPATH** | 应用（APPLICATION） | GY | 与对端协商 | （可选）为Gy应用配置字典加载路径。 |
|  | 字典序号（DICTNO） | 1 |  |  |
|  | 字典加载路径（DICTPATH） | CUSTOM1 |  |  |
| **LOD DIAMDICT** | 字典文件选择（DICTFILESELECT） | ALL | 与对端协商 | 加载Diameter字典文件。  说明：  加载Diameter字典可能会导致UNC各Diameter应用对外接口消息发生改变，请在确认UNC对应目录下保存了Diameter字典文件并且对端网元支持字典中定义的消息及信元后再执行此动作。 |
| **ADD DCCTEMPLATE**  **MOD DCCTEMPLATE** | DCC模板名称（DCCTMPLTNAME） | dcc-test | 本端规划 | 新增或者修改DCC在线计费模板，用于配置在线计费CCR消息中携带的信元。  说明：  如果需要配置在线计费全局参数，则需要使用**MOD DCCTEMPLATE**命令，“DCCTMPLTNAME”参数值为“global”。 |
|  | 私有属性使能开关（PRIVATEATTR） | ENABLE | 与对端协商 | 配置CCR消息是否携带运营商的私有扩展属性。 |
|  | CCR携带费率切换点信元开关（CCRTARIFFSW） | ENABLE |  | 配置CCR消息是否携带CCA下发的费率切换时间点。 |
|  | 是否携带累加流量信息（QUOTATOTAL） | ENABLE |  | 配置Gy接口按照累加/增量方式上报计费信息。 |
|  | RAR消息RG上报方式（RARNORGACTION） | REPORT\_ALL\_RG |  | 配置由RAR触发的CCR消息中是否携带全部Rating Group的使用信息。  说明：  * REPORT\_ALL\_RG：携带全部RG的使用信息。 * REPORT\_NO\_RG：不携带RG的使用信息。 * INHERIT：表示继承DCC模板的默认值名称为global中的RARNORGACTION配置。 |
|  | MSCC携带方式（MSCCCARRYTYPE） | MULTIPLE |  | 配置CCR-U和CCR-T中MSCC的携带方式。  说明：  * MULTIPLE：表示CCR-U和CCR-T消息中可以携带多个MSCC。 * SINGLE：表示每个CCR-U消息中只携带一个MSCC，CCR-T消息中不携带MSCC。当用户去活时，会连续发送多个CCR-U消息和一个CCR-T消息给OCS。 * INHERIT：表示继承DCC模板的默认值名称为global中的MSCCCARRYTYPE配置。 |
|  | CCR消息携带3GPP specific AVPs的M标志（CCRSPESMFLAG） | DICT\_SPECIFIED |  | 配置3GPP specific AVP的m-flag是否置为1。  说明：  此参数仅在global模板中生效。参数取值如下：   * DICT\_SPECIFIED：数据字典指定M-Flag。 * SET：M-Flag设置为1。 * CLEAR：M-Flag设置为0。 * INHERIT：表示继承DCC模板的默认值名称为global中的CCRSPESMFLAG配置。 |
|  | QHT超时触发的CCR消息MSCC中是否携带RSU（QHTEXPIREDRSU） | WITHOUT\_RSU |  | 配置QHT超时触发的CCR消息MSCC中是否携带RSU信元。  说明：  此参数仅在global模板中生效。参数取值如下：   * WITH\_RSU：携带RSU。 * WITHOUT\_RSU：不携带RSU。 * INHERIT：表示继承DCC模板的默认值名称为global中的QHTEXPIREDRSU配置。 |
|  | None IP用户的PDP类型（PDPTYPE4NONIP） | REALPDPTYPE |  | 配置CCR消息中3GPP-PDP-Type AVP的取值方式。  说明：  * REALPDPTYPE：对None IP物联网用户，Gy接口CCR消息中3GPP-PDP-Type AVP取值为PGW上真正的PDP类型：IPv4(0)，PPP(1)，IPv6(2)，IPv4v6(3)。 * NONIP：对None IP物联网用户，Gy接口CCR消息中3GPP-PDP-Type AVP取值为Non-IP（4）。 * INHERIT：表示继承DCC模板的默认值名称为global中的PdpType4NonIP配置。 |

## 操作步骤

* 为Gy应用配置字典加载路径，并执行加载动作。
  1. 为Gy应用配置字典加载路径。

     **ADD DIAMDICTPATH**

     **MOD DIAMDICTPATH**
  2. 执行字典加载动作。

     加载Diameter字典可能会导致UNC各Diameter应用对外接口消息发生改变，请在确认UNC对应目录下保存了Diameter字典文件并且对端网元支持字典中定义的消息及信元后再执行此动作。

     **LOD DIAMDICT**
* 配置DCC模板中CCR消息中携带的参数。
  1. 配置CCR消息中是否携带前一个CCA消息中下发的费率切换时间点，配置参数“CCRTARIFFSW”。

     在线计费中，费率切换时间点只能由OCS下发，UNC上无法配置。此配置是用来控制当UNC检测到发生了费率切换，在后续的CCR消息中上报费率切换信息时，是否连同对应的费率切换点一并上报。

     另外，只有当CCA消息中下发的event-trigger中包含了费率切换，发生费率切换时才会触发CCR上报。
  2. 配置CCR消息中是否携带运营商私有扩展属性开关，配置参数“PRIVATEATTR”。

     只有在本命令开关使能后，下面配置的运营商私有属性才能生效。
  3. 配置Gy接口按照累加模式上报计费信息，配置参数“QUOTATOTAL”。

     默认情况下是按照增量方式上报，上述开关打开后按照累加模式上报。
  4. 配置由RAR触发的CCR消息中是否携带全部Rating Group的使用信息，参数为“RARNORGACTION”。
  5. 配置CCR消息中携带一个或多个Multiple-Service-Credit-Control(MSCC) AVP，配置参数“MSCCCARRYTYPE”。
  6. 配置CCR消息中3GPP-PDP-Type AVP的取值方式，参数为“PDPTYPE4NONIP”。

  **ADD DCCTEMPLATE**
* 配置全局DCC模板中CCR消息中携带的参数。
  1. 配置CCR消息中是否携带Requested-Service-Unit (RSU) AVP，配置参数“QHTEXPIREDRSU”。
  2. 配置CCR消息中携带的部分AVP的M标志位是否置为1，配置参数“CCRSPESMFLAG”。

     涉及的AVP包括：

     3GPP-Charging-Characteristics、3GPP-Charging-Id、3GPP-GGSN-MCC-MNC、3GPP-GPRS-Negotiated-QoS-Profile、3GPP-IMSI-MCC-MNC、3GPP-MS-TimeZone、3GPP-NSAPI、3GPP-PDP-Type、3GPP-RAT-Type、3GPP-Selection-Mode、3GPP-Session-Stop-Indicator、3GPP-SGSN-MCC-MNC、3GPP-User-Location-Info

  **MOD DCCTEMPLATE**

## 任务示例

任务描述

任务一：修改Gy应用第一套字典路径，并执行加载动作。

任务二：修改DCC模板dcc-test中的CCR消息中携带的参数。

脚本

任务一

//修改Gy应用第一套字典路径。

```
MOD DIAMDICTPATH: APPLICATION=GY,DICTNO=1,DICTPATH=CUSTOM1;
```

//执行加载动作。

```
LOD DIAMDICT:DICTFILESELECT=ALL;
```

任务二

//配置DCC template模板。

```
MODD DCCTEMPLATE:DCCTMPLTNAME="dcc-test", CCRTARIFFSW=ENABLE, PRIVATEATTR=ENABLE, QUOTATOTAL=ENABLE, RARNORGACTION=REPORT_ALL_RG, MSCCCARRYTYPE=MULTIPLE, PDPTYPE4NONIP=REALPDPTYPE;
```

版权所有 © 华为技术有限公司
