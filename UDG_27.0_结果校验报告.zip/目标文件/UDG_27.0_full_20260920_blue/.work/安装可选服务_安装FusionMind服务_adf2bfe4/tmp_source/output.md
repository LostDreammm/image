---
id: ''
name: 安装FusionMind服务
ne_type: UDG
type: feature
description: 仅当UDG网元需要提供训推管理服务、数据服务和存储服务时，才需要上线FusionMind服务。  安装FusionMind服务场景：  * **场景一****（静态上线）**：**先**实例化UDG，**然后**再参考本章节，静态上线FusionMind服务。   + 扩容VM：基于X86虚拟机（OMU\_Num、PBU\_DMS\_Num）。基于ARM虚拟机（OMU\_ARM\_Num/OMU\_C6\_Num、PBU\_DMS\_ARM\_Num）。   + 扩容Pod：“ InferMindMgr\_Instance\_Num”，“DataService\_Instance\_Num”，“Coremind\_DFS\_Service\_Instance\_Num”。    **表1** 静态上线时虚拟机与pod对应关系    | Pod | 功能说明 | 所属微服务 | 运行VM（X86） | 运行VM（ARM） |   | --- | --- | --- | --- | --- |   | infermindmgr | 提供训推管理服务。 | FusionMind | OMU | OMU\_ARM/OMU\_C6\_ARM |   | dataservice | 提供数据服务。 |  | PBU\_DMS | PBU\_DMS\_ARM |   | dfs | 提供存储服务。 |  | PBU\_DMS | PBU\_DMS\_ARM |  * **场景二****（动态上线）**：**先**实例化UDG，**然后**再参考本章节，动态上线FusionMind服务。    **表2** 动态上线时虚拟机与pod对应关系    | Pod | 功能说明 | 所属微服务 | 运行VM（X86） | 运行VM（ARM） |   | --- | --- | --- | --- | --- |   | infermindmgr | 提供训推管理服务。 | FusionMind | OMU | OMU\_ARM/OMU\_C6\_ARM |   | dataservice | 提供数据服务。 |  | PBU\_DMS | PBU\_DMS\_ARM |   | dfs | 提供存储服务。 |  | PBU\_DMS | PBU\_DMS\_ARM |
risk_level: ''
doc_source: ["网络部署","软件安装","基于NFVO安装UDG（SDN）","安装可选服务","安装FusionMind服务"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
仅当UDG网元需要提供训推管理服务、数据服务和存储服务时，才需要上线FusionMind服务。安装FusionMind服务场景：* **场景一****（静态上线）**：**先**实例化UDG，**然后**再参考本章节，静态上线FusionMind服务。  + 扩容VM：基于X86虚拟机（OMU\_Num、PBU\_DMS\_Num）。基于ARM虚拟机（OMU\_ARM\_Num/OMU\_C6\_Num、PBU\_DMS\_ARM\_Num）。  + 扩容Pod：“ InferMindMgr\_Instance\_Num”，“DataService\_Instance\_Num”，“Coremind\_DFS\_Service\_Instance\_Num”。  **表1** 静态上线时虚拟机与pod对应关系  | Pod | 功能说明 | 所属微服务 | 运行VM（X86） | 运行VM（ARM） |  | --- | --- | --- | --- | --- |  | infermindmgr | 提供训推管理服务。 | FusionMind | OMU | OMU\_ARM/OMU\_C6\_ARM |  | dataservice | 提供数据服务。 |  | PBU\_DMS | PBU\_DMS\_ARM |  | dfs | 提供存储服务。 |  | PBU\_DMS | PBU\_DMS\_ARM |* **场景二****（动态上线）**：**先**实例化UDG，**然后**再参考本章节，动态上线FusionMind服务。  **表2** 动态上线时虚拟机与pod对应关系  | Pod | 功能说明 | 所属微服务 | 运行VM（X86） | 运行VM（ARM） |  | --- | --- | --- | --- | --- |  | infermindmgr | 提供训推管理服务。 | FusionMind | OMU | OMU\_ARM/OMU\_C6\_ARM |  | dataservice | 提供数据服务。 |  | PBU\_DMS | PBU\_DMS\_ARM |  | dfs | 提供存储服务。 |  | PBU\_DMS | PBU\_DMS\_ARM |

## 必备事项
前提条件

* 已经实例化UDG。已经安装后检查，UDG正常工作。
* 已登录UDG OM Portal。
* 依赖的特性软件包（即服务镜像文件）：X86为UDG\_xx.x.x\_DockerCoreMind\_X86.zip，ARM为UDG\_xx.x.x\_DockerCoreMind\_ARM.zip如果在安装UDG时没有上传本软件包，则需要在上线FusionMind服务前前上传软件包，否则无需再次上传。
* 已经完成检查软件包完整性。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 动态上线本服务前，必须根据客户的业务容量和设备现状进行严格的**扩容评估**。

### 确保上线服务所需的I层资源、License资源、各类网络资源（如外联口网络）是充足的，如果不充足，则要**先扩容这些资源**，然后**再上线本服务**。

### 由华为网设工程师进行网络设计，规划计算资源、存储资源、网络资源。

### 将规划数据合入《NFV LLD文档》，作为后续操作的输入。

#### 1.1 **计算资源**：承载虚拟机的主机（服务器）、主机组、虚拟机名称、虚拟机个数、容器名称、容器个数。

#### 1.2 **存储资源**：承载本服务的磁盘空间。

#### 1.3 **网络资源**：承载虚拟机的网络。承载容器的网络。承载业务的物理网口、业务网络。例如虚拟机的Base网络、容器Base网络、外联口网络、外联口Subport。

### 2 参考《UDG中心侧扩缩容指导书(基于LCM)》或《UDG中心侧扩缩容指导书(基于NFVO)》，完成扩容操作，扩容出计算资源、存储资源、网络资源、VM和POD。上线可选服务时可只扩容VM，无需扩容POD。可选服务所用VM可参见扩容指导书内非基础业务扩容规格确定章节**。**

### 由华为工程师登录华为Support网站，在技术支持>知识库>云核心网>Mobile Packet Core>5G Packet Core>UDG>技术指导，中搜索《UDG中心侧扩缩容指导书(基于LCM)》或《UDG中心侧扩缩容指导书(基于NFVO)》。

### 非SDN组网模式下使用《UDG中心侧扩缩容指导书(基于LCM)》，SDN组网模式请使用《UDG中心侧扩缩容指导书(基于NFVO)》。

### 3 检查**软件包**，确保已经上传依赖的软件包。

### 登录MAE-VNF LCM，单击“包管理 > VNFD > 单击VNFD模板，查看VNFD模板详情 > 依赖的服务镜像”。

#### 3.1 若“UDG\_xx.x.x\_DockerCoreMind\_X86.zip”“UDG\_xx.x.x\_DockerCoreMind\_ARM.zip”的状态为“已经存在”，说明已经上传软件包，则跳过上传服务镜像，执行后续步骤。

#### 3.2 若软件包的状态为“等待上传”，则需要执行上传服务镜像。

### 4 **上传服务镜像文件**。

### 如果执行LST ME命令查询的架构模式为X86，且LCM上提示ARM的包为必选时，可以忽略“是否必需上传”的提示，无需上传ARM后缀的依赖的服务镜像。

#### 4.1 在“依赖的服务镜像”区域，单击“上传”，弹出“上传服务镜像”窗口。

#### 4.2 在“单包”页面，单击“选择文件”，选择依赖的服务镜像包和对应的cms文件。

#### 4.3 单击“完成”。

#### 4.4 上传完成后，“状态”均显示为“已经存在”。上传时长依赖于现场网络情况。

#### 4.5 边缘场景（已安装agent的场景下）上传镜像后需要同步镜像包到边缘站点。

##### 4.5.1 在“VNFD”窗口中，**选择已导入的VNFD**。

##### 4.5.2 单击图标。

##### 4.5.3 在“边缘站点列表”区域中选择目标站点。

##### 4.5.4 单击“确定”。

#### **图2** 同步文件到边缘站点

### 5 参考《UDG边缘侧扩缩容指导书（扩容单板）》，扩容步骤 1中规划的所需容器POD（请参见动态上线时虚拟机与pod对应关系）及容器POD个数。

