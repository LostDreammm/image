# 配置RADIUS功能

* 操作场景
* 必备事项
* 任务示例

## 操作场景

该任务旨在指导操作人员完成SMF与AAA(RADIUS Server)的对接配置和功能配置。

## 必备事项

前提条件

* 已完成SMF基础配置。
* 已完成一跳入家要求的移动VPN相关配置。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD L3VPNINST** | VPN实例名称 (VRFNAME) | vpn\_aaa | 全局规划 | - |
| ****ADD VPNINSTAF**** | VPN实例名称 (VRFNAME) | vpn\_aaa | 已配置数据中获取 | 已通过**ADD L3VPNINST**命令进行配置，可以使用**LST L3VPNINST**进行查询。 |
|  | 地址族类型 (AFTYPE) | ipv4uni | 全局规划 | - |
|  | 实例的标签分配模式 (VRFLABELMODE) | perRoute | 全局规划 | - |
| **ADD VPNINST** | VPN实例名（VPNINSTANCE） | vpn\_aaa | 全局规划 | - |
| **ADD LOGICIP** | IP地址类型（IPVERSION） | IPv4 | 全局规划 | 逻辑接口使用的逻辑IP。 |
|  | IPv4地址（LOGICIPV4） | 10.8.20.1 | 全局规划 |  |
|  | VPN实例名称（VPNINSTNAME） | vpn\_aaa | 已配置数据中获取 | 已通过**ADD L3VPNINST**命令进行配置，可以使用**LST L3VPNINST**进行查询。 |
| ****ADD LOGICINF**** | 逻辑接口名称（NAME） | giif1/0/0 | 本端规划 | 配置使用的逻辑接口。 |
|  | 逻辑接口的IP版本（IPVERSION） | IPV4 | 全局规划 |  |
|  | 逻辑接口的IPv4地址1（IPV4ADDRESS1） | 10.8.20.1 | 全局规划 |  |
|  | 逻辑接口的IPv4掩码1（IPV4MASK1） | 255.255.255.255 | 全局规划 |  |
|  | VPN实例名称（VPNINSTANCE） | vpn\_aaa | 已配置数据中获取 | AAA服务器所属的VPN实例名。已通过**ADD VPNINST**配置，可以使用**LST VPNINST**命令进行查询。 |
| ****ADD RDSSVRGRP**** | Radius Server Group名称（RDSSVRGRPNAME） | radius\_001 | 本端规划 | 配置RADIUS服务器组。 |
|  | 模式（MODE） | MASTER\_SLAVE | 本端规划 | - |
|  | 利用鉴权服务器计费（ACCTTOAUTH） | DISABLE | 本端规划 | 指定RADIUS服务器组不支持计费。 |
|  | 支持可选计费消息（SIGOPTACCTMSG） | DISABLE | 本端规划 | 指定RADIUS服务器组不支持可选计费消息。 |
| ****ADD RDSSVR**** | Radius Server Group名称（RDSSVRGRPNAME） | radius\_001 | 已配置数据中获取 | 与AAA鉴权服务器的IP地址保持一致。 |
|  | 服务器类型（SERVERTYPE） | AUTHENTICATION | 本端规划 | - |
|  | 服务器IP版本（IPVERSION） | IPV4 | 全局规划 | 鉴权AAA服务器IP地址、端口号、密钥。 |
|  | IPv4地址（SERVERIPV4） | 10.168.10.1 | 全局规划 |  |
|  | 端口（PORT） | 1812 | 与对端协商 |  |
|  | 服务器密钥（加密的）（CIPHERKEY） | aaa@12#$ | 与对端协商 |  |
|  | VPN实例（VPNINSTANCE） | vpn\_aaa | 已配置数据中获取 | 已通过**ADD L3VPNINST**命令进行配置，可以使用**LST L3VPNINST**进行查询。 |
|  | 主备用类型（PRIFLAG） | PRIMARY | 全局规划 | - |
|  | 确认服务器密钥（加密的）（CIPHERKEYCNFM） | aaa@12#$ | 与对端协商 | - |
| **ADD RADIUSCLIENTIP** | Radius Server Group名称（RDSSVRGRPNAME） | radius\_001 | 已配置数据中获取 | 配置Gi接口鉴权。 |
|  | 鉴权或计费（AUTHORACCT） | AUTHENTICATION | 固定取值 |  |
|  | 接口名称（INTFNAME） | giif1/0/0 | 已配置数据中获取 |  |
| **ADD APNRDSCLIENTIP** | APN名称（APN） | home.dnn | 已配置数据中获取 | 可选配置。  配置APN级Gi接口鉴权。如果APN无特别规划，通过**ADD RADIUSCLIENTIP**配置即可。 |
|  | 鉴权或计费（AUTHORACCT） | AUTHENTICATION | 固定取值 |  |
|  | 接口名称（INTFNAME） | giif1/0/0 | 已配置数据中获取 |  |
| **SET APNAUTHATTR** | APN名称（APN） | home.dnn | 已配置数据中获取 | 配置对接RADIUS场景时的鉴权能力。 |
|  | 接入模式（ACCESSMODE） | NON\_TRANS | 固定取值 |  |
|  | 鉴权模式（AUTHMODE） | MSISDN | 固定取值 |  |
|  | 鉴权密码（PASSWORD） | Pwd001 | 全局规划 |  |
|  | 确认鉴权密码（CFMPASSWORD） | Pwd001 | 全局规划 |  |
|  | 公用用户名（COMMONUSERNAME） | admin | 全局规划 |  |
|  | 公用密码（COMMONUSERPASS） | Huawei12#$ | 全局规划 |  |
|  | 确认公共密码（CFMCOMMUSERPASS） | Huawei12#$ | 全局规划 |  |
| **ADD APNRDSSVRGRP** | APN名称（APN） | home.dnn | 已配置数据中获取 | APN绑定RADIUS服务器组。 |
|  | Radius Server Group名称（RDSSVRGRPNAME） | radius\_001 | 已配置数据中获取 |  |
| **SET RDSAUTHREQATTR** | RADIUS服务器组名称（RDSSVRGRPNAME） | radius\_001 | 已配置数据中获取 | 设置鉴权请求携带的属性，实际能力需与对端AAA服务器协商。 |
|  | Acct-Session-Id（ACCTSESSIONID） | ENABLE | 全局规划 |  |
|  | NAS-ID（NASID） | ENABLE | 全局规划 |  |
| **SET RDSAUTHREQVSA** | RADIUS服务器组名称（RDSSVRGRPNAME） | radius\_001 | 已配置数据中获取 | 配置鉴权请求携带的私有扩展属性，实际能力需与对端AAA服务器协商。 |
|  | 3GPP私有扩展属性开关（THREEGPP） | ENABLE | 全局规划 |  |
|  | 3GPP-IMSI（IMSI） | ENABLE | 全局规划 |  |

## 任务示例

任务描述

完成专网SMF对接RADIUS以及打开RADIUS功能。

脚本

//创建L3VPN实例。

```
ADD L3VPNINST:VRFNAME="vpn_aaa";
```

```
ADD VPNINSTAF: VRFNAME="vpn_aaa", AFTYPE=ipv4uni, VRFLABELMODE=perRoute;
```

//创建VPN实例。

```
ADD VPNINST: VPNINSTANCE ="vpn_aaa";
```

//配置Gi接口。

```
ADD LOGICIP: IPVERSION=IPv4, LOGICIPV4="10.8.20.1", VPNINSTNAME="vpn_aaa";
ADD LOGICINF:NAME="giif1/0/0",IPVERSION=IPV4,IPV4ADDRESS1="10.8.20.1",IPV4MASK1="255.255.255.255",VPNINSTANCE="vpn_aaa";
```

//配置RADIUS服务器组和RADIUS服务器。

```
ADD RDSSVRGRP: RDSSVRGRPNAME="radius_001", MODE=MASTER_SLAVE, ACCTTOAUTH=DISABLE, SIGOPTACCTMSG=DISABLE, ACCTTIMEOUT=10, ACCTRETRANSMIT=5;
```

```
ADD RDSSVR: RDSSVRGRPNAME="radius_001", SERVERTYPE=AUTHENTICATION, IPVERSION=IPV4, SERVERIPV4="10.168.10.1", PORT=1812, VPNINSTANCE="vpn_aaa", CIPHERKEY="*****", CONGESTION=DISABLE, PRIFLAG=PRIMARY, WALVALUE=0, CIPHERKEYCNFM="*****";
```

//配置Gi接口鉴权。

```
ADD RADIUSCLIENTIP: RDSSVRGRPNAME="radius_001", AUTHORACCT=AUTHENTICATION, INTFNAME="giif1/0/0";
```

//配置APN级Gi接口鉴权。如果APN无特别规划，通过**ADD RADIUSCLIENTIP**配置即可。

```
ADD APNRDSCLIENTIP: APN="home.dnn", AUTHORACCT=AUTHENTICATION, INTFNAME="giif1/0/0";
```

//配置对接RADIUS场景时的鉴权能力。

```
SET APNAUTHATTR: APN="home.dnn", ACCESSMODE=NON_TRANS, AUTHMODE=MSISDN, PASSWORD="Pwd001", CFMPASSWORD="Pwd001", COMMONUSERNAME="admin", COMMONUSERPASS="Huawei12#$", CFMCOMMUSERPASS="Huawei12#$";
```

//配置APN绑定RADIUS服务器组。

```
ADD APNRDSSVRGRP:APN="home.dnn", RDSSVRGRPNAME="radius_001";
```

//配置鉴权请求携带的属性。脚本仅为示例，实际能力需与对端AAA服务器协商。

```
SET RDSAUTHREQATTR: RDSSVRGRPNAME="radius_001", ACCTSESSIONID=ENABLE, NASID=ENABLE, NASIDTYPE=APN, IMSI=DISABLE, CHARGINGID=DISABLE, PREPAIDIND=DISABLE, GGSNIP=ENABLE, SGSNIP=ENABLE, REQUESTAPN=DISABLE, GGSNVENDOR=ENABLE, GGSNVERION=ENABLE, RQAUTHTICATOR=DISABLE, ACCTMULSESSID=ENABLE, EVENTTIME=ENABLE, NASPORTIDSW=ENABLE, NASPORTID="UNC", WLANADDR=DISABLE;
```

//配置鉴权请求携带的私有扩展属性。脚本仅为示例，实际能力需与对端AAA服务器协商。

```
SET RDSAUTHREQVSA:RDSSVRGRPNAME="radius_001", THREEGPP=ENABLE, IMSI=ENABLE, CHARGINGID=ENABLE, PDPTYPE=ENABLE, CGADDRESS=ENABLE, NEGOTIAEDQOS=ENABLE, SGSNSGWADDRESS=ENABLE, GGSNADDRESS=ENABLE, IMSIMCCMNC=ENABLE, GGSNMCCMNC=ENABLE, NSAPI=ENABLE, SELECTIONMODE=ENABLE, CHARGINGCHAR=ENABLE, SGSNSGWMCCMNC=ENABLE, IMEISV=ENABLE, RATTYPE=ENABLE, ULI=ENABLE, MSTIMEZONE=ENABLE, NEGOTIAEDDSCP=ENABLE, SGSNIPV6ADDRESS=ENABLE, GGSNIPV6ADDRESS=ENABLE, CGIPV6ADDRESS=ENABLE;
```

版权所有 © 华为技术有限公司
