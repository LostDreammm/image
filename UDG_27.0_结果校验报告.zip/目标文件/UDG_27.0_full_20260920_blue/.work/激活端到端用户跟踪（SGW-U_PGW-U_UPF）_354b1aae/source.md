# 激活端到端用户跟踪（SGW-U/PGW-U/UPF）

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本操作指导介绍在运行网络中激活端到端用户跟踪的操作过程。

适用于SGW-U、PGW-U、UPF。

## 必备事项

前提条件

完成加载License。

数据

该操作无需准备数据。

## 操作步骤

1. 打开本功能的License配置开关。

   **SET LICENSESWITCH**

## 任务示例

任务描述

开启端到端用户跟踪特性。

脚本

//打开License配置开关。

```
SET LICENSESWITCH: LICITEM="LKV3G5E2ET01", SWITCH=ENABLE;
```

版权所有 © 华为技术有限公司
