# 激活IPv4v6双栈接入（适用于SGW-U/PGW-U/UPF）

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

* 移动用户进行业务时必须获取终端IP地址。
* 分组业务开展必备项。

适用于SGW-U、PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-020403 IPv4v6双栈接入（适用于SGW-U/PGW-U/UPF）。
* 已参考初始配置的组网路由配置完成IPv4v6组网相关配置。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET LICENSESWITCH** | License项（LICITEM） | LKV3G5VDSA01 | 固定取值 | - |
|  | 开关（SWITCH） | ENABLE | 固定取值 | - |
| **ADD APN** | APN名称(APN) | apn-test | 本端规划 | - |
|  | 绑定VPN(HASVPN) | ENABLE | 本端规划 | - |
|  | VPN实例名(VPNINSTANCE) | VRF\_Internet | 已配置数据中获取 | 可以使用**LST VPNINST**命令进行查询。 |
|  | 绑定IPv6 VPN(HASVPNIPV6) | ENABLE | 本端规划 | - |
|  | IPv6 VPN实例名(VPNINSTANCEIPV6) | VRF\_Internet | 已配置数据中获取 | 可以使用**LST VPNINST**命令进行查询。 |
| **ADD POOLGROUP** | 地址池组名称（POOLGRPNAME） | poolgroup1 | 本端规划 | - |
| **ADD POOL** | 地址池名称（POOLNAME） | testpool  testpoolv6 | 本端规划 | - |
|  | 地址池类型（POOLTYPE） | LOCAL | 全网规划 | 取值为LOCAL时，表示本地地址池分配地址。 |
|  | 绑定VPN（HASVPN） | ENABLE | 本端规划 | - |
|  | VPN实例名（VPNINSTANCE） | VRF\_Internet | 已配置数据中获取 | 可以使用**LST VPNINST**命令进行查询。 |
| **ADD SECTION** | 地址池名称（POOLNAME） | testpool | 本端规划 | 可以使用**LST POOL**命令进行查询。 |
|  | 地址段号（SECTIONNUM） | 1 | 本端规划 | - |
|  | IP地址类型（IPVERSION） | IPV4 | 本端规划 | - |
|  | 地址段的起始IPv4地址（V4STARTIP） | 10.0.0.0 | 全网规划 | - |
|  | 地址段的终止IPv4地址（V4ENDIP） | 10.0.127.255 | 全网规划 | - |
| **ADD SECTION** | 地址池名称（POOLNAME） | testpoolv6 | 本端规划 | 可以使用**LST POOL**命令进行查询。 |
|  | 地址段号（SECTIONNUM） | 1 | 本端规划 | - |
|  | IP地址类型（IPVERSION） | IPV6 | 本端规划 | - |
|  | IPv6前缀起始地址（V6PREFIXSTART） | fc00:0000:0000:fcee:0000:0000:0000:0000 | 全网规划 | 本地地址池支持IPv4和IPv6类型，如果规划UE IPv4v6双栈地址，则需要配置两种类型的地址池。 |
|  | IPv6前缀结束地址（V6PREFIXEND） | fc00:0000:0000:fcef:ffff:ffff:ffff:ffff | 全网规划 | - |
|  | IPv6前缀长度（V6PREFIXLENGTH） | 64 | 全网规划 | 前缀长度范围为49~64，当前缀长度小于64时，则表示该地址池采用IPv6 Prefix Delegation方式分配。 |
| **ADD POOLBINDGROUP** | 地址池组名称(POOLGROUPNAME) | poolgroup1 | 本端规划 | 可以使用**LST POOLBINDGROUP**命令进行查询。 |
|  | 地址池名称(POOLNAME) | testpool  testpoolv6 | 本端规划 | 可以使用**LST POOL**命令进行查询。 |
| **ADD POOLGRPMAP** | 映射规则名称(MAPPINGNAME) | mapping1 | 本端规划 | - |
|  | APN名称(APN) | apn-test | 本端规划 | 可以使用**LST APN**命令进行查询。 |
|  | 地址池组名称(POOLGROUPNAME) | poolgroup1 | 本端规划 | 可以使用**LST POOLBINDGROUP**命令进行查询。 |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**
2. **可选：**配置APN及地址分配功能。
   1. 配置APN名称。

      **ADD APN**
   2. 配置地址池组。

      **ADD POOLGROUP**
   3. 配置IPv4及IPv6的地址池。

      **ADD POOL**
   4. 配置IPv4及IPv6的地址池里的地址段。

      **ADD SECTION**
   5. 将IPv4及IPv6的地址池绑定到地址池组。

      **ADD POOLBINDGROUP**
   6. 配置地址池组与APN的映射关系。

      **ADD POOLGRPMAP**

## 任务示例

任务描述

配置APN下的地址分配方式为本地地址池分配IPv4v6地址。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5VDSA01",SWITCH=ENABLE;
```

//配置APN名称。

```
ADD APN:APN="apn-test", HASVPN=ENABLE, VPNINSTANCE="VRF_Internet", HASVPNIPV6=ENABLE, VPNINSTANCEIPV6="VRF_Internet";
```

//配置地址池绑定到地址池组。

```
ADD POOLGROUP: POOLGRPNAME="poolgroup1", IPV4ALLOCPRIALG=ENABLE, IPV6ALLOCPRIALG=ENABLE;
ADD POOL:POOLNAME="testpool",POOLTYPE=LOCAL,IPVERSION=IPV4, HASVPN=ENABLE,VPNINSTANCE="VRF_Internet";
ADD POOL:POOLNAME="testpoolv6",POOLTYPE=LOCAL,IPVERSION=IPV6, HASVPN=ENABLE,VPNINSTANCE="VRF_Internet";
ADD SECTION:POOLNAME="testpool", SECTIONNUM=1, IPVERSION=IPV4, V4STARTIP="10.0.0.0", V4ENDIP="10.0.127.255";
ADD SECTION:POOLNAME="testpoolv6", SECTIONNUM=1, IPVERSION=IPV6, V6PREFIXSTART="fc00:0000:0000:fcee:0000:0000:0000:0000", V6PREFIXEND="fc00:0000:0000:fcef:ffff:ffff:ffff:ffff", V6PREFIXLENGTH=64;
ADD POOLBINDGROUP: POOLGROUPNAME="poolgroup1", POOLNAME="testpool", PRIORITY=10;
ADD POOLBINDGROUP: POOLGROUPNAME="poolgroup1", POOLNAME="testpoolv6", PRIORITY=10;
```

//配置APN与地址池组的映射关系。

```
ADD POOLGRPMAP:MAPPINGNAME="mapping1", APN="apn-test", POOLGROUPNAME="poolgroup1";
```

版权所有 © 华为技术有限公司
