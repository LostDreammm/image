# 配置Rule

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在UDG上配置业务控制规则，UDG按照规则对报文进行过滤，当报文命中规则时，采取规则上配置的策略，最终实现业务解析和业务控制。

适用于SGW-U、PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读业务感知功能描述。
* 完成加载license（如果有需求，请联系华为技术支持工程师处理）。
* 完成配置流过滤条件和配置流动作。
* 使用的流过滤器与策略已在之前完成配置。

数据

**图1** 规则配置关系图

以如下三个场景为例，对规则进行配置：

场景1——配置PCC规则

场景2——配置IP重定向规则

场景3——配置BWM规则和黑名单规则

**表1** 场景1数据规划表

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RULE** | 规则名称（RULENAME） | rule\_1 | 本端规划 | - |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 |  |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 |  |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_1 | 已配置数据中获取 | 业务规则绑定的FlowFilter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略名称（POLICYNAME） | pccpolicygrp\_1 | 已配置数据中获取 | 业务规则绑定的PCC策略组已通过**ADD PCCACTIONPROP**命令配置。 |

**表2** 场景2数据规划表

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RULE** | 规则名称（RULENAME） | rule\_2 | 本端规划 | - |
|  | 策略类型（POLICYTYPE） | IPREDIR | 本端规划 |  |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTERGRP | 本端规划 |  |
|  | 流过滤器组名称（FLWFLTRGRPNAME） | flowfiltergroup\_2 | 已配置数据中获取 | 业务规则绑定的FLOWFILTERGRP已通过**ADD FLOWFILTERGRP**命令配置。 |
|  | IP重定向虚拟IP协议版本（REDIRIPVERFLAG） | IPV4 | 本端规划 | - |
|  | IP重定向IP地址（IPREDIRECTIP） | 10.11.12.13 | 本端规划 | 重定向的目标IP地址。 |

**表3** 场景3数据规划表

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RULE** | 规则名称（RULENAME） | rule\_3 | 本端规划 | - |
|  | 策略类型（POLICYTYPE） | BWM | 本端规划 |  |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 |  |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_3a | 已配置数据中获取 | 业务规则绑定的FlowFilter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略名称（POLICYNAME） | catprop\_3 | 已配置数据中获取 | 业务规则绑定的PCC策略组已通过**ADD CATEGORYPROP**命令配置，并与带宽管理业务绑定。 |
| **ADD BLACKLISTRULE** | 规则名称（RULENAME） | rule\_blacklistrule | 本端规划 | - |
|  | 策略类型（POLICYTYPE） | BWM | 本端规划 |  |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 |  |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_3b | 已配置数据中获取 | 黑名单规则使用到的FlowFilter已通过**ADD FLOWFILTER**命令配置。 |
|  | 全局优先级（PRIORITY） | 1000 | 本端规划 | - |

## 操作步骤

1. 配置规则，并绑定过滤条件与策略。

   **ADD RULE**

   * 同种策略类型的规则不允许同名，不同策略类型的规则允许同名。每增加一条策略不同名称相同的Rule会占用系统的一条规格。
   * 支持规则多次匹配功能。
   * Rule的优先级范围是1～65535，数值越小优先级越高，优先级仅在同种策略类型的规则内生效，不同策略类型的规则之间的优先级是独立的。配置多条Rule时，其优先级数值间隔尽量预留空间，以方便后续增加介于中间优先级的Rule。
2. **可选：**配置黑名单规则。

   **ADD BLACKLISTRULE**

   * 黑名单规则的作用：当报文命中规则后，如果同时命中同种策略类型的黑名单规则，则报文命中的规则不会生效。黑名单规则的配置原则、匹配原则与规则是一致的。
   * PCC类型的规则不支持黑名单规则。
   * 当策略类型为IPREDIR或SRV\_TRIGGER时，不允许在黑名单规则中，配置绑定了七层协议和协议组的流过滤器，或绑定了这类流过滤器的流过滤器组。

## 任务示例

任务描述

以“数据”中的三个场景为例，在UDG上完成绑定规则：

场景1——配置PCC规则：将过滤条件与策略绑定到规则。

场景2——配置IP重定向规则：将过滤条件绑定到规则，并让报文命中规则时重定向到10.11.12.13。

场景3——配置BWM规则和黑名单规则：将过滤条件与策略绑定到规则，并规定当报文命中黑名单时该规则不会生效，其他情况规则正常生效。

脚本

**//场景1：**

//绑定PCC规则。

```
ADD RULE:RULENAME="rule_1",POLICYTYPE=PCC,FILTERINGMODE=FLOWFILTER,FLOWFILTERNAME="flowfilter_1",POLICYNAME="pccpolicygrp_1";
```

**//场景2：**

//绑定IP重定向规则，并设置IP重定向。

```
ADD RULE:RULENAME="rule_2",POLICYTYPE=IPREDIR,FILTERINGMODE=FLOWFILTERGRP,FLWFLTRGRPNAME="flowfiltergroup_2",REDIRIPVERFLAG=IPV4,IPREDIRECTIP=10.11.12.13;
```

**//场景3****：**

//绑定带宽控制规则。

```
ADD RULE:RULENAME="rule_3",POLICYTYPE=BWM,FILTERINGMODE=FLOWFILTER,FLOWFILTERNAME="flowfilter_3a",POLICYNAME="catprop_3";
```

//绑定黑名单规则。

```
ADD BLACKLISTRULE:RULENAME="rule_blackrule",POLICYTYPE=BWM,FILTERINGMODE=FLOWFILTER,FLOWFILTERNAME="flowfilter_3b",PRIORITY=1000;
```

版权所有 © 华为技术有限公司
