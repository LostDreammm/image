---
id: ''
name: 安装ICAPC服务
ne_type: UDG
type: feature
description: 安装ICAPC服务场景：  * **场景一****（静态上线）**：ICAPC服务和UDG网元**同时实例化**。实例化UDG前填写如下VNFD参数。   + 配置VM：基于X86虚拟机（PBU\_E-S\_Num，PBU\_E-S Redundancy Num）。基于ARM虚拟机(PBU\_E-S\_ARM\_Num，PBU\_E-S\_ARM Redundancy Num)。   + 配置Pod：“ICAPCCTRL\_Instance\_Num”，“ICAPC\_Instance\_Num”，“ICAPC\_ARM\_Instance\_Num”。 * **场景二****（动态上线）**：**先**实例化UDG，**然后**再参考本章节，动态上线ICAPC服务。
risk_level: ''
doc_source: ["网络部署","软件安装","基于VNF LCM安装UDG（非SDN）","安装可选服务","安装ICAPC服务"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
安装ICAPC服务场景：* **场景一****（静态上线）**：ICAPC服务和UDG网元**同时实例化**。实例化UDG前填写如下VNFD参数。  + 配置VM：基于X86虚拟机（PBU\_E-S\_Num，PBU\_E-S Redundancy Num）。基于ARM虚拟机(PBU\_E-S\_ARM\_Num，PBU\_E-S\_ARM Redundancy Num)。  + 配置Pod：“ICAPCCTRL\_Instance\_Num”，“ICAPC\_Instance\_Num”，“ICAPC\_ARM\_Instance\_Num”。* **场景二****（动态上线）**：**先**实例化UDG，**然后**再参考本章节，动态上线ICAPC服务。

## 必备事项
前提条件

* 已经实例化UDG。已经安装后检查，UDG正常工作。
* ICAPC服务依赖的软件包为UDG\_xx.x.x\_DockerUdg\_X86.zip或UDG\_xx.x.x\_DockerUdg\_ARM.zip。在安装UDG时已经上传本软件包，因此无需再次上传软件包。
* 已经完成检查软件包完整性。

* 当系统进行动态上下线操作期间，不允许再同时进行扩缩容操作。同理，当系统进行扩缩容期间，不允许再进行动态上下线操作。
* 上下线本服务时，不能同时上下线其他部件。
* 当动态上线一个服务的任务失败；必须先动态下线此服务，再重新触发动态上线任务。如果是动态下线失败，只能继续重新触发动态下线任务。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    opr_featureenable_list:
      type: items
      properties:
        PODINSTANCENUM:
          name: 'Pod实例个数列表'
          type: string
          minLength: 0
          maxLength: 1024
          required: true
          description: ''
          data_source: '本端规划'
          pattern: ''
          default: ''
        FUNCTIONSETNAME:
          name: '网络功能集名称'
          type: string
          minLength: 0
          maxLength: 1024
          required: false
          description: ''
          data_source: '固定取值'
          pattern: ''
          default: ''
        EXTENDEDATTR:
          name: '扩展属性'
          type: string
          minLength: 0
          maxLength: 1024
          required: false
          description: ''
          data_source: '固定取值'
          pattern: ''
          default: ''
  examples:
  - opr_featureenable_list:
    - PODINSTANCENUM: 'icapc-pod:2/icapcctrl-pod:2'
      FUNCTIONSETNAME: 'ICAPC'
      EXTENDEDATTR: '保持空白，无需填写。'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 动态上线本服务前，必须根据客户的业务容量和设备现状进行严格的**扩容评估**。

### 确保上线服务所需的I层资源、License资源、各类网络资源（如外联口网络）是充足的，如果不充足，则要**先扩容这些资源**，然后**再上线本服务**。

### 由华为网设工程师进行网络设计，规划计算资源、存储资源、网络资源。

### 将规划数据合入《NFV LLD文档》，作为后续操作的输入。

### **计算资源**：承载虚拟机的主机（服务器）、主机组、虚拟机名称、虚拟机个数、容器名称、容器个数。

### **存储资源**：承载本服务的磁盘空间。

### **网络资源**：承载虚拟机的网络。承载容器的网络。承载业务的物理网口、业务网络。例如虚拟机的Base网络、容器Base网络、外联口网络、外联口Subport。

### 2 参考《UDG中心侧扩缩容指导书(基于LCM)》或《UDG中心侧扩缩容指导书(基于NFVO)》，完成扩容操作，扩容出计算资源、存储资源、网络资源、VM和POD。上线可选服务时可只扩容VM，无需扩容POD。可选服务所用VM可参见扩容指导书内非基础业务扩容规格确定章节**。**

### 由华为工程师登录华为Support网站，在技术支持>知识库>云核心网>Mobile Packet Core>5G Packet Core>UDG>技术指导，中搜索《UDG中心侧扩缩容指导书(基于LCM)》或《UDG中心侧扩缩容指导书(基于NFVO)》。

### 非SDN组网模式下使用《UDG中心侧扩缩容指导书(基于LCM)》，SDN组网模式请使用《UDG中心侧扩缩容指导书(基于NFVO)》。

### 3 登录UDG OM Portal。

### 4 执行命令，动态上线ICAPC Pod。

```jinja2
{%- for item in opr_featureenable_list -%}
    OPR FEATUREENABLE:
    {#- --- 必选参数 --- -#}
    PODINSTANCENUM="{{item.PODINSTANCENUM}}",
    {#- --- 可选参数 --- -#}
    {%- if item.FUNCTIONSETNAME is not none -%}
        FUNCTIONSETNAME="{{item.FUNCTIONSETNAME}}",
    {%- endif -%}
    {%- if item.EXTENDEDATTR is not none -%}
        EXTENDEDATTR="{{item.EXTENDEDATTR}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 无需配置“EXTENDEDATTR(扩展属性)”参数，参数“FUNCTIONSETNAME”填写为“ICAPC”。

### 5 执行命令，确认已经成功实例化ICAPC Pod。

### 回显为“处理结果=处理成功”。

### 回显pod个数和规划一致，且“Pod状态”为“Running”。

### 6 执行命令，查询进程的状态。

### 预期结果：“未就绪进程数”和“故障进程数”均为0。

