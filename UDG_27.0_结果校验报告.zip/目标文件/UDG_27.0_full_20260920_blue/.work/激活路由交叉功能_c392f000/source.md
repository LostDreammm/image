# 激活路由交叉功能

* 操作场景
* 必备事项
* 操作流程
* 操作步骤

## 操作场景

UE激活后，能正常访问网络A中的服务器。另一网络B和网络A之间网络隔离，UE还需访问网络B中的指定服务器（服务器IP需固定，此处IP地址以10.8.8.8为例）。

该场景下，网络A和网络B是两个不同的VPN网络，需通过路由交叉功能，实现UE激活后，既能访问网络A中的服务器，又能访问网络B中的定制服务器。

组网示意如图1所示。

**图1** 路由交叉应用场景示意

## 必备事项

前提条件

* 请仔细阅读GWFD-020423 支持路由交叉功能特性概述。
* 已完成UE访问网络A中的服务器的相关配置。

数据

**如下数据仅为举例，请注意修改成局点规划的数据。**

* 表1中，是UDG与网络B互通的接口IP&路由数据。
* 表2中，是跨VPN转发上行报文的静态路由配置。
* 表3中，是将UE下行路由引入到VRF\_networkB路由表的相关配置。

**表1** UDG与网络B互通的接口IP&路由数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD L3VPNINST** | VPN实例名称（VRFNAME） | VRF\_networkB | 全网规划 | VPN实例全网统一规划，一条通信路径上所有节点绑定的VPN实例要一致，才能正常通信。 |
|  | 地址族类型(AFTYPE) | ipv4uni | 本端规划 | 此处以IPv4为例。  请根据实际业务IP类型，规划ipv4uni、ipv6uni或ipv4uni&ipv6uni的L3VPN实例地址族。 |
| **ADD VPNINSTAF** | VPN实例名称（VRFNAME） | VRF\_networkB | 全网规划 | 复用**ADD L3VPNINST**命令中定义的值。 |
|  | 地址族名称(AFTYPE) | ipv4uni | 本端规划 | - |
| **ADD AUTOSCALINGSERVICE** | 服务名称（SERVICENAME） | ServName\_networkB | 本端规划 | 如果规划外联口使用IPv4v6双栈地址，则分别执行该命令对同一外联口配置IPv4和IPv6地址。 |
|  | VPN实例名称（VPNNAME） | VRF\_networkB | 已规划数据中获取 |  |
|  | 地址族（AFTYPE） | IPv4 | 已规划数据中获取 |  |
|  | 以太Trunk模板ID（ETHTRUNKTMPID） | 6 | 已规划数据中获取 | 此处以SR-IOV bonding组网下，复用N6其他VRF的vNIC接口为例。  可通过命令**LST AUTOSCALINGETHTRUNK**查询获取。 |
|  | VLAN ID（VLANID） | 20 | 全网规划 | 此处以单平面组网为例。  此处规划的IP地址是与网关互通的外联口IP。  根据ISU VM的数量规划地址池掩码长度。  此处以25位掩码为例进行介绍，具体以网设规划为准。 |
|  | 起始地址（BEGINADDR4） | 192.168.20.2 | 参见“5G Core LLD文档 > 业务IP对接设计 > 起始IP”。 |  |
|  | 结束地址（ENDADDR4） | 192.168.20.126 | 参见“5G Core LLD文档 > 业务IP对接设计 > 结束IP”。 |  |
|  | 地址池掩码长度（MASKLEN） | 25 | 参见“5G Core LLD文档 > 业务IP对接设计 > 子网掩码”。 |  |
| **ADD AUTOSCALINGSRBFD** | 服务名称（SERVICENAME） | ServName\_networkB | 已规划数据中获取 | BFD双向检测时需要规划。 |
|  | 地址族（IPVERSION） | IPv4 | 已规划数据中获取 |  |
|  | 检测倍数（MULTIPLIER） | 4 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > detect-multiplier”。 |  |
|  | 最小接收间隔（ms）（MINRXINTERVAL） | 500 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > min-rx-interval(毫秒)”。 |  |
|  | 最小发送间隔（ms）（MINTXINTERVAL） | 500 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > min-tx-interval(毫秒)”。 |  |
| **ADD AUTOSCALINGBFD** | 模板名称（TEMPLATENAME） | BFD\_10 | 本端规划 | BFD单臂echo检测时需要规划。  参数“目的地址”是网关的接口IP，此处用于检测目的IP能否正常接收报文。 |
|  | BFD类型（BFDTYPE） | Static | 固定取值 |  |
|  | 服务名称（SERVICENAME） | ServName\_networkB | 已配置数据中获取 |  |
|  | 地址族（IPVERSION） | IPv4 | 固定取值 |  |
|  | 目的地址（DESTADDR4） | 192.168.20.1 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > 对端IP地址”。 |  |
|  | 单臂Echo会话的收包间隔（ms）（MINECHORXINT） | 500 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > min-rx-interval(毫秒)”。 |  |
|  | 检测倍数（DETECTMULTI） | 4 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > detect-multiplier”。 |  |
|  | 单臂Echo（ONEARMECHO） | TRUE | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > BFD类型”。  “BFD类型”为“BFD Echo”/“单臂BFD”时，该参数设置为“TRUE”。 |  |

**表2** 路由交叉相关数据（上行路由）

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD AUTOSCALINGSRROUTE** | 服务名称（SERVICENAME） | ServName\_networkB | 已配置数据中获取 | 采用**ADD AUTOSCALINGSERVICE**命令定的服务名称。 |
|  | VPN实例名称（VRFNAME） | VRF\_networkA | 整网规划 | UPF上，与网络A互通的接口绑定的VPN实例名称。  可通过**LST L3VPNINST**查询获取。 |
|  | 地址族（IPVERSION） | ipv4 | 本端规划 | - |
|  | 路由前缀IPv4（PREFIX4） | 10.8.8.8 | 从对端获取 | 对端服务器的IP地址及掩码。  须知会到服务器，该地址变更时必须与UPF协商，否则可能出现访问该服务器的业务失败。 |
|  | 路由掩码长度（MASKLENGTH） | 32 | 从对端获取 |  |
|  | IPv4路由下一跳分配方式（NEXTHOPALLOCTYPE4） | CONFIG | 本端规划 | - |
|  | 路由下一跳IPv4（NEXTHOP4） | 192.168.20.1 | 从对端获取 | 网关接口IP。  UPF将与网络B互通的报文，发送给该IP所属的直连交换机/路由器。 |
|  | BFD使能标识（BFDENABLE） | ENABLE | 本端规划 | 双向BFD探测或单向BFD探测时均需设置为样例值。 |
|  | BFD模板名称（BFDTEMPLATENAME） | BFD\_10 | 已配置数据中获取 | 单臂BFD探测时需要规划。  表1中**ADD AUTOSCALINGBFD**命令定义的BFD模板名称。 |

**表3** 路由交叉相关数据（下行路由）

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **MOD VPNINSTAF** | VPN实例名称（VRFNAME） | VRF\_networkA | 整网规划 | UPF上，与网络A互通的接口绑定的VPN实例名称。  可通过**LST L3VPNINST**查询获取。 |
|  | 地址族名称(AFTYPE) | ipv4uni | 本端规划 | - |
|  | 路由标识(VRFRD) | 1:1 | 本端规划 | **MPLS OptionB必须配置“VRFRD”值。**  不同VPN实例的路由标识必须不同。  此处以“VRFLABELMODE”设置为“perInstance”为例，即每VPN实例分配一个标签。设置为“perInstance”比设置为“perRoute”节省标签资源。 |
|  | 实例的标签分配模式（VRFLABELMODE） | perInstance | 本端规划 |  |
| **ADD VPNTARGET** | VPN实例名称（VRFNAME） | VRF\_networkA | 整网规划 | UPF上，与网络A互通的接口绑定的VPN实例名称。  可通过**LST L3VPNINST**查询获取。 |
|  | 地址族类型（AFTYPE） | ipv4uni | 本端规划 | - |
|  | VPN RT类型（VRFRTTYPE） | export\_extcommunity | 固定取值 | 对于VPN实例VRF\_networkA的路由，UPF增加发布扩展属性及RT值。 |
|  | VPN RT值（VRFRTVALUE） | 1:1 | 全网规划 |  |
| **SET BGP** | 使能BGP（BGPENABLE） | TRUE | 固定取值 | UDG上如已使能BGP，此处不需要重复规划。 |
|  | BGP自治域号（ASNUM） | 60001 | 参见“5G Core LLD文档 > 路由设计 > BGP设计 > AS号（VNF）”。 |  |
| **ADD BGPVRF** | VPN实例名称（VRFNAME） | VRF\_networkA | 整网规划 | UPF上，与网络A互通的接口绑定的VPN实例名称。  可通过**LST L3VPNINST**查询获取。 |
|  | 默认地址族（DEFAULTAFTYPE） | ipv4uni | 本端规划 | - |
| **ADD IMPORTROUTE** | VPN实例名称（VRFNAME） | VRF\_networkA | 整网规划 | UPF上，与网络A互通的接口绑定的VPN实例名称。  可通过**LST L3VPNINST**查询获取。 |
|  | 地址族类型（AFTYPE） | ipv4uni | 本端规划 | - |
|  | 路由协议（IMPORTPROTOCOL） | wlr | 本端规划 | 采用样例值。 |
| **MOD VPNINSTAF** | VPN实例名称（VRFNAME） | VRF\_networkB | 全网规划 | UPF上，与网络B互通的接口绑定的VPN实例名称。 |
|  | 地址族名称(AFTYPE) | ipv4uni | 本端规划 | - |
|  | 路由标识(VRFRD) | 2:2 | 本端规划 | **MPLS OptionB必须配置“VRFRD”值。**  不同VPN实例的路由标识必须不同。  此处以“VRFLABELMODE”设置为“perInstance”为例，即每VPN实例分配一个标签。设置为“perInstance”比设置为“perRoute”节省标签资源。 |
|  | 实例的标签分配模式（VRFLABELMODE） | perInstance | 本端规划 |  |
| **ADD VPNTARGET** | VPN实例名称（VRFNAME） | VRF\_networkB | 整网规划 | UPF上，与网络B互通的接口绑定的VPN实例名称。 |
|  | 地址族类型（AFTYPE） | ipv4uni | 本端规划 | - |
|  | VPN RT类型（VRFRTTYPE） | import\_extcommunity | 固定取值 | 对于VPN实例VRF\_networkB，UPF增加引入扩展属性及RT值。  当RT类型为“import\_extcommunity”时，UPF判断其他VPN实例（如VRF\_networkA）路由中的团体属性为发布，且RT值与此处配置的RT值相同时，则将VRF\_networkA中的该条路由加入到本VPN实例的路由表中。 |
|  | VPN RT值（VRFRTVALUE） | 1:1 | 全网规划 |  |

## 操作流程

1. 配置UDG与网络B互通的接口IP&路由数据。

   请参见**操作步骤**中的步骤 1~步骤 4。
2. 配置跨VPN路由交叉相关数据（上行路由）。

   请参见**操作步骤**中的步骤 5~步骤 6。
3. 跨VPN路由交叉相关数据（下行路由）。

   请参见**操作步骤**中的步骤 7~步骤 8。

## 操作步骤

1. 配置外联口的VPN实例。

   ```
   ADD L3VPNINST:VRFNAME="VRF_networkB";
   ADD VPNINSTAF:VRFNAME="VRF_networkB",AFTYPE=ipv4uni;
   ```
2. 关闭自动配置开关。

   1. 查询自动配置开关。

      ```
      LST AUTOCONFIG:;
      ```

      如果自动配置开关值为“TRUE”，需要执行如下步骤关闭自动配置开关。
   2. （可选）查询自动部署维护助手“autoscaling\_autoconfig.py”的状态，确保状态为“准备好状态（Ready）”或者查询无该脚本，以保证当前设备不在自动部署过程中。因为若系统当前有正在进行的自动部署，而自动部署生效有时延，此时若关闭自动配置开关，会影响系统配置效果。

      ```
      DSP OPSASSISTSTATE:;
      ```
   3. （可选）关闭自动配置开关。自动化配置命令只有在自动配置开关为关闭的状态下才可执行，因此需要提前关闭。

      ```
      SET AUTOCONFIG:SWITCHFLAG=FALSE;
      ```
3. 配置外联口自动部署模板。

   //如下脚本以SR-IOV bonding组网为例。SR-IOV bonding组网时，“AUTOCFGIFTYPE”取值为“ETHTRUNK”；非SR-IOV bonding组网时，“AUTOCFGIFTYPE”取值为“VNIC”。

   ```
   ADD AUTOSCALINGSERVICE:SERVICENAME="ServName_networkB",VPNNAME="VPN_networkB",AFTYPE=IPv4,IPALLOCTYPE4=USER_CONFIG,AUTOCFGIFTYPE=ETHTRUNK,ETHTRUNKTMPID=6,VLANID=20, BEGINADDR4="192.168.20.2", ENDADDR4="192.168.20.126", MASKLEN=25;
   ```
4. 配置BFD会话。
   * BFD双向检测时：

     ```
     ADD AUTOSCALINGSRBFD: SERVICENAME="ServName_networkB", IPVERSION=IPv4, MINRXINTERVAL=500, MINTXINTERVAL=500, MULTIPLIER=4;
     ```
   * BFD 单臂echo检测时：

     ```
     ADD AUTOSCALINGBFD: TEMPLATENAME="BFD_10", BFDTYPE=Static, SERVICENAME="ServName_networkB", IPVERSION=IPv4, DESTADDR4="192.168.20.1", MINECHORXINT=500, DETECTMULTI=4, ONEARMECHO=TRUE;
     ```
5. 配置路由交叉相关数据（上行路由）。

   //此处以采用单向BFD为例。采用BFD双向检测时，不需要配置BFDTEMPLATENAME参数。

   ```
   ADD AUTOSCALINGSRROUTE: SERVICENAME="ServName_networkB", VRFNAME="VRF_networkA", IPVERSION=IPv4, PREFIX4="10.8.8.8", MASKLENGTH=32, NEXTHOPALLOCTYPE4=CONFIG, NEXTHOP4="192.168.20.1", BFDENABLE=TRUE, BFDTEMPLATENAME="BFD_10";
   ```
6. 打开自动配置开关。

   ```
   SET AUTOCONFIG: SWITCHFLAG=TRUE;
   ```

   * 从自动部署开关打开到自动部署功能生效有时延，因此执行其他操作前（例如手动部署路由互通、关闭自动部署开关），务必先执行****DSP OPSASSISTSTATE****命令查询自动部署维护助手“autoscaling\_autoconfig.py”的状态为“准备好状态（Ready）”，否则结果不可预期。
   * 在网关侧上配置到VNF的回程路由，目的地址为VNF上各逻辑接口的IP地址，下一跳为VNF上配置的各逻辑接口对应的外联口的IP地址。

     需要说明的是，配置VNF与DN/PDN通信的回程路由时，目的地址为UE的网段地址。下一跳为VNF上外联口的IP地址，由于自动部署时外联口的IP地址是系统自动分配的，因此建议首先通过命令**LST IFIPV4ADDRESS**查看外联口的IP地址。
7. 配置VRF\_networkA（源VRF）的相关数据。
   1. 修改L3VPN实例地址族。

      ```
      MOD VPNINSTAF: VRFNAME="VRF_networkA", AFTYPE=ipv4uni, VRFRD="1:1", VRFLABELMODE=perInstance;
      ```
   2. 增加VPN Target。“VRFRTTYPE”须设置为“export\_extcommunity”。

      ```
      ADD VPNTARGET: VRFNAME="VRF_networkA", AFTYPE=ipv4uni, VRFRTTYPE=export_extcommunity, VRFRTVALUE="1:1";
      ```
   3. 使能全局BGP。如已使能BGP，则此处不需要重复配置。

      ```
      SET BGP: BGPENABLE=TRUE, ASNUM="60001";
      ```
   4. 增加BGP VPN实例。如已配置，则此处不需要重复配置。

      ```
      ADD BGPVRF: VRFNAME="VRF_networkA", DEFAULTAFTYPE=ipv4uni, VRFRIDAUTOSEL=FALSE;
      ```
   5. 增加BGP引入路由。如已配置，则此处不需要重复配置。

      ```
      ADD IMPORTROUTE: VRFNAME="VRF_networkA", AFTYPE=ipv4uni, IMPORTPROTOCOL=wlr, MEDENABLE=FALSE;
      ```
8. 配置VRF\_networkB（目的VRF）的相关数据。
   1. 修改L3VPN实例地址族。

      ```
      MOD VPNINSTAF: VRFNAME="VRF_networkB", AFTYPE=ipv4uni, VRFRD="2:2", VRFLABELMODE=perInstance;
      ```
   2. 增加VPN Target。“VRFRTTYPE”须设置为“import\_extcommunity”。

      ```
      ADD VPNTARGET: VRFNAME="VRF_networkB", AFTYPE=ipv4uni, VRFRTTYPE=import_extcommunity, VRFRTVALUE="1:1";
      ```

版权所有 © 华为技术有限公司
