# 修改重定向Server的负荷分担方式

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

重定向Server的负荷分担方式需要修改。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-110281 用户Portal。
* 完成配置用户Portal。

数据

该操作无需准备数据。

## 操作步骤

1. 配置整机的针对IPFARM配置的重定向Server的负荷分担方式。

   **SET IPFARMGLOBAL**

   负荷分担方式有下列三种：
   * ROUND\_ROBIN：轮询方式。
   * LEAST\_RECENTLY\_USED：选择最久未被使用的Server。
   * LEAST\_LOAD：选择最小负荷Server方式。

## 任务示例

任务描述

负荷分担方式由LEAST\_LOAD改为LEAST\_RECENTLY\_USED。

脚本

//配置整机的针对IPFARM配置的重定向Server的负荷分担方式。

```
SET IPFARMGLOBAL:SERVERTYPE=REDIRECT,LBMETHOD=LEAST_RECENTLY_USED;
```

版权所有 © 华为技术有限公司
