---
id: GWFD-110281
name: 修改重定向Server的负荷分担方式
ne_type: UDG
type: feature
description: 重定向Server的负荷分担方式需要修改。  适用于PGW-U、UPF。
risk_level: ''
doc_source: ["特性部署","特性指南","UDG特性指南","智能策略控制功能","GWFD-110281 用户Portal","调整用户Portal参数","修改重定向Server的负荷分担方式"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
重定向Server的负荷分担方式需要修改。适用于PGW-U、UPF。

## 必备事项
前提条件

* 请仔细阅读GWFD-110281 用户Portal。
* 完成配置用户Portal。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    set_ipfarmglobal_list:
      type: items
      properties:
        SERVERTYPE:
          name: '服务器类型'
          type: string
          enum:
          - IPMS
          - PCSCF
          - REDIRECT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LBMETHOD:
          name: '负载均衡模式'
          type: string
          enum:
          - INVAILD
          - LEAST_LOAD
          - LEAST_RECENTLY_USED
          - ROUND_ROBIN
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HEALTHFAILLIMIT:
          name: '健康检查失败次数'
          type: integer
          minimum: 1
          maximum: 10
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HEALTHSUCCLIMIT:
          name: '健康检查成功次数'
          type: integer
          minimum: 1
          maximum: 10
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TIMEOUT:
          name: 'Ping探测超时时长（秒）'
          type: integer
          minimum: 1
          maximum: 59
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TIMETHRESHOLD:
          name: '时间阈值（秒）'
          type: integer
          minimum: 6
          maximum: 60
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - set_ipfarmglobal_list:
    - SERVERTYPE: REDIRECT
      LBMETHOD: LEAST_RECENTLY_USED
      HEALTHFAILLIMIT: ''
      HEALTHSUCCLIMIT: ''
      TIMEOUT: ''
      TIMETHRESHOLD: ''
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 配置整机的针对IPFARM配置的重定向Server的负荷分担方式。

```jinja2
{%- for item in set_ipfarmglobal_list -%}
    SET IPFARMGLOBAL:
    {#- --- 必选参数 --- -#}
    SERVERTYPE={{item.SERVERTYPE}},
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：SERVERTYPE=REDIRECT 时可选 --- -#}
    {%- if item.SERVERTYPE == 'REDIRECT' -%}
        {%- if item.LBMETHOD is not none -%}
            LBMETHOD={{item.LBMETHOD}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SERVERTYPE=REDIRECT/IPMS/PCSCF 时可选 --- -#}
    {%- if item.SERVERTYPE in ['REDIRECT', 'IPMS', 'PCSCF'] -%}
        {%- if item.HEALTHFAILLIMIT is not none -%}
            HEALTHFAILLIMIT={{item.HEALTHFAILLIMIT}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SERVERTYPE=REDIRECT/IPMS/PCSCF 时可选 --- -#}
    {%- if item.SERVERTYPE in ['REDIRECT', 'IPMS', 'PCSCF'] -%}
        {%- if item.HEALTHSUCCLIMIT is not none -%}
            HEALTHSUCCLIMIT={{item.HEALTHSUCCLIMIT}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SERVERTYPE=REDIRECT/IPMS/PCSCF 时可选 --- -#}
    {%- if item.SERVERTYPE in ['REDIRECT', 'IPMS', 'PCSCF'] -%}
        {%- if item.TIMEOUT is not none -%}
            TIMEOUT={{item.TIMEOUT}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SERVERTYPE=REDIRECT/IPMS/PCSCF 时可选 --- -#}
    {%- if item.SERVERTYPE in ['REDIRECT', 'IPMS', 'PCSCF'] -%}
        {%- if item.TIMETHRESHOLD is not none -%}
            TIMETHRESHOLD={{item.TIMETHRESHOLD}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 负荷分担方式有下列三种：

### ROUND\_ROBIN：轮询方式。

### LEAST\_RECENTLY\_USED：选择最久未被使用的Server。

### LEAST\_LOAD：选择最小负荷Server方式。

