# 配置CCR触发场景

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本指导描述UNC上触发CCR消息的相关配置操作。

UNC和OCS都可以指定CCR触发场景，OCS可以通过CCA消息携带的信元Trigger AVP指定触发CCR上报的场景，UNC本地也可以配置CCR触发场景，OCS下发优先级更高。

UNC在多种场景下支持向OCS发起CCR更新流程，配置的时候可以根据需要选择配置。在线计费过程中，当其中一个条件满足时，便会触发CCR上报。建议配置的配额门限的大小适度，要满足CCR与CCA之间下次新配额申请时使用。

## 必备事项

前提条件

* 请仔细阅读Ga/Gy接口离线/在线计费。
* 完成加载license。
* 已完成计费属性、APN、User Profile创建。
* 已根据配置在线计费模板完成在线计费模板创建和绑定，根据配置在线计费的费率标识完成在线计费费率标识配置。

数据

* 为了避免CCR消息突发导致UNC与OCS间的交互信令增加，请合理设置CCR消息触发场景。尽量控制忙时每PDP上下文/EPS承载或每业务会话（RG+SID）每小时触发的CCR消息数不超过6个，具体参见下表设置。
* 如下示例参数值为举例，请根据业务实际需要进行配置。

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET OCSINIT** | DCC模板名称（DCCTMPLTNAME） | dcc-test | 已配置数据中获取 | 配置用户激活时是否与OCS交互以及交互时是否等待OCS响应。  说明：  如果需要配置在线计费全局参数，则“DCCTMPLTNAME”参数值为“global”。 |
|  | OCS交互使能开关（OCSINIT） | ENABLE | 与对端协商 |  |
|  | OCS交互等待OCS响应开关（WAITOCSRESP） | ENABLE |  |  |
| **ADD DCCTEMPLATE**  **MOD DCCTEMPLATE** | DCC模板名称（DCCTMPLTNAME） | dcc-test | 本端规划 | 新增或者修改DCC在线计费模板，用于配置在线计费相关属性。  说明：  如果需要配置在线计费全局参数，则需要使用**MOD DCCTEMPLATE**命令，“DCCTMPLTNAME”参数值为“global”。 |
|  | 配额空耗时间门限值（秒）（QCT） | 0 | 与对端协商 | 配额空耗时间标识如何统计业务时长。QCT=0表示连续统计业务时长。 |
|  | 配额空闲时间门限值（秒）（QHT） | 0 |  | 配额空闲时间监控业务暂停的时长。QHT=0表示QHT不生效。  说明：  如果OCS支持接收QHT超时触发的CCR消息，建议QHT不小于60秒，避免频繁触发CCR消息。 |
|  | 流量阈值触发百分比（%）（VQT） | 20 |  | 标识业务剩余流量配额百分比小于等于VQT时，触发上报CCR消息请求新配额。 |
|  | 时间阈值触发百分比（%）（TQT） | 20 |  | 标识业务剩余时长配额百分比小于等于TQT时，触发上报CCR消息请求新配额。 |
|  | 事件阈值触发百分比（%）（UQT） | 20 |  | 标识业务剩余事件配额百分比小于等于UQT时，触发上报CCR消息请求新配额。 |
|  | 指定CCR-I消息中携带RG的个数（CCRINITRGNUM） | 5 |  | 用户激活时发送的CCR-I消息中携带RG的个数。  说明：  该参数要与**SET CTXSTARTRATING**命令配合使用。如果在**SET CTXSTARTRATING**命令中指定了N个RG，则该参数至少要配置为N，才能使得上述N个RG都能被CCR-I消息带上申请配额。 |
|  | 在线配额有效时长（分）（VALIDTIME） | 30 |  | 标识配额有效时长，超时后触发上报CCR消息。 |
|  | 业务触发请求使能开关（SERVICETRIGGER） | ENABLE |  | 使用新业务是否发送CCR。 |
|  | Rat变化触发使能开关（RATTRIGGER） | ENABLE |  | RAT改变是否发送CCR。 |
|  | SGSN变化触发使能开关（SGSNTRIGGER） | ENABLE |  | SGSN/SGW地址改变是否发送CCR。 |
|  | QoS变化触发使能开关（QOSTRIGGER） | ENABLE |  | QoS改变是否发送CCR。 |
|  | ULI变化触发使能开关（ULITRIGGER） | ENABLE |  | ULI改变是否发送CCR。 |
|  | MCC变化触发重授权开关（MCCTRIGGER） | ENABLE |  | MCC改变是否发送CCR。 |
|  | MNC变化触发重授权开关（MNCTRIGGER） | ENABLE |  | MNC改变是否发送CCR. |
|  | LAC变化触发重授权开关（LACTRIGGER） | ENABLE |  | LAC改变是否发送CCR。 |
|  | UE TimeZone改变触发重授权开关（UETZTRIGGER） | ENABLE |  | 终端时区改变是否发送CCR。 |
|  | TA改变触发重授权开关（TACTRIGGER） | DISABLE |  | TA改变是否触发重授权CCR请求。 |
|  | ECGI改变触发重授权开关（ECGITRIGGER） | DISABLE |  | ECGI改变是否触发重授权CCR请求 |
|  | 无配额更新开关（NOQUOTATRIGGER） | ENABLE |  | 业务无配额情况下，是否在PDP更新时发起重授权请求。 |
|  | RAC改变触发重授权开关（RACTRIGGER） | DISABLE |  | 用户RAC改变是否发送CCR。 |
|  | CellID改变触发重授权开关（CELLIDTRIGGER） | DISABLE |  | 用户CellID改变是否发送CCR。 |
|  | eNodeB变化触发重授权开关（ENBTRIGGER） | DISABLE |  | eNodeB变化是否触发重授权CCR请求。 |
|  | 服务PLMN控制速率改变触发重授权开关（SPRATETRIGGER） | DISABLE |  | 服务PLMN控制速率改变是否触发重授权CCR请求。 |
|  | APN控制速率改变触发重授权开关（APNRATETRIGGER） | DISABLE |  | APN控制速率改变是否触发重授权CCR请求。 |
| **SET CTXSTARTRATING** | 用户模板名称（USERPROFILENAME） | up-test | 已配置数据中获取 | 配置用户激活时与OCS交互的CCR消息中携带的Rating Group信息。  说明：  此命令只对内容计费用户生效，PDP级别计费用户不适用该命令。PDP级别计费用户CCR-I中携带User Profile下或者全局下配置的默认计费属性，其中User Profile下的优先。如果User Profile下没有配置CCR-I的计费属性，则使用配置在全局下的CCR-I的计费属性。如果全局下没有配置CCR-I的计费属性，则CCR-I不携带计费属性。 |
|  | 初始请求URR组名称1（CTXRURRGRPNAME1） | urrgroup1 |  |  |
|  | 初始请求URR组名称2（CTXRURRGRPNAME2） | urrgroup2 |  |  |
|  | 初始请求URR组名称3（CTXRURRGRPNAME3） | urrgroup3 |  |  |
|  | 初始请求URR组名称4（CTXRURRGRPNAME4） | urrgroup4 |  |  |
|  | 初始请求URR组名称5（CTXRURRGRPNAME5） | urrgroup5 |  |  |

## 操作步骤

* 配置UNC Gy接口与OCS之间的DCC会话建立方式。

  配置全局通用参数DCC模板，DCC模板名称。“DCCTMPLTNAME”=“global”

  **MOD DCCTEMPLATE**
* 配置/修改DCC模板。

  **ADD DCCTEMPLATE**

  **MOD DCCTEMPLATE**

  1. 配置CCR-I消息中允许携带的RG的最大个数。配置参数“CCRINITRGNUM”
  2. 配置剩余流量配额小于VQT后向OCS发起CCR。配置参数“VQT”
  3. 配置剩余时长配额小于TQT后向OCS发起CCR。配置参数“TQT”

     “VQT”和“TQT”配置值不建议小于20，建议保持默认配置。
  4. 配置剩余事件配额小于UQT后向OCS发起CCR。配置参数“UQT”
  5. 配置配额能使用的有效时长超时后向OCS发起CCR。配置参数“VALIDTIME”
  6. 配置当用户数据包停止传送时长超过QHT后向OCS发起CCR。配置参数“QHT”

     + 如果不想使用该功能，即无论用户停止数据传送多长时间也不触发CCR，则可以在OCS上指定CCA中携带的Quota-Holding-Time AVP值为0，或CCA中不携带Quota-Holding-Time AVP，且UNC本地配置QHT为0。
     + 在没有明确需求的情况下建议不使用QHT，配置为0。
     + 当QHT不为0时QHT必须大于QCT（Quota Consumption Time）。
  7. 尚未申请过配额的新业务触发向OCS发起CCR。配置参数“SERVICETRIGGER”

     以下为配置PDP上下文/EPS承载更新场景（RAT改变、SGSN/S-GW地址改变、QoS改变、用户位置信息ULI改变（包括用户MCC、MNC改变）、终端时区改变触发的PDP上下文/EPS承载更新等）触发CCR。
  8. 配置RAT改变发送CCR。配置参数“RATTRIGGER”
  9. 配置SGSN/S-GW地址改变发送CCR。配置参数“SGSNTRIGGER”
  10. 配置QoS改变发送CCR。配置参数“QOSTRIGGER”
  11. 配置ULI改变发送CCR。配置参数“ULITRIGGER”
  12. 配置终端时区改变发送CCR。配置参数“UETZTRIGGER”
  13. 配置终端的MCC改变发送CCR。配置参数“MCCTRIGGER”
  14. 配置终端的MNC改变发送CCR。配置参数“MNCTRIGGER”
  15. 配置终端的LAC改变发送CCR。配置参数“LACTRIGGER”
  16. 配置终端的eNodeB改变发送CCR。配置参数“ENBTRIGGER”
  17. 配置终端的RAC改变发送CCR。配置参数“RACTRIGGER”
  18. 配置终端的CellID改变发送CCR。配置参数“CELLIDTRIGGER”
  19. 配置无配额情况下，在PDP/bearer更新时发送CCR。配置参数“NOQUOTATRIGGER”
  20. 配置终端的服务PLMN控制速率改变发送CCR。配置参数“SPRATETRIGGER”
  21. 配置终端的APN控制速率改变发送CCR。配置参数“APNRATETRIGGER”
* 配置PDP上下文/EPS承载激活时发送CCR-I与OCS交互。
  1. 配置在线计费用户激活时需要与OCS交互。

     **SET OCSINIT**
  2. 配置在线计费用户激活时CCR-I消息中携带指定的费率标识。

     **SET CTXSTARTRATING**

     此命令只对内容计费用户生效，PDP级别计费用户不适用该命令。PDP级别计费用户CCR-I中携带User Profile下或者全局下配置的默认计费属性，其中User Profile下的优先。如果User Profile下没有配置CCR-I的计费属性，则使用配置在全局下的CCR-I的计费属性。如果全局下没有配置CCR-I的计费属性，则CCR-I不携带计费属性。

     **ADD DCCTEMPLATE**命令配置CCR-I消息中允许携带的RG的最大个数时要与**SET CTXSTARTRATING**命令配合使用。如果在**SET CTXSTARTRATING**命令中指定了N个RG，则**ADD DCCTEMPLATE**命令配置CCR-I消息中允许携带的RG的最大个数至少要配置为N，才能使得上述N个RG都能被CCR-I消息带上申请配额。

## 任务示例

任务描述

以修改DCC模板dcc-test为例，配置单用户单DCC会话在线计费的各种CCR触发场景。

脚本

//配置DCC模板。

```
ADD DCCTEMPLATE:DCCTMPLTNAME="dcc-test", QCT=0, QHT=0, VQT=20, TQT=20, UQT=20, CCRINITRGNUM=5, VALIDTIME=30, RATTRIGGER=ENABLE, SGSNTRIGGER=ENABLE, QOSTRIGGER=ENABLE, ULITRIGGER=ENABLE, SERVICETRIGGER=ENABLE, UETZTRIGGER=ENABLE, MCCTRIGGER=ENABLE, MNCTRIGGER=ENABLE, LACTRIGGER=ENABLE, TACTRIGGER=DISABLE, ECGITRIGGER=DISABLE, NOQUOTATRIGGER=ENABLE, APNRATETRIGGER=DISABLE, SPRATETRIGGER=DISABLE, RACTRIGGER=DISABLE, CELLIDTRIGGER=DISABLE, ENBTRIGGER=DISABLE;
```

//配置PDP上下文/EPS承载激活时发送CCR-I与OCS交互。

```
SET OCSINIT:DCCTMPLTNAME="dcc-test",OCSINIT=ENABLE, WAITOCSRESP=ENABLE;
SET CTXSTARTRATING:USERPROFILENAME="up-test", CTXRURRGRPNAME1="urrgroup1", CTXRURRGRPNAME2="urrgroup2", CTXRURRGRPNAME3="urrgroup3", CTXRURRGRPNAME4="urrgroup4",CTXRURRGRPNAME5="urrgroup5";
```

版权所有 © 华为技术有限公司
