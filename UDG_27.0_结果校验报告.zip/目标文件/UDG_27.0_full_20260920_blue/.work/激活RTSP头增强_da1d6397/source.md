# 激活RTSP头增强

* 操作场景
* 必备事项
* 操作流程
* 任务示例

## 操作场景

当需要将用户信息（如APN、IMEI等）中的一个或多个信息添加到RTSP（Real Time Streaming Protocol）报文头并传递给Streaming Server时，需要完成RTSP报文头的内容增强处理。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读RTSP头增强原理描述。
* 操作员已经获取到运营商对使用RTSP头增强特性的插入字段规划、字段前缀名称规划以及需要RTSP头增强信息的Streaming Server的IP地址、URL等信息。
* 完成加载license（如果有需求，请联系华为技术支持工程师处理）。

数据

**表1** License信息

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 打开License配置开关。  **SET LICENSESWITCH** | License项（LICITEM） | LKV3G5RTHE01 | 本端规划 | - |
|  | 开关（SWITCH） | ENABLE | 本端规划 | - |

**表2** 流过滤器

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 配置流过滤器。  **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test | 本端规划 | 不同流过滤器之间，该参数不能重复。 |

使用三四层过滤条件触发头增强时，需要规划表3中的数据，否则不需要规划。

**表3** 三四层过滤条件（基于IP）

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 配置三四层过滤条件。  **ADD FILTER** | 过滤器名称（FILTERNAME） | filter\_test\_1  filter\_test\_2 | 本端规划 | 不同过滤器之间，该参数不能重复。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 | - |
|  | 三四层协议类型（L34PROTOCOL） | TCP | 本端规划 | - |
|  | 服务器IP地址配置模式（SVRIPMODE） | IP | 本端规划 | 支持基于IP、主机名和IP地址列表三种方式，此处以IP为例。 |
|  | 服务器IP地址（SVRIP） | 10.10.10.10  10.10.10.11 | 与对端协商 | Streaming Server的IP地址。 |
|  | 服务器IP地址掩码类型（SVRIPMASKTYPE） | IPTYPE | 本端规划 | - |
|  | 服务器IP地址反掩码（SVRIPMASK） | 0.0.0.0  0.0.0.0 | 与对端协商 | Streaming Server的IP地址掩码反码。 |
|  | 服务器起始端口号（SVRSTARTPORT） | 0 | 与对端协商 | Streaming Server接收RTSP报文的端口号。 |
|  | 服务器结束端口号（SVRENDPORT） | 65535 | 与对端协商 |  |
| 配置三四层过滤条件与流过滤器的绑定关系。  **ADD FLTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 过滤器名称（FILTERNAME） | filter\_test\_1  filter\_test\_2 | 已配置数据中获取 | 使用**ADD FILTER**命令定义的过滤器名称。 |
| 将新配置的Filter置为生效。  **SET REFRESHSRV** | 刷新类型  （REFRESHTYPE） | ALL | 本端规划 | - |

使用七层过滤条件触发头增强时，需要规划表4中的数据，否则不需要规划。

**表4** 七层过滤条件（基于URL或RTSP协议）

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 配置七层过滤条件。  **ADD L7FILTER** | 七层过滤器名称（L7FILTERNAME） | l7filter\_test | 本端规划 | 不同的七层过滤器，其名称不能相同。  仅采用基于RTSP协议时，不需要规划该数据。 |
|  | 子七层过滤器名称（SUBL7FLTNAME） | sl7\_test\_1  sl7\_test\_2 | 本端规划 | 同一个七层过滤器包含的多个子七层过滤器名称不能相同。 |
|  | URL（URL） | www.huawei.com/\*  www.example.com | 与对端协商 | 根据Streaming Server的URL规划。  采用基于URL时，需要规划；仅采用基于RTSP协议时，不需要规划该数据。 |
| 配置七层过滤条件与流过滤器/协议的绑定关系。  **ADD PROTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 协议名称（PROTOCOLNAME） | rtsp | 本端规划 | 使用样例值。 |
|  | 七层过滤器名字（L7FILTERNAME） | l7filter\_test | 已配置数据中获取 | 使用**ADD L7FILTER**命令定义的七层过滤器名称。  采用基于URL时，需要规划；仅采用基于RTSP协议，且使用默认方法类型时不需要规划。 |
| 将新配置的Filter置为生效。  **SET REFRESHSRV** | 刷新类型  （REFRESHTYPE） | ALL | 本端规划 | 系统自动在60s后将配置的L7Filter置为生效。如果需要将新配置的L7Filter立即生效，可执行本此命令。 |
| 配置知名端口识别RTSP协议。  **ADD WELLKNOWNPORT** | 知名端口名称（IDENPROTNAME） | rtsp\_554 | 本端规划 | 存在多条数据时，该参数不能相同。 |
|  | 协议名称（PROTOCOLNAME） | rtsp | 固定取值 | - |
|  | 端口范围操作码（PORTOP） | EQUAL | 与对端协商 | 根据Streaming Server的端口情况进行规划。  优先级取值越小，优先级越高。 |
|  | 起始端口号（STARTPORT） | 554 | 与对端协商 |  |
|  | 优先级（PRIORITY） | 5 | 与对端协商 |  |
| 配置协议特征库识别RTSP协议。  **LOD SIGNATUREDB** | 特征库加载模式（LOADMODE） | LATEST | 本端规划 | 如无特殊需求，使用样例值即可。 |
| 配置协议解析数据库识别RTSP协议。  **LOD PARSERDB** | 解析库加载模式（LOADMODE） | LATEST | 本端规划 | 如无特殊需求，使用样例值即可。 |

**表5** 头增强插入字段规划数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 配置RTSP头增强动作属性。  **ADD HEADEN**  说明：  UDG支持头增强灰名单功能，当**ADD HEADEN**命令中的“GRAYLIST”设置为“ENABLE”时，UDG将不支持插入头增强字段。该功能可适用于只进行防欺诈而不需要头增强的场景。 | 头增强名称（HEADERENNAME） | header\_test | 本端规划 | - |
|  | 数据类型（DATATYPE） | APN  IMSI1  MSIP1  MSISDN1 | 与对端协商 | 根据Streaming Server业务需求规划。 |
|  | 前缀名称（PREFIXNAME） | pre-apn  pre-imsi  pre-msip  pre-msisdn | 与对端协商 | 根据Streaming Server识别规划。 |
|  | 加密算法标识（ENCRYALGORI） | NONE | 与对端协商 | 根据Streaming Server能力规划。建议使用安全的加密算法。 |

* 如果是4G场景，头增强插入的是用户的IMSI/MSISDN/IMEI。如果是4/5G融合场景和5G场景，可以设置字段IMSI/MSISDN/IMEI按照5G的形式插入，头增强插入的是用户的GPSI/SUPI/PEI。该设置仅对RAT类型为5G的用户生效。

  ```
  SET SOFTPARA:DT=BYTE,BYTENUM=896,BYTEVALUE=1;
  ```
* 4G用户接入5GC场景，设置字段ULI按照3GPP TS29.061规定的格式插入。

  ```
  SET SOFTPARA:DT=BYTE,BYTENUM=896,BYTEVALUE=2;
  ```

当**ADD HEADEN**中的参数“ENCRYALGORI”配置了加密算法时，需要配置对应的加密算法。

**表6** 与加密算法相关的配置命令

| 参数“ENCRYALGORI” | 与加密算法相关的配置命令 |
| --- | --- |
| MD5 | - |
| RC4 | 可以有如下两种配置方式：   * 将**ADD HEADEN**命令的“RC4KEYMD5EN”参数配置为“INHERIT”，再将**SET HEADENGLBPARA**命令的“RC4KEYMD5EN”参数设置为“ENABLE”，设置头增强功能RC4加密前需要做一次MD5加密。 * 将**ADD HEADEN**命令的“RC4KEYMD5EN”参数配置为“ENABLE”，设置头增强功能RC4加密前需要做一次MD5加密。 |
| AES128 | 使用**SET AES128**命令，设置AES128加密算法的IV值。“HEADENRANDOMIV”参数设置为“ENABLE”时，支持通过安全随机函数生成IV值。 |
| AES256 | 使用**SET AES256**命令，设置AES256加密算法的IV值。“HEADENRANDOMIV”参数设置为“ENABLE”时，支持通过安全随机函数生成IV值。 |
| RSA2048 | 使用**ADD RSA2048**命令，配置RSA2048加密使用的公钥文件及相关参数。 |
| RSA1024 | 使用**ADD RSA1024**命令，配置RSA1024加密使用的公钥文件及相关参数。 |
| SHA256 | - |

表7仅为配置属性举例，详细描述请参见计费特性。因头增强仅针对上行报文，所以，需要包含上行报文的计费属性。

**表7** 计费属性和策略规划数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 配置URR。  **ADD URR** | 使用量上报规则名称（URRNAME） | urr01 | 本端规划 | - |
|  | URR标识（URRID） | 1000 | 全网规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE | 全网规划 |  |
| 配置上行和下行发起的业务对应的URR。  **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | cp\_test | 本端规划 | - |
|  | 上行发起URR名称1（UPURRNAME1） | urr01 | 已配置数据中获取 | 已在该配置任务中通过命令**ADD URR**配置。 |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr01 | 已配置数据中获取 |  |
| 配置PCC策略组。  **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | pg\_test | 本端规划 | 存在多条数据时，该参数不能相同。 |
|  | URR组名称(URRGROUPNAME) | cp\_test | 已配置数据中获取 | PCC策略组绑定的URR组，已通过**ADD URRGROUP**命令配置完成。 |

**表8** 头增强规则规划数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 配置头增强使用的规则。  ****ADD RULE**** | 规则名称（RULENAME） | rule\_test1 | 本端规划 | 存在多条数据时，该参数+策略类型不能完全相同。 |
|  | 策略类型（POLICYTYPE） | HEADEN | 本端规划 | 使用样例值。 |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 策略名称（POLICYNAME） | header\_test | 已配置数据中获取 | 使用**ADD HEADEN**命令定义的头增强名称。 |

**表9** 计费规则规划数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 配计费规则。  **ADD RULE** | 规则名称（RULENAME） | rule\_test2 | 本端规划 | 存在多条数据时，该参数+策略类型不能完全相同。 |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | 使用样例值。 |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 策略名称（POLICYNAME） | pg\_test | 已配置数据中获取 | 使用**ADD PCCPOLICYGRP**命令定义的PCC策略组名称。 |

**表10** 头增强规则和计费规则绑定到用户模板规划数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 创建UserProfile实例。  **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | up\_test | 与对端协商 | 与SMF上配置的用户模板名称保持一致。 |
| 将已配置的使用量上报规则绑定到UserProfile。  **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | up\_test | 已配置数据中获取 | 使用**ADD USERPROFILE**命令定义的用户模板名称。 |
|  | 规则名称（RULENAME） | rule\_test1  rule\_test2 | 与对端协商 | UserProfile绑定的业务规则，已通过**ADD RULE**命令配置完成。  与SMF上配置的规则名称保持一致。 |

## 操作流程

本流程仅给出与RTSP头增强相关的关键配置逻辑，与RTSP头增强配合的带宽等其他控制策略不在本处体现。

**图1** 配置逻辑

* 在RTSP头中插入RAT时，如果需要灵活定义RAT参数，可以通过**SET HEADENRATTYPE**命令配置。
* 如果需要调整头增强全局参数，可以通过**SET HEADENGLBPARA**命令配置。
* 如果需要调整头增强业务流的五元组老化时间，可以通过**SET FLOWAGETIME**命令配置。

## 任务示例

任务描述

运营商的Streaming Server需要通过获取用户的APN、IMSI、MSIP、MSISDN给某些用户提供特殊定制业务，因此，运营商需要UDG将用户发起的上行RTSP报文进行RTSP头增强，采用基于特定IP地址、基于特定URL或RTSP协议的触发头增强方式，将用户的APN、IMSI、MSIP、MSISDN字段插入用户报文，将其携带给Streaming Server。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH: LICITEM="LKV3G5RTHE01",SWITCH=ENABLE;
```

//配置流过滤器。

```
ADD FLOWFILTER:FLOWFILTERNAME="flowfilter_test";
```

//配置基于特定IP地址触发RTSP头增强，使用的三四层过滤条件。使用UE IP地址、Streaming Server IP地址、三四层协议类型、手机端口号或服务器端口号作为过滤条件。仅采用七层过滤条件时请跳过该脚本。

```
ADD FILTER: FILTERNAME="filter_test1", L34PROTTYPE=STRING, L34PROTOCOL=TCP, SVRIPMODE=IP, SVRIP="10.10.10.10", SVRIPMASKTYPE=IPTYPE, SVRIPMASK="0.0.0.0", SVRSTARTPORT=0, SVRENDPORT=65535;
ADD FILTER: FILTERNAME="filter_test2", L34PROTTYPE=STRING, L34PROTOCOL=TCP, SVRIPMODE=IP, SVRIP="10.10.10.11", SVRIPMASKTYPE=IPTYPE, SVRIPMASK="0.0.0.0", SVRSTARTPORT=0, SVRENDPORT=65535;
ADD FLTBINDFLOWF:FLOWFILTERNAME="flowfilter_test",FILTERNAME="filter_test1";
ADD FLTBINDFLOWF:FLOWFILTERNAME="flowfilter_test",FILTERNAME="filter_test2";
SET REFRESHSRV:REFRESHTYPE=ALL;
```

//配置基于特定URL和RTSP协议触发RTSP头增强，使用七层过滤条件。可配置知名端口+特征库方式识别，也可仅使用特征库识别。仅采用三四层过滤条件时请跳过该脚本。

//配置RTSP头增强的七层过滤条件（URL）。仅采用三四层过滤条件时请跳过该脚本。仅采用七层过滤条件（RTSP协议）过滤时请跳过该脚本。

```
ADD L7FILTER:L7FILTERNAME="l7filter_test",SUBL7FLTNAME="sl7_test_1",URL="www.huawei.com/*";
ADD L7FILTER:L7FILTERNAME="l7filter_test",SUBL7FLTNAME="sl7_test_2",URL="www.example.com";
ADD PROTBINDFLOWF:FLOWFILTERNAME="flowfilter_test",PROTOCOLNAME="rtsp",L7FILTERNAME="l7filter_test";
SET REFRESHSRV:REFRESHTYPE=ALL;
```

//配置RTSP头增强的七层过滤条件（RTSP协议）。仅采用三四层过滤条件时请跳过该脚本。采用七层过滤条件（URL）过滤时请跳过该脚本。

```
ADD PROTBINDFLOWF:FLOWFILTERNAME="flowfilter_test",PROTOCOLNAME="rtsp";
SET REFRESHSRV:REFRESHTYPE=ALL;
```

//配置知名端口识别RTSP协议。推荐采用特征库识别协议。同时配置知名端口识别协议和特征库识别协议时，UDG通过知名端口识别协议成功后，再通过特征库识别协议。不配置知名端口识别协议时，直接通过特征库识别协议。

```
ADD WELLKNOWNPORT:IDENPROTNAME="rtsp_554",PROTOCOLNAME="rtsp",PORTOP=EQUAL,STARTPORT=554,PRIORITY=5;
```

//通过报文特征库识别协议。

```
LOD SIGNATUREDB:LOADMODE=LATEST;
LOD PARSERDB:LOADMODE=LATEST;
```

//配置七层过滤条件结束。

//配置RTSP头增强动作属性。头增强字段为APN、IMSI1、MSIP1、MSISDN1。

```
ADD HEADEN:HEADERENNAME="header_test",DATATYPE=APN,PREFIXNAME="pre-apn", ENCRYALGORI=NONE; 
ADD HEADEN:HEADERENNAME="header_test",DATATYPE=IMSI1,PREFIXNAME="pre-imsi",ENCRYALGORI=NONE;
ADD HEADEN:HEADERENNAME="header_test",DATATYPE=MSIP1,PREFIXNAME="pre-msip",ENCRYALGORI=NONE;
ADD HEADEN:HEADERENNAME="header_test",DATATYPE=MSISDN1,PREFIXNAME="pre-msisdn",ENCRYALGORI=NONE;
```

//配置RTSP头增强使用的计费属性。

```
ADD URR:URRNAME="urr01",URRID=1000,USAGERPTMODE=OFFLINE;
ADD URRGROUP:URRGROUPNAME="cp_test",UPURRNAME1="urr01",DOWNURRNAME1="urr01";
```

//配置RTSP头增强使用的PCC动作策略组。

```
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="pg_test",URRGROUPNAME="cp_test";
```

//配置RTSP头增强使用的规则。

```
ADD RULE:RULENAME="rule_test1",POLICYTYPE=HEADEN,FILTERINGMODE=FLOWFILTER,FLOWFILTERNAME="flowfilter_test",POLICYNAME="header_test";
```

//配置计费规则。

```
ADD RULE:RULENAME="rule_test2",POLICYTYPE=PCC,FILTERINGMODE=FLOWFILTER,FLOWFILTERNAME="flowfilter_test",PRIORITY=20, POLICYNAME="pg_test";
```

//配置RTSP头增强使用的业务策略组合（规则与用户模板的绑定关系）。

```
ADD USERPROFILE:USERPROFILENAME="up_test";
ADD RULEBINDING:USERPROFILENAME="up_test",RULENAME="rule_test1";
ADD RULEBINDING:USERPROFILENAME="up_test",RULENAME="rule_test2";
```

版权所有 © 华为技术有限公司
