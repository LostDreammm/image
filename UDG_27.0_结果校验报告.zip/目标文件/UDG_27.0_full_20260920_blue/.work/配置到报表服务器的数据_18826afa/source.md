# 配置到报表服务器的数据

* 操作场景
* 对系统的影响
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

报表服务器支持如下功能：

* 接收UDG上报的UFDR与ADR单据，生成相关报表，用于分析用户业务故障原因、了解运营商网络、扩展运营商业务等场景。
* 根据业务场景确定是否进行UFDR单据订阅，并下发订阅。

UDG通过Router A与Router B，以静态路由或动态路由的组网方式与报表服务器互联。如图1所示，以静态路由作为示例。

**图1** UDG与报表服务器的组网对接示意图

与报表服务器的对接支持IPv4和IPv6地址，该配置以IPv4地址举例。

## 对系统的影响

该操作对系统正常运行无影响。

## 必备事项

前提条件

已经完成**安装RPT服务**。

数据

**表1** 需要准备的数据

| 类别 | 参数 | 取值样例 | 获取方式 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RPTSVR** | 报表服务器名称（RPTSVRNAME） | UFDR\_SERVER | 本端规划 | 配置报表服务器。 |
|  | 报表话单消息格式（RPTSVRTYPE） | UFDR | 本端规划 |  |
| **ADD RPTSVRADDR** | 接入点名称（ACCESSNAME） | rpt\_access1  rpt\_access2 | 本端规划 | 配置报表服务器IP接入点。 |
|  | 报表服务器名称（RPTSVRNAME） | UFDR\_SERVER | 本端规划 |  |
|  | IP类型(IPTYPE) | IPv4 | 本端规划 |  |
|  | IPv4地址（IPv4\_ADDR） | 10.80.128.1  10.80.129.1 | 本端规划 |  |
|  | 端口号（SVRPORT） | 10700 | 全网规划 |  |
|  | VPN实例名称（VPNINSTANCE） | VPN\_report | 已配置数据中获取 | 绑定VPN时需要确保该VPN已经通过**ADD VPNINST**配置。  如果**ADD LOGICINF**命令绑定了VPN实例，那么**ADD RPTSVRADDR**命令也必须绑定VPN实例，否则链路建立不成功。 |
| **ADD VPNINST** | VPN实例名（VPNINSTANCE） | VPN\_report | 本端规划 | 配置VPN实例。 |
| **ADD LOGICINF** | 逻辑接口名称（NAME） | grpif1/0/0 | 固定取值 | 配置Grp逻辑接口。 |
|  | 逻辑接口的IP版本（IPVERSION） | IPv4 | 本端规划 |  |
|  | 逻辑接口的IPv4地址1（IPV4ADDRESS1） | 10.1.1.2 | 本端规划 |  |
|  | 逻辑接口的IPv4掩码1（IPV4MASK1） | 255.255.255.255 | 本端规划 |  |
|  | VPN实例名称（VPNINSTANCE） | VPN\_report | 已配置数据中获取 |  |
| **MOD URR** | 使用量上报规则名称（URRNAME） | urr\_red | 本端规划 | URR名称。  配置**MOD URR**的同时需要开启软参BIT1557 控制报表UFDR单据上报字段内容，以保证UPF上报的UFDR单据中包含Charging TLV相关字段。 |
|  | URR标识（URRID） | 1000 | 本端规划 | URR标识。 |
|  | 使用量上报模式（USAGERPTMODE） | ONLINE | 本端规划 | 该URR为在线计费应用的URR。 |
|  | 计费组（RG） | 10 | 本端规划 | * 在线计费时，和SMF上**ADD URR**命令的ONLINERG配置保持一致。 * 离线计费时，和SMF上**ADD URR**命令的RG配置保持一致。 |
|  | 业务标识（SID） | 20 | 本端规划 | * 在线计费时，和SMF上**ADD URR**命令的ONLINESID配置保持一致。 * 离线计费时，和SMF上**ADD URR**命令的SID配置保持一致。 |

## 操作步骤

1. 已经完成**安装RPT服务**。
2. 配置RPT的外联口物理IP、静态路由和BFD组网。

   具体步骤请参见配置静态路由+BFD组网（IPv4）。

   动态路由具体步骤请参见配置动态路由OSPF+BFD组网（IPv4）。
3. 配置报表服务器。

   **ADD RPTSVR**
4. 配置报表服务器的IP接入点。

   **ADD RPTSVRADDR**

   报表服务器的UFDR接入点IP地址的默认端口为10700。
5. 配置Grp逻辑接口。

   **ADD VPNINST**

   **ADD LOGICINF**
6. 可选：配置UFDR支持上报Charging TLV。

   **MOD URR**

   当需要UFDR支持上报Charging TLV时，需要UPF本地配置**ADD URR**/**MOD URR**命令中的RG和SID参数，且RG和SID参数的配置和SMF上**ADD URR**/**MOD URR**命令对应的离线/在线（RG，SID）配置保持一致。同时需要开启软参BIT1557 控制报表UFDR单据上报字段内容，以保证UPF上报的UFDR单据中包含Charging TLV相关字段。

## 任务示例

任务描述

配置到报表服务器的数据。

脚本

1. 配置RPT的外联口物理IP、静态路由和BFD探测，请参见配置静态路由+BFD组网（IPv4）。
2. 配置报表服务器。

   ```
   ADD RPTSVR: RPTSVRNAME="UFDR_SERVER",RPTSVRTYPE=UFDR;
   ```
3. 配置报表服务器的IP接入点。如果**ADD LOGICINF**命令绑定了VPN实例，那么**ADD RPTSVRADDR**命令也必须绑定VPN实例，否则链路建立不成功。

   ```
   ADD RPTSVRADDR: ACCESSNAME="rpt_access1", RPTSVRNAME="UFDR_SERVER", IPTYPE=IPv4, IPv4_Addr="10.80.128.1",SVRPORT=10700,VPNINSTANCE="VPN_report";
   ```

   ```
   ADD RPTSVRADDR: ACCESSNAME="rpt_access2", RPTSVRNAME="UFDR_SERVER", IPTYPE=IPv4, IPv4_Addr="10.80.129.1",SVRPORT=10700,VPNINSTANCE="VPN_report";
   ```
4. 配置Grp逻辑接口。

   ```
   ADD VPNINST: VPNINSTANCE ="VPN_report";
   ```

   ```
   ADD LOGICINF:NAME="grpif1/0/0",IPVERSION=IPV4,IPV4ADDRESS1="10.1.1.2",IPV4MASK1="255.255.255.255",VPNINSTANCE="VPN_report";
   ```
5. 可选：配置UFDR支持上报Charging TLV。以UPF上的**MOD URR**命令配置费率标识（RG，SID）=（10,20）为例。

   ```
   MOD URR:URRNAME="urr_red",URRID=1000,USAGERPTMODE=ONLINE,RG=10,SID=20;
   SET SOFTPARA:DT=BIT,BITNUM=1557,BITVALUE=1;
   ```

版权所有 © 华为技术有限公司
