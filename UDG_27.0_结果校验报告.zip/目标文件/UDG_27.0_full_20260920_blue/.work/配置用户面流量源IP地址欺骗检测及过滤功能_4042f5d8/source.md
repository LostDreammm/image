# 配置用户面流量源IP地址欺骗检测及过滤功能

* 操作场景
* 必备事项
* 操作步骤
* 验证方法
* 任务示例

## 操作场景

当运营商需要禁止源IP地址非法的用户上行用户面报文在网络内转发，可以在ePDG上基于Domain启用anti-spoofing功能，以避免IP地址欺骗攻击。

适用于ePDG。

## 必备事项

前提条件

无。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET CONDOMAIN** | Domain名称(DOMAINNAME) | domain1 | 本端规划 | - |
|  | 防IP欺诈开关(ANTISPOOFING) | ENABLE | 本端规划 | - |
| **ADD DOMAIN** | Domain Name(DOMAINNAME) | domain1 | 本端规划 | - |
|  | 防IP欺诈开关(ANTISPOOFING) | ENABLE | 本端规划 | - |
| **MOD DOMAIN** | Domain Name(DOMAINNAME) | domain1 | 本端规划 | - |
|  | 防IP欺诈开关(ANTISPOOFING) | ENABLE | 本端规划 | - |
| **SET IPSPOOFALMTHD** | 初始阈值(INITTHRESH) | 1500 | 本端规划 | - |
|  | 增量阈值(ADDTHRESH) | 1500 | 本端规划 |  |

## 操作步骤

1. 登录OM Portal。
2. 执行如下命令，使能Domain粒度的防IP欺诈功能。
   1. 配置构造域，使能其anti-spoofing功能。

      **SET CONDOMAIN**
   2. 使能Domain实例的anti-spoofing功能。

      **ADD DOMAIN**或**MOD DOMAIN**
3. 执行如下命令，anti spoofing开关使能状态下，设置是否产生anti spoofing告警以及何时产生告警。

   **SET IPSPOOFALMTHD**

## 验证方法

查询Domain实例的anti spoofing开关状态，以及IP spoofing攻击的告警阈值。

1. **LST CONDOMAIN**

   ```
   RETCODE = 0  Operation Success.

   The result is as follows:
   -------------------------
              Domain Name  =  domain1
     Anti-Spoofing Switch  =  ENABLE
              Lock Domain  =  DISABLE
   Deactivate Subscribers  =  DISABLE
   (Number of results = 1)
   ```

   或

   **LST DOMAIN**

   ```
   The result is as follows:
   -------------------------
              Domain Name  =  domain1
     Anti-Spoofing Switch  =  ENABLE
              Lock Domain  =  DISABLE
   Deactivate Subscribers  =  DISABLE
   (Number of results = 1)
   ```
2. **LST IPSPOOFALMTHD**

   ```
   RETCODE = 0  Operation Success.

   IP Spoofing Alarm Threshold
   ---------------------------
   Anti Spoofing Alarm Switch  =  ENABLE
            Initial Threshold  =  1500
        Consecutive Threshold  =  1500
   (Number of results = 1)
   ---    END
   ```

## 任务示例

任务描述

运营商部署anti-spoofing功能，禁止ePDG传输源IP地址非法的上行用户面流量来避免IP地址欺骗攻击。

脚本

1. 使能Domain的anti-spoofing功能。

   ```
   SET CONDOMAIN:DOMAINNAME="domain1",ANTISPOOFING=ENABLE;
   ```

   ```
   ADD DOMAIN:DOMAINNAME="domain1",ANTISPOOFING=ENABLE;
   ```

   或

   ```
   MOD DOMAIN:DOMAINNAME="domain1",ANTISPOOFING=ENABLE;
   ```
2. 设置IP spoofing攻击的告警阈值

   ```
   SET IPSPOOFALMTHD:ALARMSWITCH=ENABLE,INITTHRESH=1500,ADDTHRESH=1500;
   ```

版权所有 © 华为技术有限公司
