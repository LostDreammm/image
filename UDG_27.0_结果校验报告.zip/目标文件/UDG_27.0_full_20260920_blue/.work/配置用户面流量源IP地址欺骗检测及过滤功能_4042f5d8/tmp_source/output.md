---
id: ''
name: 配置用户面流量源IP地址欺骗检测及过滤功能
ne_type: UDG
type: feature
description: 当运营商需要禁止源IP地址非法的用户上行用户面报文在网络内转发，可以在ePDG上基于Domain启用anti-spoofing功能，以避免IP地址欺骗攻击。  适用于ePDG。
risk_level: ''
doc_source: ["网络部署","安全配置","UDG安全配置","安全配置建议","可选配置","业务安全配置","配置用户面流量源IP地址欺骗检测及过滤功能"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当运营商需要禁止源IP地址非法的用户上行用户面报文在网络内转发，可以在ePDG上基于Domain启用anti-spoofing功能，以避免IP地址欺骗攻击。适用于ePDG。

## 必备事项
前提条件

无。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    set_condomain_list:
      type: items
      properties:
        DOMAINNAME:
          name: 'Domain名称'
          type: string
          minLength: 1
          maxLength: 63
          required: true
          description: '-'
          data_source: '本端规划'
          pattern: ''
          default: ''
        ANTISPOOFING:
          name: '防IP欺诈开关'
          type: string
          enum:
          - DISABLE
          - ENABLE
          required: false
          description: '-'
          data_source: '本端规划'
          pattern: ''
          default: ''
    add_domain_list:
      type: items
      properties:
        DOMAINNAME:
          name: 'Domain Name'
          type: string
          minLength: 1
          maxLength: 63
          required: true
          description: '-'
          data_source: '本端规划'
          pattern: ''
          default: ''
        ANTISPOOFING:
          name: '防IP欺诈开关'
          type: string
          enum:
          - DISABLE
          - ENABLE
          required: false
          description: '-'
          data_source: '本端规划'
          pattern: ''
          default: ENABLE
    mod_domain_list:
      type: items
      properties:
        DOMAINNAME:
          name: 'Domain Name'
          type: string
          minLength: 1
          maxLength: 63
          required: true
          description: '-'
          data_source: '本端规划'
          pattern: ''
          default: ''
        ANTISPOOFING:
          name: '防IP欺诈开关'
          type: string
          enum:
          - DISABLE
          - ENABLE
          required: false
          description: '-'
          data_source: '本端规划'
          pattern: ''
          default: ''
    set_ipspoofalmthd_list:
      type: items
      properties:
        ALARMSWITCH:
          name: 'anti spoofing告警开关'
          type: string
          enum:
          - DISABLE
          - ENABLE
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INITTHRESH:
          name: '初始阈值'
          type: integer
          minimum: 100
          maximum: 65535
          required: false
          description: '-'
          data_source: '本端规划'
          pattern: ''
          default: ''
        ADDTHRESH:
          name: '增量阈值'
          type: integer
          minimum: 100
          maximum: 65535
          required: false
          description: ''
          data_source: '本端规划'
          pattern: ''
          default: ''
  examples:
  - set_condomain_list:
    - DOMAINNAME: 'domain1'
      ANTISPOOFING: ENABLE
    add_domain_list:
    - DOMAINNAME: 'domain1'
      ANTISPOOFING: ENABLE
    mod_domain_list:
    - DOMAINNAME: 'domain1'
      ANTISPOOFING: ENABLE
    set_ipspoofalmthd_list:
    - ALARMSWITCH: ENABLE
      INITTHRESH: 1500
      ADDTHRESH: 1500
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录OM Portal。

### 2 执行如下命令，使能Domain粒度的防IP欺诈功能。

#### 2.1 配置构造域，使能其anti-spoofing功能。

```jinja2
{%- for item in set_condomain_list -%}
    SET CONDOMAIN:
    {#- --- 必选参数 --- -#}
    DOMAINNAME="{{item.DOMAINNAME}}",
    {#- --- 可选参数 --- -#}
    {%- if item.ANTISPOOFING is not none -%}
        ANTISPOOFING={{item.ANTISPOOFING}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 2.2 使能Domain实例的anti-spoofing功能。

```jinja2
{%- for item in add_domain_list -%}
    ADD DOMAIN:
    {#- --- 必选参数 --- -#}
    DOMAINNAME="{{item.DOMAINNAME}}",
    {#- --- 可选参数 --- -#}
    {%- if item.ANTISPOOFING is not none -%}
        ANTISPOOFING={{item.ANTISPOOFING}},
    {%- endif -%}
    ;
{%- endfor -%}
```

```jinja2
{%- for item in mod_domain_list -%}
    MOD DOMAIN:
    {#- --- 必选参数 --- -#}
    DOMAINNAME="{{item.DOMAINNAME}}",
    {#- --- 可选参数 --- -#}
    {%- if item.ANTISPOOFING is not none -%}
        ANTISPOOFING={{item.ANTISPOOFING}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 3 执行如下命令，anti spoofing开关使能状态下，设置是否产生anti spoofing告警以及何时产生告警。

```jinja2
{%- for item in set_ipspoofalmthd_list -%}
    SET IPSPOOFALMTHD:
    {#- --- 必选参数 --- -#}
    ALARMSWITCH={{item.ALARMSWITCH}},
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：ALARMSWITCH=ENABLE 时可选 --- -#}
    {%- if item.ALARMSWITCH == 'ENABLE' -%}
        {%- if item.INITTHRESH is not none -%}
            INITTHRESH={{item.INITTHRESH}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：ALARMSWITCH=ENABLE 时可选 --- -#}
    {%- if item.ALARMSWITCH == 'ENABLE' -%}
        {%- if item.ADDTHRESH is not none -%}
            ADDTHRESH={{item.ADDTHRESH}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

