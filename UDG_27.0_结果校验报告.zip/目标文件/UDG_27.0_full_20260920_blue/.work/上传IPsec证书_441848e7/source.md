# 上传IPsec证书

* 操作场景
* 对系统的影响
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在IPsec VPN中，对等体间可以通过证书进行身份认证。对等体事先向证书颁发机构申请证书，在建立VPN连接之前，先验证对方证书是否合法。认证通过后，才能与对方建立连接，从而有效防止中间人攻击。

若IPSec通信双方通过预共享密钥或其他方式进行身份认证，则无需申请并上传IPSec证书。

## 对系统的影响

本特性对系统无影响。

## 必备事项

前提条件

* 操作人员已经登录OM Portal。
* 已申请并获取IPsec证书，包括CA证书、设备证书和设备证书私钥文件。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| SET PKICRLCHECK | CRL检查（ISCRLENABLE） | TRUE | 本端规划 | 可选操作，存在IPsec CA证书对应的证书吊销列表（CRL文件）时，使能CRL检查功能。 |
| ADD CERTSCENE | 场景名称（SCENENAME） | * CA证书：DeviceA\_CA * 设备证书：DeviceA\_Local | 本端规划 | 增加IPsec CA证书场景和IPsec设备证书场景。 |
|  | 场景类型（SCENETYPE） | * CA证书：CA * 设备证书：LOCAL | 本端规划 |  |
|  | 场景英文描述（ENDESCRIPTION） | * CA证书：DeviceA\_CA * 设备证书：DeviceA\_Local | 本端规划 |  |
|  | 场景中文描述（CNDESCRIPTION） | * CA证书：DeviceA\_CA * 设备证书：DeviceA\_Local | 本端规划 |  |
| DSP PKICERTLIST | 文件类型（FILETYPE） | - | 本端规划 | 查询IPsec微服务证书。 |

## 操作步骤

1. 如果存在IPsec CA证书对应的证书吊销列表（CRL文件），则使能CRL检查功能。

   SET PKICRLCHECK
2. 上传IPsec证书文件。

   选择“安全 > 证书管理>证书与证书集管理”，单击“上传证书”，分别上传IPsec CA证书和IPsec设备证书（包含设备证书私钥文件）。
3. 如果步骤 1中使能了CRL检查功能，则必须上传IPsec CRL文件。

   选择“安全 > 证书管理>上传证书吊销列表”，单击“上传证书吊销列表”，上传IPsec CRL文件。
4. 分别创建IPsec CA证书场景和IPsec设备证书场景。

   ADD CERTSCENE
5. 关联IPsec证书和证书场景。
   1. 选择“安全 > 证书管理 > 证书应用场景关联”，在证书场景列表中选择步骤 4中增加的IPsec证书场景，单击“关联证书”。
   2. 选择需要与该场景关联的IPsec证书，比如IPsec设备证书场景则选择对应的IPsec设备证书进行关联，IPsec CA证书场景则选择对应的IPsec CA证书和CRL文件进行关联。

      CA证书与CRL文件一一对应。当一个证书场景关联了多个CA证书时，如果需要启用CRL功能，那么还需要一一关联这些CA证书所对应的CRL文件。当使用IKEv1国密数字信封时，如果签名证书和加密证书配反了，需要正确配置两次以上才可恢复到正常的配置；其他情况下的证书认证，只需要正确配置一次即可。
6. 查询IPsec微服务证书列表，检查步骤 2中的证书是否已通过场景关联同步到IPsec微服务。

   DSP PKICERTLIST

## 任务示例

任务描述

以上传DeviceA的CA证书和设备证书为例，脚本不包含OM Portal操作。

脚本

//创建CA证书场景。

```
ADD CERTSCENE: SCENENAME="DeviceA_CA", SCENETYPE=CA, ENDESCRIPTION="DeviceA_CA", CNDESCRIPTION="DeviceA_CA";
```

//创建设备证书场景。

```
ADD CERTSCENE: SCENENAME="DeviceA_Local", SCENETYPE=LOCAL, ENDESCRIPTION="DeviceA_Local", CNDESCRIPTION="DeviceA_Local";
```

//查询IPsec微服务证书。

```
DSP PKICERTLIST:;
```

版权所有 © 华为技术有限公司
