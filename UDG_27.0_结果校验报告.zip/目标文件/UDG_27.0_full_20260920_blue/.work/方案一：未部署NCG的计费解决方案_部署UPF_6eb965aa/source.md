# 部署UPF

* 操作场景
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

## 操作场景

当前移动网络上承载的业务越来越丰富，运营商为了不断优化自身的服务及提升网络安全性，要求UPF能够根据数据包的分析（包括34层和7层的内容），按照预先定义的规则执行业务管理。UPF上该能力由SMF下发的Rule（规则）实现。

内容计费的配置需要做好规划，在PCF、SMF、UPF网元上统一进行配置，保证网元间配置的一致性。PCF、SMF、UPF上的配置及对应关系如图1所示。

**图1** PCF/SMF/UPF配置对应关系

## 必备事项

前提条件

* 请仔细阅读融合计费原理。
* 完成加载License。

数据

**表1** 场景1：访问网址是www.huawei.com的网站

| **类别** | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_offline\_URL | 全网规划 | 配置业务离线计费URR。 |
|  | URR标识（URRID） | 12500 |  | URRID、USAGERPTMODE、OFFMETERINGTYPE在SMF和UPF上的配置需要保持一致。  此处以按流量计费为例。 |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE |  |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | VOLUME |  |  |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_online\_URL | 全网规划 | 配置业务在线计费URR。 |
|  | URR标识（URRID） | 2300 |  | URRID、USAGERPTMODE、ONLMETERINGTYPE在SMF和UPF上的配置需要保持一致。  此处以按流量计费为例。 |
|  | 使用量上报模式（USAGERPTMODE） | ONLINE |  |  |
|  | 在线计费统计类型（ONLMETERINGTYPE） | VOLUME |  |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | UrrGp\_URL | 全网规划 | 配置URRGROUP。  说明：  URRGROUP下必须配置在线URR和离线URR，只配置一种计费模式且计费模式和用户的计费模式不匹配时无法计费。以下特殊场景除外：  当SMF使用融合计费时，SMF上的**SET USRPROFCHARGE** 、**SET APNCHARGECTRL**、**ADD CHARGEMETHOD**命令的“RGAPPLIED”配置为“DEFAULT”时，不能同时配置RG相同的离线和在线URR，否则会导致计费冲突。 |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_offline\_URL | 已配置数据中获取 | 上下行业务触发使用的离线URR，已通过**ADD URR**命令配置。 |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_offline\_URL |  |  |
|  | 上行发起URR名称2（UPURRNAME2） | urr\_online\_URL |  | 上下行业务触发使用的在线URR，已通过**ADD URR**命令配置。 |
|  | 下行发起URR名称2（DOWNURRNAME2） | urr\_online\_URL |  |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | PPG\_URL | 本端规划 | 配置PCC业务策略组。 |
|  | URR组名称（URRGROUPNAME） | UrrGp\_URL | 已配置数据中获取 | 已通过**ADD URRGROUP**命令配置。 |
| **ADD SPECURRGRPLIST** | URR组名称（URRGROUPNAME） | UrrGp\_URL | 已配置数据中获取 | 配置防欺诈URR列表。对有欺诈风险的费率，将费率加入防欺诈费率列表。 |
| **ADD FILTER** | 过滤器名字（FILTERNAME） | L34\_any | 本端规划 | 配置过滤器名字。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING |  | 字符串类型。 |
|  | 三四层协议类型（L34PROTOCOL） | ANY |  | 任意三四层协议。 |
|  | 手机起始端口号（MSSTARTPORT） | 0 |  | 设置手机起始端口号。该参数不大于手机结束端口号。 |
|  | 手机结束端口号（MSENDPORT） | 65535 |  | 设置手机结束端口号。该参数不小于手机起始端口号。 |
|  | 服务器起始端口号（SVRSTARTPORT） | 0 |  | 设置服务器起始端口号。该参数不大于服务器结束端口号。 |
|  | 服务器结束端口号（SVRENDPORT） | 65535 |  | 设置服务器结束端口号。该参数不小于服务器起始端口号。 |
| **ADD L7FILTER** | 七层过滤器名称（L7FILTERNAME） | L7\_URL | 本端规划 | 配置七层过滤器。 |
|  | 子七层过滤器名称（SUBL7FLTNAME） | http |  | 配置该L7Filter的子七层过滤器名称。 |
|  | URL类型（URLTYPE） | URL |  | 指定七层URL配置类型。  防欺诈功能开启时，RULE下绑定URL类型的7层filter时必须同时绑定三四层filter；防欺诈未开启时，RULE下可仅绑定URL类型的7层filter。 |
|  | URL（URL） | www.huawei.com |  | - |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | ff\_L7 | 本端规划 | 配置流过滤器。FLOWFILTER必须绑定过滤条件，否则该FLOWFILTER匹配失败，对应的Rule为无效配置。 |
| **ADD FLTBINDFLOWF** | 过滤器名称（FILTERNAME） | L34\_any | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER**命令配置。 |
|  | 流过滤器名称（FLOWFILTERNAME） | ff\_L7 |  | 绑定的流过滤器已通过**ADD FLOWFILTER**命令配置。 |
| **ADD PROTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | ff\_L7 | 已配置数据中获取 | 绑定的流过滤器已通过**ADD FLOWFILTER**命令配置。 |
|  | 协议名称（PROTOCOLNAME） | http | 本端规划 | - |
|  | 七层过滤器名字（L7FILTERNAME） | L7\_URL | 已配置数据中获取 | 绑定的流过滤器已通过**ADD L7FILTER**命令配置。 |
| **ADD RULE** | 规则名称（RULENAME） | Rule001\_url | 本端规划 | 配置规则。SMF、UPF上RuleName以及RULE下配置的POLICYTYPE、POLICYNAME需要保持一致。 |
|  | 策略类型（POLICYTYPE） | PCC |  | - |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER |  | - |
|  | 流过滤器名称（FLOWFILTERNAME） | ff\_L7 | 已配置数据中获取 | 使用的Flow Filter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略名称（POLICYNAME） | PPG\_URL |  | 使用的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置。 |
|  | 优先级（PRIORITY） | 100 | 本端规划 | 数字越小优先级越高。只绑定三四层filter的RULE的优先级应该低于绑定7层filter的RULE的优先级。 |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | userprofile001 | 本端规划 | USERPROFILE的名称统一规划，保证在PCF、SMF、UPF间名称一致。不一致时PCF下发的策略无法生效。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | userprofile001 | 已配置数据中获取 | 已通过**ADD USERPROFILE**命令配置。 |
|  | 规则名称（RULENAME） | Rule001\_url |  | 已通过**ADD RULE**命令配置。  SMF、UPF上USERPROFILE下绑定的RULENAME、POLICYTYPE需要保持一致。不一致策略无法按照预期生效。 |
|  | 策略类型（POLICYTYPE） | PCC |  |  |

**表2** 场景2：访问IMS业务

| **类别** | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_offline\_IMS | 全网规划 | 配置语音离线计费URR。 |
|  | URR标识（URRID） | 13500 |  | URRID、USAGERPTMODE、OFFMETERINGTYPE在SMF和UPF上的配置需要保持一致。  此处以按流量计费为例。 |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE |  |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | VOLUME |  |  |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_online\_IMS | 全网规划 | 配置语音在线计费URR。 |
|  | URR标识（URRID） | 3300 |  | URRID、USAGERPTMODE、ONLMETERINGTYPE在SMF和UPF上的配置需要保持一致。  此处以按流量计费为例。 |
|  | 使用量上报模式（USAGERPTMODE） | ONLINE |  |  |
|  | 在线计费统计类型（ONLMETERINGTYPE） | VOLUME |  |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | UrrGp\_IMS | 本端规划 | 配置URRGROUP。  说明：  URRGROUP下必须配置在线URR和离线URR，只配置一种计费模式且计费模式和用户的计费模式不匹配时无法计费。以下特殊场景除外：  当SMF使用融合计费时，SMF上的**SET USRPROFCHARGE** 、**SET APNCHARGECTRL**、**ADD CHARGEMETHOD**命令的“RGAPPLIED”配置为“DEFAULT”时，URRGROUP下不能同时配置离线和在线URR，否则会导致计费冲突。 |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_offline\_IMS | 已配置数据中获取 | 上下行业务触发使用的离线URR，已通过**ADD URR**命令配置。 |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_offline\_IMS |  |  |
|  | 上行发起URR名称2（UPURRNAME2） | urr\_online\_IMS |  | 上下行业务触发使用的在线URR，已通过**ADD URR**命令配置。 |
|  | 下行发起URR名称2（DOWNURRNAME2） | urr\_online\_IMS |  |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | PPG\_IMS | 本端规划 | 配置PCC业务策略组。 |
|  | URR组名称（URRGROUPNAME） | UrrGp\_IMS | 已配置数据中获取 | 已通过**ADD URRGROUP**命令配置。 |
| **ADD FILTERIPV6** | 过滤器名字（FILTERNAME） | ipv6\_ims | 本端规划 | 配置过滤器名字。 |
|  | 三四层IPv6协议输入类型（L34PROTTYPEV6） | STRING |  | 字符串类型。 |
|  | 三四层协议类型（L34PROTOCOL） | ANY |  | 任意三四层协议。 |
|  | 服务器IP地址配置模式（SVRIPMODE） | IP | 与对端协商 | 参数取值取决于服务器侧的IP地址配置模式。 |
|  | 手机起始端口号（MSSTARTPORT） | 0 |  |  |
|  | 手机结束端口号（MSENDPORT） | 65535 |  |  |
|  | 服务器起始端口号（SVRSTARTPORT） | 0 |  |  |
|  | 服务器结束端口号（SVRENDPORT） | 65535 |  |  |
|  | 服务器IPv6地址（SVRIPV6） | fc00:8028:5002:10D::181 |  |  |
|  | 服务器IPv6地址掩码类型（SVRIPV6MASKTYPE） | LENGTHTYPE |  |  |
|  | 服务器IPv6地址掩码长度（SVRIPV6MASKLEN） | 128 |  |  |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | ff\_IMS | 本端规划 | 配置流过滤器。FLOWFILTER必须绑定过滤条件，否则该FLOWFILTER匹配失败，对应的Rule为无效配置。 |
| **ADD FLTBINDFLOWF** | 过滤器名称（FILTERNAME） | ipv6\_ims | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER**命令配置。 |
|  | 流过滤器名称（FLOWFILTERNAME） | ff\_IMS |  | 绑定的流过滤器已通过**ADD FLOWFILTER**命令配置。 |
| **ADD RULE** | 规则名称（RULENAME） | Rule002\_IMS | 本端规划 | 配置规则。RULENAME在SMF和UPF上的配置需要保持一致。 |
|  | 策略类型（POLICYTYPE） | PCC |  | - |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER |  | - |
|  | 流过滤器名称（FLOWFILTERNAME） | ff\_IMS | 已配置数据中获取 | 使用的Flow Filter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略名称（POLICYNAME） | PPG\_IMS |  | 使用的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置。 |
|  | 优先级（PRIORITY） | 110 | 本端规划 | 数字越小优先级越高。只绑定三四层filter的RULE的优先级应该低于绑定7层filter的RULE的优先级。 |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | userprofile002 | 本端规划 | USERPROFILE的名称统一规划，保证在PCF、SMF、UPF间名称一致。不一致时PCF下发的策略无法生效。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | userprofile002 | 已配置数据中获取 | 已通过**ADD USERPROFILE**命令配置。 |
|  | 规则名称（RULENAME） | Rule002\_IMS |  | 已通过**ADD RULE**命令配置。  SMF、UPF上USERPROFILE下绑定的RULENAME、POLICYTYPE需要保持一致。不一致策略无法按照预期生效。 |

**表3** 场景3：访问除了上述两种情况外的基础业务，过滤条件为any的Rule

| **类别** | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_offline\_any | 全网规划 | 配置业务离线计费URR。 |
|  | URR标识（URRID） | 11500 |  | URRID、USAGERPTMODE、OFFMETERINGTYPE在SMF和UPF上的配置需要保持一致。 |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE |  |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | VOLUME |  |  |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_online\_any | 全网规划 | 配置业务在线计费URR。 |
|  | URR标识（URRID） | 1300 |  | URRID、USAGERPTMODE、ONLMETERINGTYPE在SMF和UPF上的配置需要保持一致。 |
|  | 使用量上报模式（USAGERPTMODE） | ONLINE |  |  |
|  | 在线计费统计类型（ONLMETERINGTYPE） | VOLUME |  |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | UrrGp\_any | 本端规划 | 配置URRGROUP。  说明：  URRGROUP下必须配置在线URR和离线URR，只配置一种计费模式且计费模式和用户的计费模式不匹配时无法计费。以下特殊场景除外：  当SMF使用融合计费时，SMF上的**SET USRPROFCHARGE** 、**SET APNCHARGECTRL**、**ADD CHARGEMETHOD**命令的“RGAPPLIED”配置为“DEFAULT”时，URRGROUP下不能同时配置离线和在线URR，否则会导致计费冲突。 |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_offline\_any | 已配置数据中获取 | 上下行业务触发使用的离线URR，已通过**ADD URR**命令配置。 |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_offline\_any |  |  |
|  | 上行发起URR名称2（UPURRNAME2） | urr\_online\_any |  | 上下行业务触发使用的在线URR，已通过**ADD URR**命令配置。 |
|  | 下行发起URR名称2（DOWNURRNAME2） | urr\_online\_any |  |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | PPG\_any | 本端规划 | 配置PCC业务策略组。 |
|  | URR组名称（URRGROUPNAME） | UrrGp\_any | 已配置数据中获取 | 已通过**ADD URRGROUP**命令配置。 |
| **ADD FILTER** | 过滤器名字（FILTERNAME） | L34\_any | 本端规划 | 配置IPv4 any to any过滤器名字。UPF通过将用户上下行报文匹配filter，实现报文的过滤。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING |  | 字符串类型。 |
|  | 三四层协议类型（L34PROTOCOL） | ANY |  | 任意三四层协议。 |
|  | 手机起始端口号（MSSTARTPORT） | 0 |  | 设置手机起始端口号。该参数不大于手机结束端口号。 |
|  | 手机结束端口号（MSENDPORT） | 65535 |  | 设置手机结束端口号。该参数不小于手机起始端口号。 |
|  | 服务器起始端口号（SVRSTARTPORT） | 0 |  | 设置服务器起始端口号。该参数不大于服务器结束端口号。 |
|  | 服务器结束端口号（SVRENDPORT） | 65535 |  | 设置服务器结束端口号。该参数不小于服务器起始端口号。 |
| **ADD FILTERIPV6** | 过滤器名字（FILTERNAME） | L34\_any\_ipv6 | 本端规划 | 配置IPv6 any to any过滤器名字。UPF通过将用户上下行报文匹配filter，实现报文的过滤。 |
|  | 三四层IPv6协议输入类型（L34PROTTYPEV6） | STRING |  | 字符串类型。 |
|  | 三四层协议类型（L34PROTOCOL） | ANY |  | 任意三四层协议。 |
|  | 手机起始端口号（MSSTARTPORT） | 0 |  | 设置手机起始端口号。该参数不大于手机结束端口号。 |
|  | 手机结束端口号（MSENDPORT） | 65535 |  | 设置手机结束端口号。该参数不小于手机起始端口号。 |
|  | 服务器起始端口号（SVRSTARTPORT） | 0 |  | 设置服务器起始端口号。该参数不大于服务器结束端口号。 |
|  | 服务器结束端口号（SVRENDPORT） | 65535 |  | 设置服务器结束端口号。该参数不小于服务器起始端口号。 |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | ff\_L34any | 本端规划 | 配置流过滤器。FLOWFILTER必须绑定过滤条件，否则该FLOWFILTER匹配失败，对应的rule为无效配置。 |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | ff\_L34any\_IPv6 | 本端规划 | 配置流过滤器。FLOWFILTER必须绑定过滤条件，否则该FLOWFILTER匹配失败，对应的rule为无效配置。 |
| **ADD FLTBINDFLOWF** | 过滤器名称（FILTERNAME） | L34\_any | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER**命令配置。 |
|  | 流过滤器名称（FLOWFILTERNAME） | ff\_L34any |  | 绑定的流过滤器已通过**ADD FLOWFILTER**命令配置。 |
| **ADD FLTBINDFLOWF** | 过滤器名称（FILTERNAME） | L34\_any\_ipv6 | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER**命令配置。 |
|  | 流过滤器名称（FLOWFILTERNAME） | ff\_L34any\_IPv6 |  | 绑定的流过滤器已通过**ADD FLOWFILTER**命令配置。 |
| **ADD RULE** | 规则名称（RULENAME） | Rule003\_any | 本端规划 | 配置规则。   * RULENAME在SMF和UPF上的配置需要保持一致。 * 不配置过滤条件为any的RULE时，没有明确规划匹配规则的业务无法进行。 |
|  | 策略类型（POLICYTYPE） | PCC |  | - |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER |  | - |
|  | 流过滤器名称（FLOWFILTERNAME） | ff\_L34any | 已配置数据中获取 | 使用的Flow Filter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略名称（POLICYNAME） | PPG\_any |  | 使用的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置。 |
|  | 优先级（PRIORITY） | 65000 | 本端规划 | 数字越小优先级越高。过滤条件为any的RULE，优先级设置为最低。 |
| **ADD RULE** | 规则名称（RULENAME） | Rule003\_any\_IPv6 | 本端规划 | 配置规则。   * RULENAME在SMF和UPF上的配置需要保持一致。 * 不配置过滤条件为any的RULE时，没有明确规划匹配规则的业务无法进行。 |
|  | 策略类型（POLICYTYPE） | PCC |  | - |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER |  | - |
|  | 流过滤器名称（FLOWFILTERNAME） | ff\_L34any\_IPv6 | 已配置数据中获取 | 使用的Flow Filter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略名称（POLICYNAME） | PPG\_any |  | 使用的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置。 |
|  | 优先级（PRIORITY） | 65010 | 本端规划 | 数字越小优先级越高。过滤条件为any的RULE，优先级设置为最低。 |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | userprofile001 | 本端规划 | USERPROFILE的名称统一规划，保证在PCF、SMF、UPF间名称一致。不一致时PCF下发的策略无法生效。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | userprofile001 | 已配置数据中获取 | 已通过**ADD USERPROFILE**命令配置。 |
|  | 规则名称（RULENAME） | Rule003\_any |  | 已通过**ADD RULE**命令配置。  SMF、UPF上USERPROFILE下绑定的RULENAME、POLICYTYPE需要保持一致。不一致策略无法按照预期生效。 |
|  | 策略类型（POLICYTYPE） | PCC |  |  |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | userprofile001 | 已配置数据中获取 | 已通过**ADD USERPROFILE**命令配置。 |
|  | 规则名称（RULENAME） | Rule003\_any\_IPv6 |  | 已通过**ADD RULE**命令配置。  SMF、UPF上USERPROFILE下绑定的RULENAME、POLICYTYPE需要保持一致。不一致策略无法按照预期生效。 |
|  | 策略类型（POLICYTYPE） | PCC |  |  |

**表4** 场景4：配置未匹配中过滤条件的异常场景流量的计费方式

| **类别** | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | URR\_abnormal\_offline | 全网规划 | 配置业务离线计费URR。 |
|  | URR标识（URRID） | 14500 |  | URRID、USAGERPTMODE、OFFMETERINGTYPE在SMF和UPF上的配置需要保持一致。 |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE |  |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | FREE |  |  |
| **ADD URR** | 使用量上报规则名称（URRNAME） | URR\_abnormal\_online | 全网规划 | 配置业务在线计费URR。 |
|  | URR标识（URRID） | 4300 |  | URRID、USAGERPTMODE、ONLMETERINGTYPE在SMF和UPF上的配置需要保持一致。 |
|  | 使用量上报模式（USAGERPTMODE） | ONLINE |  |  |
|  | 在线计费统计类型（ONLMETERINGTYPE） | FREE |  |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | UrrGp\_abnormal | 本端规划 | 配置URRGROUP。  说明：  URRGROUP下必须配置在线URR和离线URR，只配置一种计费模式且计费模式和用户的计费模式不匹配时无法计费。以下特殊场景除外：  当SMF使用融合计费时，SMF上的**SET USRPROFCHARGE** 、**SET APNCHARGECTRL**、**ADD CHARGEMETHOD**命令的“RGAPPLIED”配置为“DEFAULT”时，URRGROUP下不能同时配置离线和在线URR，否则会导致计费冲突。 |
|  | 上行发起URR名称1（UPURRNAME1） | URR\_abnormal\_offline | 已配置数据中获取 |  |
|  | 下行发起URR名称1（DOWNURRNAME1） | URR\_abnormal\_offline |  |  |
|  | 上行发起URR名称2（UPURRNAME2） | URR\_abnormal\_online |  |  |
|  | 下行发起URR名称2（DOWNURRNAME2） | URR\_abnormal\_online |  |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | PPG\_any | 本端规划 | 配置PCC业务策略组。 |
|  | 信令URR组名称（SIGURRGRPNAME） | UrrGp\_abnormal | 已配置数据中获取 | 已通过**ADD URRGROUP**命令配置。 |
| **SET URRGRPBINDING** | 用户模板名称（USERPROFILENAME） | userprofile001 | 已配置数据中获取 | 已通过**ADD USERPROFILE**命令配置生成。  说明：  USERPROFILE需要将缺省业务和缺省信令的URR组都配置完整，不配置时按照RULE没有匹配到URR的报文无法计费。 |
|  | 缺省URR组名称（DFTURRGRPNAME） | UrrGp\_any |  | 已通过**ADD URRGROUP**命令配置生成。 |
|  | 缺省信令URR组名称（DFTSIGURRGNAME） | UrrGp\_abnormal |  | 已通过**ADD URRGROUP**命令配置生成。 |
|  | 继承全局缺省URR组配置开关（GLBDFTURRGSW） | ENABLE |  | 已通过**SET SPECTRAFURRGRP**命令配置生成。 |
|  | 继承全局缺省信令URR组开关（GLBDFTSIGURRGSW） | ENABLE |  | 已通过**SET SPECTRAFURRGRP**命令配置生成。 |
| **SET SPECTRAFURRGRP** | 特殊流量使用量上报规则组名称（URRGROUPNAME） | UrrGp\_abnormal | 已配置数据中获取 | 该参数使用**ADD URRGROUP**命令配置生成。  说明：  * BIT1232软参值设置为1时，特殊流量通过该规则组进行计费。特殊流量是指当某些业务报文丢失，未能完成七层精确匹配时，已经转发的流量。 例如，在线计费用户下线时，业务流只有信令报文，没有业务报文。在这种场景下，已经转发的信令报文的流量称为特殊流量。 * 对于没有配置任何URR的业务场景，通过该URR组进行计费。 |
| **SET REFRESHSRV** | 刷新类型（REFRESHTYPE） | ALL | 本端规划 | 刷新Filter。 |

## 操作流程

新增或修改内容计费业务分为如下几个配置步骤：

**图2** 部署UPF流程图

1. 配置业务URR组。配置业务流规则匹配的URR、计费方式（在线、离线）。URR和计费方式通过**ADD URR**命令配置，可以通过**ADD URRGROUP**命令为上行报文和下行报文分别配置URR。对应的操作步骤见步骤 1-步骤 2。
2. 配置过滤规则。过滤规则包含三四层过滤条件和七层过滤条件。三四层过滤条件包含IPV4协议和IPV6协议，通过**ADD FILTER**、**ADD FILTERIPV6**命令配置；七层过滤条件通过**ADD L7FILTER**命令配置。将多个三、四层过滤条件和七层过滤条件可以聚合为一个业务流过滤器，通过**ADD FLTBINDFLOWF**、**ADD PROTBINDFLOWF**命令和FLOWFILTER绑定实现。对应的操作步骤见步骤 3-步骤 5。
3. 将业务URR和业务过滤器绑定为业务策略规则，业务策略规则通过**ADD RULE**命令配置。对应的操作步骤见步骤 6。
4. 配置USERPROFILE。通过**ADD USERPROFILE**命令配置规则组，通过**ADD RULEBINDING**命令将业务策略规则关联到USERPROFILE。对应的操作步骤见步骤 7-步骤 8。
5. 配置缺省URR组和全局缺省URR组。通过**SET URRGRPBINDING**配置规则组下的默认URR组，通过**SET SPECTRAFURRGRP**配置全局缺省URR组。对应的操作步骤见步骤 9-步骤 10。

## 操作步骤

1. 配置使用量上报规则组属性。
   1. 配置URR。

      **ADD URR**
   2. 配置URR组。

      **ADD URRGROUP**
2. 配置PCC策略组，并与PCC动作属性、URR组绑定。

   **ADD PCCPOLICYGRP**
3. 配置过滤条件。
   * 配置三四层过滤条件。

     **ADD FILTER**
   * 配置七层过滤条件。

     **ADD L7FILTER**
4. 配置流过滤器。

   **ADD FLOWFILTER**
5. 将流过滤器与过滤条件绑定。
   1. 将已配置的三四层过滤条件与流过滤器绑定。

      **ADD FLTBINDFLOWF**
   2. 将已配置的七层过滤条件、协议与流过滤器绑定。

      **ADD PROTBINDFLOWF**
6. 添加规则，并与PCC策略组和流过滤器绑定。

   **ADD RULE**
7. 添加User Profile。

   **ADD USERPROFILE**
8. 将规则与User Profile绑定。

   **ADD RULEBINDING**
9. 配置缺省URR组。

   **SET URRGRPBINDING**
10. 配置全局缺省URR组。

    **SET SPECTRAFURRGRP**
11. 配置防欺诈URR列表。

    **ADD SPECURRGRPLIST**
12. 将新配置的Filter置为生效。

    **SET REFRESHSRV**

## 任务示例

任务描述

配置User Profile，并且配置三个不同的规则与该User Profile绑定。规则的具体要求如下：

场景1：访问网址是www.huawei.com的网站。

场景2：访问IMS业务。

场景3：访问除了上述两种情况外的基础业务，过滤条件为any的Rule。

场景4：配置未匹配中过滤条件的异常场景流量的计费方式。

脚本

//配置URR。URRID、USAGERPTMODE、OFFMETERINGTYPE、ONLMETERINGTYPE在SMF和UPF上的配置需要保持一致。

```
//配置网址是www.huawei.com的网站业务的URR。
ADD URR:URRNAME="urr_offline_URL", URRID=12500, USAGERPTMODE=OFFLINE, OFFMETERINGTYPE=VOLUME;
ADD URR:URRNAME="urr_online_URL", URRID=2300, USAGERPTMODE=ONLINE, ONLMETERINGTYPE=VOLUME;
//配置语音业务的URR。
ADD URR:URRNAME="urr_offline_IMS", URRID=13500, USAGERPTMODE=OFFLINE, OFFMETERINGTYPE=VOLUME;
ADD URR:URRNAME="urr_online_IMS", URRID=3300, USAGERPTMODE=ONLINE, ONLMETERINGTYPE=VOLUME;
//访问除了上述两种情况外的基础业务的URR。
ADD URR:URRNAME="urr_offline_any",URRID=11500,USAGERPTMODE=OFFLINE,OFFMETERINGTYPE=VOLUME;
ADD URR:URRNAME="urr_online_any",URRID=1300,USAGERPTMODE=ONLINE,ONLMETERINGTYPE=VOLUME;
//配置未匹配中过滤条件的异常场景的URR。
ADD URR:URRNAME="URR_abnormal_offline",URRID=14500,USAGERPTMODE=OFFLINE,OFFMETERINGTYPE=FREE;
ADD URR:URRNAME="URR_abnormal_online",URRID=4300,USAGERPTMODE=ONLINE,ONLMETERINGTYPE=FREE;
```

//配置URRGROUP。

```
//配置网址是www.huawei.com的网站的URRGROUP。
ADD URRGROUP:URRGROUPNAME="UrrGp_URL", UPURRNAME1="urr_offline_URL", DOWNURRNAME1="urr_offline_URL", UPURRNAME2="urr_online_URL", DOWNURRNAME2="urr_online_URL";
//配置语音业务的URRGROUP。
ADD URRGROUP:URRGROUPNAME="UrrGp_IMS", UPURRNAME1="urr_offline_IMS", DOWNURRNAME1="urr_offline_IMS", UPURRNAME2="urr_online_IMS", DOWNURRNAME2="urr_online_IMS";
//访问除了上述两种情况外的基础业务的URRGROUPR。
ADD URRGROUP:URRGROUPNAME="UrrGp_any",UPURRNAME1="urr_offline_any",DOWNURRNAME1="urr_offline_any",UPURRNAME2="urr_online_any",DOWNURRNAME2="urr_online_any";
//配置未匹配中过滤条件的异常场景的URRGROUP。
ADD URRGROUP:URRGROUPNAME="UrrGp_abnormal",UPURRNAME1="URR_abnormal_offline",DOWNURRNAME1="URR_abnormal_offline",UPURRNAME2="URR_abnormal_online",DOWNURRNAME2="URR_abnormal_online";
```

//配置PCC业务策略组。

```
//配置网址是www.huawei.com的网站的PCC业务策略组，绑定URRGROUP。
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="PPG_URL", URRGROUPNAME="UrrGp_URL";
//配置语音业务的PCC业务策略组，绑定URRGROUP。
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="PPG_IMS", URRGROUPNAME="UrrGp_IMS";
//访问除了上述两种情况外的基础业务的PCC业务策略组，绑定URRGROUP。
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="PPG_any", URRGROUPNAME="UrrGp_any", SIGURRGRPNAME="UrrGp_abnormal";
```

//配置特殊URR组列表。比如，对有欺诈风险的费率，将费率加入防欺诈费率列表，此处以避免用户访问www.huawei.com的网站欺诈举例。

```
ADD SPECURRGRPLIST:URRGROUPNAME="UrrGp_URL";
```

//配置过滤规则。

```
//配置场景1的www.huawei.com的网站的三四层/七层过滤器和流过滤器。FLOWFILTER必须绑定过滤条件，否则该FLOWFILTER匹配失败，对应的rule为无效配置。
ADD FILTER: FILTERNAME="L34_any", L34PROTTYPE=STRING, L34PROTOCOL=ANY, MSSTARTPORT=0, MSENDPORT=65535, SVRSTARTPORT=0, SVRENDPORT=65535;
ADD L7FILTER: L7FILTERNAME="L7_URL", SUBL7FLTNAME="http", URLTYPE=URL, URL="www.huawei.com";
ADD FLOWFILTER: FLOWFILTERNAME="ff_L7"; 
ADD FLTBINDFLOWF: FLOWFILTERNAME="ff_L7", FILTERNAME="L34_any";
ADD PROTBINDFLOWF: FLOWFILTERNAME="ff_L7", PROTOCOLNAME="http", L7FILTERNAME="L7_URL";
```

```
//配置场景2语音业务的三四层过滤器和流过滤器，并将两者绑定。FLOWFILTER必须绑定过滤条件，否则该FLOWFILTER匹配失败，对应的rule为无效配置。
ADD FILTERIPV6:FILTERNAME="ipv6_ims", L34PROTTYPEV6=STRING, L34PROTOCOL=ANY, SVRIPMODE=IP, MSSTARTPORT=0, MSENDPORT=65535, SVRSTARTPORT=0, SVRENDPORT=65535, SVRIPV6="fc00:8028:5002:10D::181", SVRIPV6MASKTYPE=LENGTHTYPE, SVRIPV6MASKLEN=128;
ADD FLOWFILTER: FLOWFILTERNAME="ff_IMS";
ADD FLTBINDFLOWF: FLOWFILTERNAME="ff_IMS", FILTERNAME="ipv6_ims";
```

```
//配置场景3的any的基础业务三四层过滤器和流过滤器，并将两者绑定。FLOWFILTER必须绑定过滤条件，否则该FLOWFILTER匹配失败，对应的rule为无效配置。
ADD FILTERIPV6:FILTERNAME="L34_any_ipv6", L34PROTTYPEV6=STRING, L34PROTOCOL=ANY, MSSTARTPORT=0, MSENDPORT=65535, SVRSTARTPORT=0, SVRENDPORT=65535;
ADD FLOWFILTER: FLOWFILTERNAME="ff_L34any";
ADD FLOWFILTER: FLOWFILTERNAME="ff_L34any_IPv6";
ADD FLTBINDFLOWF: FLOWFILTERNAME="ff_L34any", FILTERNAME="L34_any";
ADD FLTBINDFLOWF: FLOWFILTERNAME="ff_L34any_IPv6", FILTERNAME="L34_any_ipv6";
```

//配置规则，并绑定已配置的流过滤器和PCC策略组。SMF、UPF上RULENAME以及RULE下配置的POLICYTYPE、POLICYNAME需要保持一致。

```
//只绑定三四层filter的RULE的优先级应该低于绑定7层filter的RULE的优先级。过滤条件为any的RULE，优先级设置为最低。
ADD RULE: RULENAME="Rule001_url", POLICYTYPE=PCC, FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="ff_L7", POLICYNAME="PPG_URL", PRIORITY=100;
ADD RULE: RULENAME="Rule002_IMS", POLICYTYPE=PCC, FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="ff_IMS", POLICYNAME="PPG_IMS", PRIORITY=110;
ADD RULE: RULENAME="Rule003_any", POLICYTYPE=PCC, FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="ff_L34any", POLICYNAME="PPG_any", PRIORITY=65000;
ADD RULE: RULENAME="Rule003_any_IPv6", POLICYTYPE=PCC, FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="ff_L34any_IPv6", POLICYNAME="PPG_any", PRIORITY=65010;
```

//添加User Profile。USERPROFILE的名称统一规划，保证在PCF、SMF、UPF间名称一致。不一致时PCF下发的策略无法生效。

```
ADD USERPROFILE: USERPROFILENAME="userprofile001";
ADD USERPROFILE: USERPROFILENAME="userprofile002";
```

//将Rule绑定到User Profile。SMF、UPF上USERPROFILE下绑定的RULENAME、POLICYTYPE需要保持一致。不一致策略无法按照预期生效。

```
ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule001_url", POLICYTYPE=PCC;
ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule003_any", POLICYTYPE=PCC;
ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule003_any_IPv6", POLICYTYPE=PCC;
ADD RULEBINDING: USERPROFILENAME="userprofile002", RULENAME="Rule002_IMS";
```

//配置User Profile的缺省URR组。USERPROFILE需要将缺省业务和缺省信令的URR组都配置完整，不配置时按照RULE没有匹配到URR的报文无法计费。

```
SET URRGRPBINDING:USERPROFILENAME="userprofile001", DFTURRGRPNAME="UrrGp_any", DFTSIGURRGNAME="UrrGp_abnormal", GLBDFTURRGSW=ENABLE, GLBDFTSIGURRGSW=ENABLE;
```

//配置全局缺省URR组，当SET URRGRPBINDING中的缺省URR组未配置时可以继承全局缺省URR组配置。

```
SET SPECTRAFURRGRP: URRGROUPNAME="UrrGp_abnormal";
```

//将配置的所有Filter置为生效。不执行SET REFRESHSRV命令FILTER的配置变更不会生效。

```
SET REFRESHSRV: REFRESHTYPE=ALL;
```

版权所有 © 华为技术有限公司
