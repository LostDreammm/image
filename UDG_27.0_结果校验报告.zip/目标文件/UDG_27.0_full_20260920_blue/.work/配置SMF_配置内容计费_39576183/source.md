# 配置内容计费

* 操作场景
* 对系统的影响
* 必备事项
* 任务示例

## 操作场景

用户访问园区业务时，智能分流SMF发起园区专网会话创建，数据流被分流到专网UPF上，需要在专网SMF和专网UPF上针对园区业务配置内容计费规则。

场景一：运营商对于园区业务未规划单独费率，则使用缺省费率（RG= 2000000002）。

场景二：运营商对于园区业务的费率有单独规划，按照运营商规划配置对应的费率。

此配置页面内容计费中的URR、PCCPOLICYGRPNM（PCC策略组名称）、RULENAME（规则名称）、USERPROFILENAME（用户模板名称）等需要与专网UPF和PCF中的名称保持一致。

UPF的相关配置参见配置内容计费，PCF的相关配置参见配置专用DNN策略数据。

## 对系统的影响

无。

## 必备事项

前提条件

已参考运营商配置规范完成网元的基本配置。

数据

场景一：运营商对于园区业务未规划单独费率，则使用缺省费率（RG= 2000000002）。

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | common\_01\_ch\_p | 本端规划 | 内容计费规则：URR组。 |
|  | 上行发起URR名称1（UPURRNAME1） | common\_01\_cbb\_online | 本端规划 |  |
|  | 下行发起URR名称1（DOWNURRNAME1） | common\_01\_cbb\_online | 本端规划 |  |
|  | 上行发起URR名称2（UPURRNAME2） | common\_01\_cbb\_offline | 本端规划 |  |
|  | 下行发起URR名称2（DOWNURRNAME2） | common\_01\_cbb\_offline | 本端规划 |  |
|  | 不计费标记（NOCHARGINGFLAG） | NONE | 本端规划 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | common\_01\_pcc\_p\_g | 本端规划 | - |
|  | URR组名称（URRGROUPNAME） | common\_01\_ch\_p | 已配置数据中获取 | 使用**ADD URRGROUP**命令定义的“URRGROUPNAME”。 |
|  | Session级FUP累计标识（FUPSESSIONEXC） | DISABLE | 本端规划 | - |
| **ADD RULE** | 规则名称（RULENAME） | common\_any  common\_any\_ipv6\_r | 本端规划 | SMF配置的Rule名称需要和UPF配置的Rule名称一致，且与PCF下发的PCC规则保持一致。 |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | - |
|  | 全局优先级（PRIORITY） | 65000  65010 | 本端规划 | Rule优先级需要和UPF的 Rule优先级一致， |
|  | 策略名称（POLICYNAME） | common\_01\_pcc\_p\_g | 已配置数据中获取 | 使用**ADD URRGROUP**命令定义的“URRGROUPNAME”。 |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | u\_p\_multi\_default | 本端规划 | PCF下发的PCC规则需要和SMF、UPF上配置UserProfileName的一致。 |
|  | 用户模板类型（UPTYPE） | PCC | 全网规划 |  |
|  | 免费业务在线计费标识（FREESERONLCHG） | ENABLE | 本端规划 |  |
|  | 免费业务离线计费标识（FREESEROFFCHG） | ENABLE | 本端规划 |  |
|  | 免费业务融合计费标识（FREESERCVGCHG） | ENABLE | 本端规划 |  |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | u\_p\_multi\_default | 本端规划 | 使用**ADD USERPROFILE**令定义的“USERPROFILENAME”。 |
|  | 规则名称（RULENAME） | common\_any  common\_any\_ipv6\_r | 本端规划 | 使用**ADD RULE**令定义的“RULENAME”。 |

场景二：运营商对于园区业务的费率有单独规划，按照运营商规划配置对应的费率。

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | multi\_01\_cbb\_online  multi\_01\_cbb\_offline | 本端规划 | 该命令配置一个URR规则，同一个RG对在线计费需要配置在线计费的URR ID，对离线计费需要配置离线计费的URR ID。  同一个RG对应的在线、离线计费URR ID取值必须不同。可以按照在线计费URRID=RG，离线计费URRID=RG+10000做映射。 |
|  | URR标识（URRID） | 2000000003 | 全网规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | ONLINE  OFFLINE | 全网规划 |  |
|  | 在线计费标识组成类型（ONLCOMPOUNDTYPE） | ONLYRG | 全网规划 |  |
|  | 离线计费标识组成类型（OFFCOMPOUNDTYPE） | ONLYRG | 全网规划 |  |
|  | 在线计费组（ONLINERG） | 2000000003 | 本端规划 |  |
|  | 离线计费组（RG） | 2000000003 | 本端规划 |  |
|  | 在线计费统计类型（ONLMETERINGTYPE） | VOLUME | 全网规划 |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | VOLUME | 全网规划 |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | multi\_01\_ch\_p | 本端规划 | 该命令配置一个URR组。 |
|  | 上行发起URR名称1（UPURRNAME1） | multi\_01\_cbb\_online | 本端规划 |  |
|  | 下行发起URR名称1（DOWNURRNAME1） | multi\_01\_cbb\_online | 本端规划 |  |
|  | 上行发起URR名称2（UPURRNAME2） | multi\_01\_cbb\_offline | 本端规划 |  |
|  | 下行发起URR名称2（DOWNURRNAME2） | multi\_01\_cbb\_offline | 本端规划 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | multi\_01\_pcc\_p\_g | 本端规划 | - |
|  | URR组名称（URRGROUPNAME） | multi\_01\_ch\_p | 已配置数据中获取 | 使用**ADD URRGROUP**命令定义的“URRGROUPNAME”。 |
| **ADD RULE** | 规则名称（RULENAME） | multi\_01\_r  multi\_01\_ipv6\_r | 本端规划 | SMF配置的Rule名称需要和UPF配置的Rule名称一致，且与PCF下发的PCC规则保持一致。 |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | - |
|  | 全局优先级（PRIORITY） | 60000  60010 | 本端规划 | Rule优先级需要和UPF的 Rule优先级一致， |
|  | 策略名称（POLICYNAME） | multi\_01\_pcc\_p\_g | 已配置数据中获取 | 使用**ADD URRGROUP**命令定义的“URRGROUPNAME”。 |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | u\_p\_01\_multi | 本端规划 | PCF下发的PCC规则需要和SMF、UPF上配置UserProfileName的一致。 |
|  | 用户模板类型（UPTYPE） | PCC | 全网规划 |  |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | u\_p\_01\_multi | 本端规划 | 使用**ADD USERPROFILE**令定义的“USERPROFILENAME”。 |
|  | 规则名称（RULENAME） | multi\_01\_r  multi\_01\_ipv6\_r | 本端规划 | 使用**ADD RULE**令定义的“RULENAME”。 |

## 任务示例

任务描述

任务一：园区业务未规划单独费率，则使用现网普通2C用户的兜底计费规则（费率为2000000002），在园区专用DNN下默认绑定兜底计费规则。

任务二：园区业务规划单独的费率，则根据园区规划，规划单独的费率，在SMF配置对应的计费策略，并且需要PCF针对该计费规则做下发。

脚本

任务一： 园区业务未规划单独费率，使用缺省费率。

1. 假设5GC设备使用common\_01\_cbb\_online和common\_01\_cbb\_offline两个URR作为使用量上报规则，执行LST URR:URRNAME="common\_01\_cbb\_online";和LST URR:URRNAME="common\_01\_cbb\_offline";命令查询设备是否已经配置缺省费率。如下，查询的结果中若包含如下红色字体，则说明已经配置缺省费率（部分省份可能使用的URRNAME稍有差异，可以在配置中搜索RG=2000000002，找到对应的缺省费率规则组）。

   ```
   %%LST URR:URRNAME="common_01_cbb_online";%%
   RETCODE = 0  操作成功
   使用量上报规则信息：
   --------------------
   使用量上报规则名称  =  common_01_cbb_online
   URR标识  =  2000000002
   使用量上报模式  =  在线计费
   离线计费标识组成类型  =  费率组
   离线计费组  =  4294967295
   离线业务标识  =  4294967295
   离线上行业务标识  =  4294967295
   离线下行业务标识  =  4294967295
   离线计费统计类型  =  流量
   离线业务模板名  =  NULL
   在线计费标识组成类型  =  费率组
   在线计费组  =  2000000002
   在线业务标识  =  4294967295
   在线计费统计类型  =  流量
   流量配额值（字节）  =  0
   时间配额值（秒）  =  0
   Gy重定向结束Token  =  NULL
   监控属性值  =  NULL
   事件配额值（次）  =  0
   (结果个数 = 1)
   ---    END
   %%LST URR:URRNAME="common_01_cbb_offline";%%
   RETCODE = 0  操作成功
   使用量上报规则信息：
   --------------------
   使用量上报规则名称  =  common_01_cbb_offline
   URR标识  =  2000010002
   使用量上报模式  =  离线计费
   离线计费标识组成类型  =  费率组
   离线计费组  =  2000000002
   离线业务标识  =  4294967295
   离线上行业务标识  =  4294967295
   离线下行业务标识  =  4294967295
   离线计费统计类型  =  流量
   离线业务模板名  =  NULL
   在线计费标识组成类型  =  费率组
   在线计费组  =  4294967295
   在线业务标识  =  4294967295
   在线计费统计类型  =  流量
   流量配额值（字节）  =  0
   时间配额值（秒）  =  0
   Gy重定向结束Token  =  NULL
   监控属性值  =  NULL
   事件配额值（次）  =  0
   (结果个数 = 1)
   ---    END
   ```
2. 配置缺省计费规则/用户模板。
   * 场景一：当PCF下缺省内容计费对应的规则时，请执行以下脚本：
     1. 一般会使用common\_01\_ch\_p作为缺省费率的URRGROUP，使用LST URRGROUP:URRGROUPNAME="common\_01\_ch\_p";命令查询。

        ```
        %%LST URRGROUP:URRGROUPNAME="common_01_ch_p";%%
        RETCODE = 0  操作成功
        URR组信息：
        -----------
        使用量上报规则组名称  =  common_01_ch_p上行发起URR名称1  =  common_01_cbb_online上行发起URR名称2  =  common_01_cbb_offline
        上行发起URR名称3  =  NULL
        下行发起URR名称1  =  common_01_cbb_online下行发起URR名称2  =  common_01_cbb_offline
        下行发起URR名称3  =  NULL
        不计费标记  =  无
        (结果个数 = 1)
        ---    END
        ```

        若无查询结果，则执行以下命令添加对应的URRGROUP。

        ```
        ADD URRGROUP:URRGROUPNAME="common_01_ch_p", UPURRNAME1="common_01_cbb_online", DOWNURRNAME1="common_01_cbb_online", UPURRNAME2="common_01_cbb_offline", DOWNURRNAME2="common_01_cbb_offline", NOCHARGINGFLAG=NONE;
        ```
     2. 一般会使用common\_01\_pcc\_p\_g"作为缺省费率的PCCPOLICYGRP，使用LST PCCPOLICYGRP:PCCPOLICYGRPNM="common\_01\_pcc\_p\_g";命令查询。

        ```
        %%LST PCCPOLICYGRP:PCCPOLICYGRPNM="common_01_pcc_p_g";%%
        RETCODE = 0  操作成功
         
        PCC策略组信息
               PCC策略组名称  =  common_01_pcc_p_g使用量上报规则组名称  =  common_01_ch_p
                 QoS属性名称  =  NULL
        Session级FUP累计标识  =  不使能
        (结果个数 = 1)
        ```

        若无查询结果，则执行以下命令添加对应的PCCPOLICYGRP。

        ```
        ADD PCCPOLICYGRP:PCCPOLICYGRPNM="common_01_pcc_p_g", URRGROUPNAME="common_01_ch_p", FUPSESSIONEXC=DISABLE;
        ```
     3. 一般会使用common\_any和common\_any\_ipv6\_r作为兜底的计费规则，使用LST RULE:RULENAME="common\_any";和LST RULE:RULENAME="common\_any\_ipv6\_r";命令查询。

        ```
        %%LST RULE:RULENAME="common_any";%%
        RETCODE = 0  操作成功
         
        规则信息
            规则名称  =  common_any
          全局优先级  =  65000
            策略类型  =  PCC
            策略名称  =  common_01_pcc_p_g
        流过滤器名称  =  NULL
        (结果个数 = 1)
         
        %%LST RULE:RULENAME="common_any_ipv6_r";%%
        RETCODE = 0  操作成功
         
        规则信息

            规则名称  =  common_any_ipv6_r
          全局优先级  =  65010
            策略类型  =  PCC
            策略名称  =  common_01_pcc_p_g
        流过滤器名称  =  NULL
        (结果个数 = 1)
        ```

        若无查询结果，则执行以下命令添加兜底的计费规则。SMF、UPF上RULENAME以及RULE下配置的POLICYTYPE、POLICYNAME需要保持一致。

        ```
        ADD RULE:RULENAME="common_any", POLICYTYPE=PCC, PRIORITY=65000, POLICYNAME="common_01_pcc_p_g";
        ADD RULE:RULENAME="common_any_ipv6_r", POLICYTYPE=PCC, PRIORITY=65010, POLICYNAME="common_01_pcc_p_g";
        ```
   * 场景二：当PCF下缺省的内容计费对应的用户模板时，添加园区缺省计费规则对应的UserProfile。USERPROFILE的名称统一规划，保证在PCF、SMF、UPF间名称一致。不一致时PCF下发的策略无法生效。

     ```
     ADD USERPROFILE:USERPROFILENAME="u_p_multi_default", FREESERONLCHG=ENABLE, FREESEROFFCHG=ENABLE, UPTYPE=PCC, FREESERCVGCHG=ENABLE;
     ```

   当PCF同时下发园区业务内容计费对应的规则及用户模板时，以上脚本均需要执行。
3. （条件必选）当同时配置了步骤2中的场景一和场景二时，需要执行此步骤。配置园区业务使用的Rule和园区业务的User Profile绑定关系。如果配置需要和UPF上配置的UserProfile的名称保持一致。

   ```
   ADD RULEBINDING:USERPROFILENAME="u_p_multi_default", RULENAME="common_any";
   ADD RULEBINDING:USERPROFILENAME="u_p_multi_default", RULENAME="common_any_ipv6_r";
   ```

任务二： 园区业务规划单独费率，以2000000003为例进行配置。

1. 配置园区业务对应的URR。以下脚本假设园区费率为2000000003为例进行配置。

   ```
   ADD URR:URRNAME="multi_01_cbb_online", URRID=2000000003, USAGERPTMODE=ONLINE, ONLCOMPOUNDTYPE=ONLYRG, ONLINERG=2000000003, ONLMETERINGTYPE=VOLUME;
   ADD URR:URRNAME="multi_01_cbb_offline", URRID=2000010003, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=2000000003, OFFMETERINGTYPE=VOLUME;
   ```
2. 配置园区计费规则/用户模板。
   * 场景一：当PCF下发园区业务内容计费对应的规则时，请执行以下脚本：
     1. 配置园区业务流量对应URR Group。

        ```
        ADD URRGROUP:URRGROUPNAME="multi_01_ch_p", UPURRNAME1="multi_01_cbb_online", UPURRNAME2="multi_01_cbb_offline", DOWNURRNAME1="multi_01_cbb_online",DOWNURRNAME2="multi_01_cbb_offline";
        ```
     2. 配置园区业务内容计费规则对应的PCC策略组名并和URR Group绑定。

        ```
        ADD PCCPOLICYGRP:PCCPOLICYGRPNM="multi_01_pcc_p_g", URRGROUPNAME="multi_01_ch_p";
        ```
     3. 配置园区业务内容计费对应的Rule。SMF、UPF上RULENAME以及RULE下配置的POLICYTYPE、POLICYNAME需要保持一致。

        ```
        ADD RULE:RULENAME="multi_01_r", POLICYTYPE=PCC, PRIORITY=60000, POLICYNAME="multi_01_pcc_p_g";
        ADD RULE:RULENAME="multi_01_ipv6_r", POLICYTYPE=PCC, PRIORITY=60010, POLICYNAME="multi_01_pcc_p_g";
        ```
   * 场景二：当PCF下发园区业务内容计费对应的用户模板时，添加园区业务内容计费对应的UserProfile。USERPROFILE的名称统一规划，保证在PCF、SMF、UPF间名称一致。不一致时PCF下发的策略无法生效。

     ```
     ADD USERPROFILE:USERPROFILENAME="u_p_01_multi", UPTYPE=PCC
     ```

   当PCF同时下发园区业务内容计费对应的规则及用户模板时，以上脚本均需要执行。
3. （条件必选）当同时配置了步骤2中的场景一和场景二时，需要执行此步骤。配置园区业务使用的Rule和园区业务的UserProfile绑定关系。如果配置需要和UPF上配置的UserProfile的名称保持一致。

   ```
   ADD RULEBINDING:USERPROFILENAME="u_p_01_multi", RULENAME="multi_01_r";
   ADD RULEBINDING:USERPROFILENAME="u_p_01_multi", RULENAME="multi_01_ipv6_r";
   ```

版权所有 © 华为技术有限公司
