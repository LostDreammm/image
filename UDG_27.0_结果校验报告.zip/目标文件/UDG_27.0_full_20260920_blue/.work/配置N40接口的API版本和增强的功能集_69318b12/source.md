# 配置N40接口的API版本和增强的功能集

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本指导描述在UNC上配置N40接口的API版本和增强的功能集的相关操作过程。

3GPP TS 32291协议定义的SMF的N40接口API版本不断演进，不同运营商对N40接口有不同的协议版本要求，部分运营商还有在指定基础协议版本基础上跟进后续协议版本的要求。

SMF支持根据现网实际情况配置指定N40接口支持的协议版本，并支持在该协议版本基础上叠加指定的增加功能。

## 必备事项

前提条件

* 请仔细阅读融合计费原理。
* 完成加载License。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| ****SET N40APIVER**** | API接口版本（APIVER） | F30 | 全网规划 | 配置N40接口支持的API版本，需和NCG/CHF(OCS)使用相同的协议版本。 |
|  | 特性（FEATURE） | NBIOTCHG-1&LTEMCHG-1 | 全网规划 | 配置N40接口增强的功能，需和NCG/CHF(OCS)使用相同的接口能力。  该参数类型为位域类型，支持取值叠加进行选择，功能使能时参数后携带-1，不使能时参数后携带-0，如果不修改对应功能，无需携带对应参数，详细可参考任务示例。 |
| ****ADD N40MSGTEMP**** | N40消息属性模板名（TEMPLATENAME） | n40attr | 本端规划 | 指定N40消息字段模板名。 |
|  | NB扩展属性（NBEXTENDATTR） | ENABLE | 本端规划 | 控制NB-IOT、LTEM接入时是否携带扩展属性信息，包括APN Rate Control、Serving PLMN Rate Control、CP only indication和PtP隧道。 |

## 操作步骤

* 进入“MML命令行-UNC”窗口。
* 配置N40接口支持的API版本及增强功能集。

  **SET N40APIVER**
* 配置N40消息属性模板，控制N40消息中是否携带对应字段。

  **ADD N40MSGTEMP**

## 任务示例

任务描述

* 任务一：配置SMF支持N40接口的API版本是F30版本，并且N40接口Serving Node类型支持SGW，AMF。
* 任务二：配置SMF支持N40接口的API版本是F30版本，并且N40接口在NB-IOT用户接入时支持携带对应的接入类型（NBIOT）及相关扩展字段信息，PDU会话类型支持填写“NONIP”；在eMTC用户接入时支持携带对应的接入类型（LTE-M）及相关扩展字段等信息，PDU会话类型支持填写“NONIP”。并且NB-IOT、LTEM接入时携带扩展属性信息。
* 任务三：配置SMF支持N40接口的API版本是F30版本，并且N40接口在3G用户接入时，非国际漫游漫出场景携带位置信息且支持ULI变化事件。
* 任务四：配置SMF支持N40接口的API版本是F30版本，N40接口在2/3G用户接入时，支持处理CHF下发的TriggerTypeCGI\_SAI\_CHANGE和TriggerTypeRAI\_CHANGE。
* 任务五：配置SMF支持N40接口的API版本是F30版本，并且N40接口在2G用户接入时支持携带对应的位置类型（geraLocation），接入类型（GERA）和服务节点类型（SGSN）等信息。
* 任务六：配置SMF支持N40接口的API版本是F30版本，并且N40接口在非可信Non-3GPP用户接入时携带的服务节点类型为“EPDG”。
* 任务七：配置SMF支持N40接口的API版本是F30版本，并且N40接口Serving Node类型支持SGW，AMF；在2G用户接入时支持携带对应的位置类型（geraLocation），接入类型（GERA）和服务节点类型（SGSN）等信息；在非可信Non-3GPP用户接入时携带的服务节点类型为“EPDG”。

脚本

任务一：配置N40接口支持的API版本，支持Serving Node类型支持SGW，AMF。

```
SET N40APIVER: APIVER=F30, FEATURE=NODEFUNC-1;
```

任务二：配置SMF支持N40接口的API版本是F30版本，并且N40接口在NB-IOT用户接入时支持携带对应的接入类型（NBIOT）及相关扩展字段信息，PDU会话类型支持填写“NONIP”；在eMTC用户接入时支持携带对应的接入类型（LTE-M）及相关扩展字段等信息，PDU会话类型支持填写“NONIP”。

```
SET N40APIVER: APIVER=F30, FEATURE=NBIOTCHG-1&LTEMCHG-1;
ADD N40MSGTEMP: TEMPLATENAME="n40attr", NBEXTENDATTR=ENABLE;
```

任务三：配置SMF支持N40接口的API版本是F30版本，并且N40接口在3G用户接入时，非国际漫游漫出场景携带位置信息且支持ULI变化事件。

```
SET N40APIVER: APIVER=F30, FEATURE=UTRANCHG3GPP-1;
```

任务四：配置SMF支持N40接口的API版本是F30版本，N40接口在2/3G用户接入时，支持处理CHF下发的TriggerTypeCGI\_SAI\_CHANGE和TriggerTypeRAI\_CHANGE。

```
SET N40APIVER: APIVER=F30, FEATURE=TRIGGER23G-1;
```

任务五：配置N40接口支持的API版本，支持在2G用户接入时支持携带对应的位置类型（geraLocation），接入类型（GERA）和服务节点类型（SGSN）等信息。

```
SET N40APIVER: APIVER=F30, FEATURE=GERANCHG-1;
```

任务六：配置N40接口支持的API版本，支持在非可信Non-3GPP用户接入时携带的服务节点类型为“EPDG”。

```
SET N40APIVER: APIVER=F30, FEATURE=WLANCHG-1;
```

任务七：配置SMF支持N40接口的API版本是F30版本，并且N40接口Serving Node类型支持SGW，AMF；在2G用户接入时支持携带对应的位置类型（geraLocation），接入类型（GERA）和服务节点类型（SGSN）等信息；在非可信Non-3GPP用户接入时携带的服务节点类型为“EPDG”。

```
SET N40APIVER: APIVER=F30, FEATURE=NODEFUNC-1&GERANCHG-1&WLANCHG-1;
```

版权所有 © 华为技术有限公司
