---
id: ''
name: 配置OSPF安全
ne_type: UDG
type: feature
description: 网络上对OSPF协议的攻击方法主要为伪造报文攻击，可以通过配置报文认证手段来识别并丢弃这些报文。  可能的攻击手段有：  * 修改报文老化时间到最大老化时间，导致所有UDG废弃这个报文。 * 发布合法的Max Sequence Number的LSA或者接近Max Seq Num的报文。 * 邻居UDG重启时复位其加密序列号的时机，更改序列号。 * 修改Hello报文中的邻居列表。  OSPF支持报文验证功能，只有通过验证的报文才能接收，否则将不能正常建立邻居关系。使用区域验证时，一个区域中所有的UDG在该区域下的验证模式和口令必须一致。例如，在Area0内所有UDG上配置验证模式为简单验证，口令为abc。接口验证方式用于在相邻的UDG之间设置验证模式和口令，优先级高于区域验证方式。
risk_level: ''
doc_source: ["网络部署","安全配置","UDG安全配置","安全配置建议","可选配置","网络安全配置","配置业务路由安全功能","配置OSPF安全"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
网络上对OSPF协议的攻击方法主要为伪造报文攻击，可以通过配置报文认证手段来识别并丢弃这些报文。可能的攻击手段有：* 修改报文老化时间到最大老化时间，导致所有UDG废弃这个报文。* 发布合法的Max Sequence Number的LSA或者接近Max Seq Num的报文。* 邻居UDG重启时复位其加密序列号的时机，更改序列号。* 修改Hello报文中的邻居列表。OSPF支持报文验证功能，只有通过验证的报文才能接收，否则将不能正常建立邻居关系。使用区域验证时，一个区域中所有的UDG在该区域下的验证模式和口令必须一致。例如，在Area0内所有UDG上配置验证模式为简单验证，口令为abc。接口验证方式用于在相邻的UDG之间设置验证模式和口令，优先级高于区域验证方式。

## 必备事项
前提条件

该操作无需具备特殊条件。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_ospf_list:
      type: items
      properties:
        PROCID:
          name: '进程号'
          type: integer
          minimum: 1
          maximum: 4294967295
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ospfarea_list:
      type: items
      properties:
        PROCID:
          name: '进程号'
          type: integer
          minimum: 1
          maximum: 4294967295
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AREAID:
          name: '区域号'
          type: string
          maxLength: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ospfinterface_list:
      type: items
      properties:
        PROCID:
          name: '进程号'
          type: integer
          minimum: 1
          maximum: 4294967295
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AREAID:
          name: '区域标识'
          type: string
          maxLength: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IFNAME:
          name: '接口名'
          type: string
          maxLength: 63
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ospfnetwork_list:
      type: items
      properties:
        PROCID:
          name: '进程号'
          type: integer
          minimum: 1
          maximum: 4294967295
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AREAID:
          name: '区域号'
          type: string
          maxLength: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPADDRESS:
          name: 'IP地址'
          type: string
          maxLength: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        WILDCARDMASK:
          name: '反掩码'
          type: string
          maxLength: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_ospfinterfaceauth_list:
      type: items
      properties:
        PROCID:
          name: 'OSPF进程号'
          type: integer
          minimum: 1
          maximum: 4294967295
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AREAID:
          name: '区域号'
          type: string
          maxLength: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IFNAME:
          name: '接口名'
          type: string
          maxLength: 63
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AUTHENMODE:
          name: '认证模式'
          type: string
          enum:
          - hmac-md5
          - hmac-sha256
          - keychain
          - md5
          - 'null'
          - simple
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AUTHTEXTSIMPLE:
          name: '简单认证密码'
          type: string
          maxLength: 8
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AUTHTEXTMD5:
          name: 'MD5/HMAC-MD5/HMAC-SHA256 密码'
          type: string
          maxLength: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AUTHTEXTTYPE:
          name: '密文口令类型'
          type: string
          enum:
          - cipher
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        KEYCHAINNAME:
          name: 'KeyChain名称'
          type: string
          maxLength: 47
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        KEYID:
          name: '密文验证字标识符'
          type: integer
          minimum: 1
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_ospf_interface:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '在“MML命令行-UDG”窗口上执行：'
      data_source: ''
      pattern: ''
      default: TRUE
    is_scenario_ospf_network:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '在“MML命令行-UDG”窗口上执行：'
      data_source: ''
      pattern: ''
      default: TRUE
  examples:
  - add_ospf_list:
    - PROCID: 进程号
    add_ospfarea_list:
    - PROCID: 进程号
      AREAID: '区域号'
    add_ospfinterface_list:
    - PROCID: 进程号
      AREAID: '区域标识'
      IFNAME: '接口名'
    add_ospfnetwork_list:
    - PROCID: 进程号
      AREAID: '区域号'
      IPADDRESS: 'IP地址'
      WILDCARDMASK: '掩码'
    mod_ospfinterfaceauth_list:
    - PROCID: OSPF进程号
      AREAID: '区域号'
      IFNAME: '接口名'
      AUTHENMODE: 认证模式
      AUTHTEXTSIMPLE: '简单认证密码'
      AUTHTEXTMD5: ''
      AUTHTEXTTYPE: ''
      KEYCHAINNAME: ''
      KEYID: ''
    is_scenario_ospf_interface: TRUE
    is_scenario_ospf_network: TRUE
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 创建OSPF进程。

### 在“MML命令行-UDG”窗口上执行：

```jinja2
{%- for item in add_ospf_list -%}
    ADD OSPF:
    {#- --- 必选参数 --- -#}
    PROCID={{item.PROCID}},
    ;
{%- endfor -%}
```

### 2 增加OSPF区域。

### 在“MML命令行-UDG”窗口上执行：

```jinja2
{%- for item in add_ospfarea_list -%}
    ADD OSPFAREA:
    {#- --- 必选参数 --- -#}
    PROCID={{item.PROCID}},
    AREAID="{{item.AREAID}}",
    ;
{%- endfor -%}
```

### 3 增加运行OSPF协议的接口。

### 选择执行如下步骤之一：

#### 3.1 在“MML命令行-UDG”窗口上执行：

```jinja2
{%- if is_scenario_ospf_interface -%}
    {%- for item in add_ospfinterface_list -%}
        ADD OSPFINTERFACE:
        {#- --- 必选参数 --- -#}
        PROCID={{item.PROCID}},
        AREAID="{{item.AREAID}}",
        IFNAME="{{item.IFNAME}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 参数“AREAID”（区域号）与步骤2中的“AREAID”的取值相一致。

#### 3.2 在“MML命令行-UDG”窗口上执行：

```jinja2
{%- if is_scenario_ospf_network -%}
    {%- for item in add_ospfnetwork_list -%}
        ADD OSPFNETWORK:
        {#- --- 必选参数 --- -#}
        PROCID={{item.PROCID}},
        AREAID="{{item.AREAID}}",
        IPADDRESS="{{item.IPADDRESS}}",
        WILDCARDMASK="{{item.WILDCARDMASK}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 如果接口的IP地址在**ADD OSPFNETWORK**命令指定的网段范围内，接口就会自动运行OSPF协议。

#### 参数“AREAID”（区域号）与步骤2中的“AREAID”的取值相一致。

### 4 配置OSPF接口验证参数。

### 在“MML命令行-UDG”窗口上执行：

```jinja2
{%- for item in mod_ospfinterfaceauth_list -%}
    MOD OSPFINTERFACEAUTH:
    {#- --- 必选参数 --- -#}
    PROCID={{item.PROCID}},
    AREAID="{{item.AREAID}}",
    IFNAME="{{item.IFNAME}}",
    AUTHENMODE={{item.AUTHENMODE}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：AUTHENMODE=keychain 时必选 --- -#}
    {%- if item.AUTHENMODE == 'keychain' -%}
        KEYCHAINNAME="{{item.KEYCHAINNAME}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：AUTHENMODE=simple 时可选 --- -#}
    {%- if item.AUTHENMODE == 'simple' -%}
        {%- if item.AUTHTEXTSIMPLE is not none -%}
            AUTHTEXTSIMPLE="{{item.AUTHTEXTSIMPLE}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：AUTHENMODE=hmac-sha256/md5/hmac-md5 时可选 --- -#}
    {%- if item.AUTHENMODE in ['hmac-sha256', 'md5', 'hmac-md5'] -%}
        {%- if item.AUTHTEXTMD5 is not none -%}
            AUTHTEXTMD5="{{item.AUTHTEXTMD5}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：AUTHENMODE=hmac-sha256/simple/md5/hmac-md5 时可选 --- -#}
    {%- if item.AUTHENMODE in ['hmac-sha256', 'simple', 'md5', 'hmac-md5'] -%}
        {%- if item.AUTHTEXTTYPE is not none -%}
            AUTHTEXTTYPE={{item.AUTHTEXTTYPE}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：AUTHENMODE=hmac-sha256/md5/hmac-md5 时可选 --- -#}
    {%- if item.AUTHENMODE in ['hmac-sha256', 'md5', 'hmac-md5'] -%}
        {%- if item.KEYID is not none -%}
            KEYID={{item.KEYID}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

