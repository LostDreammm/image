# 配置专用DNN基本数据

* 操作场景
* 对系统的影响
* 必备事项
* 任务示例

## 操作场景

本操作用于指导在专网SMF上开启通用DNN漫游分流特性，配置专用DNN下的专用UPF属性等基本数据。

## 对系统的影响

无。

## 必备事项

前提条件

已参考运营商配置规范完成网元的基本配置。

数据

**表1** SMF基础数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET LICENSESWITCH** | License项（LICITEM） | LKV2ASLSR02 | 本端规划 | 该参数用于指定需要开通的License项。 |
|  | 开关（SWITCH） | ENABLE | 本端规划 | 该参数用于表示License项的配置开关是否已经打开。 |
| ****ADD VPNINST**** | VPN实例名（VPNINSTANCE） | VRF\_N6\_Local\_2B\_APP | 本端规划 | 增加VPN实例名。建议该VPN实例与专网UPF的N6接口新开专线的VPN实例保持一致。 |
| **ADD APN** | APN名称（APN） | stjwt.gd | 本端规划 | 增加APN，该APN为用户签约的专用DNN。 |
|  | 绑定VPN（HASVPN） | ENABLE | 本端规划 | 将专用DNN绑定VPN实例。 |
|  | VPN实例名（VPNINSTANCE） | VRF\_N6\_Local\_2B\_APP | 本端规划 |  |
|  | 绑定IPv6 VPN（HASVPNIPV6） | ENABLE | 本端规划 |  |
|  | IPv6 VPN实例名（VPNINSTANCEIPV6） | VRF\_N6\_Local\_2B\_APP | 本端规划 |  |
| **MOD APN** | APN名称（APN） | stjwt.gd | 已配置数据中获取 | 参数“APN”已在**ADD APN**中定义。 |
|  | 位置上报（LOCREPORT） | DISABLE | 本端规划 | 通用DNN漫游分流方案约束，专用会话不支持AOI，PRA，实时位置上报等特性，因此参数“LOCREPORT”、“LADN”、“AOI”取值分别为“DISABLE”、“NotSupport”、“NotSupport”。 |
|  | 局域数据网络（LADN） | NotSupport | 本端规划 |  |
| **SET SMFFUNC** | 兴趣区（AOI） | NotSupport | 本端规划 |  |
| **SET APNIDLETIME** | APN名称（APN） | stjwt.gd | 已配置数据中获取 | 参数“APN”已在**ADD APN**中定义。 |
|  | 继承默认开关（INHERIT） | NO | 本端规划 | 专用会话使用自定义的IDLETIMER配置。 |
|  | H-SMF空闲上下文核查开关（HCTXCHKSW） | ENABLE | 本端规划 |  |
|  | SMF会话空闲定时器时长（SMFSESIDLETIMER） | 2880 | 本端规划 |  |
| **ADD NSDNN** | 网络切片索引（NSIDX） | 0 | 已配置数据中获取 | * 增加DNN切片绑定关系。 * 参数“NSIDX”由命令**LST NSDNN**查询结果中的“网络切片索引”获取。当存在切片发放场景时，此参数引用切片发放对应的参数。 * 参数“DNN”已在**ADD APN**中定义。 |
|  | 数据网络名称（DNN） | stjwt.gd | 已配置数据中获取 |  |
| **ADD PNFDNN**  说明：  如果新增业务场景需要新增DNN可通过本命令添加。 | 索引（INDEX） | 100  101 | 全网规划 | 配置专网UPF的DNN属性，若部署容灾模式，此处涉及两个UPF。   * 参数“NFINSTANCEID”通过**LST PNFPROFILE**查询。 * 参数“DNN”已在**ADD APN**中定义。 * 参数“PNFNSINDEX”通过**LST PNFNS**查询，当存在切片发放场景时，此参数引用切片发放对应的参数。 |
|  | NF实例标识（NFINSTANCEID） | 5EA7F228-47CC-2032-03A3-0E1313000001  5EA7F228-47CC-2032-03A3-0E1313000002 | 已配置数据中获取 |  |
|  | 数据网络名称（DNN） | stjwt.gd | 已配置数据中获取 |  |
|  | 对端NF的切片索引（PNFNSINDEX） | 3  4 | 已配置数据中获取 |  |
| **ADD APNUPFINFO** | APN名称（APN） | stjwt.gd | 本端规划 | 配置专网UPF在专用DNN下的位置特征。 |
|  | UPF实例标识（UPFINSTANCEID） | 5EA7F228-47CC-2032-03A3-0E1313000001  5EA7F228-47CC-2032-03A3-0E1313000002 | 全网规划 |  |
|  | UPF的位置特征（LOCATION） | CENTERONLY | 本端规划 |  |
| **SET APNPCCFUNC** | APN名称（APN） | stjwt.gd | 全网规划 | 配置专用DNN用户的动态PCC规则开关。 |
|  | 本地用户动态PCC功能（HOMEPCCSWITCH） | ENABLE | 对端协商 |  |

## 任务示例

任务描述

在专网SMF上开启专用DNN的基本数据。

脚本

1. 打开“跨域互联互通-SMF”的License配置开关，当UE进行跨区域移动超出SMF的服务范围可插入I-SMF为UE提供服务。

   ```
   SET LICENSESWITCH: LICITEM="LKV2ASLSR02", SWITCH=ENABLE;
   ```
2. 配置VPN和DNN，如已完成VPN和专用DNN创建，请跳过本步骤。建议该VPN实例与专网UPF的N6接口VPN实例保持一致。

   ```
   ADD VPNINST:VPNINSTANCE="VRF_N6_Local_2B_APP";
   ADD APN:APN="stjwt.gd",HASVPN=ENABLE,VPNINSTANCE="VRF_N6_Local_2B_APP",HASVPNIPV6=ENABLE,VPNINSTANCEIPV6="VRF_N6_Local_2B_APP";
   ```
3. 特性约束专用会话不支持AOI，PRA，实时位置上报等特性，设置专用DNN不支持位置上报，设置专用SMF不支持兴趣区。请使用LST SMFFUNC查询系统是否有该配置记录，若无记录请配置SET SMFFUNC命令，若已有记录请按照SET SMFFUNC命令参数核查并调整。

   ```
   MOD APN:APN="stjwt.gd",LOCREPORT=DISABLE,LADN=NotSupport;
   LST SMFFUNC:;
   SET SMFFUNC:AOI=NotSupport;
   ```
4. 关闭APN空闲上下文定时器配置。

   如果是一跳入家场景，且开启业务触发专用DNN分流会话时，需要打开APN空闲上下文定时器配置。

   ```
   SET APNIDLETIME:APN="stjwt.gd",INHERIT=NO,HCTXCHKSW=DISABLE;
   ```
5. 配置专用DNN下的切片信息，建议专网业务使用通用DNN的切片策略。
   1. 如果专网SMF和公网SMF合一部署，配置专网SMF在专用DNN下支持的切片时，请使用LST NSDNN查询公用DNN下网络切片索引并通过ADD NSDNN配置。如果专网SMF独立部署，没有配置common.dnn，则使用LST NFNS命令查询切片索引再通过ADD NSDNN配置。

      ```
      LST NSDNN: DNN="common.dnn";
      LST NFNS: NFTYPE=NfSMF;
      ADD NSDNN:NSIDX=0, DNN="stjwt.gd";
      ```
   2. 配置专网UPF在专用DNN下支持的切片。请使用LST PNFPROFILE查询专网UPF的实例，LST PNFNS查询专网UPF支持的切片索引。并通过ADD PNFDNN配置。

      ```
      LST PNFPROFILE: NFTYPE=NfUPF;
      LST PNFNS:;
      ADD PNFDNN: INDEX=100, NFINSTANCEID="5EA7F228-47CC-2032-03A3-0E1313000001", DNN="stjwt.gd", PNFNSINDEX=3; 
      ADD PNFDNN: INDEX=101, NFINSTANCEID="5EA7F228-47CC-2032-03A3-0E1313000002", DNN="stjwt.gd", PNFNSINDEX=4;
      ```
6. 配置专网UPF在专用DNN下的属性。

   ```
   ADD APNUPFINFO:APN="stjwt.gd",UPFINSTANCEID="5EA7F228-47CC-2032-03A3-0E1313000001",LOCATION=CENTERONLY;
   ADD APNUPFINFO:APN="stjwt.gd",UPFINSTANCEID="5EA7F228-47CC-2032-03A3-0E1313000002",LOCATION=CENTERONLY;
   ```
7. 配置DNN用户的动态PCC规则开关。

   ```
   SET APNPCCFUNC: APN="stjwt.gd", HOMEPCCSWITCH=ENABLE;
   ```
8. （条件必选）如果未完成2/3/4G融合，需要配置本步骤，限制ratType为2G/3G的用户接入。如果已完成2/3/4G融合，不需要配置本步骤。

   SGSN IPv4地址举例为10.1.1.1，IPv6地址举例为0000:0000:0000:0000:0000:0000:0000:0001。

   ```
   SET SRVNODERATPRI: NODETYPE=GGSN, FIRSTPRIORITY=SGSN_IP, SECONDPRIORITY=RAT;
   ADD SRVNODERAT: IPVERSION=IPV4, SRVNODESTARTV4="10.1.1.1", SRVNODEENDV4="255.255.255.255", RATTYPE=UTRAN;
   ADD SRVNODERAT: IPVERSION=IPV6, SRVNODESTARTV6="0000:0000:0000:0000:0000:0000:0000:0001", SRVNODEENDV6="FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF", RATTYPE=UTRAN;
   LCK APN: APN="stjwt.gd", LOCKED=ENABLE, LCKRATTYPE=UTRAN-1&GERAN-1&WLAN-0&GAN-0&HSPA-0&EUTRAN-0&VIRTUAL-0&EUTRAN_NB_IoT-0&LTE_M-0&NR-0;
   ```

版权所有 © 华为技术有限公司
