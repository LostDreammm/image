# 配置点播业务的安全认证策略

* 操作场景
* 必备事项
* 任务示例

## 操作场景

在媒体中继业务中，UPF使用HTTPS方式进行通信时，在不同场景下分别承担着不同的角色。在和UE通信时，UPF作为服务端，而当和CDN进行通信时，UPF则作为客户端。

本章节主要介绍针对点播业务UPF使用HTTPS方式进行通信时，如何配置TLS证书作为业务的安全认证策略。

适用于UPF。

## 必备事项

前提条件

* 已获取证书：商用证书，由客户申请。
* 已参考配置点播业务的媒体中继域名（点播域名）完成媒体中继域名配置。

数据

**表1** 配置UE认证策略

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD SRVCERTSCENE** | 证书使用场景名称（SCENE） | * 设备证书：**relay\_sc\_ne\_sp\_vod\_001** * CA证书：**relay\_sc\_ca\_sp\_vod\_001** | 本端规划 | - |
|  | 场景类型（TYPE） | * 设备证书：SCENE\_NE * CA证书：SCENE\_CA | 固定取值   * 设备证书固定取值为SCENE\_NE。 * CA证书固定取值SCENE\_CA。 | - |
|  | 证书使用场景中文描述（CNDESC） | * **Relay\_NE** * **Relay\_CA** | 本端规划 | - |
| **ADD SRVTLSPLY** | 策略名称  （PLYNAME） | * **relay\_tls\_s\_sp\_vod\_001** * **relay\_tls\_c\_sp\_vod\_001** | 本端规划 | * relay\_tls\_s\_sp\_vod\_001：本端实体作为服务端时的策略名称。relay\_tls\_c\_sp\_vod\_001：本端实体作为客户端时的策略名称。 |
|  | 实体类型（TYPE） | * Server * Client | 本端规划 | * “Client（客户端）”：本端实体作为Client。和UE通信，UPF作为服务器端，UE作为客户端。 * “Server（服务端）”：本端实体作为Server。 和CDN通信，UPF作为客户端，CDN作为服务器端。 |
|  | 协议版本  （PROTOCOL） | TLS1\_2-1&TLS1\_3-1 | 本端规划 | * “TLS1\_2（传输层安全性协议版本v1.2）”：TLS1\_2表示使用传输层安全性协议版本v1.2。 * “TLS1\_3（传输层安全性协议版本v1.3）”：TLS1\_3表示使用传输层安全性协议版本v1.3。 |
|  | 加密套件集合（CIPHER） | TLS\_DHE\_RSA\_WITH\_AES128\_GCM\_SHA256-1&TLS\_DHE\_RSA\_WITH\_AES256\_GCM\_SHA384-1&TLS\_DHE\_DSS\_WITH\_AES128\_GCM\_SHA256-1&TLS\_DHE\_DSS\_WITH\_AES256\_GCM\_SHA384-1&TLS\_ECDHE\_ECDSA\_WITH\_AES128\_GCM\_SHA256-1&TLS\_ECDHE\_ECDSA\_WITH\_AES256\_GCM\_SHA384-1&TLS\_ECDHE\_RSA\_WITH\_AES128\_GCM\_SHA256-1&TLS\_ECDHE\_RSA\_WITH\_AES256\_GCM\_SHA384-1&TLS\_DHE\_RSA\_WITH\_AES128\_CCM-1&TLS\_DHE\_RSA\_WITH\_AES256\_CCM-1&TLS\_ECDHE\_ECDSA\_WITH\_AES\_128\_CCM-1&TLS\_ECDHE\_ECDSA\_WITH\_AES256\_CCM-1&TLS\_AES128\_GCM\_SHA256-1&-1&TLS\_AES256\_GCM\_SHA384-1&TLS\_CHACHA20\_POLY1305\_SHA256-1&TLS\_AES\_128\_CCM\_SHA256-1 | 本端规划 | "PROTOCOL"参数选中TLS1\_2，"CIPHER"选中的算法必须有TLS1\_2支持的算法，否则命令会执行失败；  "PROTOCOL"参数选中TLS1\_3，"CIPHER"未选中TLS1\_3的算法命令不会执行失败，系统会使用默认的TLS1\_3算法；  TLS1\_2选中TLS1\_3的算法不生效，同样TLS1\_3选中TLS1\_2的算法也不会生效。 |
|  | 设备证书场景（NESCENE） | relay\_sc\_ne\_sp\_vod\_001 | 已配置数据中获取 | 与**ADD SRVCERTSCENE**命令中配置的设备证书场景的“SCENE”参数值保持一致。 |
|  | CA证书场景（CASCENE） | relay\_sc\_ca\_sp\_vod\_001 | 已配置数据中获取 | **与ADD SRVCERTSCENE**命令中配置的CA证书场景的“SCENE”参数值保持一致。 |
|  | 验证对端证书  （VERIFYPEER） | Yes | 本端规划 | * Yes：开启校验对端证书 * No：关闭校验对端证书。当参数设置为“No”时，不校验对端证书合法性，存在安全风险。 |
|  | 验证对端证书（VDEPTH） | 100 | 本端规划 | 系统默认100。 |
|  | 吊销证书列表  （CRLFLAG） | CRL\_ON | 本端规划 | * CRL\_OFF：关闭吊销证书列表。 * CRL\_ON：开启吊销证书列表。若启用CRL，即吊销证书列表，则需上传CRL文件。若启用CRL，即吊销证书列表，则需上传CRL文件。 |
| **ADD RELAYTLSCFG** | TLS配置名称（TLSCFGNM） | **relay\_tls\_cfg\_sp\_vod\_001** | 本端规划 | - |
|  | 与UE认证策略（UETLSPLY） | relay\_tls\_s\_sp\_vod\_001 | 已配置数据中获取 | * 该参数来源于**ADD SRVTLSPLY**命令的“PLYNM”参数，可通过**LST SRVTLSPLY**命令查询获取。 * 该参数用于指定Relay作为服务端与UE客户端使用HTTPS方式连接时使用的TLS认证策略名称。 |
|  | 与CDN认证策略（CDNTLSPLY） | relay\_tls\_c\_sp\_vod\_001 | 已配置数据中获取 | * 该参数来源于**ADD SRVTLSPLY**命令的“PLYNM”参数，可通过**LST SRVTLSPLY**命令查询获取 * 该参数用于指定Relay作为客户端与CDN服务端使用HTTPS方式连接时使用的TLS认证策略名称。 * Relay与CDN之间使用HTTPS时必须配置否则TLS协商失败。 |

**表2** 安全认证策略绑定到媒体中继模板

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **MOD RELAYDOMAIN** | 媒体中继域名配置名称（RELAYDOMAINNAME） | sp\_relay\_dm\_vod\_001 | 已配置数据中获取 | 已通过**ADD RELAYTEMPLATE**完成配置。 |
|  | 媒体中继域名配置名称（RELAYDOMAINNAME） | relay\_tls\_cfg\_sp\_vod\_001 | 已配置数据中获取 | 已通过**ADD RELAYTLSCFG**完成配置。 |

## 任务示例

任务描述

配置媒体中继直播业务使用的TLS证书。

脚本

//增加UPF的TLS证书场景。

```
ADD SRVCERTSCENE: SCENE="relay_sc_ne_sp_vod_001", TYPE=SCENE_NE, CNDESC="Relay_NE";
ADD SRVCERTSCENE: SCENE="relay_sc_ca_sp_vod_001", TYPE=SCENE_CA, CNDESC="Relay_CA";
```

//增加UPF作为服务器端的TLS认证策略配置。即UPF作为服务器端，UE作为客户端。

```
ADD SRVTLSPLY: PLYNAME="relay_tls_s_sp_vod_001", TYPE=SERVER, PROTOCOL=TLS1_2-1&TLS1_3-1, CIPHER=TLS_DHE_RSA_WITH_AES128_GCM_SHA256-1&TLS_DHE_RSA_WITH_AES256_GCM_SHA384-1&TLS_DHE_DSS_WITH_AES128_GCM_SHA256-1&TLS_DHE_DSS_WITH_AES256_GCM_SHA384-1&TLS_ECDHE_ECDSA_WITH_AES128_GCM_SHA256-1&TLS_ECDHE_ECDSA_WITH_AES256_GCM_SHA384-1&TLS_ECDHE_RSA_WITH_AES128_GCM_SHA256-1&TLS_ECDHE_RSA_WITH_AES256_GCM_SHA384-1&TLS_DHE_RSA_WITH_AES128_CCM-1&TLS_DHE_RSA_WITH_AES256_CCM-1&TLS_ECDHE_ECDSA_WITH_AES_128_CCM-1&TLS_ECDHE_ECDSA_WITH_AES256_CCM-1&TLS_AES128_GCM_SHA256-1&TLS_AES256_GCM_SHA384-1&TLS_CHACHA20_POLY1305_SHA256-1&TLS_AES_128_CCM_SHA256-1, NESCENE="relay_sc_ne_sp_vod_001", CASCENE="relay_sc_ca_sp_vod_001", VERIFYPEER=Yes, CRLFLAG=CRL_ON;
```

//增加UPF作为客户端的TLS认证策略配置。即UPF作为客户端，CDN作为服务器端。

```
ADD SRVTLSPLY: PLYNAME="relay_tls_c_sp_vod_001", TYPE=Client, PROTOCOL=TLS1_2-1&TLS1_3-1, CIPHER=TLS_DHE_RSA_WITH_AES128_GCM_SHA256-1&TLS_DHE_RSA_WITH_AES256_GCM_SHA384-1&TLS_DHE_DSS_WITH_AES128_GCM_SHA256-1&TLS_DHE_DSS_WITH_AES256_GCM_SHA384-1&TLS_ECDHE_ECDSA_WITH_AES128_GCM_SHA256-1&TLS_ECDHE_ECDSA_WITH_AES256_GCM_SHA384-1&TLS_ECDHE_RSA_WITH_AES128_GCM_SHA256-1&TLS_ECDHE_RSA_WITH_AES256_GCM_SHA384-1&TLS_DHE_RSA_WITH_AES128_CCM-1&TLS_DHE_RSA_WITH_AES256_CCM-1&TLS_ECDHE_ECDSA_WITH_AES_128_CCM-1&TLS_ECDHE_ECDSA_WITH_AES256_CCM-1&TLS_AES128_GCM_SHA256-1&TLS_AES256_GCM_SHA384-1&TLS_CHACHA20_POLY1305_SHA256-1&TLS_AES_128_CCM_SHA256-1, NESCENE="relay_sc_ne_sp_vod_001", CASCENE="relay_sc_ca_sp_vod_001", VERIFYPEER=Yes, CRLFLAG=CRL_ON;
```

//配置媒体中继业务绑定TLS策略配置。

```
ADD RELAYTLSCFG: TLSCONFIGNAME="relay_tls_cfg_sp_vod_001", UETLSPLYNAME="relay_tls_s_sp_vod_001", CDNTLSPLYNAME="relay_tls_c_sp_vod_001";
```

//安全认证策略绑定到媒体中继模板。

```
MOD RELAYDOMAIN: RELAYDOMAINNAME="sp_relay_dm_vod_001", TLSCFGNAME="relay_tls_cfg_sp_vod_001";
```

版权所有 © 华为技术有限公司
