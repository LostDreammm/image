# 配置融合计费费率标识

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本操作描述融合计费使用的费率标识的配置过程。

SMF与NCG/CHF(OCS)交互需要用到费率标识。费率标识可以是费率组（Rating Group，RG）；也可以是费率组（Rating Group，RG）+业务ID（Service ID，SID）即（RG，SID）。使用（RG，SID）做费率标识可以进行更细粒度的配额管理。UNC支持内容计费，即按用户使用的业务粒度进行计费。对应内容计费的不同的业务，对应的费率标识不同。

## 必备事项

前提条件

* 请详细阅读融合计费原理。
* 使用内容计费时，已申请内容计费的License项。
* 完成加载License。
* 本操作任务涉及的APN/DNN、User Profile、User Profile group已经创建完成，并完成User Profile group与APN/DNN的绑定。

数据

以表1中的业务套餐为例，待规划的内容计费数据如表2所示。其中条件数据仅在UPF上配置，SMF上不需要配置。

**表1** 业务套餐规划

| 条件 | 计费类型 | RG | URR ID | Rule Name | User Profile Name |
| --- | --- | --- | --- | --- | --- |
| 访问网址是www.huawei.com的网站 | online | 100 | 2300 | Rule001\_url | userprofile001 |
|  | offline | 1100 | 12500 |  |  |
| 访问IMS业务 | online | 200 | 3300 | Rule002\_IMS | userprofile002 |
|  | offline | 1200 | 13500 |  |  |
| any to any的业务流 | online | 300 | 1300 | Rule003\_any  Rule003\_any\_IPv6 | userprofile001 |
|  | offline | 1300 | 11500 |  |  |
| 异常场景计费URR | online | 400 | 4300 | - | - |
|  | offline | 1400 | 14500 |  |  |

**表2** 内容计费费率标识

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_online\_URL  urr\_online\_IMS  urr\_online\_any  URR\_abnormal\_online | 本端规划 | 配置业务在线计费URR。  说明：  URRID、USAGERPTMODE、OFFMETERINGTYPE需要与UPF上的配置保持一致。 |
|  | URR标识（URRID） | 2300  3300  1300  4300 | 全网规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | ONLINE | 全网规划 |  |
|  | 在线计费标识组成类型（ONLCOMPOUNDTYPE） | ONLYRG | 全网规划 | 根据业务套餐情况，确定使用RG还是（RG，SID）作为费率标识。  此处以使用RG作为费率标识为例。 |
|  | 在线计费组（ONLINERG） | 100  200  300  400 | 本端规划 | - |
|  | 在线计费统计类型（ONLMETERINGTYPE） | VOLUME  VOLUME  VOLUME  FREE | 全网规划 | 根据业务套餐情况，确定使用免费、按时长计费、按流量计费，还是按照流量+时长计费。  此处以按流量计费为例。 |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_offline\_URL  urr\_offline\_IMS  urr\_offline\_any  URR\_abnormal\_offline | 本端规划 | 配置业务离线计费URR。  说明：  URRID、USAGERPTMODE、OFFMETERINGTYPE需要与UPF上的配置保持一致。 |
|  | URR标识（URRID） | 12500  13500  11500  14500 | 全网规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE | 全网规划 |  |
|  | 离线计费标识组成类型（OFFCOMPOUNDTYPE） | ONLYRG | 全网规划 | 根据业务套餐情况，确定使用RG还是（RG，SID）作为费率标识。  此处以使用RG作为费率标识为例。 |
|  | 离线计费组（RG） | 1100  1200  1300  1400 | 本端规划 | - |
|  | 离线计费统计类型（OFFMETERINGTYPE） | VOLUME  VOLUME  VOLUME  FREE | 全网规划 | 根据业务套餐情况，确定使用免费、按时长计费、按流量计费，还是按照流量+时长计费。  此处以按流量计费为例。 |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | UrrGp\_URL  UrrGp\_IMS  UrrGp\_any  UrrGp\_abnormal | 本端规划 | 配置URRGROUP。  说明：  * 当**SET USRPROFCHARGE** 、**SET APNCHARGECTRL**、**ADD CHARGEMETHOD**命令的“RGAPPLIED”配置为“DEFAULT”时，不能同时配置RG相同的离线和在线URR。 * 当“RGAPPLIED”配置为“ONLINERGONLY”或“OFFLINERGONLY”时，建议同时配置离线和在线URR。 |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_online\_URL  urr\_online\_IMS  urr\_online\_any  URR\_abnormal\_online | 已配置数据中获取 |  |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_online\_URL  urr\_online\_IMS  urr\_online\_any  URR\_abnormal\_online | 已配置数据中获取 |  |
|  | 上行发起URR名称2（UPURRNAME2） | urr\_offline\_URL  urr\_offline\_IMS  urr\_offline\_any  URR\_abnormal\_offline | 已配置数据中获取 |  |
|  | 下行发起URR名称2（DOWNURRNAME2） | urr\_offline\_URL  urr\_offline\_IMS  urr\_offline\_any  URR\_abnormal\_offline | 已配置数据中获取 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | PPG\_URL  PPG\_IMS  PPG\_any | 本端规划 | 配置PCC业务策略组。 |
|  | URR组名称（URRGROUPNAME） | UrrGp\_URL  UrrGp\_IMS  UrrGp\_any | 已配置数据中获取 | 使用**ADD URRGROUP**命令定义的“URRGROUPNAME”。 |
| **ADD RULE** | 规则名称（RULENAME） | Rule001\_url  Rule002\_IMS  Rule003\_any  Rule003\_any\_IPv6 | 本端规划 | 配置规则，并绑定已配置的PCC策略组。  说明：  SMF、UPF上RULENAME以及RULE下配置的POLICYTYPE、POLICYNAME需要保持一致。 |
|  | 策略类型（POLICYTYPE） | PCC | 固定取值 | 表示该规则可以配置PCC策略，用于实现计费和策略控制功能。 |
|  | 全局优先级（PRIORITY） | 100  110  65000  65010 | 本端规划 | 取值越小，优先级越高。 |
|  | 策略名称（POLICYNAME） | PPG\_URL  PPG\_IMS  PPG\_any | 已配置数据中获取 | 使用**ADD PCCPOLICYGRP**命令定义的“PCCPOLICYGRPNM”。 |
| **SET URRGRPBINDING** | 用户模板名称（USERPROFILENAME） | userprofile001  userprofile002 | 本端规划 | 设置用户模板和URR Group的绑定关系。如果User Profile下不绑定默认URR Group，用户的数据包按全局URR Group计费，否则不计费。 |
|  | 缺省URR组名称（DFTURRGRPNAME） | UrrGp\_abnormal | 已配置数据中获取 | 指定缺省URR组名称，使用**ADD URRGROUP**命令配置生成。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | userprofile001 | 已配置数据中获取 | 使用**ADD USERPROFILE**命令定义的“USERPROFILENAME”。 |
|  | 规则名称（RULENAME） | Rule001\_url  Rule003\_any  Rule003\_any\_IPv6 | 已配置数据中获取 | 使用**ADD RULE**命令定义的**RULENAME**。  说明：  SMF、UPF上USERPROFILE下绑定的RULENAME、POLICYTYPE需要保持一致。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | userprofile002 | 已配置数据中获取 | 使用**ADD USERPROFILE**命令定义的“USERPROFILENAME”。 |
|  | 规则名称（RULENAME） | Rule002\_IMS | 已配置数据中获取 | 使用**ADD RULE**命令定义的**RULENAME**。  说明：  SMF、UPF上USERPROFILE下绑定的RULENAME、POLICYTYPE需要保持一致。 |

## 操作步骤

* 配置内容计费费率标识。
  1. 配置内容计费使用的URR组及相应URR。

     1. 配置URR。

        **ADD URR**
     2. 配置URR组，将URR绑定到URR组上。

        **ADD URRGROUP**
  2. 配置内容计费使用的Rule，将URR组绑定到对应的Rule上。

     1. 配置PCC策略组，将URR组绑定到PCC策略组。

        **ADD PCCPOLICYGRP**
     2. 配置Rule，将PCC策略组绑定到Rule上。

        **ADD RULE**
  3. 配置User Profile，将Rule绑定到User Profile上。

     1. 绑定该User Profile的缺省URR组，建议每个User Profile都绑定缺省费率URR组。

        **SET URRGRPBINDING**
     2. 将Rule绑定到User Profile上。

        **ADD RULEBINDING**
  4. **可选：**配置在线RG配额耗尽后的默认动作。

     **ADD QUOTAEXHAUSTACT**

     当计费事件触发SMF发起Charging Data Request[Update]更新消息申请配额，Total Volume到达后仍未收到NCG/CHF(OCS)响应消息，且SMF本地通过**SET FAILHANDLING**命令配置的TXTIMER超时时长未到达时，RG配额耗尽后的默认动作根据“ACTION”参数配置生效。

     + 当参数配置为“BLOCK”时，SMF在N4接口下发的该业务的URR绑定的FAR动作为drop，即在线RG配额耗尽后阻塞业务，使业务不能继续进行。
     + 当参数配置为“REDIRECT”时，SMF在N4接口下发的该业务的URR绑定的FAR动作为Redirect Information，即在线RG配额耗尽后将当前业务重定向到指定的地址。
     + 当参数配置为“FORWARD”时，SMF在N4接口下发的该业务的URR绑定的FAR动作为FORW，即在线RG配额耗尽后允许继续转发业务。

## 任务示例

任务描述

配置内容计费，相关条件、URRID及RG如下表所示。下表中数据与数据规划中表1相同。

| 条件 | 计费类型 | RG | URR ID | Rule Name | User Profile Name |
| --- | --- | --- | --- | --- | --- |
| 访问网址是www.huawei.com的网站 | online | 100 | 2300 | Rule001\_url | userprofile001 |
|  | offline | 1100 | 12500 |  |  |
| 访问IMS业务 | online | 200 | 3300 | Rule002\_IMS | userprofile002 |
|  | offline | 1200 | 13500 |  |  |
| any to any的业务流 | online | 300 | 1300 | Rule003\_any  Rule003\_any\_IPv6 | userprofile001 |
|  | offline | 1300 | 11500 |  |  |
| 异常场景计费URR | online | 400 | 4300 | - | - |
|  | offline | 1400 | 14500 |  |  |

脚本

//以下内容计费配置举例和UPF上的内容计费配置匹配。APN/DNN实例apn-test下绑定User Profile group实例upg\_test，upg\_test中绑定有User Profile实例userprofile001和userprofile002。

//配置URR。URRID、USAGERPTMODE、OFFMETERINGTYPE、ONLMETERINGTYPE在SMF和UPF上的配置需要保持一致。

```
ADD URR: URRNAME="urr_online_URL", URRID=2300, USAGERPTMODE=ONLINE, ONLCOMPOUNDTYPE=ONLYRG, ONLINERG=100, ONLMETERINGTYPE=VOLUME;
ADD URR: URRNAME="urr_offline_URL", URRID=12500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1100, OFFMETERINGTYPE=VOLUME;
ADD URR: URRNAME="urr_online_IMS", URRID=3300, USAGERPTMODE=ONLINE, ONLCOMPOUNDTYPE=ONLYRG, ONLINERG=200, ONLMETERINGTYPE=VOLUME;
ADD URR: URRNAME="urr_offline_IMS", URRID=13500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1200, OFFMETERINGTYPE=VOLUME;
ADD URR: URRNAME="urr_online_any", URRID=1300, USAGERPTMODE=ONLINE, ONLCOMPOUNDTYPE=ONLYRG, ONLINERG=300, ONLMETERINGTYPE=VOLUME;
ADD URR: URRNAME="urr_offline_any", URRID=11500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1300, OFFMETERINGTYPE=VOLUME;
ADD URR: URRNAME="URR_abnormal_online", URRID=4300, USAGERPTMODE=ONLINE, ONLCOMPOUNDTYPE=ONLYRG, ONLINERG=400, ONLMETERINGTYPE=FREE;
ADD URR: URRNAME="URR_abnormal_offline", URRID=14500, USAGERPTMODE=OFFLINE, OFFCOMPOUNDTYPE=ONLYRG, RG=1400, OFFMETERINGTYPE=FREE;
```

//配置URRGROUP。

```
ADD URRGROUP: URRGROUPNAME="UrrGp_URL", UPURRNAME1="urr_online_URL", DOWNURRNAME1="urr_online_URL", UPURRNAME2="urr_offline_URL", DOWNURRNAME2="urr_offline_URL";
ADD URRGROUP: URRGROUPNAME="UrrGp_IMS", UPURRNAME1="urr_online_IMS", DOWNURRNAME1="urr_online_IMS", UPURRNAME2="urr_offline_IMS", DOWNURRNAME2="urr_offline_IMS";
ADD URRGROUP: URRGROUPNAME="UrrGp_any", UPURRNAME1="urr_online_any", DOWNURRNAME1="urr_online_any", UPURRNAME2="urr_offline_any", DOWNURRNAME2="urr_offline_any";
ADD URRGROUP: URRGROUPNAME="UrrGp_abnormal", UPURRNAME1="URR_abnormal_online", DOWNURRNAME1="URR_abnormal_online", UPURRNAME2="URR_abnormal_offline", DOWNURRNAME2="URR_abnormal_offline";
```

//配置PCC组策略数据。

```
ADD PCCPOLICYGRP: PCCPOLICYGRPNM="PPG_URL", URRGROUPNAME="UrrGp_URL";
ADD PCCPOLICYGRP: PCCPOLICYGRPNM="PPG_IMS", URRGROUPNAME="UrrGp_IMS";
ADD PCCPOLICYGRP: PCCPOLICYGRPNM="PPG_any", URRGROUPNAME="UrrGp_any";
```

//配置规则，并绑定已配置的PCC策略组。SMF、UPF上RULENAME以及RULE下配置的POLICYTYPE、POLICYNAME需要保持一致。

```
ADD RULE: RULENAME="Rule001_url", POLICYTYPE=PCC, PRIORITY=100, POLICYNAME="PPG_URL";
ADD RULE: RULENAME="Rule002_IMS", POLICYTYPE=PCC, PRIORITY=110, POLICYNAME="PPG_IMS";
ADD RULE: RULENAME="Rule003_any", POLICYTYPE=PCC, PRIORITY=65000, POLICYNAME="PPG_any";
ADD RULE: RULENAME="Rule003_any_IPv6", POLICYTYPE=PCC, PRIORITY=65010, POLICYNAME="PPG_any";
```

//配置User Profile，将Rule绑定到User Profile上。USERPROFILE的名称统一规划，保证在PCF、SMF、UPF间名称一致。不一致时PCF下发的策略无法生效。

```
ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule001_url";
ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule003_any";
ADD RULEBINDING: USERPROFILENAME="userprofile001", RULENAME="Rule003_any_IPv6";
ADD RULEBINDING: USERPROFILENAME="userprofile002", RULENAME="Rule002_IMS";
```

//配置规则组下的URR组。建议每个User Profile都绑定缺省费率URR组。

```
SET URRGRPBINDING:USERPROFILENAME="userprofile001",DFTURRGRPNAME="UrrGp_abnormal";
SET URRGRPBINDING:USERPROFILENAME="userprofile002",DFTURRGRPNAME="UrrGp_abnormal";
```

版权所有 © 华为技术有限公司
