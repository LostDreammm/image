# Diameter定制字典加载

* 操作场景
* 对系统的影响
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

当系统启动后，Diameter接口应用会自动加载一套标准字典。如果用户有定制规范的需要，而现有标准Diameter字典无法满足定制需求，则需要通过定制字典方式进行适配。

该章节主要介绍定制字典文件的加载方式。若不需要加载定制字典，请跳过本章节。

## 对系统的影响

该操作对系统正常运行无影响。

## 必备事项

前提条件

* UPF软件安装已完成。
* UPF初始配置已完成。
* 已完成一跳入家依赖功能的License加载。
* 已联系华为技术工程师获取定制字典文件。”

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **MOD UPDIAMDICTPATH** | 应用(APPLICATION) | SWM | 固定值 | 该参数用于指定字典的Diameter应用。固定为SWM。 |
|  | 字典序号(DICTNO) | 1 | 本端规划 | 该参数用于指定字典编号。 |
|  | 字典加载路径(DICTPATH) | CUSTOM1 | 本端规划 | 该参数用于指定字典加载路径。CUSTOM1是指定制字典路径。 |
| **LOD UPDIAMDICT** | 字典文件选择(DICTFILESELECT) | ALL | 本端规划 | 该参数用于指定Diameter字典类型。 |
| **DSP UPDIAMDICTSTAT** | 选项(ITEM) | * LOAD\_STAT * PATH\_STAT | 本端规划 | 该参数用于指定状态输出类型。   * LOAD\_STAT：字典加载状态。 * PATH\_STAT：字典加载路径状态。 |

## 操作步骤

1. OM Portal上传定制字典文件。

   将定制字典文件custom\_signed.zip，上传到OM Portal界面中的“系统 -> 文件传输 -> Diameter字典 Custom”路径下。

   **图1** 定制字典文件目录

   **图2** OM Portal上传定制字典文件
2. 修改定制字典路径。

   在“MML命令行 - UDG”窗口上执行**MOD UPDIAMDICTPATH**命令将SWm应用的字典设置为“CUSTOM1”。
3. 加载字典文件。

   执行**LOD UPDIAMDICT**命令，加载SWm应用配置的定制字典路径下的Diameter字典文件。
4. 查看字典加载路径和字典加载状态。

   执行**LOD UPDIAMDICT**命令后，等待10-20秒，执行**DSP UPDIAMDICTSTAT**命令查看字典加载路径和字典加载状态。

## 任务示例

任务描述

定制字典文件加载。

脚本

1. 将SWm应用的字典加载路径修改为定制字典路径：

   ```
   MOD UPDIAMDICTPATH: APPLICATION=SWM, DICTNO=1,DICTPATH=CUSTOM1;
   ```
2. 加载SWm应用配置的定制字典路径下的Diameter字典文件：

   ```
   LOD UPDIAMDICT: DICTFILESELECT=ALL;
   ```
3. 查看字典加载路径和字典加载状态：

   ```
   DSP UPDIAMDICTSTAT: ITEM=PATH_STAT;
   DSP UPDIAMDICTSTAT: ITEM=LOAD_STAT;
   ```

版权所有 © 华为技术有限公司
