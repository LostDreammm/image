# 配置三四层业务触发的QoS保证（PGW-U、UPF）

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

当运营商规划了为某类需要QoS保证的业务提供专有承载/专有QoS Flow时，需要在UDG上配置基于三四层的业务触发的QoS保证数据。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-020358 业务触发的QoS保证。
* 完成加载license（如果有需求，请联系华为技术支持工程师处理）。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD FILTER** | 过滤器名字 （FILTERNAME） | filter\_test | 本端规划 | UDG通过将用户上下行报文匹配Filter，实现三四层报文的分析，从而过滤出会触发的数据报文。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 |  |
|  | 三四层协议类型（L34PROTOCOL） | ANY | 本端规划 |  |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test1 | 本端规划 | 流过滤器。 |
| **ADD FLTBINDFLOWF** | 过滤器名字 （FILTERNAME） | filter\_test | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER**命令配置，可以通过**LST FILTER**命令查询。 |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test1 | 已配置数据中获取 | 已通过**ADD FLOWFILTER**命令配置。 |
| **ADD QOSPROP** | Qos属性名称（QOSPROPNAME） | qos-property1 | 本端规划 | - |
|  | QoS使用量上报规则名称  （QOSURRNAME） | urr\_1 |  |  |
|  | 保证的上行比特率（GBRUPLKVALUE） | 110 |  |  |
|  | 保证的下行比特率（GBRDNLKVALUE） | 110 |  |  |
|  | 最大上行比特率（MBRUPLKVALUE） | 220 |  |  |
|  | 最大下行比特率（MBRDNLKVALUE） | 220 |  |  |
|  | 质差分析上报开关（QBGRPT） | DISABLE | 全网规划 | * DISABLE：无需关联质差检测，匹配中QoS规则即可上报。 * ENABLE：业务触发专载时，当系统检测到QoS质差后触发上报。   该参数需要与**SET QOSURRRPTCTRL**命令的**QBGRPT**参数保持一致。 |
|  | 上下行解耦开关（DECOUPLINGSW） | DISABLE | 全网规划 | 当**QBGRPT**参数设置为“ENABLE”时，**DECOUPLINGSW**参数设置为“ENABLE”可开启应用级下行保障。 |
| **ADD URR** | 使用量上报规则名称  （URRNAME） | urr\_1 | 本端规划 | 增加用于QoS事件上报的规则。 |
|  | URR标识（URRID） | 1001 | 本端规划 |  |
|  | 使用量上报模式  （USAGERPTMODE） | QOS | 固定取值 |  |
| **ADD RULE** | 规则名称（RULENAME） | rule\_test | 本端规划 | - |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | - |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_test1 | 已配置数据中获取 | 绑定的FlowFilter已通过**ADD FLOWFILTER**命令配置，可以通过**LST FLOWFILTER**命令查询。 |
|  | 策略名称（POLICYNAME） | ppg1 | 本端规划 | 绑定的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置，可以通过**LST PCCPOLICYGRP**命令查询。 |
|  | 全局优先级（PRIORITY） | 10 | 本端规划 | - |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | up\_test | 本端规划 | - |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | up\_test | 本端规划 | 使用**ADD USERPROFILE**命令定义的用户模板名称。 |
|  | 规则名称（RULENAME） | rule\_test | 已配置数据中获取 | UserProfile绑定的业务规则，已通过**ADD RULE**命令配置完成。 |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**
2. 配置三四层过滤条件。
   1. 配置三四层过滤条件。

      **ADD FILTER**
   2. 配置流过滤器。

      **ADD FLOWFILTER**
   3. 配置三四层过滤条件与流过滤器的绑定关系。

      **ADD FLTBINDFLOWF**
   4. 将新配置的Filter置为生效。

      **SET REFRESHSRV**
3. 配置QoS属性。
   1. 配置QoS类型URR。

      **ADD URR**
   2. 配置QoS属性。

      **ADD QOSPROP**
4. 配置PCC策略组。

   **ADD PCCPOLICYGRP**
5. 配置业务规则。

   **ADD RULE**

   如果运营商希望基于流过滤器组设置过滤条件时，配置“流过滤器或流过滤器组选择(FILTERINGMODE)”为“FLOWFILTERGRP”，并且使用**ADD FLOWFILTERGRP**命令配置流过滤器组。
6. 配置业务策略组合。
   1. 创建UserProfile。

      **ADD USERPROFIL**
   2. 将已配置的Rule绑定到UserProfile。

      **ADD RULEBINDING**
7. 配置UPF上报Flow-Description信息的格式。

   **SET UPGLBPMPARA**
8. 可选：配置软参**BIT1104**。

## 任务示例

任务描述

配置基于三四层专有承载创建。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5STQE01",SWITCH=ENABLE;
```

//配置三四层过滤条件。

```
ADD FILTER:FILTERNAME="filter_test",L34PROTTYPE=STRING,L34PROTOCOL=ANY;
```

```
ADD FLOWFILTER:FLOWFILTERNAME="flowfilter_test1",TETHERDETFLAG=DETECT_ONLY;
```

```
ADD FLTBINDFLOWF:FLOWFILTERNAME="flowfilter_test1",FILTERNAME="filter_test";
```

```
SET REFRESHSRV:REFRESHTYPE=USERPROFILE;
```

//配置QoS属性。

```
ADD URR: URRNAME="urr_1", URRID=1001, USAGERPTMODE=QOS;
```

```
ADD QOSPROP:QOSPROPNAME="qos-property1", QOSURRNAME="urr_1", GBRUPLKVALUE=110, GBRDNLKVALUE=110, MBRUPLKVALUE=220, MBRDNLKVALUE=220, QBGRPT=DISABLE;
```

//配置PCC策略组。

```
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="ppg1",QOSPROPNAME="qos-property1";
```

//配置业务规则。

```
ADD RULE:RULENAME="rule_test",POLICYTYPE=PCC,FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="flowfilter_test1", POLICYNAME="ppg1", PRIORITY=10;
```

//配置业务策略组合。

```
ADD USERPROFILE:USERPROFILENAME="up_test";
```

```
ADD RULEBINDING:USERPROFILENAME="up_test",RULENAME="rule_test";
```

//配置UPF上报Flow-Description信息的格式。

```
SET UPGLBPMPARA: FLOWDANYFMT=AnyFMT;
```

版权所有 © 华为技术有限公司
