# 配置费率切换

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

UNC支持节假日、星期及其费率时段的灵活设置，增强话单的计费信息收集功能。运营商可以在UNC上针对节日、周末和工作日的特定时间段设置不同的计费标准，从而吸引移动用户消费，增加运营商收入。

UNC支持如下粒度配置费率切换：“User Profile实例 > APN实例 > 计费属性 > 整机”，优先级依次降低，如果高一优先级的参数没有配置，则默认继承低一优先级的参数配置。

## 必备事项

前提条件

* 请仔细阅读融合计费原理和Ga/Gy接口离线/在线计费。
* 完成加载License。
* 本操作任务涉及的APN/DNN、User Profile、User Profile group已经创建完成，并完成User Profile group与APN/DNN的绑定。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD FESTIVAL** | 全局配置（GLOBALFLG） | CHARGE\_CHARACT | 本端规划 | 配置指定日期的费率类型为节假日。   * 该命令可以基于计费属性配置，“CCVALUE”不能取值为“0x0200”，因为统一费率类型的用户费率不变，不会发生费率切换。 * “GLOBALFLG”取值可以为：   + “GLOBAL”：全局计费属性。   + “CHARGE\_CHARACT”：特殊计费属性。 基于特殊计费属性的节假日信息优先级高于全局计费属性的节假日信息。 |
|  | 计费属性值（CCVALUE） | 0x0800 | 本端规划 |  |
|  | 节假日月份（MONTH） | 8 | 本端规划 |  |
|  | 节假日日期（DAY） | 1 | 本端规划 |  |
| **ADD WEEKDAY** | 全局配置（GLOBALFLG） | CHARGE\_CHARACT | 本端规划 | 配置计费星期表记录，指定每周日期的费率类型为工作日或周末。   * 该命令可以基于计费属性配置。 * 由于统一费率计费不涉及费率切换，因此该命令中的计费类型不包括统一费率计费。 * “GLOBALFLG”取值可以为：   + “GLOBAL”：全局计费属性。   + “CHARGE\_CHARACT”：特殊计费属性。 基于特殊计费属性的计费星期表记录优先级高于全局计费属性的计费星期表记录。 |
|  | 计费属性值（CCVALUE） | 0x0800 | 本端规划 |  |
|  | 周日期（DAYOFWEEK） | MONDAY  TUESDAY  WEDNESDAY  THURSDAY  FRIDAY  SATURDAY  SUNDAY | 全网规划 |  |
|  | 费率类型（TARIFFTYPE） | WORKDAY  WEEKEND | 全网规划 |  |
| **ADD TARIFFGROUP** | 费率切换组名（TARIFFGRPNAME） | tar\_nb | 本端规划 | 配置费率切换点。   * 该命令可以基于计费属性配置。 * 由于统一费率计费不涉及费率切换，因此该命令中的“CCVALUE”不能取值为“0x0200”。 * “GLOBALFLG”取值可以为：   + “GLOBAL”：全局计费属性。   + “CHARGE\_CHARACT”：特殊计费属性。 基于特殊计费属性配置的费率切换点优先级高于全局计费属性的费率切换点。 |
|  | 全局配置（GLOBALFLG） | CHARGE\_CHARACT | 本端规划 |  |
|  | Charge Characteristic值（CCVALUE） | 0x0800 | 本端规划 |  |
|  | 费率类型（TARIFFTYPE） | FESTIVAL  WEEKEND  WORKDAY | 全网规划 |  |
|  | 费率切换起始时间（STARTTIME） | 7:00 | 全网规划 |  |
|  | 费率切换终止时间（ENDTIME） | 23:00 | 全网规划 |  |
| **SET N40QUOTACTRL** | 费率切换模式（TCMODE） | DEFAULT | 本端规划 | 费率切换发生的时间点按照**ADD TARIFFGROUP**命令配置的费率切换生效。 |
| **SET GLBTARIFFGROUP** | 费率切换组名（GLBTARIFFGRP） | tar\_nb | 本端规划 | 配置全局费率切换组。 |
| **SET APNCHARGECTRL** | APN名称（APN） | apn-test | 已配置数据中获取 | 每个DNN只能绑定一个费率切换组。如果DNN已绑定了费率切换组，要修改为绑定其他的费率切换组，必须先执行**SET APNCHARGECTRL**命令修改原来的绑定关系。 |
|  | 费率切换组名（TARIFFGRPNAME） | tar\_nb | 已配置数据中获取 |  |
| **SET USRPROFCHARGE** | 用户模板名称（USRPROFNAME） | up-test | 已配置数据中获取 | 每个User Profile只能绑定一个费率切换组。如果User Profile下已绑定了费率切换组，要修改为绑定其他的费率切换组，必须先执行**SET USRPROFCHARGE**命令修改原来的绑定关系。 |
|  | 费率切换组名（TARIFFGRPNAME） | tar\_nb | 已配置数据中获取 |  |

## 操作步骤

1. 配置费率切换。
   1. 配置节假日信息，即设置指定日期的费率类型为节假日。

      **ADD FESTIVAL**
   2. 配置星期表信息，即设置指定星期的费率类型为工作日或周末。

      **ADD WEEKDAY**
   3. 配置节假日，工作日或周末的费率时间段。

      **ADD TARIFFGROUP**
   4. **可选**：配置费率切换模式。

      **SET N40QUOTACTRL**

      * 当“TCMODE”参数配置为“DEFAULT”时，表示费率切换发生的时间点按照**ADD TARIFFGROUP**命令配置的费率切换生效。
      * 当“TCMODE”参数配置为“DAILY”时，表示在**ADD TARIFFGROUP**命令的费率切换配置基础上，每天00：00再强制进行费率切换，生效范围为所有用户。
      * 当“TCMODE”参数配置为“MONTHLY”时，表示在**ADD TARIFFGROUP**命令的费率切换配置基础上，月初第一天00：00再强制进行费率切换，生效范围为所有用户。
2. 配置全局费率切换组。

   **SET GLBTARIFFGROUP**
3. 为APN实例绑定费率切换组。

   **SET APNCHARGECTRL**
4. 为User Profile实例绑定费率切换组。

   **SET USRPROFCHARGE**

## 任务示例

任务描述

配置整机下的用户费率时间段：

* 节假日：8月1日
* 工作日：星期一，星期二，星期三，星期四，星期五
* 周末：星期六，星期天
* 每天的07:00–23:00是一个费率时段
* 费率切换发生的时间点默认按照**ADD TARIFFGROUP**的费率切换配置生效

脚本

1. 配置费率切换组。

   //配置节假日。

   ```
   ADD FESTIVAL: GLOBALFLG=CHARGE_CHARACT,CCVALUE="0x0800", MONTH=8,DAY=1;
   ```

   //配置星期。

   ```
   ADD WEEKDAY: GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", DAYOFWEEK=MONDAY, TARIFFTYPE=WORKDAY;
   ```

   ```
   ADD WEEKDAY: GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", DAYOFWEEK=TUESDAY, TARIFFTYPE=WORKDAY;
   ```

   ```
   ADD WEEKDAY: GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", DAYOFWEEK=WEDNESDAY, TARIFFTYPE=WORKDAY;
   ```

   ```
   ADD WEEKDAY: GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", DAYOFWEEK=THURSDAY, TARIFFTYPE=WORKDAY;
   ```

   ```
   ADD WEEKDAY: GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", DAYOFWEEK=FRIDAY, TARIFFTYPE=WORKDAY;
   ```

   ```
   ADD WEEKDAY: GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", DAYOFWEEK=SATURDAY, TARIFFTYPE=WEEKEND;
   ```

   ```
   ADD WEEKDAY: GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", DAYOFWEEK=SUNDAY, TARIFFTYPE=WEEKEND;
   ```

   //配置节假日和星期的费率时间段。

   ```
   ADD TARIFFGROUP: TARIFFGRPNAME="tar_nb", GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", TARIFFTYPE=WORKDAY, STARTTIME=07&00, ENDTIME=23&00;
   ```

   ```
   ADD TARIFFGROUP: TARIFFGRPNAME="tar_nb", GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", TARIFFTYPE=WEEKEND, STARTTIME=07&00, ENDTIME=23&00;
   ```

   ```
   ADD TARIFFGROUP: TARIFFGRPNAME="tar_nb", GLOBALFLG=CHARGE_CHARACT, CCVALUE="0x0800", TARIFFTYPE=FESTIVAL, STARTTIME=07&00, ENDTIME=23&00;
   ```

   //配置费率切换模式。

   ```
   SET N40QUOTACTRL: TCMODE=DEFAULT;
   ```
2. 配置全局的费率切换组。

   ```
   SET GLBTARIFFGROUP: GLBTARIFFGRP="tar_nb";
   ```
3. 为APN实例绑定费率切换组。

   ```
   SET APNCHARGECTRL: APN="apn-test", TARIFFGRPNAME="tar_nb";
   ```
4. 为User Profile实例绑定费率切换组。

   ```
   SET USRPROFCHARGE:USRPROFNAME="up-test", TARIFFGRPNAME="tar_nb";
   ```

版权所有 © 华为技术有限公司
