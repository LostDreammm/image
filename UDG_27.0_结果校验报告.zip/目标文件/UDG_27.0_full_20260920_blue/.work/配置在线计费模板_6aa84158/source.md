# 配置在线计费模板

* 操作场景
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

## 操作场景

本指导描述在UNC上配置在线计费模板的相关操作过程。

在线计费模板是用来绑定在线计费本地配置参数的，在线计费DCC模板分为全局通用参数模板global和普通的模板DCC Template，前者用于配置整机通用的在线计费参数，后者用于配置特殊场景下的在线计费参数。

在线计费参数中，除了OCS的基本信息是基于全局配置的之外，其他的参数，如要使用的OCS服务器、CCR触发场景、DCC处理动作、CCR消息中携带的参数等都可以选择基于整机或特殊场景生效。

UNC支持以下几种粒度范围的在线计费参数配置：

* 支持配置整机通用参数。
* 支持根据用户计费属性Charging Characteristics配置在线计费参数。
* 支持根据APN配置在线计费参数。
* 支持根据User Profile配置在线计费参数。

上述几种粒度范围的优先级从高到低依次是：User Profile下的配置–〉APN下的配置–〉计费属性下的配置–〉整机通用参数。如果高级别的参数没有配置或者配置为inherit，则依次向下继承低一级别的参数取值。整机通用参数配置在global模板中，其他几种粒度都配置在DCC Template中，并进而跟随DCC Template绑定其生效的范围：某一计费属性、APN、或者User Profile。

在线计费参数的配置粒度，建议与在线计费使能的粒度保持一致，即如果基于APN开启在线计费功能，同样基于APN配置在线计费参数，这样可以避免各配置参数生效范围冲突和不一致。一旦确定了整个系统的在线计费参数配置粒度，则所有在线计费参数的配置原则上都必须统一使用该粒度。

## 必备事项

前提条件

* 请仔细阅读Ga/Gy接口离线/在线计费。
* 完成配置到OCS的数据(静态路由+BFD组网)。
* 完成加载license。
* 已完成计费属性、APN、User Profile创建。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD DCCTEMPLATE** | DCC模板名称（DCCTMPLTNAME） | dcc-test | 本端规划 | 新增DCC在线计费模板，用于配置在线计费相关属性。  说明：  如果需要配置在线计费全局参数，则需要使用**MOD DCCTEMPLATE**命令，“DCCTMPLTNAME”参数值为“global”。 |
| **ADD GLBDCCTEMPLATE** | 计费属性（CHARGECHARACT） | CHARGE\_CHARACT | 本端规划 | 基于计费属性绑定在线计费模板。 |
|  | 计费属性值（SPECIFICCCVALUE） | 0x0800 | 本端规划 |  |
|  | 在线计费模板名称（DCCTEMPLATENAME） | dcc-test | 已配置数据中获取 |  |
| **SET APNCHARGECTRL** | APN名称（APN） | apn-test | 已配置数据中获取 | 基于APN绑定DCC模板。  说明：  APN通过**ADD APN**命令创建。 |
|  | DCC模板名称（DCCTEMPLATE） | dcc-test | 已配置数据中获取 |  |
| **SET USRPROFCHARGE** | 用户模板名称（USRPROFNAME） | up-test | 已配置数据中获取 | 基于User Profile绑定DCC模板。  说明：  User Profile通过**ADD USERPROFILE**命令创建。 |
|  | DCC模板名称（DCCTEMPLATE） | dcc-test | 已配置数据中获取 |  |

## 操作流程

* 配置全局通用参数DCCGlobal模板，请执行步骤 1。
* 配置计费属性下的DCC Template模板，请执行步骤 1，步骤 2。
* 配置APN下的DCC Template模板，请执行步骤 1，步骤 3。
* 配置User Profile下的DCC Template模板，请执行步骤 1，步骤 4。

## 操作步骤

1. 配置DCC Template模板。重复执行本步骤可增加多个DCC Template模板。
   1. 配置全局通用参数DCC模板。

      **MOD DCCTEMPLATE**
   2. 配置DCC Template模板，以及触发CCR的各参数、CCR消息中携带的参数。

      **ADD DCCTEMPLATE**
2. 配置DCC Template模板绑定到计费属性。

   **ADD GLBDCCTEMPLATE**
3. 配置DCC Template模板绑定APN实例。

   **SET APNCHARGECTRL**
4. 配置DCC Template模板绑定User Profile实例。

   **SET USRPROFCHARGE**

## 任务示例

任务描述

任务一：配置计费属性下的DCC Template模板。

任务二：配置APN下的DCC Template模板。

任务三：配置User Profile下的DCC Template模板。

脚本

//任务一：配置计费属性下的DCC Template模板。

```
ADD DCCTEMPLATE:DCCTMPLTNAME="dcc-test";
```

```
ADD GLBDCCTEMPLATE:CHARGECHARACT=CHARGE_CHARACT,SPECIFICCCVALUE="0x0800",DCCTEMPLATENAME ="dcc-test";
```

//任务二：配置APN下的DCC Template模板。

```
ADD DCCTEMPLATE:DCCTMPLTNAME="dcc-test";
SET APNCHARGECTRL:APN="apn-test",DCCTEMPLATE="dcc-test";
```

//任务三：配置User Profile下的DCC Template模板。

```
ADD DCCTEMPLATE:DCCTMPLTNAME="dcc-test";
SET USRPROFCHARGE: USRPROFNAME="up-test", DCCTEMPLATE="dcc-test";
```

版权所有 © 华为技术有限公司
