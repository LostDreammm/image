# 激活DNS端口计费防欺诈

* 操作场景
* 必备事项
* 操作流程
* 任务示例

## 操作场景

当运营商设置了DNS免费策略，为了避免黑客用专用的客户端将原始报文的端口修改为DNS知名端口53，伪装成免费的DNS报文实现免费上网。DNS端口防欺诈方案不再仅通过端口号对DNS数据报文进行解析，而是通过增强的DNS报文识别功能对DNS数据报文进行深度解析，判断DNS报文的协议一致性，将真正的用户DNS报文按照原来的规则记为免费，而对伪造的DNS报文按照正常的流量进行计费。

* 服务器端口53，L7识别为DNS报文，则判断为正常DNS报文。
* 服务器端口53，L7识别为非DNS报文，则判断为使用DNS 53端口欺诈报文。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读DNS计费防欺诈原理。
* 完成加载license（如果有需求，请联系华为技术支持工程师处理）。

数据

**表1** License信息

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| 打开License配置开关。  **SET LICENSESWITCH** | License项（LICITEM） | LKV3G5DCAS01 | 本端规划 | - |
|  | 开关（SWITCH） | ENABLE | 本端规划 | - |

**表2** 三四层过滤条件（基于53端口）

| 命令 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD FILTER** | 过滤器名字（FILTERNAME） | filter\_dns | 本端规划 | 通过将用户上下行报文匹配Filter，实现端口为53的UDP报文的过滤。   * 如果能预先获取DNS Server IP列表，在三四层filter中配置端口和Server IP可实现DNS端口计费防欺诈。 * 如果不能预先获取DNS Server IP列表，需要配置七层filter进行DNS协议识别可实现DNS端口计费防欺诈。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 |  |
|  | 三四层协议类型（L34PROTOCOL） | UDP | 本端规划 |  |
|  | 服务器起始端口号（SVRSTARTPORT） | 53 | 本端规划 |  |
|  | 服务器结束端口号（SVRENDPORT） | 53 | 本端规划 |  |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_dns | 本端规划 | 用于绑定Filter的FLOWFILTER。 |
| **ADD FLTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_dns | 已配置数据中获取 | 流过滤器名称已通过**ADD FLOWFILTER**命令配置。 |
|  | 过滤器名称（FILTERNAME） | filter\_dns | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER**命令配置。 |

**表3** 七层过滤条件（DNS协议）

| 命令 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD L7FILTER** | 七层过滤器名称（L7FILTERNAME） | l7filter\_dns | 本端规划 | 配置七层Filter，实现报文识别，判断DNS报文的协议一致性。 |
|  | 子七层过滤器名称（SUBL7FLTNAME） | 1 | 本端规划 |  |
|  | URL（URL） | \*/\* | 本端规划 |  |
| **ADD PROTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_dns | 已配置数据中获取 | DNS端口计费防欺诈功能需要对DNS报文进行解析。 |
|  | 协议名称（PROTOCOLNAME） | dns | 本端规划 |  |
|  | 七层过滤器名字（L7FILTERNAME） | l7filter\_dns | 已配置数据中获取 |  |
| **SET REFRESHSRV** | 刷新类型  （REFRESHTYPE） | ALL | 本端规划 | 将新配置的Filter置为生效。 |

**表4** URR组和策略

| 命令 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_dns | 本端规划 | urr\_dns用于DNS报文的使用量上报规则处理，计费类型为免费。 |
|  | URR标识（URRID） | 2000 | 本端规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE | 本端规划 |  |
|  | 离线计费统计类型（OFFMETERINGTYPE） | FREE | 本端规划 |  |
| **ADD URRGROUP** | 使用量上报规则组名称(URRGROUPNAME) | cp\_dns | 本端规划 | - |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_dns | 已配置数据中获取 | 上行业务触发使用的URRName，已通过**ADD URR**命令配置完成。 |
|  | 下行发起URR名称1(DOWNURRNAME1) | urr\_dns | 已配置数据中获取 | 下行业务触发使用的URRName，已通过**ADD URR**命令配置完成。 |
| **ADD PCCACTIONPROP** | PCC动作属性名称（PCCACTPROPNAME） | ap\_dns | 本端规划 | ap\_dns用于DNS报文的动作处理。 |
|  | 上行发起上行门控（UPINITUPGATE） | PASS | 本端规划 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称(PCCPOLICYGRPNM) | pg\_dns | 本端规划 | pg\_dns用于DNS报文的PCC策略组，包括计费处理和动作处理。 |
|  | URR组名称(URRGROUPNAME) | cp\_dns | 已配置数据中获取 | PCC策略组绑定的URR组名称，已通过**ADD URRGROUP**命令配置完成。 |
|  | PCC动作属性名称（PCCACTPROPNAME） | ap\_dns | 已配置数据中获取 | PCC策略组绑定的动作属性，已通过**ADD PCCACTIONPROP**命令配置完成。 |

**表5** 规则

| 命令 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RULE** | 规则名称（RULENAME） | rule\_dns | 本端规划 | - |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 |  |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 |  |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_dns | 已配置数据中获取 | 业务策略绑定的FlowFilter，已通过**ADD FLOWFILTER**命令配置完成。 |
|  | 策略名称（POLICYNAME） | pg\_dns | 已配置数据中获取 | 策略名称，已经通过命令**ADD PCCPOLICYGRP**配置完成。 |

**表6** 用户属性模板

| 命令 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | up\_dns | 本端规划 | - |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | up\_dns | 已配置数据中获取 | 用户模板名称，已通过**ADD USERPROFILE**命令配置完成。 |
|  | 规则名称（RULENAME） | rule\_dns | 已配置数据中获取 | UserProfile绑定的业务规则，已通过**ADD RULE**命令配置完成。 |

## 操作流程

**图1** 配置逻辑

## 任务示例

任务描述

配置DNS的报文识别，将满足端口号为53且协议识别为DNS的报文设置为免费。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5DCAS01",SWITCH=ENABLE;
```

//配置三四层过滤条件，报文满足端口号为53时才会命中该过滤条件。

```
ADD FILTER:FILTERNAME="filter_dns",L34PROTTYPE=STRING,L34PROTOCOL=UDP,SVRSTARTPORT=53,SVRENDPORT=53;
ADD FLOWFILTER:FLOWFILTERNAME="flowfilter_dns";
ADD FLTBINDFLOWF:FLOWFILTERNAME="filter_dns",FILTERNAME="flowfilter_dns";
```

//配置七层过滤条件，报文满足七层协议是DNS时才会命中该过滤条件。

```
ADD L7FILTER:L7FILTERNAME="l7filter_dns",SUBL7FLTNAME="1",URL="*/*"; 
ADD PROTBINDFLOWF:FLOWFILTERNAME="flowfilter_dns", PROTOCOLNAME="dns", L7FILTERNAME="l7filter_dns";
SET REFRESHSRV:REFRESHTYPE=USERPROFILE;
```

//配置免费的DNS报文使用的URR组和策略。

```
ADD URR:URRNAME="urr_dns",URRID=2000,USAGERPTMODE=ONLINE,OFFMETERINGTYPE=FREE;
ADD URRGROUP:URRGROUPNAME="cp_dns",UPURRNAME1="urr_dns",DOWNURRNAME1="urr_dns";
ADD PCCACTIONPROP:PCCACTPROPNAME="ap_dns",UPINITUPGATE=PASS;
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="pg_dns",PCCACTPROPNAME="ap_dns",URRGROUPNAME="cp_dns";
```

//配置免费的DNS报文使用的规则。

```
ADD RULE:RULENAME="rule_dns",POLICYTYPE=PCC,FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="filter_dns",POLICYNAME="pg_dns";
```

//配置免费的DNS报文的规则绑定用户模板。

```
ADD USERPROFILE:USERPROFILENAME="up_test";
ADD RULEBINDING:USERPROFILENAME="up_test",RULENAME="rule_red";
```

版权所有 © 华为技术有限公司
