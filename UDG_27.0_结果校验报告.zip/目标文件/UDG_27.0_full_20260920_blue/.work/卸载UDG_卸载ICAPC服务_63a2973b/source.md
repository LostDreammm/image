# 卸载ICAPC服务

* 操作场景
* 必备事项
* 操作步骤

## 操作场景

当运营商不需要ICAPC服务或ICAPC服务动态上线失败时，可以单独卸载ICAPC pod，从而下线ICAPC服务。

## 必备事项

前提条件

已经完成网络设计，已规划下线ICAPC pod的类型和数量。

数据

| 类别 | 参数名称 | 取值样例/说明 | 获取方法 |
| --- | --- | --- | --- |
| UDG OM Portal帐户 | IP地址 | 192.168.1.1  操作维护接口IP，即“VNFD模板”中的“MNG\_IP”或“MNG\_IPv6”参数。 | 本端规划 |
|  | 端口号 | 31943 | 本端规划 |
|  | 用户名 | admin | 本端规划 |
|  | 密码 | Changeme\_123 | 本端规划 |
| 特性下线  OPR FEATUREDISABLE | Pod类型列表（PODTYPE） | icapc-pod/icapcctrl-pod  pod类型，用/分割。不要带空格。 | 本端规划 |
|  | 下线方式（DISABLETYPE） | Normal | 本端规划 |
|  | FUNCTIONSETNAME  （网络功能集名称） | ICAPC | 固定取值 |

## 操作步骤

1. 登录UDG OM Portal。
2. 执行命令，动态下线ICAPC pod。

   ```
   OPR FEATUREDISABLE:PODTYPE="icapc-pod/icapcctrl-pod", DISABLETYPE=Normal, FUNCTIONSETNAME="ICAPC";
   ```
3. 执行命令，确认已经成功下线ICAPC pod。

   ```
   DSP FEATUREOPRHIST:;
   ```

   回显为“处理结果=处理成功”。

   ```
   DSP POD: MEID="网元ID", TYPE=byType, PODTYPE="icapc-pod";
   DSP POD: MEID="网元ID", TYPE=byType, PODTYPE="icapcctrl-pod";
   ```

   回显为“查询Pod不存在”。
4. 若动态下线ICAPC服务后，不再上线ICAPC服务，则需要缩容ICAPC自身VM（PBU\_E-S），释放VM资源。

   若后续还需要上线ICAPC服务，则不必缩容ICAPC自身VM。

   **缩容VM**：请参见《UDG中心侧扩缩容指导书(基于LCM)》或《UDG中心侧扩缩容指导书(基于NFVO)》。

版权所有 © 华为技术有限公司
