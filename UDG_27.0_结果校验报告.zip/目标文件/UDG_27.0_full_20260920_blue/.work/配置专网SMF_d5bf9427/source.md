# 配置专网SMF

* 操作场景
* 必备事项
* 任务示例

## 操作场景

该任务旨在指导操作人员完成专网SMF一跳入家解决方案的配置。

## 必备事项

前提条件

* 已完成一跳入家依赖功能的License加载。
* 已经完成与专网UPF的基础对接配置。
* 已完成一跳入家要求的移动VPN相关配置。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **MOD PNFDNN** | 索引（Index） | * 1 * 2 | 本端规划 | - |
|  | 优先级功能开关（PRISWITCH） | SPECIFIC | 本端规划 | - |
|  | 优先级（PRIORITY） | * 1 * 2 | 全网规划 | 值越小优先级越高。 |
| **SET APNUPSELPLY** | APN名称（APN） | home.area1.dnn | 全网规划 | 开通一跳入家业务的Home DNN。 |
|  | 基于优先级优选UPF开关（PRIORITYFLAG） | ENABLE | 本端规划 | - |
| **MOD UPNODE** | UPF实例名称（NFINSTANCENAME） | * upf\_instance\_1 * upf\_instance\_2 | 全网规划 | - |
|  | 是否支持作为智家随行场景To Home会话主锚点（TOHPSASW） | ENABLE | 全网规划 | 主UPF需要配置此开关参数为“ENABLE”。 |
| **ADD APNTOHCTRL** | APN名称（APN） | home.area1.dnn | 全网规划 | 开通一跳入家业务的Home DNN。 |
|  | 智家随行会话开关（TOHSW） | ENABLE | 本端规划 | - |
| **SET SMFFUNC** | 5G LAN会话是否向UDM查询VnGroupData(VNGROUPDATASW) | Support | 本端规划 | 当“智家随行会话开关”配置为“ENABLE”时，此开关参数必须设置为“Support”。 |
| **ADD APNUPRECOVER** | APN名称（APN） | home.area1.dnn | 全网规划 | 开通一跳入家业务的Home DNN。 |
|  | 主UPF实例名称（MASTERUPFID） | upf\_instance\_1 | 全网规划 | - |
|  | UP链路故障恢复处理模式（HANDLINGMODE） | BACKMIGRATION | 全网规划 | 设置为“BACKMIGRATION”，SMF检测到主UPF故障恢复后将Home DNN下的会话从备UPF回迁到主UPF。 |
|  | 备UPF实例名称（BACKUPFID） | upf\_instance\_2 | 全网规划 | - |
| **SET PFCPPVTEXT** | 特性名称（FEATURE） | * Session\_Delete\_Cause * NGLAN | 本端规划 | - |
|  | 私有信元携带开关（SWITCH） | ENABLE | 本端规划 | 当“UP链路故障恢复处理模式”配置为“BACKMIGRATION”时，此开关参数必须设置为“ENABLE”。 |

## 任务示例

任务描述

在SMF上配置一跳入家主备UPF的属性和优先级，并设置SMF一跳入家相关的开关参数。

脚本

1. 在SMF上使能专网UPF的一跳入家功能：设置upf\_instance\_1和upf\_instance\_2“是否支持作为智家随行场景To Home会话主锚点”参数为“使能”。

   ```
   LST UPNODE:;//查询当前配置。
   MOD UPNODE: NFINSTANCENAME="upf_instance_1", TOHPSASW=ENABLE;
   MOD UPNODE: NFINSTANCENAME="upf_instance_2", TOHPSASW=ENABLE;
   ```
2. 配置SMF进行UPF选择时，优先选择主UPF：设置upf\_instance\_1和upf\_instance\_2“优先级功能开关”参数为“指定”，且upf\_instance\_1的“优先级”取值比upf\_instance\_2的小。

   ```
   SET APNUPSELPLY: APN="home.area1.dnn", PRIORITYFLAG=ENABLE;//设置Home DNN下支持基于优先级选择UPF。
   LST PNFDNN:;//查询当前配置。
   MOD PNFDNN: INDEX=1, PRISWITCH=SPECIFIC, PRIORITY=1;//设置upf_instance_1为主UPF。“PRIORITY”参数取值越小，优先级越高。
   MOD PNFDNN: INDEX=2, PRISWITCH=SPECIFIC, PRIORITY=2;//设置upf_instance_2为备UPF。
   ```
3. 配置主UPF故障恢复后，SMF回迁业务会话至主UPF。**注意此处的主备UPF务必和2中定义的主备UPF保持一致，否则会导致无法回迁。**

   ```
   ADD APNUPRECOVER: APN="home.area1.dnn", MASTERUPFID="upf_instance_1", HANDLINGMODE=BACKMIGRATION, BACKUPFID="upf_instance_2";
   ```
4. 打开SMF上的一跳入家功能开关。注意“APN”值已经在**ADD APN**中配置。

   ```
   ADD APNTOHCTRL: APN="home.area1.dnn", TOHSW=ENABLE;
   ```
5. 设置SMF向UDM查询家庭组ID对应的VnGroupData。用户会话建立时，当UDM返回的签约数据中包括家庭组ID和SharedDataID，SMF会基于SharedDataID向UDM发送一次查询消息来再次确认该家庭组ID对应的VnGroupData，以确保家庭组ID的准确性。

   ```
   SET SMFFUNC: VNGROUPDATASW=Support;
   ```
6. 打开SMF上一跳入家相关的私有信元开关。

   ```
   SET PFCPPVTEXT: FEATURE=Session_Delete_Cause, SWITCH=ENABLE;//配置PFCP Session Deletion Request消息中携带Session级私有信元Session Delete Cause（指示删除备UPF的会话）。
   SET PFCPPVTEXT: FEATURE=NGLAN, SWITCH=ENABLE;//配置PFCP Session Establishment Request消息中携带私有信元5GLan Session Type（标识智家业务）和5G VN Instance（家庭组ID）。
   ```

版权所有 © 华为技术有限公司
