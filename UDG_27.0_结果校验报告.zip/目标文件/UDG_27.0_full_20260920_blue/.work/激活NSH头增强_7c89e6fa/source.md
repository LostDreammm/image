# 激活NSH头增强

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

当需要将用户信息通过NSH封装方式传递给第三方APP时，需要部署此功能。

适用于PGW-U、UPF。

## 必备事项

前提条件

请仔细阅NSH头增强原理描述。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD APN** | APN名称（APN） | apn-test | 本端规划 | 配置需要进行NSH头增强功能的APN信息。 |
| ****SET APNNSHHEADENFUNC**** | APN（APN） | apn-test | 已配置数据中获取 | 已通过**ADD APN**配置。 |
|  | 功能开关（SWITCH） | ENABLE | 本端规划 | 基于APN粒度开启NSH头增强功能。 |
| ****ADD NSHHEADEN**** | NSH头增强名称（NSHNAME） | nsh | 本端规划 | - |
|  | 数据类型（DATATYPE） | MSISDN1 | 本端规划 | - |
|  | TAG编码（TAGVALUE） | 1 | 本端规划 | - |
|  | 加密算法标识（ENCRYALGORI） | SHA256 | 本端规划 | 注意：  **ENCRYALGORI**取值为NONE时表示不进行加密，有安全风险，不建议使用。 |
|  | 密码（PSWDKEY） | 123456 | 本端规划 | - |
|  | 确认密码（PSWDKEYCONFIRM） | 123456 | 本端规划 | - |
| ****SET GLBNSHHDNPLY**** | NSH头增强名称（NSHNAME） | nsh | 已配置数据中获取 | 已通过**ADD NSHHEADEN**配置。 |
|  | 重定向IP协议版本（REDIRIPVER） | IPV4 | 本端规划 | - |
|  | 重定向IPV4地址（REDIRIPV4） | 10.0.0.0 | 全网规划 | - |
|  | NSH对端设备端口号（DSTSERVERPORT） | 6633 | 本端规划 | - |

## 操作步骤

1. 配置需要进行NSH头增强功能的APN信息。

   **ADD APN**
2. 基于APN粒度开启NSH头增强功能。

   **SET APNNSHHEADENFUNC**
3. 配置NSH头增强功能参数。

   **ADD NSHHEADEN**
4. 配置NSH头增强全局策略。

   **SET GLBNSHHDNPLY**

## 任务示例

任务描述

UDG将特定APN下用户的MSISDN信息进行NSH封装。

脚本

//配置需要进行NSH头增强功能的APN信息。

```
ADD APN: APN="apn-test";
```

//基于APN粒度开启NSH头增强功能。

```
SET APNNSHHEADENFUNC: APN="apn-test", SWITCH=ENABLE;
```

//配置NSH头增强功能参数。

```
ADD NSHHEADEN: NSHNAME="nsh", DATATYPE=MSISDN1, TAGVALUE=1, ENCRYALGORI=SHA256, PSWDKEY="123456", PSWDKEYCONFIRM="123456";
```

//配置NSH头增强全局策略。

```
SET GLBNSHHDNPLY: NSHNAME="nsh", REDIRIPVER=IPV4, REDIRIPV4="10.0.0.0", DSTSERVERPORT=6633;
```

版权所有 © 华为技术有限公司
