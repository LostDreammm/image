# 激活终端异常下行流量检测

* 操作场景
* 必备事项
* 操作步骤
* 验证方法
* 任务示例

## 操作场景

需要开启终端异常下行流量检测功能时，执行此任务。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-020305 终端异常下行流量检测特性概述。
* 完成**加载license**（如果有需求，请联系华为技术支持工程师处理）。
* 完成配置APN。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD ABNTRAFFICDT** | APN名称(APN) | apn1.com | 从已配置数据中获取 | APN名称已经通过命令**ADD APN**进行配置。 |
|  | 开关(SWITCH) | ENABLE | 本端规划 |  |
|  | 基于流行为的检测开关(TRAFFICBEHAVIORSWITCH) | ENABLE | 本端规划 |  |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**
2. 配置APN下使能终端异常下行流量检测功能。

   **ADD ABNTRAFFICDT**

## 验证方法

具体步骤请参见调测终端异常流量下行检测。

## 任务示例

任务描述

在UDG上开启终端异常下行流量检测功能。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM ="LKV3G5ADTD01",SWITCH=ENABLE;
```

//配置开启终端异常下行流量检测功能。

```
ADD ABNTRAFFICDT:APN="apn1.com",SWITCH=ENABLE,TRAFFICBEHAVIORSWITCH=ENABLE;
```

版权所有 © 华为技术有限公司
