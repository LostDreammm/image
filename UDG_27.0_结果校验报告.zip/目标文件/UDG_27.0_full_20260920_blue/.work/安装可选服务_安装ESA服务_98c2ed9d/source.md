# 安装ESA服务

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

仅当UDG网元需要部署GWFD-110321 支持内置百万级业务规则库特性时，才需要安装ESA（Enhanced Service Awareness）服务。

安装ESA服务场景：

* **场景一****（静态上线）**：ESA服务和UDG网元**同时实例化**。实例化UDG前填写如下VNFD参数。
  + 配置VM：基于X86虚拟机（PBU\_E-S\_Num，PBU\_E-S Redundancy Num）。基于ARM虚拟机(PBU\_E-S\_ARM\_Num，PBU\_E-S\_ARM Redundancy Num)。
  + 配置Pod：“ESACTRL\_Instance\_Num”，“ESA\_Instance\_Num”，“ESA\_ARM\_Instance\_Num”。
* **场景二****（动态上线）**：**先**实例化UDG，**然后**再参考本章节，动态上线ESA服务。

## 必备事项

前提条件

* 已经实例化UDG。已经安装后检查，UDG正常工作。
* ESA服务依赖的软件包为UDG\_xx.x.x\_DockerUdg\_X86.zip或UDG\_xx.x.x\_DockerUdg\_ARM.zip。在安装UDG时已经上传本软件包，因此无需再次上传软件包。
* 已经完成检查软件包完整性。

* 当系统进行动态上下线操作期间，不允许再同时进行扩缩容操作。同理，当系统进行扩缩容期间，不允许再进行动态上下线操作。
* 上下线本服务时，不能同时上下线其他部件。
* 当动态上线一个服务的任务失败；必须先动态下线此服务，再重新触发动态上线任务。如果是动态下线失败，只能继续重新触发动态下线任务。

数据

| 类别 | 参数名称 | 取值样例/说明 | 获取方法 |
| --- | --- | --- | --- |
| UDG OM Portal帐户 | IP地址 | 192.168.1.1  操作维护接口IP，即“VNFD模板”中的“MNG\_IP”或“MNG\_IPv6”参数。 | 本端规划 |
|  | 端口号 | 31943 | 本端规划 |
|  | 用户名 | admin | 本端规划 |
|  | 密码 | Changeme\_123 | 本端规划 |
| 软件包 | ESA软件包 | ESA服务基于X86硬件的软件包：UDG\_xx.x.x\_DockerUdg\_X86.zip  ESA服务基于ARM硬件的软件包：UDG\_xx.x.x\_DockerUdg\_ARM.zip | 固定取值 |
| 特性使能  OPR FEATUREENABLE | Pod实例个数列表  （PODINSTANCENUM） | esa-pod:2/esactrl-pod:2  pod类型:上线的pod个数，用/分割。不能带空格。 | 本端规划 |
|  | 扩展属性  （EXTENDEDATTR） | 保持空白，无需填写。 | 固定取值 |
|  | FUNCTIONSETNAME  （网络功能集名称） | ESA | 固定取值 |

## 操作步骤

1. 动态上线本服务前，必须根据客户的业务容量和设备现状进行严格的**扩容评估**。

   确保上线服务所需的I层资源、License资源、各类网络资源（如外联口网络）是充足的，如果不充足，则要**先扩容这些资源**，然后**再上线本服务**。

   由华为网设工程师进行网络设计，规划计算资源、存储资源、网络资源。

   将规划数据合入《NFV LLD文档》，作为后续操作的输入。

   * **计算资源**：承载虚拟机的主机（服务器）、主机组、虚拟机名称、虚拟机个数、容器名称、容器个数。
   * **存储资源**：承载本服务的磁盘空间。
   * **网络资源**：承载虚拟机的网络。承载容器的网络。承载业务的物理网口、业务网络。例如虚拟机的Base网络、容器Base网络、外联口网络、外联口Subport。
2. 参考《UDG中心侧扩缩容指导书(基于LCM)》或《UDG中心侧扩缩容指导书(基于NFVO)》，完成扩容操作，扩容出计算资源、存储资源、网络资源、VM和POD。上线可选服务时可只扩容VM，无需扩容POD。可选服务所用VM可参见扩容指导书内非基础业务扩容规格确定章节**。**

   由华为工程师登录华为Support网站，在技术支持>知识库>云核心网>Mobile Packet Core>5G Packet Core>UDG>技术指导，中搜索《UDG中心侧扩缩容指导书(基于LCM)》或《UDG中心侧扩缩容指导书(基于NFVO)》。

   非SDN组网模式下使用《UDG中心侧扩缩容指导书(基于LCM)》，SDN组网模式请使用《UDG中心侧扩缩容指导书(基于NFVO)》。
3. 登录UDG OM Portal。
4. 执行命令，动态上线ESA Pod。

   ```
   OPR FEATUREENABLE: PODINSTANCENUM="esa-pod:pod个数/esactrl-pod:pod个数", FUNCTIONSETNAME="ESA";
   ```

   无需配置“EXTENDEDATTR(扩展属性)”参数，参数“FUNCTIONSETNAME”填写为“ESA”。
5. 执行命令，确认已经成功实例化ESA Pod。

   ```
   DSP FEATUREOPRHIST:;
   ```

   回显为“处理结果=处理成功”。

   ```
   DSP POD: MEID="网元ID", TYPE=byType, PODTYPE="esa-pod";
   DSP POD: MEID="网元ID", TYPE=byType, PODTYPE="esactrl-pod";
   ```

   回显pod个数和规划一致，且“Pod状态”为“Running”。
6. 执行命令，查询进程的状态。

   ```
   DSP CELLSTAT: OBJECT=PODTYPE, PODTYPE="esa-pod";
   DSP CELLSTAT: OBJECT=PODTYPE, PODTYPE="esactrl-pod";
   ```

   预期结果：“未就绪进程数”和“故障进程数”均为0。

## 任务示例

任务描述

已经参考《UDG中心侧扩缩容指导书(基于LCM)》或《UDG中心侧扩缩容指导书(基于NFVO)》扩容好计算资源、存储资源、网络资源。例如已在VNF LCM或NFVO上扩容出ESA服务自身VM（PBU\_E-S）。

在上述场景中动态上线ESA服务。

脚本

1. 执行命令，动态上线ESA pod。

   ```
   OPR FEATUREENABLE: PODINSTANCENUM="esa-pod:2/esactrl-pod:2", FUNCTIONSETNAME="ESA";
   ```
2. 执行命令，确认已经成功实例化ESA Pod。

   ```
   DSP FEATUREOPRHIST:;
   ```

   回显为“处理结果=处理成功”。

   ```
   DSP POD: MEID="0", TYPE=byType, PODTYPE="esa-pod";
   DSP POD: MEID="0", TYPE=byType, PODTYPE="esactrl-pod";
   ```

   回显pod个数和规划一致，且“Pod状态”为“Running”。
3. 执行命令，查询进程的状态。

   ```
   DSP CELLSTAT: OBJECT=PODTYPE, PODTYPE="esa-pod";
   DSP CELLSTAT: OBJECT=PODTYPE, PODTYPE="esactrl-pod";
   ```

   预期结果：“未就绪进程数”和“故障进程数”均为0。

版权所有 © 华为技术有限公司
