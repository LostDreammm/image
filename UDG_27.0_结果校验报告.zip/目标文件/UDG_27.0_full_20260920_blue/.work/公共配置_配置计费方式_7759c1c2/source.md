# 配置计费方式

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本指导用于描述UNC同时支持离线计费和在线计费的操作过程。

**GGSN-C/PGW-C/SMF**

对于SMF，计费方式的选择有PCF下发和本地配置，PCF下发的优先级高于本地配置。对于GGSN-C/PGW-C，计费方式的选择有PCRF下发、RADIUS Server下发和本地配置，优先级从高到低依次为：PCRF下发>RADIUS Server下发>本地配置。

GGSN-C/PGW-C/SMF本地配置计费方式开关有三种粒度：User Profile、DNN和计费属性，优先级依次降低。

根据用户归属属性（本地用户，漫游用户和拜访用户）配置的开关**SET CHARGECTRL**是控制GGSN-C/PGW-C/SMF本地配置的计费开关是否有效的总开关，当总开关使能了某种计费，其他开关的配置才能生效。默认情况下，总开关同时使能在线/离线/融合计费。

**SGW-C**

对于SGW-C，计费方式要通过本地进行配置。SGW-C本地配置计费开关有三种粒度：IMSI/MSISDN号段组、APN和计费属性，优先级依次降低。根据用户归属属性（本地用户，漫游用户和拜访用户）配置的开关**SET SGWCHARGECFG**是控制SGW-C本地配置的计费开关是否有效的总开关，当总开关使能了离线计费，其他开关的配置才能生效。默认情况下，漫游用户和拜访用户使能离线计费，本地用户不使能离线计费。

## 必备事项

前提条件

* 请仔细阅读Ga/Gy接口离线/在线计费。
* 完成加载License。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET CHARGECTRL** | 归属地在线用户计费控制（HOMEONLINE） | ENABLE | 全网规划 | 开启GGSN-C/PGW-C/SMF计费总开关，配置漫游用户、拜访用户、本地用户均开启在线计费和离线计费，不开启融合计费。 |
|  | 归属地融合用户计费控制（HOMECONVERGED） | DISABLE |  |  |
|  | 归属地离线用户计费控制（HOMEOFFLINE） | ENABLE |  |  |
|  | 拜访地在线计费用户计费控制（VISITONLINE） | ENABLE |  |  |
|  | 拜访地离线计费用户计费控制（VISITOFFLINE） | ENABLE |  |  |
|  | 拜访地融合计费用户计费控制（VISITCONVERGED） | DISABLE |  |  |
|  | 漫游在线计费用户计费控制（ROAMONLINE） | ENABLE |  |  |
|  | 漫游离线计费用户计费控制（ROAMOFFLINE） | ENABLE |  |  |
|  | 漫游融合计费用户计费控制（ROAMCONVERGED） | DISABLE |  |  |
| **SET USRPROFCHARGE** | 用户模板名称（USRPROFNAME） | up-test | 已配置数据中获取 | （可选）基于用户模板配置GGSN-C/PGW-C/SMF的计费方式。在全局配置不能满足业务要求时，可执行本命令基于用户模板配置计费方式。  说明：  * “ONLINESW”和“OFFLINESW”配置“INHERIT”，表示计费方式继承基于DNN的配置。 * 本示例配置User Profile为up-test的用户在线计费开关和离线计费开关继承上一级配置，不开启融合计费。请根据业务实际需要进行配置。 |
|  | 在线计费开关（ONLINESW） | INHERIT | 全网规划 |  |
|  | 离线计费开关（OFFLINESW） | INHERIT |  |  |
|  | 融合计费开关（CONVERGEDSW） | DISABLE |  |  |
| **SET APNCHARGECTRL** | APN名称（APN） | apn-test | 已配置数据中获取 | （可选）基于DNN配置GGSN-C/PGW-C/SMF的计费方式。在全局配置不能满足业务要求时，可执行本命令基于DNN配置计费方式。  说明：  * “ONLINESW”和“OFFLINESW”配置“INHERIT”，表示计费方式继承基于计费属性的配置。 * 本示例配置APN为apn-test的用户在线计费开关、离线计费开关均继承上一级配置，融合计费开关关闭。请根据业务实际需要进行配置。 |
|  | 在线计费开关（ONLINESW） | INHERIT | 全网规划 |  |
|  | 离线计费开关（OFFLINESW） | INHERIT |  |  |
|  | 融合计费开关（CONVERGEDSW） | DISABLE |  |  |
| **ADD CHARGEMETHOD** | 计费属性（CHARGECHARACT） | SPECIFIC\_VALUE | 全网规划 | （可选）基于用户计费属性配置GGSN-C/PGW-C/SMF的计费方式。在全局配置不能满足业务要求时，可执行本命令基于计费属性配置计费方式。  说明：  本示例配置计费属性为0x0400的用户在线计费开关、离线计费开关和融合计费开关均使能，融合计费开关不使能。请根据业务实际需要进行配置。 |
|  | 计费属性值（CCVALUE） | 0x0400 |  |  |
|  | 计费属性掩码（MASK） | 0xFFFF |  |  |
|  | 计费属性优先级（PRIORITY） | 1 |  |  |
|  | 在线计费开关（ONLINE） | ENABLE |  |  |
|  | 离线计费开关（OFFLINE） | ENABLE |  |  |
|  | 融合计费开关（CONVERGED） | DISABLE |  |  |
| **SET SGWCHARGECFG** | 本地用户离线计费开关（HOMEOFFLINE） | DISABLE | 全网规划 | 基于用户的漫游属性配置SGW-C的计费开关。  说明：  本示例配置本地用户不使能离线计费 ，漫游和拜访用户使能离线计费。 一般对于本地用户，在PGW-C计费的情况下，SGW-C可以不使能离线计费。对于漫游用户和拜访用户，SGW-C使能离线计费用于运营商之间进行费用结算。请根据业务实际需要进行配置。 |
|  | 漫游用户离线计费开关（ROAMOFFLINE） | ENABLE |  |  |
|  | 拜访用户离线计费开关（VISITOFFLINE） | ENABLE |  |  |
| **SET SGWCHGMETH** | 计费属性（CHARGECHAR） | SPECIFIC\_VALUEENENA | 全网规划 | （可选）基于用户的计费属性配置SGW-C的计费开关。  说明：  本示例配置计费属性为0x0800的用户使能离线计费。请根据业务实际需要进行配置。 |
|  | 计费属性值（CHARGECHARVALUE） | 0x0800 |  |  |
|  | 计费属性掩码（CCMASK） | 0xFFFF |  |  |
|  | 计费属性优先级（CCPRIORITY） | 1 |  |  |
|  | 是否离线计费（OFFLINEFLAG） | ENABLE |  |  |
| **SET SGWAPNCHGMETH** | APN名称（APN） | apn-test | 全网规划 | （可选）基于APN配置SGW-C的计费开关。  说明：  本示例配置APN为apn-test的用户离线开关继承上一级配置。请根据业务实际需要进行配置。 |
|  | APN离线计费开关（OFFLINE） | INHERIT |  |  |
| **ADD SGWSEGGCHGMETH** | IMSI/MSISDN号段组名称（SEGGROUPNAME） | segment1 | 已配置数据中获取 | （可选）基于用户的IMSI/MSISDN号段组配置SGW-C的计费开关。  说明：  本示例配置在号段组segment1中的用户使能离线计费 。请根据业务实际需要进行配置。 |
|  | IMSI/MSISDN号段组优先级（PRIORITY） | 1 | 全网规划 |  |
|  | IMSI/MSISDN号段组离线计费开关（OFFLINEFLAG） | ENABLE |  |  |

## 操作步骤

1. 基于用户归属属性配置GGSN-C/PGW-C/SMF的计费方式。

   **SET CHARGECTRL**

   **SET CHARGECTRL**根据用户漫游属性设置计费方式，**ADD CHARGEMETHOD**根据计费属性设置计费方式，针对同一个用户，两者规划的计费方式要一致，否则用户计费会出错。例如，针对计费属性是normal的本地用户，如果设置本地用户进行在线计费，又设置normal用户进行离线计费，那用户最终计费结果将出错。
2. **可选：**基于User Profile配置GGSN-C/PGW-C/SMF的计费方式。

   **SET USRPROFCHARGE**
3. **可选：**基于DNN配置GGSN-C/PGW-C/SMF的计费方式。

   **SET APNCHARGECTRL**
4. **可选：**基于用户计费属性配置GGSN-C/PGW-C/SMF的计费方式。

   **ADD CHARGEMETHOD**
5. 配置基于用户的漫游属性配置SGW-C的计费开关。

   **SET SGWCHARGECFG**
6. **可选：**基于用户的计费属性配置SGW-C的计费开关。

   **SET SGWCHGMETH**
7. **可选：**基于APN配置SGW-C的计费开关。

   **SET SGWAPNCHGMETH**
8. **可选：**基于用户的IMSI/MSISDN号段组配置SGW-C的计费开关。

   **ADD SGWSEGGCHGMETH**

## 任务示例

任务描述

* 任务一：在GGSN-C/PGW-C/SMF上配置使能在线计费和离线计费，不使能融合计费。
* 任务二：在GGSN-C/PGW-C/SMF上配置计费属性为0x0400的用户在线计费开关和离线计费开关均使能，不使能融合计费开关。
* 任务三：在GGSN-C/PGW-C/SMF上配置APN为apn-test的用户在线计费开关和离线计费开关均继承上一级配置，不使能融合计费开关。
* 任务四：在GGSN-C/PGW-C/SMF上配置User Profile为up-test的用户在线计费开关和离线计费开关继承上一级配置，不使能融合计费开关。
* 任务五：在SGW-C上配置使能离线计费。
* 任务六：在SGW-C上配置计费属性为0x0800的用户使能离线计费。
* 任务七：在SGW-C上配置APN为apn-test的用户离线开关继承上一级配置。
* 任务八：在SGW-C上配置在号段组segment1中的用户使能离线计费。

脚本

**任务一**

```
SET CHARGECTRL:HOMECONVERGED=DISABLE, HOMEONLINE=ENABLE, HOMEOFFLINE=ENABLE, VISITONLINE=ENABLE, VISITOFFLINE=ENABLE, VISITCONVERGED=DISABLE, ROAMONLINE=ENABLE, ROAMOFFLINE=ENABLE, ROAMCONVERGED=DISABLE;
```

**任务二**

```
SET CHARGECTRL:HOMECONVERGED=DISABLE, HOMEONLINE=ENABLE, HOMEOFFLINE=ENABLE, VISITONLINE=ENABLE, VISITOFFLINE=ENABLE, VISITCONVERGED=DISABLE, ROAMONLINE=ENABLE, ROAMOFFLINE=ENABLE, ROAMCONVERGED=DISABLE;
ADD CHARGEMETHOD:CHARGECHARACT=SPECIFIC_VALUE, CCVALUE="0x0400", MASK="0xFFFF", PRIORITY=1, ONLINE=ENABLE, OFFLINE=ENABLE, CONVERGED=DISABLE;
```

**任务三**

```
SET CHARGECTRL:HOMECONVERGED=DISABLE, HOMEONLINE=ENABLE, HOMEOFFLINE=ENABLE, VISITONLINE=ENABLE, VISITOFFLINE=ENABLE, VISITCONVERGED=DISABLE, ROAMONLINE=ENABLE, ROAMOFFLINE=ENABLE, ROAMCONVERGED=DISABLE;
SET APNCHARGECTRL:APN="apn-test", ONLINESW=INHERIT, OFFLINESW=INHERIT, CONVERGEDSW=DISABLE;
```

**任务四**

```
SET CHARGECTRL:HOMECONVERGED=DISABLE, HOMEONLINE=ENABLE, HOMEOFFLINE=ENABLE, VISITONLINE=ENABLE, VISITOFFLINE=ENABLE, VISITCONVERGED=DISABLE, ROAMONLINE=ENABLE, ROAMOFFLINE=ENABLE, ROAMCONVERGED=DISABLE;
SET USRPROFCHARGE:USRPROFNAME="up-test", ONLINESW=INHERIT, OFFLINESW=INHERIT, CONVERGEDSW=DISABLE;
```

**任务五**

```
SET SGWCHARGECFG:HOMEOFFLINE=DISABLE, ROAMOFFLINE=ENABLE, VISITOFFLINE=ENABLE;
```

**任务六**

```
SET SGWCHARGECFG:HOMEOFFLINE=DISABLE, ROAMOFFLINE=ENABLE, VISITOFFLINE=ENABLE;
SET SGWCHGMETH: CHARGECHAR=SPECIFIC_VALUE, CHARGECHARVALUE="0x0800", CCMASK="0xFFFF", CCPRIORITY=1, OFFLINEFLAG=ENABLE;
```

**任务七**

```
SET SGWCHARGECFG:HOMEOFFLINE=DISABLE, ROAMOFFLINE=ENABLE, VISITOFFLINE=ENABLE;
SET SGWAPNCHGMETH:APN="apn-test", OFFLINE=INHERIT;
```

**任务八**

```
SET SGWCHARGECFG:HOMEOFFLINE=DISABLE, ROAMOFFLINE=ENABLE, VISITOFFLINE=ENABLE;
ADD SGWSEGGCHGMETH: SEGGROUPNAME="segment1", PRIORITY=1, OFFLINEFLAG=ENABLE;
```

版权所有 © 华为技术有限公司
