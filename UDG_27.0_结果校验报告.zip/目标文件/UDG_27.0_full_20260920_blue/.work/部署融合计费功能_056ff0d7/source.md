# 部署融合计费功能

* 操作场景
* 必备事项
* 操作步骤

## 操作场景

该任务用于指导操作人员完成5G融合计费所需的相关参数。

## 必备事项

前提条件

* 具备管理员权限的操作人员已经登录华为操作维护系统（登录MAE客户端或登录OM Portal）。

* UNC软件安装已完成。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD CCPFOT** | Failover模板标识（FOTNM） | FR1 | 本端规划 | 在线计费CC处理动作。 |
|  | 是否支持Failover开关（FOENABLE） | TRUE | 固定取值 |  |
|  | NCG代应答时的配额类型选择（RESPPLCY） | TIME-0&SUMVOLUME-1 | 本端规划 |  |
|  | 默认上行流量额度(KB)（UVDQ） | 102400 | 本端规划 |  |
|  | 默认下行流量额度(KB)（DVDQ） | 102400 | 本端规划 |  |
| **ADD CCPCCACT** | CC类型（CCTYPE） | VALUE | 固定取值 | 离线计费CC处理动作。 |
|  | 指定计费属性值（CHGCHAR） | 0x400 | 固定取值 |  |
|  | 指定计费属性掩码（CHGCHARMASK） | 0xFFFF | 固定取值 |  |
|  | Failover模板标识（FOTNM） | FR1 | 本端规划 |  |
|  | 是否转发OCS（FWDOCSENABLE） | TRUE | 固定取值 |  |
| **ADD CCPRCACT** | RC类型（RCTYPE） | VALUE  DEFAULT | 固定取值 | 异常返回码处理动作。 |
|  | 指定异常返回码类型（CODETYPE ） | 408  429  500  503 | 全网规划 |  |
|  | Failover模板标识（FOTNM） | FR1 | 本端规划 |  |
|  | 代表对端不可用（PEERUNAVAILABLE） | FALSE | 固定取值 |  |
| **SET AGFFUNCPARA** | 计费消息重发次数（OCSRETRYCNT ） | 0 | 全网规划 | 配置AGF的功能参数。 |
|  | OCS选择策略（OCSDISCPLCY ） | SUPI-0&GPSI-1 | 全网规划 |  |
|  | CDF I包抄送策略（CDFIPKGPLCY ） | TRUE | 全网规划 |  |
| **SET CCPTIMER** | 定时器标识（TID） | CCTIMEOUT | 固定取值 | OCS超时时长配置。 |
|  | 定时器的时长（VALUE） | 3 | 全网规划 |  |
| **SET CCPTIMER** | 定时器标识（TID） | RECOVERINTERVAL | 固定取值 | 尝试恢复OCS时长配置。 |
|  | 定时器的时长（VALUE） | 300 | 全网规划 |  |

## 操作步骤

1. 配置默认Failover模板。

   ```
   ADD CCPFOT: FOTNM="FR1", FOENABLE=TRUE, RESPPLCY=TIME-0&SUMVOLUME-1, UVDQ=102400, DVDQ=102400;
   ```
2. 配置基于CC值的处理模板

   ```
   ADD CCPCCACT:CCTYPE=VALUE, CHGCHAR="0x0400", CHGCHARMASK="0xFFFF", FOTNM="FR1", FWDOCSENABLE=TRUE;
   ADD CCPCCACT:CCTYPE=VALUE, CHGCHAR="0x0800", CHGCHARMASK="0xFFFF", FOTNM="FR1", FWDOCSENABLE= FALSE;
   ```
3. 配置基于异常返回码的处理模板

   ```
   ADD CCPRCACT:RCTYPE=VALUE, CODETYPE=408, FOTNM="FR1", PEERUNAVAILABLE=FALSE;
   ADD CCPRCACT:RCTYPE=VALUE, CODETYPE=429, FOTNM="FR1", PEERUNAVAILABLE=FALSE;
   ADD CCPRCACT:RCTYPE=VALUE, CODETYPE=500, FOTNM="FR1", PEERUNAVAILABLE=FALSE;
   ADD CCPRCACT:RCTYPE=VALUE, CODETYPE=503, FOTNM="FR1", PEERUNAVAILABLE=FALSE;
   ADD CCPRCACT: RCTYPE=DEFAULT, FOTNM="FR1";
   ```
4. 配置AGF功能参数。此处配置create消息生成话单、NCG等待OCS计费响应超时后不重发响应超时的计费请求，根据GPSI选择OCS。

   ```
   SET AGFFUNCPARA: OCSRETRYCNT=0, OCSDISCPLCY=SUPI-0&GPSI-1, CDFIPKGPLCY=TRUE;
   ```
5. CHF(OCS)超时时长配置，默认值为3秒。

   ```
   SET CCPTIMER: TID= CCTIMEOUT, VALUE=3;
   ```
6. 主备CHF(OCS)故障后NCG再次尝试转发CHF(OCS)时长配置，默认值为5分钟。

   ```
   SET CCPTIMER: TID= RECOVERINTERVAL, VALUE=300;
   ```

版权所有 © 华为技术有限公司
