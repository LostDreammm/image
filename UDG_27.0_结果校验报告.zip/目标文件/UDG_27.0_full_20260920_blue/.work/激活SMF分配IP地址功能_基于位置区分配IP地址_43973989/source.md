# 基于位置区分配IP地址

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

运营商规划SMF为UE分配IP地址，可基于APN/DNN、位置、UPF或其任意组合分配地址，基于位置区分配IP地址的配置方法可参考本章节。

适用于GGSN、PGW-C、SMF、PGW-U、UPF。

## 必备事项

前提条件

请仔细阅读SMF分配IP地址流程。

数据

SMF数据：

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD APN** | APN（APN名称） | apn1 | 本端规划 | 配置APN实例。 |
|  | HASVPN（绑定VPN） | ENABLE | 本端规划 |  |
|  | VPNINSTANCE（VPN实例名） | vpn1 | 本端规划 |  |
| **ADD VPNINST** | VPNINSTANCE（VPN实例名） | vpn1 | 全网规划 | - |
| **ADD ADDRPOOLGRP** | POOLGRPNAME（地址池组名称） | poolgroup1 | 本端规划 | 配置地址池组。 |
|  | POOLGRPTYPE（地址池类型） | Radius | 本端规划 |  |
| **ADD ADDRTACGROUP** | TACGROUPNAME（TAC组名称） | TAC1 | 本端规划 | 配置TAC组。 |
|  | TACTYPE（TAC类型） | N2TAC | 本端规划 |  |
| **ADD ADDRN2TACID** | TACGROUPNAME（N2TAC组名） | TAC1 | 本端规划 | 配置N2TAC组内N2TAC号段。 |
|  | TACSECNUM（N2TAC段编号） | 2 | 本端规划 |  |
|  | TACSTARTID（N2TAC起始ID） | 0x000001 | 本端规划 |  |
|  | TACENDID（N2TAC终止ID） | 0x00001F | 本端规划 |  |
| **ADD ADDRUPGROUP** | UPFGRPNAME（UPF组名称） | upfgrp1 | 本端规划 | 配置UPF组。 |
|  | UPFGRPTYPE（UPF组类型） | Local | 本端规划 |  |
| **ADD UPFBINDGRP** | UPFGRPNAME（UPF组名称） | upfgrp1 | 本端规划 | 配置UPF和UPF组的绑定关系。 |
|  | UPFID（UPF实例标识） | upf\_instance\_1 | 本端规划 |  |
| **ADD POOLGRPMAP** | MAPPINGNAME（映射名称） | mapping01 | 本端规划 | - |
|  | POOLGRPNAME（地址池组名称） | poolgroup1 | 已配置数据中获取 | 已通过**ADD ADDRPOOLGRP**配置。 |
|  | LOCATIONGRPTYPE（位置区组类型） | TAC | 已配置数据中获取 | 已通过**ADD ADDRTACGROUP**配置 |
|  | LOCATIONGRPNAME（位置区组名称） | TAC1 | 已配置数据中获取 |  |
| **ADD ADDRPOOL** | 地址池名（POOLNAME） | pool01 | 本端规划 | 为用户配置对应的地址池。 |
|  | IP地址类型（IPVERSION） | IPV4 | 本端规划 |  |
|  | POOLTYPE（地址池类型） | UDM | 本端规划 |  |
|  | CHECKIPVALID（检查地址合法性） | Enable | 本端规划 |  |
| **ADD POOLBINDGRP** | POOLGRPNAME（地址池组名称） | poolgroup1 | 已配置数据中获取 | 已通过**ADD ADDRPOOLGRP**配置。 |
|  | POOLNAME（地址池名称） | pool01 | 已配置数据中获取 | 已通过**ADD ADDRPOOL**配置。 |
| **ADD SECTION** | POOLNAME（Pool名称） | pool01 | 本端规划 | 配置地址池里的地址段。 |
|  | SECTIONNUM（Section序号） | 1 | 本端规划 |  |
|  | IPVERSION（IP类型） | IPv4 | 本端规划 |  |
|  | V4STARTIP（IPV4开始地址） | 10.0.0.0 | 全网规划 |  |
|  | V4ENDIP（IPV4结束地址） | 10.1.2.3 | 全网规划 |  |
| ****MOD UPNODE**** | NFINSTANCENAME（UPF实例名称） | upf\_instance\_1 | 全网规划 | 配置UPF节点的地址分配属性。 |
|  | ADDRALLOCMODE（地址分配属性） | INHERIT | 本端规划 |  |
| **SET APNADDRESSATTR** | APN（APN名称） | apn1 | 本端规划 | 已通过**ADD APN**配置。 |
|  | IPV4ALLOCTYPE（IPV4分配方式） | LOCAL | 本端规划 | - |
| **SET IPALLOCRULE** | IPV4FIRSTRULESW（IPv4第一级规则开关） | ENABLE | 本端规划 | 配置地址分配规则。 |
|  | IPV4FIRSTRULE（IPv4第一级规则） | LOCATION | 本端规划 |  |
| **SET IPALLOCBYLOCGLBSW** | SWITCH（基于位置区分配IPv4地址的全局开关） | ENABLE | 本端规划 | - |
| **ADD CONFLICTIP** | POOLNAME（地址池名称） | pool01 | 全网规划 | 配置冲突IP。 |
|  | IPVERSION（IP地址类型） | IPv4 | 本端规划 |  |
|  | IPADDRESS（冲突IPv4地址） | 10.1.1.1 | 本端规划 |  |

UPF数据：

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD VPNINST** | VPN实例（VPNINSTANCE） | vpn1 | 全网规划 | - |
| **ADD POOL** | 地址池名称（POOLNAME） | testpool | 本端规划 | - |
|  | 地址池类型（POOLTYPE） | EXTERNAL | 固定取值 | - |
|  | 绑定VPN（HASVPN） | ENABLE | 本端规划 | - |
|  | VPN实例名（VPNINSTANCE） | vpn1 | 已配置数据中获取 | 可以使用**LST VPNINST**命令进行查询。 |
| **ADD SECTION** | 地址池名称（POOLNAME） | testpool | 本端规划 | 可以使用**LST POOL**命令进行查询。 |
|  | 地址段号（SECTIONNUM） | 1 | 本端规划 | - |
|  | IP地址类型（IPVERSION） | IPV4 | 本端规划 | - |
|  | 地址段的起始IPv4地址(V4STARTIP) | 10.10.1.1 | 全网规划 | - |
|  | 地址段的终止IPv4地址(V4ENDIP) | 10.10.1.10 | 全网规划 | - |
| **ADD L3VPNINST** | VPN实例名称（VRFNAME） | vpn1 | 本端规划 | - |
| **ADD VPNINSTAF** | 地址族类型（AFTYPE） | ipv4uni | 本端规划 | - |
| **ADD OSPF** | 进程号（PROCID） | 100 | 本端规划 | - |
|  | VPN名称（VRFNAME） | vpn1 | 已配置数据中获取 | 可以使用**LST VPNINST**命令进行查询。 |
|  | 路由器标识（SCHEMAROUID） | 10.10.10.1 | 全网规划 | 须知：  Router ID必须全网唯一。 |
| **ADD OSPFAREA** | 进程号（PROCID） | 100 | 本端规划 | - |
|  | 区域号（AREAID） | 0.0.0.0 | 与对端协商 | - |
| **ADD OSPFNETWORK** | 进程号（PROCID） | 100 | 本端规划 | - |
|  | 区域号（AREAID） | 0.0.0.0 | 与对端协商 | - |
|  | IP地址（IPADDRESS） | 10.13.21.0 | 全网规划 | - |
|  | 反掩码（WILDCARDMASK） | 0.0.0.255 | 全网规划 | - |
| **ADD OSPFIMPORTROUTE** | OSPF进程号（PROCID） | 100 | 本端规划 | - |
|  | 拓扑标识（TOPOID） | 0 | 全网规划 | - |
|  | 协议分类（PROTOCOL） | wlr | 本端规划 | - |

## 操作步骤

1. 在SMF上执行如下命令：
   1. 指定APN实例名称。

      **ADD APN**
   2. 配置VPN实例。

      **ADD VPNINST**
   3. 配置地址池组名称。

      ****ADD ADDRPOOLGRP****
   4. 配置LAC组。

      ****ADD ADDRLACGROUP****
   5. 配置LAC组内LAC号段。

      ****ADD ADDRLACID****
   6. 配置TAC组。

      ****ADD ADDRTACGROUP****
   7. 配置S1TAC组内S1TAC号段。

      ****ADD ADDRS1TACID****
   8. 配置N2TAC组内N2TAC号段。

      ****ADD ADDRN2TACID****
   9. 配置UPF组。

      ****ADD ADDRUPGROUP****
   10. 配置UPF和UPF组的绑定关系。

       ****ADD UPFBINDGRP****
   11. 为该位置区组绑定本地地址池组。

       **ADD POOLGRPMAP**
   12. 创建本地地址池。

       **ADD ADDRPOOL**
   13. 配置地址池与地址池组绑定。

       ****ADD POOLBINDGRP****
   14. 配置地址池里的IPv4地址段。

       **ADD SECTION**

       * 本地地址池：本地负责分配地址的地址池。本地地址池下需要配置地址段，一个本地地址池最多可以配置64个地址段。
       * 配置地址池后，必须配置地址段。如果不配置地址段，将导致用户激活失败。
       * 本地地址池在配置时，建议尽量使用完整的网段地址，方便生成用户下行路由。
   15. 配置UPF节点的地址分配属性。

       ****MOD UPNODE****
   16. 配置基于APN的地址分配属性。

       **SET APNADDRESSATTR**
   17. 配置地址分配规则。

       **SET IPALLOCRULE**
   18. 配置基于位置区地址分配的全局开关。

       ****SET IPALLOCBYLOCGLBSW****
   19. （可选）如果某一指定位置区的地址分配开关不同于全局位置区地址分配开关的使能状态，则需执行配置基于指定位置区分配地址的开关。

       ****SET IPALLOCBYLOCSW****
   20. 在本地地址池中将冲突的地址标识为冲突状态，禁止地址被分配给用户。

       **ADD CONFLICTIP**
   21. 配置本地地址池中IP地址的等待释放时间。

       **MOD ADDRPOOL**
2. 在UPF上执行如下命令：
   1. 配置VPN实例。

      **ADD VPNINST**
   2. （可选）如需节省UPF路由，配置EXTERNAL类型地址池。

      **ADD POOL**
   3. （可选）如需节省UPF路由，配置地址池里的IPv4地址段。

      **ADD SECTION**
   4. 配置VPN实例。

      **ADD L3VPNINST**

      **ADD VPNINSTAF**
   5. 启动OSPF进程。

      **ADD OSPF**
   6. 添加OSPF区域。

      **ADD OSPFAREA**
   7. 配置运行OSPF协议的接口。

      **ADD OSPFNETWORK**
   8. 引入WLR路由。

      **ADD OSPFIMPORTROUTE**

      采用路由策略方式发布路由时，不能只选择发布WLR\_SP或者WLR\_UD路由，必须选择WLR方式发布所有路由。

## 任务示例

任务描述

某企业用户接入网络时，为用户分配的IP地址采用SMF分配IP地址方式。

脚本

SMF上配置如下命令：

//配置APN。

```
ADD APN:APN="apn-test", HASVPN=ENABLE, VPNINSTANCE="vpn1";
```

//配置VPN实例。

```
ADD VPNINST:VPNINSTANCE="vpn1";
```

//配置地址池组名称。

```
ADD ADDRPOOLGRP:POOLGRPNAME="poolgroup1", POOLGRPTYPE=Local;
```

//配置TAC组。

```
ADD ADDRTACGROUP:TACGROUPNAME="TAC1", TACTYPE=N2TAC;
```

//配置TAC组内N2TAC号段。

```
ADD ADDRN2TACID:TACGROUPNAME="TAC1",TACSECNUM=2,TACSTARTID="0x000001",TACENDID="0x00001F";
```

//配置UPF组。

```
ADD ADDRUPGROUP:UPFGRPNAME="upfgrp1",UPFGRPTYPE="Local";
```

//配置UPF和UPF组的绑定关系。

```
ADD UPFBINDGRP:UPFGRPNAME="upfgrp1", UPFID="upf_instance_1";
```

//配置地址池与位置区组的绑定关系。

```
ADD POOLGRPMAP:MAPPINGNAME="one",POOLGRPNAME="poolgroup1",LOCATIONGRPTYPE="TAC",LOCATIONGRPNAME="TAC1", UPFGRPNAME="upfgrp1";
```

//配置地址池。

```
ADD ADDRPOOL:POOLNAME="pool01",POOLTYPE=Local,HASVPN=Enable,VPNINSTANCE="vpn1";
```

//配置地址池与地址池组绑定。

```
ADD POOLBINDGRP:POOLGRPNAME="poolgroup1", POOLNAME="pool01";
```

//配置本地地址池里的IPv4地址段。

```
ADD SECTION:POOLNAME="pool01", SECTIONNUM=1, IPVERSION=IPv4, V4STARTIP="10.10.1.1", V4ENDIP="10.10.1.10";
```

//配置UPF节点的地址分配属性。

```
MOD UPNODE:NFINSTANCENAME="upf_instance_1", ADDRALLOCMODE=INHERIT;
```

//配置基于APN的地址分配属性。

```
SET APNADDRESSATTR:APN="apn-test",IPV4ALLOCTYPE=LOCAL,IPV4ALLOCPRIALG=ENABLE,ALLOCPRECEDENCE=SMF_ALLOC;
```

//配置地址分配规则。

```
SET IPALLOCRULE:IPV4FIRSTRULESW=ENABLE, IPV4FIRSTRULE=APN-0&LOCATION-1&UPNODE-0;
```

//配置基于位置区地址分配的全局开关。

```
SET IPALLOCBYLOCGLBSW:SWITCH=ENABLE;
```

//配置基于位置区地址分配的开关。

```
SET IPALLOCBYLOCSW:LOCATIONGRPTYPE=TAC, LOCATIONGRPNAME="TAC1", SWITCH=ENABLE;
```

//配置地址池中IP地址的等待释放时间。

```
MOD ADDRPOOL:POOLNAME="pool01",POOLTYPE=LOCAL,RELEASETIME=20;
```

//配置地址池中的冲突地址。

```
ADD CONFLICTIP:POOLNAME="pool01",IPVERSION=IPv4,IPADDRESS="10.1.1.1";
```

UPF上配置如下命令：

//配置UPF上包含该网段的地址池信息。

```
ADD VPNINST:VPNINSTANCE="vpn1";
```

//（可选）如需节省UPF路由，配置EXTERNAL类型地址池。

```
ADD POOL:POOLNAME="pool01",POOLTYPE=EXTERNAL,HASVPN=ENABLE,VPNINSTANCE="vpn1";
```

//（可选）如需节省UPF路由，配置地址池里的IPv4地址段。

```
ADD SECTION:POOLNAME="pool01",SECTIONNUM=1,IPVERSION=IPV4,V4STARTIP="10.10.1.1",V4ENDIP="10.10.1.10";
```

//配置手机下行路由。

```
ADD L3VPNINST:VRFNAME="vpn1";
```

```
ADD VPNINSTAF:VRFNAME="vpn1",AFTYPE=ipv4uni;
```

```
ADD OSPF:PROCID=100,VRFNAME="vpn1",SCHEMAROUID="10.10.10.1",LSAARRMAXINTV=1000,LSAARRSTARINTV=500,LSAARRHLDINTV=500;
```

```
ADD OSPFAREA:PROCID=100,AREAID="0.0.0.0";
```

```
ADD OSPFNETWORK:PROCID=100,AREAID="0.0.0.0", IPADDRESS="10.13.21.0", WILDCARDMASK="0.0.0.255";
```

```
ADD OSPFIMPORTROUTE:PROCID=100,TOPOID=0,PROTOCOL=wlr;
```

版权所有 © 华为技术有限公司
