# 配置Ga接口数据

* 操作场景
* 必备事项
* 操作步骤

## 操作场景

该任务用于指导工程师完成Ga口的IP资源数据的配置。该章节仅针对于组网场景有Ga接口的计费方案。

## 必备事项

前提条件

* 具备管理员权限的操作人员已经登录华为操作维护系统（登录MAE客户端或登录OM Portal）。

* UNC软件安装已完成。

数据

* Ga接口数据

  | 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
  | --- | --- | --- | --- | --- |
  | **ADD VPNINST** | VPN实例名(VPNINSTANCE) | Ga-test | 参见“水平网设LLD文档 -> 5G Core业务IP对接设计”。  全网规划 | 该命令用于创建指定的VPN实例。 |
  | **ADD CDRPROC** | 接入网元分组标识（AGID） | + group1 + group2 + group3 |  | 该命令用于增加话单处理所需要的格式引擎包。 |
  |  | 格式引擎包名（ PRFNAME） | + PS\_R9\_V940\_huawei\_test.tar.gz + PS\_R9\_V940\_huawei\_test4G.tar.gz + PS\_R9\_V940\_huawei\_test2G.tar.gz |  |  |
  |  | 共享第二份最终话单文件序列号（SHAREFILECSN） | OFF |  |  |
  |  | 序列号模式（SEQNUMMODE） | IE |  |  |
  | **ADD MODULE** | 模块名(MNAME) | + AP64\_1 + AP64\_2 + AP64\_3 |  | 该命令用于配置实现话单接收，分拣，转换，存储功能的模块。 |
  |  | 接入网元分组标识(AGID) | + group1 + group2 + group3 |  |  |
  | **ADD CDRSTOR** | 话单存储标识(CDRSTORID) | + OriginalCDR + FinalCDR\_1stCopy + FinalCDR\_2ndCopy | 参见“水平网设LLD文档 -> 5G Core业务IP对接设计”。  全网规划 | 该命令用于配置原始话单、第一份最终话单以及第二份最终话单以及可能重复帧的存储规则。 |
  |  | 是否开启Bi口SingleIP功能(ISSINGLEBI) | 否 |  |  |
  |  | 话单文件类型(FILETYPE) | + Original + FirstFinal + SecondFinal |  |  |

## 操作步骤

1. 配置Ga接口信令的VPN。

   ```
   ADD VPNINST: VPNINSTANCE="Ga-test";
   ```
2. 配置Ga接口话单处理，加载格式引擎包。

   ```
   ADD CDRPROC: AGID="group1", PRFNAME="PS_R9_V940_huawei_test.tar.gz", SHAREFILECSN=OFF, SEQNUMMODE=IE;
   ADD CDRPROC: AGID="group2", PRFNAME="PS_R9_V940_huawei_test4G.tar.gz", SHAREFILECSN=OFF, SEQNUMMODE=IE;
   ADD CDRPROC: AGID="group3", PRFNAME="PS_R9_V940_huawei_test2G.tar.gz", SHAREFILECSN=OFF, SEQNUMMODE=IE;
   ```
3. 配置Ga接口接入网元分组。

   ```
   ADD MODULE: MNAME="AP64_1", AGID="group1";
   ADD MODULE: MNAME="AP64_2", AGID="group2";
   ADD MODULE: MNAME="AP64_3", AGID="group3";
   ```

   MNAME目前仅支持APXX\_Y命名，XX为RUID。
4. 配置话单存储规则。

   ```
   ADD CDRSTOR: CDRSTORID="OriginalCDR", ISSINGLEBI=No, FILETYPE=Original;
   ADD CDRSTOR: CDRSTORID="FinalCDR_1stCopy", ISSINGLEBI=No, FILETYPE=FirstFinal, FSTORDAYS=8, FCMRRULE=GZIP;
   ADD CDRSTOR: CDRSTORID="FinalCDR_2ndCopy", ISSINGLEBI=No, FILETYPE=SecondFinal, AGID="PS_GROUP_1", CHLNAME="All", CLOSEFILECOND=BySize, SFCDRSIZE=2048, NAMINGRULE="bABC%08L%A.dat";
   ```

   存储天数和文件命名规则要根据规划填写，以上只是样例。

版权所有 © 华为技术有限公司
