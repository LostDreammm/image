# 激活计费信息实时提醒

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

#### 操作场景

当运营商部署在线计费用户上网欢迎页面提醒、上网过程流量提醒或者欠费充值提醒业务时，需要激活计费信息实时提醒特性。

适用于SGW-U、PGW-U、UPF。

#### 必备事项

**前提条件**

* 请仔细阅读GWFD-110314 计费信息实时提醒。
* 完成**加载license**（如果有需求，请联系华为技术支持工程师处理）。
* 完成激活在线计费。

**数据**

| 命令 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD EXTENDEDFILTER** | 扩展过滤器名字（EXTFLTNAME） | gy-oneshot-url | 本端规划 | 一次重定向的URL白名单列表，匹配上该名单的URL才能触发页面提醒。 |
|  | URL | www.huawei.com | 本端规划 |  |
| **ADD REDIRAPPENDINFO** | 重定向携带信息名称（APPENDINFONAME） | testredirappendinfo | 本端规划 | 设置重定向URL中可携带用户的原始请求URL、IMSI、IMEI或MS-IP信息。 |
|  | 请求URL标识（REQURLFLAG） | ENABLE | 本端规划 |  |
|  | MSISDN携带标识（MSISDNFLAG） | DISABLE | 本端规划 |  |
|  | IMSI携带标识（IMSIFLAG） | ENABLE | 本端规划 |  |
|  | IMEI携带标识（IMEIFLAG） | ENABLE | 本端规划 |  |
|  | MSIP携带标识（MSIPFLAG） | ENABLE | 本端规划 |  |
| **SET GYONESHOT** | 扩展过滤器名字（EXTFLTNAME） | gy-oneshot-url | 已配置数据中获取 | 设置重定向动作的名称，已通过**ADD EXTENDEDFILTER**命令配置完成。 |
|  | 重定向携带信息名称（APPENDINFONAME） | testredirappendinfo | 已配置数据中获取 | 设置重定向URL中携带的信息，已通过**ADD REDIRAPPENDINFO**命令配置完成。 |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_red | 本端规划 | - |
|  | 使用量上报模式（USAGERPTMODE） | OFFLINE | 本端规划 |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | cp\_red | 本端规划 |  |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_red | 已配置数据中获取 |  |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_red | 已配置数据中获取 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | cg\_red | 本端规划 | PCC策略组。 |
|  | URR组名称(URRGROUPNAME) | cp\_red | 已配置数据中获取 | PCC策略组绑定的URR组，已通过**ADD URRGROUP**命令配置完成。 |
| **ADD FILTER** | 过滤器名字（FILTERNAME） | filter\_red | 本端规划 | UDG通过将用户上下行报文匹配filter，实现报文的过滤。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 |  |
|  | 三四层协议类型（L34PROTOCOL） | TCP | 本端规划 |  |
|  | 服务器起始端口号（SVRSTARTPORT） | 80 | 本端规划 |  |
|  | 服务器结束端口号（SVRENDPORT） | 80 | 本端规划 |  |
| **ADD L7FILTER** | 七层过滤器名称（L7FILTERNAME） | l7-red | 本端规划 | 七层过滤条件。 |
|  | 子七层过滤器名称（SUBL7FLTNAME） | sl7-red | 本端规划 |  |
|  | URL | 10.13.4.3/\* | 本端规划 |  |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | fg\_red | 本端规划 | 流过滤器。 |
| **ADD FLTBINDFLOWF** | 过滤器名字（FILTERNAME） | filter\_red | 已配置数据中获取 | 绑定的三四层过滤条件已通过**ADD FILTER**命令配置。 |
| **ADD PROTBINDFLOWF** | 协议名称（PROTOCOLNAME） | http | 本端规划 | 绑定的七层协议。 |
|  | 七层过滤器名字（L7FILTERNAME） | l7-red | 已配置数据中获取 | 绑定的七层过滤条件已通过**ADD L7FILTER**命令配置。 |
| **ADD RULE** | 规则名称（RULENAME） | rule\_red | 本端规划 | 重定向页面使用的内容计费规则。 |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | fg\_red | 已配置数据中获取 | 绑定的FlowFilter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | 绑定的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置。 |
|  | PCC策略组名称（PCCPOLICYGRPNM） | cg\_red | 本端规划 |  |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | up\_test | 本端规划 | - |
| **ADD RULEBINDING** | 规则名称（RULENAME） | rule\_red | 已配置数据中获取 | UserProfile绑定的业务规则，已通过**ADD RULE**命令配置完成。 |

#### 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**

2. 配置一次重定向的参数。
   1. 配置一次重定向URL白名单列表，匹配上白名单的URL才会触发重定向。

      **ADD EXTENDEDFILTER**
   2. 配置一次重定向携带的用户原始请求URL、IMSI、IMEI或MS-IP信息。

      **ADD REDIRAPPENDINFO**
   3. 配置一次重定向的URL白名单列表。

      **SET GYONESHOT**

3. 配置一次重定向中重定向页面的计入的URR。
   1. 配置URR。

      **ADD URR**
   2. 配置URR组。

      **ADD URRGROUP**
   3. 配置PCC策略组，绑定上面配置的URR组。

      **ADD PCCPOLICYGRP**;

      多次执行步骤4.1~步骤4.3，可以分别配置欢迎页面和流量提醒页面的PCC策略组，也可以使用同一PCC策略组，具体根据运营商的需求规划。
   4. 配置三四层过滤条件。

      **ADD FILTER**
   5. 配置七层过滤条件。

      **ADD L7FILTER**
   6. 配置流过滤器。

      **ADD FLOWFILTER**
   7. 绑定三四层过滤条件。

      **ADD FLTBINDFLOWF**
   8. 绑定七层过滤条件。

      **ADD PROTBINDFLOWF**
   9. 将新配置的Filter、L7filter置为生效。

      **SET REFRESHSRV**
   10. 配置重定向页面的内容计费规则。

       **ADD RULE**

       如果运营商希望基于流过滤器组设置过滤条件时，配置“流过滤器或流过滤器组选择(FILTERINGMODE)”为“FLOWFILTERGRP”，并且使用命令配置流过滤器组。

4. 配置计费信息实时提醒使用的业务策略组合。
   1. 创建UserProfile。

      **ADD USERPROFILE**
   2. 将已配置的Rule绑定到UserProfile。

      **ADD RULEBINDING**

#### 任务示例

**任务描述**

本例中，当用户访问www.huawei.com URL时触发欢迎页面提醒和流量页面提醒，用户账户余额耗尽，访问www.huawei.com页面触发欠费充值提醒。

为欢迎提醒和流量提醒的重定向页面规划相同URR ID。

**脚本**

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5RCIN01",SWITCH=ENABLE;
```

//配置一次重定向的参数。

```
ADD EXTENDEDFILTER:EXTFLTNAME="gy-oneshot-url",URL="www.huawei.com";
ADD REDIRAPPENDINFO:APPENDINFONAME="testredirappendinfo",REQURLFLAG=ENABLE,MSISDNFLAG=DISABLE,IMSIFLAG=ENABLE,IMSIENCRYALGORI=AES256,IMEIFLAG=ENABLE,MSIPFLAG=ENABLE;
SET GYONESHOT:EXTFLTNAME="gy-oneshot-url",APPENDINFONAME="testredirappendinfo";
```

//配置一次重定向中重定向页面的URR ID。

//配置计费PCC策略组。

```
ADD URR:URRNAME="urr_red",URRID=1000,USAGERPTMODE=OFFLINE;
ADD URRGROUP:URRGROUPNAME="cp_red",UPURRNAME1="urr_red",DOWNURRNAME1="urr_red";
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="cg_red",URRGROUPNAME="cp_red";
```

//配置三四层和七层信息。

```
ADD FILTER:FILTERNAME="filter_red",L34PROTTYPE=STRING,L34PROTOCOL=TCP,SVRSTARTPORT=80,SVRENDPORT=80;
ADD L7FILTER:L7FILTERNAME="l7-red",SUBL7FLTNAME="sl7-red",URL="10.13.4.3/*";
ADD FLOWFILTER:FLOWFILTERNAME="fg_red";
ADD FLTBINDFLOWF:FLOWFILTERNAME="fg_red",FILTERNAME="filter_red";
ADD PROTBINDFLOWF:FLOWFILTERNAME="fg_red",PROTOCOLNAME="http",L7FILTERNAME="l7-red";
```

//配置重定向页面的内容计费规则。

```
ADD RULE:RULENAME="rule_red",POLICYTYPE=PCC,FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="fg_red",POLICYNAME="cg_red";
SET REFRESHSRV:REFRESHTYPE=USERPROFILE;
```

//配置计费信息实时提醒使用的业务策略组合。

```
ADD USERPROFILE:USERPROFILENAME="up_test";
ADD RULEBINDING:USERPROFILENAME="up_test",RULENAME="rule_red";
```

版权所有 © 华为技术有限公司
