---
id: ''
name: 安装后配置
ne_type: UDG
type: feature
description: VNF安装完成后，需要配置部分数据，确保系统正常工作。
risk_level: ''
doc_source: ["网络部署","软件安装","基于VNF LCM安装UDG（非SDN）","安装后配置"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
VNF安装完成后，需要配置部分数据，确保系统正常工作。

## 必备事项
前提条件

* 已实例化网元。
* 已修改系统默认帐号密码，请参见《安全配置》。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    mod_virtualip_list:
      type: items
      properties:
        IPTYPE:
          name: '浮动IP类型'
          type: string
          enum:
          - IPv4
          - IPv6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4ADDR:
          name: 'IPv4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW:
          name: 'IPv4网关'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        NETMASK:
          name: '子网掩码'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6ADDR:
          name: 'IPv6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW:
          name: 'IPv6网关'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PREFIXLENGTH:
          name: '前缀长度'
          type: integer
          minimum: 0
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_optional_modify_om_ip:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '**仅当**网元已经实例化，且OM操作维护IP（即OM浮动IP）的规划值已被更改时，才需要修改OM操作维护IP地址。示例如下：'
      data_source: ''
      pattern: ''
      default: TRUE
  examples:
  - mod_virtualip_list:
    - IPTYPE: IPv4
      IPV4ADDR: '10.145.27.173'
      IPV4GW: '10.145.27.1'
      NETMASK: '255.255.255.0'
      IPV6ADDR: ''
      IPV6GW: ''
      PREFIXLENGTH: ''
    is_optional_modify_om_ip: TRUE
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录UDG OM portal。

### 2 在UDG OM portal，选择“监控分析 > 告警管理 > 活动告警”，查看系统是否上报告警“ALM-135301 PaasBroker和FusionStage的通信失败”。

#### 2.1 是 => 步骤3。

#### 2.2 否 => 步骤4。

### 3 处理ALM-135301 PaasBroker和FusionStage的通信失败告警。

### 4 **仅当**网元已经实例化，且OM操作维护IP（即OM浮动IP）的规划值已被更改时，才需要修改OM操作维护IP地址。示例如下：

```jinja2
{%- if is_optional_modify_om_ip -%}
    {%- for item in mod_virtualip_list -%}
        MOD VIRTUALIP:
        {#- --- 必选参数 --- -#}
        IPTYPE={{item.IPTYPE}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPTYPE=IPv4 时必选 --- -#}
        {%- if item.IPTYPE == 'IPv4' -%}
            IPV4ADDR="{{item.IPV4ADDR}}",
        {%- endif -%}
        {#- --- 条件必选：IPTYPE=IPv4 时必选 --- -#}
        {%- if item.IPTYPE == 'IPv4' -%}
            IPV4GW="{{item.IPV4GW}}",
        {%- endif -%}
        {#- --- 条件必选：IPTYPE=IPv4 时必选 --- -#}
        {%- if item.IPTYPE == 'IPv4' -%}
            NETMASK="{{item.NETMASK}}",
        {%- endif -%}
        {#- --- 条件必选：IPTYPE=IPv6 时必选 --- -#}
        {%- if item.IPTYPE == 'IPv6' -%}
            IPV6ADDR="{{item.IPV6ADDR}}",
        {%- endif -%}
        {#- --- 条件必选：IPTYPE=IPv6 时必选 --- -#}
        {%- if item.IPTYPE == 'IPv6' -%}
            IPV6GW="{{item.IPV6GW}}",
        {%- endif -%}
        {#- --- 条件必选：IPTYPE=IPv6 时必选 --- -#}
        {%- if item.IPTYPE == 'IPv6' -%}
            PREFIXLENGTH={{item.PREFIXLENGTH}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 执行该命令会导致UDG OM Portal的连接中断。

### 此时需要调整本地PC IP，与新的UDG的OM操作维护IP正常通信后，再重新登录UDG OM Portal。

### 对于同网段IP，可以使用MOD VIRTUALIP/SET OMIP修改OM IP；对于不同网段的OM IP调整，请联系华为技术支持工程师处理或参考《5G Core 20.XX&XX.X 组网参数改造指导书(虚机容器) 》。

### 5 请参见《初始配置与调测》>配置网元和网管对接，对接VNF和网管。

### 初次对接必须重置密码，否则会导致网管对接失败。

