# 激活支持OTT业务规则库功能

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在UDG上激活支持百万级OTT业务规则库功能。配置加载外部定义的业务规则库，并将其绑定在指定的flow-filter下，配置OTT业务对应的计费策略和动作策略，从而实现对不同的业务流执行不同的计费策略和动作策略。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-110321 支持内置百万级业务规则库。
* ESA VMPod正常运行，且部署该特性时不影响ESA VMPod上已承载的业务。若网络中未部署ESA VMPod，请参考安装ESA服务完成ESA VMPod的部署。
* OTT业务规则库已上传至UDG。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **LOD EXTERNALDB** | 数据库类型（DBTYPE） | OTT | 本端规划 | 加载OTT业务规则库。 |
|  | 外置规则数据库版本号（VERSION） | 0020.01.0000.0000.001 | 本端规划 |  |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | ff1 | 本端规划 | 流过滤器，采用外部OTT业务规则库。 |
|  | FlowFilter类型（FLOWFILTERTYPE） | EXTEROTTDB | 本端规划 |  |
| **SET EXTOTTMATCHSW** | IPv4流量OTT业务规则匹配功能开关（IPV4MATCH） | ENABLE | 本端规划 | 使能OTT业务规则匹配功能。 |
|  | IPv6流量OTT业务规则匹配功能开关（IPV6MATCH） | ENABLE | 本端规划 |  |
| **ADD URR** | 使用量上报规则名称（URRNAME） | urr\_red | 本端规划 | 使用量上报规则信息，配置计费规则。 |
|  | URR标识（URRID） | 1000 | 全网规划 |  |
|  | 使用量上报模式（USAGERPTMODE） | ONLINE | 全网规划 |  |
| **ADD URRGROUP** | 使用量上报规则组名称（URRGROUPNAME） | cp\_red | 本端规划 | - |
|  | 上行发起URR名称1（UPURRNAME1） | urr\_red | 已配置数据中获取 | 已在该配置任务中通过命令**ADD URR**配置。 |
|  | 下行发起URR名称1（DOWNURRNAME1） | urr\_red | 已配置数据中获取 |  |
| **ADD PCCPOLICYGRP** | PCC策略组名称（PCCPOLICYGRPNM） | cg\_red | 本端规划 | PCC策略组。 |
|  | URR组名称(URRGROUPNAME) | cp\_red | 已配置数据中获取 | PCC策略组绑定的URR组，已通过**ADD URRGROUP**命令配置完成。 |
| **ADD RULE** | 规则名称（RULENAME） | rule\_red | 本端规划 | 使用的计费规则。 |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | ff1 | 已配置数据中获取 | 绑定的FlowFilter已通过**ADD FLOWFILTER**命令配置。 |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | - |
|  | 策略名称（POLICYNAME） | cg\_red | 本端规划 | 绑定的PCC策略组已通过**ADD PCCPOLICYGRP**命令配置。 |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | up\_test | 本端规划 | - |
| **ADD RULEBINDING** | 规则名称（RULENAME） | rule\_red | 已配置数据中获取 | UserProfile绑定的业务规则，已通过**ADD RULE**命令配置完成。 |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**
2. 加载外部OTT业务规则库。

   **LOD EXTERNALDB**
3. 使能外部OTT业务规则库。

   **ADD FLOWFILTER**
4. 打开OTT业务规则库匹配开关。

   **SET EXTOTTMATCHSW**
5. 配置在线计费的费率标识。

   **ADD URR**

   **ADD URRGROUP**

   **ADD PCCPOLICYGRP**
6. 配置计费规则。

   **ADD RULE**
7. 配置计费规则绑定用户模板。

   **ADD USERPROFILE**

   **ADD RULEBINDING**

## 任务示例

任务描述

设置加载外部业务规则库功能，对匹配OTT业务规则库成功的报文做在线计费策略。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5MSFM01",SWITCH=ENABLE;
```

//加载OTT业务规则库。

```
LOD EXTERNALDB: DBTYPE=OTT,VERSION="0020.01.0000.0000.001";
```

```
SET REFRESHSRV:REFRESHTYPE=USERPROFILE;
```

//使能外部OTT业务规则库。

```
ADD FLOWFILTER:FLOWFILTERNAME="ff1",FLOWFILTERTYPE=EXTEROTTDB;
```

//打开OTT业务规则库匹配开关。

```
SET EXTOTTMATCHSW:IPV4MATCH=ENABLE,IPV6MATCH=ENABLE;
```

//配置在线计费的费率标识。

```
ADD URR:URRNAME="urr_red",URRID=1000,USAGERPTMODE=ONLINE;
ADD URRGROUP:URRGROUPNAME="cp_red",UPURRNAME1="urr_red",DOWNURRNAME1="urr_red";
ADD PCCPOLICYGRP:PCCPOLICYGRPNM="cg_red",URRGROUPNAME="cp_red";
```

//配置计费规则。

```
ADD RULE:RULENAME="rule_red",POLICYTYPE=PCC,FILTERINGMODE=FLOWFILTER, FLOWFILTERNAME="ff1",POLICYNAME="cg_red";
SET REFRESHSRV:REFRESHTYPE=USERPROFILE;
```

//配置计费规则绑定用户模板。

```
ADD USERPROFILE:USERPROFILENAME="up_test";
ADD RULEBINDING:USERPROFILENAME="up_test",RULENAME="rule_red";
```

版权所有 © 华为技术有限公司
