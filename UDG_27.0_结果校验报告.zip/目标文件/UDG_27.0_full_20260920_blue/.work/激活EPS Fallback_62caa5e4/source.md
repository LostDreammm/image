# 激活EPS Fallback

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在UDG上开启特性的License开关激活EPS Fallback功能。

适用于UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-020282 EPS Fallback。
* 完成配置VoLTE基础语音业务。
* 完成**加载license**（如果有需求，请联系华为技术支持工程师处理）。

数据

无

## 操作步骤

打开本特性的License配置开关。

**SET LICENSESWITCH**

## 任务示例

任务描述

打开本特性的License配置开关，使能EPS Fallback功能。

脚本

打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5EPSF01",SWITCH=ENABLE;
```

版权所有 © 华为技术有限公司
