# 激活WLAN热点切换语音保障（MOBIKE）

* 操作场景
* 对系统的影响
* 必备事项
* 操作步骤
* 验证方法
* 任务示例

## 操作场景

当VoWiFi基础业务的用户需要开启MOBIKE的WiFi业务连续性功能时，需要加载License“82207426 LKV8PGSMBK01 WLAN热点切换语音保障（MOBIKE）”即可完成激活。

## 对系统的影响

无。

## 必备事项

前提条件

* 请仔细阅读GWFD-711515 WLAN热点切换语音保障(MOBIKE)特性概述。
* 完成加载包含此特性的license(如果有需求，请联系华为技术支持工程师处理)。

数据

无。

## 操作步骤

1. 打开本特性的License配置开关。

   在“MML命令行-ePDG\_VNFC”窗口执行：

   **SET LICENSESWITCH**:ITEM=License项,SWITCH=开关;

## 验证方法

执行**SET LICENSESWITCH**:ITEM=License项; 查看相应的license项是否已开启。

执行**LST IKEPEER**，查看MOBIKE功能开关是否已开启。

如果MOBIKE功能开关显示为DISABLE，请执行**LST IKEPEER**，开启MOBIKE功能开关。

## 任务示例

任务描述

在UDG上使能MOBIKE的WiFi业务连续性功能。

脚本

1. 打开本特性的License配置开关。

   ```
   SET LICENSESWITCH: ITEM="LKV8PGSMBK01", SWITCH=ENABLE;
   ```
2. 验证license开关和MOBIKE功能开关是否开启。

   LST LICENSESWITCH: ITEM="LKV8PGSMBK01";

   ```
   RETCODE = 0  操作成功。

   License项开关
   -------------
     License项  =  LKV8PGSMBK01
   License名称  =  WLAN Hotspot Switching Voice Guarantee (MOBIKE)
          开关  =  打开
   (结果个数 = 1)
   ---    END
   ```

   LST EPDGIKEPEER

   ```
   RETCODE = 0  操作成功。

   IKE对端配置:
   ------------
                  IKE认证方式  =  PRE-KEY
                   预共享密钥  =  *****
               Cookie功能开关  =  不使能
                  DPD功能开关  =  不使能
           空闲时间间隔（秒）  =  NULL
      DPD探测报文重传时间间隔  =  NULL
      DPD探测报文最大重传次数  =  NULL
               Mobike功能开关  =  使能
   Error Code Mapping功能开关  =  不使能
   (结果个数 = 1)
   ---    END
   ```

版权所有 © 华为技术有限公司
