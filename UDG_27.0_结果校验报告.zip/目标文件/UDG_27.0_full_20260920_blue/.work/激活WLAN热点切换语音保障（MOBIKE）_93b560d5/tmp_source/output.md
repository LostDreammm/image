---
id: ''
name: 激活WLAN热点切换语音保障（MOBIKE）
ne_type: UDG
type: feature
description: 当VoWiFi基础业务的用户需要开启MOBIKE的WiFi业务连续性功能时，需要加载License“82207426 LKV8PGSMBK01 WLAN热点切换语音保障（MOBIKE）”即可完成激活。
risk_level: ''
doc_source: ["特性部署","特性指南","UDG特性指南","VoWiFi扩展功能","激活WLAN热点切换语音保障（MOBIKE）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当VoWiFi基础业务的用户需要开启MOBIKE的WiFi业务连续性功能时，需要加载License“82207426 LKV8PGSMBK01 WLAN热点切换语音保障（MOBIKE）”即可完成激活。

## 必备事项
前提条件

* 请仔细阅读GWFD-711515 WLAN热点切换语音保障(MOBIKE)特性概述。
* 完成加载包含此特性的license(如果有需求，请联系华为技术支持工程师处理)。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    set_licenseswitch_list:
      type: items
      properties:
        ITEM:
          name: 'ITEM'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SWITCH:
          name: 'SWITCH'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - set_licenseswitch_list:
    - ITEM: License项
      SWITCH: 开关
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 打开本特性的License配置开关。

### 在“MML命令行-ePDG\_VNFC”窗口执行：

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该set_licenseswitch_list的变量区（command: SET LICENSESWITCH） -#}
<!-- MISSING_MACRO: command=SET LICENSESWITCH list_name=set_licenseswitch_list step_id=1 -->
```

### 2 验证license开关和MOBIKE功能开关是否开启。

