# 配置VoLTE业务快速恢复

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在UDG上激活VoLTE业务快速恢复功能，让UE快速附着PS网络，降低网元故障对语音业务的影响。

适用于SGW-U、PGW-U。

## 必备事项

前提条件

请仔细阅读GWFD-020254 VoLTE业务快速恢复。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET FASTRECOVERY** | 故障重启业务恢复功能PGW开关（RESTORPGWSWITCH） | ENABLE | 全网规划 | PGW打开网络侧触发的业务恢复功能。 |
|  | 故障重启业务恢复功能SGW开关（RESTORSGWSWITCH） | ENABLE | 全网规划 | SGW打开网络侧触发的业务恢复功能。 |
|  | PDTN功能开关（PDTNSWITCH） | ENABLE | 全网规划 | SGW-C故障重启场景下，开启PGW-U触发SGW-C业务恢复功能。 |

## 操作步骤

1. 设置VoLTE业务快速恢复功能。

   **SET FASTRECOVERY**

## 任务示例

任务描述

使能VoLTE业务快速恢复功能。

脚本

//设置VoLTE快速恢复功能。

```
SET FASTRECOVERY:RESTORPGWSWITCH=ENABLE,PDTNSWITCH=ENABLE,RESTORSGWSWITCH=ENABLE;
```

版权所有 © 华为技术有限公司
