# 激活DNS纠错

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

运营商规划要求用户在访问internet时出现页面不存在的情况下，能引导用户访问第三方Platform，则需要在UDG上部署DNS纠错功能。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-110283 DNS纠错。
* 完成激活PCC基本功能。

数据

**图1** UDG上DNS纠错配置逻辑关系

**表1** UDG上规划的数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **LOD SIGNATUREDB** | 特征库加载模式(LOADMODE) | SPECIFIC | 本端规划 | - |
|  | 特征库版本号(VERSION) | 01.0002.0358.01 | 本端规划 |  |
| **ADD FILTER** | 过滤器名字（FILTERNAME） | filter1 | 本端规划 | 53为DNS Server的端口号。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 |  |
|  | 三四层协议类型（L34PROTOCOL） | UDP | 本端规划 |  |
|  | 服务器起始端口号（SVRSTARTPORT） | 53 | 与对端协商 |  |
|  | 服务器结束端口号（SVRENDPORT） | 53 | 与对端协商 |  |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | flow-filter1 | 本端规划 | - |
| **ADD FLTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | flow-filter1 | 已配置数据中获取 | 已通过**ADD FLOWFILTER**命令配置，可以使用**LST FLOWFILTER**查询。 |
|  | 过滤器名字（FILTERNAME） | filter1 | 已配置数据中获取 | 已通过**ADD FILTER**命令配置，可以使用**LST FILTER**查询。 |
| **ADD EXTENDEDFILTER** | 扩展过滤器名字（EXTFLTNAME） | l7-filter1 | 本端规划 | - |
|  | URL（URL） | www.example.com | 全网规划 |  |
| **ADD ERRORCODE** | 错误码名称（ERRORCODENAME） | dnserrorcode | 全网规划 | - |
|  | 错误码范围操作码（ERRORCODEOP） | EQUAL | 本端规划 |  |
|  | 错误码范围起始值（ERRORCODESTART） | 3 | 本端规划 |  |
| **ADD DNSOVERWRITING** | DNS重写动作名字（DNSOVERWRTNAME） | dec\_1 | 本端规划 | - |
|  | 扩展过滤器类型1（EXTFLTTYPE1） | AND | 本端规划 |  |
|  | 扩展过滤器名称1（EXTFLTNAME1） | l7-filter1 | 已配置数据中获取 | 已通过**ADD EXTENDEDFILTER**命令配置，可以使用**LST EXTENDEDFILTER**查询。 |
|  | 服务器IPv4地址1（SERVERIP1） | 192.168.1.1 | 全网规划 | 服务器IPv4地址是第三方Platform的IP地址。 |
|  | 绑定错误码名称（BINDERRCODENAME） | dnserrorcode | 已配置数据中获取 | 已通过**ADD ERRORCODE**命令配置，可以使用**LST ERRORCODE**查询。 |
| **ADD RULE** | 规则名称（RULENAME） | testrule | 本端规划 | - |
|  | 策略类型（POLICYTYPE） | SMARTREDIRECT | 本端规划 |  |
|  | 流过滤器或流过滤器组选择（FILTERINGMODE） | FLOWFILTER | 本端规划 |  |
|  | 流过滤器名称（FLOWFILTERNAME） | flow-filter1 | 已配置数据中获取 | 已通过**ADD FLOWFILTER**命令配置，可以使用**LST FLOWFILTER**查询。 |
|  | 全局优先级（PRIORITY） | 20 | 本端规划 | - |
|  | 策略名称（POLICYNAME） | dec\_1 | 已配置数据中获取 | 已通过**ADD DNSOVERWRITING**命令配置，可以使用**LST DNSOVERWRITING**查询。 |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**
2. **可选：**解析七层协议时，需要加载协议特征库文件。

   **LOD SIGNATUREDB**

   如果已经加载协议特征库文件，则使用本命令升级到最新版本的协议特征库文件。
3. 配置DNS纠错业务使用的三四层过滤条件。
   1. 配置DNS纠错业务使用的三四层过滤规则。

      **ADD FILTER**
   2. 配置流过滤器。

      **ADD FLOWFILTER**
   3. 绑定三四层过滤信息。

      **ADD FLTBINDFLOWF**
   4. 将新配置的Filter置为生效。

      **SET REFRESHSRV**
4. 配置DNS纠错使用的扩展过滤器。

   **ADD EXTENDEDFILTER**

   重复执行本步骤可以增加多个不同过滤条件的扩展过滤器。
5. 配置DNS错误码。

   **ADD ERRORCODE**
6. 配置DNS纠错动作策略。

   **ADD DNSOVERWRITING**
7. 配置DNS纠错使用的业务规则。

   **ADD RULE**

   如果运营商希望基于流过滤器组设置过滤条件时，配置“流过滤器或流过滤器组选择(FILTERINGMODE)”为“FLOWFILTERGRP”，并且使用**ADD FLOWFILTERGRP**命令配置流过滤器组。

## 任务示例

任务描述

本例采用PCRF下发预定义规则的方式进行说明。

当用户访问internet时输入错误的域名，如www.example.com，UDG执行DNS纠错动作，将DNS响应报文中的IP地址设置为第三方Platform的IP地址192.168.1.1，用户可以访问第三方Platform。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5DNSO01",SWITCH=ENABLE;
```

//加载协议特征库文件。

```
LOD SIGNATUREDB:LOADMODE=SPECIFIC,VERSION="01.0002.0358.01";
```

//配置DNS纠错使用的三四层过滤条件。

```
ADD FILTER:FILTERNAME="filter1",L34PROTTYPE=STRING,L34PROTOCOL=UDP,SVRSTARTPORT=53,SVRENDPORT=53;
```

```
ADD FLOWFILTER:FLOWFILTERNAME="flow-filter1";
```

```
ADD FLTBINDFLOWF:FLOWFILTERNAME="flow-filter1",FILTERNAME="filter1";
```

```
SET REFRESHSRV:REFRESHTYPE=USERPROFILE;
```

//配置DNS纠错使用的扩展过滤器。

```
ADD EXTENDEDFILTER:EXTFLTNAME="l7-filter1",URL="www.example.com/*";
```

//配置DNS错误码。

```
ADD ERRORCODE: ERRORCODENAME="dnserrorcode", ERRORCODEOP=EQUAL, ERRORCODESTART=3;
```

//配置DNS纠错动作。

```
ADD DNSOVERWRITING:DNSOVERWRTNAME="dec_1",EXTFLTTYPE1=AND,EXTFLTNAME1="l7-filter1",SERVERIP1="192.168.1.1",BINDERRCODENAME="dnserrorcode";
```

//配置DNS纠错规则。

```
ADD RULE:RULENAME="testrule",POLICYTYPE=SMARTREDIRECT,FILTERINGMODE=FLOWFILTER,FLOWFILTERNAME="flow-filter1",PRIORITY=20,POLICYNAME="dec_1";
```

版权所有 © 华为技术有限公司
