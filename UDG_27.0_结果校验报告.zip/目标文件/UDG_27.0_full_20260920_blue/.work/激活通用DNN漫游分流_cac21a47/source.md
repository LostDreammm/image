# 激活通用DNN漫游分流

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在UDG上部署通用DNN漫游分流功能，需要开启通用DNN漫游分流功能开关。

## 必备事项

前提条件

* 请仔细阅读GWFD-020531 通用DNN漫游分流。
* UDG完成与周边网元的对接。
* 已完成分流业务相关的部署。
* 完成**License****加载**（如果有需求，请联系华为技术支持工程师处理）。

数据

**表1** 公网UPF配置

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET LICENSESWITCH** | License项（LICITEM） | LKV3G5STCA01 | 固定取值 | 该参数用于指定“移动VPN智能分流园区接入”License项。 |
|  | 开关（SWITCH） | ENABLE | 固定取值 | 该参数用于表示License项的配置开关是否已经打开。 |
| **SET RTSDNNPARA** | 公网通用DNN漫游分流开关（PUBLICNETSW） | ENABLE | 固定取值 | 该参数用于指定系统是否开启公网的通用DNN漫游分流功能。 |
|  | N4上报通用DNN漫游分流的锚点功能开关（N4RPTSW） | ENABLE | 与对端协商 | 该参数用于指定系统是否在N4偶联消息中上报系统当前配置的公网通用DNN漫游分流特性功能开关。 |
|  | UE IP地址冲突检测开关（UEIPCONFLICTCHK） | ENABLE | 本端规划 | 该参数用于指定是否开启UE IP地址和园区服务器IP地址冲突的检测。 |
|  | UE IP地址重分配开关（UEIPREALLOC） | ENABLE | 本端规划 | 该参数用于指定系统当UE IP地址和园区服务器IP地址冲突时是否开启UE IP地址重分配。 |
|  | UE IP地址重分配次数（UEIPREALLOCNUM） | 1000 | 本端规划 | 该参数用于指定当分配的UE IP地址和园区服务器的IP地址列表冲突时，系统在空闲地址列表中获取非冲突IP地址的最大的尝试次数。 |
|  | UE IP地址冲突处理策略  （UEIPCONFLICTPLY） | BYPASS | 本端规划 | 该参数用于指定系统出现分配的UE IP地址和园区服务器IP地址冲突时是否继续激活用户。 |

**表2** 专网UPF配置

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET RTSDNNPARA** | 专网通用DNN漫游分流开关（PRIVATENETSW） | ENABLE | 固定取值 | 用于指定系统是否开启专网的通用DNN漫游分流功能。 |
|  | IPv4 NAT ALG协议（NATALGPROTV4） | FTP-1&RTSP-1 | 本端规划 | 用于指定系统是否开启通用DNN漫游分流特定协议类型NAT ALG的IPv4地址替换。 |
|  | IPv6 NAT ALG协议（NATALGPROTV6） | FTP-1 | 本端规划 | 用于指定系统是否开启通用DNN漫游分流特定协议类型NAT ALG的IPv6 地址替换。 |

## 操作步骤

1. 在公网UPF上打开特性License开关。

   **SET LICENSESWITCH**
2. 在公网UPF上配置通用DNN漫游分流开关。

   **SET RTSDNNPARA**
3. 在专网UPF上配置通用DNN漫游分流开关。

   **SET RTSDNNPARA**
4. （可选）在专网UPF上配置针对指定协议的地址替换。

   **SET RTSDNNPARA**

## 任务示例

任务描述

在公网UPF、专网UPF上开启通用DNN漫游分流功能，打开需要支持的license开关。

脚本

* 公网UPF

  //开启公网UPF的通用DNN漫游分流功能相关的License。

  ```
  SET LICENSESWITCH:LICITEM="LKV3G5STCA01",SWITCH=ENABLE;
  ```

  //开启公网UPF的通用DNN漫游分流功能开关和通过N4接口上报通用DNN漫游分流能力的开关，同时开启UE IP和园区服务IP冲突检测功能，设置UE IP冲突的策略为继续激活会话。

  ```
  SET RTSDNNPARA: PUBLICNETSW=ENABLE, UEIPCONFLICTCHK=ENABLE, UEIPREALLOC=ENABLE, UEIPREALLOCNUM=1000, UEIPCONFLICTPLY=BYPASS;
  ```
* 专网UPF

  //开启专网UPF的通用DNN漫游分流功能开关。

  ```
  SET RTSDNNPARA: PRIVATENETSW=ENABLE;
  ```

  //（可选）专网UPF开启针对FTP和RTSP协议的IPv4地址替换，针对FTP协议的IPv6地址替换。

  ```
  SET RTSDNNPARA: NATALGPROTV4=FTP-1&RTSP-1, NATALGPROTV6=FTP-1;
  ```

版权所有 © 华为技术有限公司
