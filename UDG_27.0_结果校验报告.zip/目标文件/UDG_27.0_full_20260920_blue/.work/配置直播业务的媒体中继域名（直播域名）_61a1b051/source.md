# 配置直播业务的媒体中继域名（直播域名）

* 操作场景
* 必备事项
* 任务示例

## 操作场景

使用媒体中继业务时，需要配置媒体中继模板使用的媒体中继域名。本章节用于指导如何配置媒体中继模板使用的直播域名。

## 必备事项

前提条件

已参考增加媒体服务商基础配置完成媒体中继模板配置。

数据

**表1** 媒体中继域名数据规划

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RELAYDOMAIN** | 媒体中继模板名称（RELAYTPLNAME） | sp\_relay\_tpl | 已配置数据中获取 | 已通过**ADD RELAYTEMPLATE**完成配置。 |
|  | 媒体中继域名配置名称（RELAYDOMAINNAME） | sp\_relay\_dm\_live\_001 | 本端规划 | - |
|  | 域名（DOMAINVALUE） | **relay.spliving.com** | 与对端协商 | 该参数与OTT为媒体中继业务规划的媒体中继域名保持一致。 |
|  | UE业务请求协议（UESERVICEPROTO） | **HTTPS** | 全网规划 | 该参数用于设置UE请求支持的协议。 |
|  | 业务回源协议（ORIGINPULLPROTO） | **HTTPS** | 全网规划 | 该参数用于设置业务从CDN回源时使用的协议。 |
|  | 业务服务类型（SERVICETYPE） | LIVE | 固定取值 | 该参数用于设置媒体中继业务支持的业务服务类型。LIVE表示直播。 |
|  | 点播协议类型（VODPROTOTYPE） | FLV-1 | 固定取值 | 直播固定是FLV. |
|  | 不支持的媒体访问动作（UNSPTMEDIAACT） | PROXY | 本端规划 | 该参数用于配置对于无法识别出的媒体文件，UPF的处理原则。 |
|  | 优先级（PRIORITY） | 1000 | 本端规划 | 值越小，优先级越高。 |
|  | ABR功能开关（ABRSW） | **ENABLE** | 与对端协商 | 该参数用于控制媒体中继UPF是否开启直播ABR功能。开启此功能后，能一定程度上优化直播的体验。 |
|  | 缺省的ABR参数（DFTABRPARA） | **-7000** | 与对端协商 | 该参数用于控制请求未携带ABR参数时，媒体中继UPF默认的取值。  由于各厂商OTT携带ABR参数的字段可能不同，实现机制也可能存在差异，此参数配置值请与对应OTT厂商进行协商。 |
| ****ADD RELAYSHRGROUP**** | 媒体中继共享域名称（SHAREGROUPNAME） | sp\_relay\_dm\_live\_sharegroup | 本端规划 | - |
|  | 媒体中继模板名称（RELAYTEMPLATE） | sp\_relay\_tpl | 已配置数据中获取 | 已通过**ADD RELAYTEMPLATE**完成配置。 |
|  | 主域名（MAINDOMAIN） | **relay.spliving.share.com** | 本端规划 | - |
| ****ADD RELAYSHAREDM**** | 从域名名称（SLAVEDOMAINNM） | sp\_relay\_dm\_live\_sub\_001 | 本端规划 | - |
|  | 媒体中继共享域组名称（SLAVEDOMAINNM） | sp\_relay\_dm\_live\_sharegroup | 已配置数据中获取 | 已通过**ADD RELAYSHRGROUP**完成配置。 |
|  | 共享域名（SHAREDOMAIN） | **relay.spliving.com** | 已配置数据中获取 | 已通过**ADD RELAYTEMPLATE**完成配置。 |

**表2** 媒体中继域名绑定URL鉴权

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RELAYAUTHKEY** | 媒体中继鉴权密钥名称（RELAYAUTHKEYNAME） | relay\_ak\_sp\_live\_001 | 本端规划 | 用于配置URL鉴权使用的鉴权密钥名称。 |
|  | 鉴权密钥类型（AUTHKEYTYPE） | TEXT\_STRING | 与对端协商 | 由OTT规划，用于指定鉴权密钥格式。 |
|  | 主鉴权密钥（MASTERAUTHKEY） | **\*\*\*** | 与对端协商 | 由OTT规划，用于媒体中继UPF对终端APP携带ULR鉴权参数进行校验。 |
|  | 确认主鉴权密钥（MASTERKEYCONFIRM） | **\*\*\*** | 与对端协商 | 由OTT规划，用于媒体中继UPF对终端APP携带ULR鉴权参数进行校验。 |
|  | 备鉴权密钥（SLAVEAUTHKEY） | **\*\*\*** | 与对端协商 | - |
|  | 确认备鉴权密钥（SLAVEKEYCONFIRM） | **\*\*\*** | 与对端协商 | - |
|  | IV鉴权配置开关（AUTHIVPARAMODE） | None | 与对端协商 | 由OTT规划，用于配置是否开启IV鉴权。当此参数配置为LocalCfg时，需要同时配置主鉴权**IVMASTERAUTHIV**与备鉴权IV**SLAVEAUTHIV**。 |
| **SET RLYURLENCSW** | 媒体中继域名名称（DOMAINNAME） | sp\_relay\_dm\_live\_001 | 已配置数据中获取 | 已通过  **ADD RELAYDOMAIN**命令完成配置。 |
|  | URL加密功能开关（ENCRYPTSW） | DISABLE | 与对端协商 | 由OTT规划。当OTT针对URL进行加密时需要开启此功能开关。 |
| **ADD RELAYURLAUTH** | 媒体中继URL鉴权名称（RELAYURLAUTHNM） | relay\_ur\_sp\_live\_001 | 本端规划 | 用于配置URL鉴权使用的鉴权方式名称。 |
|  | 媒体中继鉴权密钥名称（RELAYAUTHKEYNM） | relay\_ak\_sp\_live\_001 | 已配置数据中获取 | 已通过**ADD RELAYAUTHKEY**命令完成配置。 |
|  | URL鉴权方法（URLAUTHMETHOD） | **TYPEA** | 与对端协商 | 由OTT规划，用于媒体中继UPF对终端APP携带ULR鉴权参数进行校验。 |
|  | 加密算法（ALGORITHM） | **SHA256** | 与对端协商 | 由OTT规划，用于媒体中继UPF对终端APP携带ULR鉴权参数进行校验。 |
|  | 时间戳格式（TIMESTAMPFMT） | **DEFAULT** | 与对端协商 | 由OTT规划，用于媒体中继UPF对终端APP携带ULR鉴权参数进行校验。 |
|  | 鉴权失败动作（AUTHFAILACT） | FORBIDDEN | 与对端协商 | - |
|  | Dash扩展鉴权开关（DASHAUTHEXTSW） | DISABLE | 与对端协商 | - |
| **MOD RELAYDOMAIN** | 媒体中继域名配置名称（RELAYDOMAINNAME） | sp\_relay\_dm\_live\_001 | 已配置数据中获取 | 已通过  **ADD RELAYDOMAIN**命令完成配置。 |
|  | URL鉴权名称（URLAUTHNAME） | relay\_ur\_sp\_live\_001 | 已配置数据中获取 | 已通过**ADD RELAYURLAUTH**完成配置。 |

**表3** 配置HTTP头域字段，并绑定到域名

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RELAYHTTPMCTL** | 媒体中继Http消息控制名称（HTTPMSGCTRLNAME） | sp\_relay\_hhd\_vod\_001 | 本端规划 | - |
| **ADD RELAYHTTPMHD** | HTTP消息控制名称（HTTPMSGCTRLNAME） | sp\_relay\_hhd\_vod\_001 | 已配置数据中获取 | 已通过  **ADD RELAYHTTPMCTL**命令完成配置。 |
|  | 消息类型（MSGTYPE） | UEHTTPRSP | 固定取值 | - |
|  | 头域名称（HEADERNAME） | * **Cache-Control** * **Access-Control-Allow-Credentials** * **Access-Control-Allow-Headers** * **Access-Control-Allow-Methods** * **Access-Control-Allow-Origin** * **Access-Control-Expose-Headers** * **Access-Control-Max-Age** | 全网规划 | - |
|  | 头域值（HEADERVALUE） | * **no-cache** * **true** * **range** * **GET** * **\*** * **Content-Length,Content-Range,content-type,expires,last-modified,via,X-Cache,X-Request-ID** * **3600** | 全网规划 | - |
| **MOD RELAYDOMAIN** | 媒体中继域名配置名称（RELAYDOMAINNAME） | sp\_relay\_dm\_vod\_001 | 已配置数据中获取 | 已通过  **ADD RELAYDOMAIN**命令完成配置。 |
|  | 媒体中继Http消息控制名称（HTTPMSGCTRLNAME） | sp\_relay\_hhd\_vod\_001 | 已配置数据中获取 | 已通过**ADD RELAYURLAUTH**完成配置。 |

## 任务示例

任务描述

配置媒体中继的直播域名为**relay.spliving.com**，并为直播域名绑定URL鉴权规则。

URL鉴权密钥信息属于敏感数据，不支持查询或配置导出，请管理员妥善保管。

脚本

//增加直播域名配置，支持FLV类型的直播为业务。

```
ADD RELAYDOMAIN: RELAYTPLNAME="sp_relay_tpl", RELAYDOMAINNAME="sp_relay_dm_live_001", DOMAINVALUE="relay.spliving.com", UESERVICEPROTO=HTTPS, ORIGINPULLPROTO=HTTPS, SERVICETYPE=LIVE, LIVEPROTOTYPE=FLV-1, UNSPTMEDIAACT=PROXY, PRIORITY=1000,ABRSW=ENABLE,DFTABRPARA=-7000;
```

//（可选）：当实际配置存在多个直播域名，且多个直播域名能共享视频内容时，可配置共享域名。

```
ADD RELAYSHRGROUP: RELAYTEMPLATE="sp_relay_tpl", SHAREGROUPNAME="sp_relay_dm_live_sharegroup", MAINDOMAIN="relay.spliving.share.com";
ADD RELAYSHAREDM: SHAREGROUPNAME="sp_relay_dm_live_sharegroup", SLAVEDOMAINNM="sp_relay_dm_live_sub_001", SHAREDOMAIN="relay.spliving.com";
```

//配置直播URL鉴权规则。以鉴权算法为“TypeA"、加密算法为“SHA256为例。

```
ADD RELAYAUTHKEY: RELAYAUTHKEYNAME="relay_ak_sp_live_001", AUTHKEYTYPE=TEXT_STRING, MASTERAUTHKEY="***", MASTERKEYCONFIRM="***"，SLAVEAUTHKEY="***", SLAVEKEYCONFIRM="***",AUTHIVPARAMODE=None;
SET RLYURLENCSW: DOMAINNAME="sp_relay_dm_live_001", ENCRYPTSW=DISABLE;
ADD RELAYURLAUTH: RELAYURLAUTHNM="relay_ur_sp_live_001", RELAYAUTHKEYNM="relay_ak_sp_live_001", URLAUTHMETHOD=TYPEA, ALGORITHM=SHA256, TIMESTAMPFMT=DEFAULT, AUTHFAILACT=FORBIDDEN, DASHAUTHEXTSW=DISABLE;
MOD RELAYDOMAIN: RELAYDOMAINNAME="sp_relay_dm_live_001", URLAUTHNAME="relay_ur_sp_live_001";
```

//配置HTTP头域字段，并绑定到域名下。

```
ADD RELAYHTTPMCTL: HTTPMSGCTRLNAME="sp_relay_hhd_live_001"; 
ADD RELAYHTTPMHD: HTTPMSGCTRLNAME="sp_relay_hhd_live_001", MSGTYPE=UEHTTPRSP, HEADERNAME="Cache-Control", HEADERVALUE="no-cache"; 
ADD RELAYHTTPMHD: HTTPMSGCTRLNAME="sp_relay_hhd_live_001", MSGTYPE=UEHTTPRSP, HEADERNAME="Access-Control-Allow-Credentials", HEADERVALUE="true";
ADD RELAYHTTPMHD: HTTPMSGCTRLNAME="sp_relay_hhd_live_001", MSGTYPE=UEHTTPRSP, HEADERNAME="Access-Control-Allow-Headers", HEADERVALUE="range";
ADD RELAYHTTPMHD: HTTPMSGCTRLNAME="sp_relay_hhd_live_001", MSGTYPE=UEHTTPRSP, HEADERNAME="Access-Control-Allow-Methods", HEADERVALUE="GET";
ADD RELAYHTTPMHD: HTTPMSGCTRLNAME="sp_relay_hhd_live_001", MSGTYPE=UEHTTPRSP, HEADERNAME="Access-Control-Allow-Origin", HEADERVALUE="*";
ADD RELAYHTTPMHD: HTTPMSGCTRLNAME="sp_relay_hhd_live_001", MSGTYPE=UEHTTPRSP, HEADERNAME="Access-Control-Expose-Headers", HEADERVALUE="Content-Length,Content-Range,content-type,expires,last-modified,via,X-Cache,X-Request-ID";
ADD RELAYHTTPMHD: HTTPMSGCTRLNAME="sp_relay_hhd_live_001", MSGTYPE=UEHTTPRSP, HEADERNAME="Access-Control-Max-Age", HEADERVALUE="3600";
MOD RELAYDOMAIN: RELAYDOMAINNAME="sp_relay_dm_live_001", HTTPMSGCTRLNAME="sp_relay_hhd_live_001";
```

版权所有 © 华为技术有限公司
