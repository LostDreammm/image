# 激活基于服务PLMN的eMTC终端接入速率控制

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在UDG上激活基于服务PLMN的eMTC终端接入速率控制，PGW-U根据MME发来的速率控制信息，对数据包的转发速率进行控制。对于超过门限的数据包，PGW-U进行丢包处理，未超过门限的数据包进行正常的转发处理。

适用于SGW-U、PGW-U。

## 必备事项

前提条件

* 请仔细阅读GWFD-110647 基于服务PLMN的eMTC终端接入速率控制。
* 完成加载License（本特性完整的功能需要同时在SGW-U/PGW-U和MME上开启对应License，如果有需求，请联系华为技术支持工程师处理）。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD APN** | APN名称（APN） | apnmtcsp | 与对端协商 | * 如果需要配置APN下的基于服务PLMN的终端接入速率控制，则配置该APN，否则仅打开License即可。 * APN配置需要与控制面保持一致。 |

## 操作步骤

1. 打开本特性的License控制开关。

   **SET LICENSESWITCH**
2. **可选：**配置基于服务PLMN的eMTC终端接入速率控制使用的APN。

   **ADD APN**

   本特性需要同时在MME、SGW-C/PGW-C进行配置以确保能够生效，在MME上可配置速率控制参数，在SGW-C/PGW-C上可以配置如下相关内容：

   * APN下的基于服务PLMN的终端接入速率控制开关：打开后，当UE使用特定的APN接入且位于特定的PLMN下时，该特性生效。
   * 全局基于服务PLMN的终端接入速率控制开关：打开后，当UE位于特定的PLMN下时，该特性生效。
   * Serving PLMN Rate Control相关信息。

   详情请查阅相关产品文档。

## 任务示例

任务描述

开启UDG上的Serving PLMN速率控制功能。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM ="LKV3G5PMRC01", SWITCH=ENABLE;
```

//配置Service PLMN速率控制功能使用的APN。

```
ADD APN: APN="apnmtcsp";
```

版权所有 © 华为技术有限公司
