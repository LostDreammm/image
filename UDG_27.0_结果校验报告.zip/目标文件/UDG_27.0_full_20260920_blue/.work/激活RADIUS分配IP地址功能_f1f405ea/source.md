# 激活RADIUS分配IP地址功能

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

可以在本地配置静态IP地址网段与UPF的绑定关系，当用户接入网络时，对静态IP地址用户、Radius分配IP地址用户可以基于配置的网段绑定关系为用户选择指定的UPF。

适用于GGSN、PGW-C、SMF、PGW-U、UPF。

## 必备事项

前提条件

请仔细阅读RADIUS分配IP地址流程。

数据

UPF数据：

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD VPNINST** | VPN实例（VPNINSTANCE） | vpn1 | 全网规划 | - |
| **ADD APN** | APN名称（APN） | apn-test2 | 本端规划 | APN/DNN实例应该全网规划，UPF配置的APN/DNN实例应该与SMF配置的APN/DNN实例一致。 |
|  | 绑定VPN  （HASVPN） | ENABLE | 本端规划 | 如下三者绑定的VPN实例必须一致。   * 地址池绑定的VPN实例 * 用户激活使用的APN/DNN绑定的VPN实例 * 与PDN/DN连接的Gi/SGi/N6接口的外联口绑定的VPN实例 |
|  | VPN实例名（VPNINSTANCE） | vpn1 | 本端规划 | 可以使用**LST VPNINST**命令进行查询。 |
| **SET APNADDRESSATTR** | APN名称（APN） | apn-test2 | 已配置数据中获取 | 已通过**ADD APN**命令配置，可以使用**LST APN**命令进行查询。 |
|  | 支持IPV4（SUPPORTIPV4） | ENABLE | 本端规划 | 配置指定APN/DNN是否支持IPV4地址。 |
|  | 主机地址（HOSTROUTEIP） | ENABLE | 本端规划 | 配置指定APN下是否支持CP使用主机地址接入。 |
| **ADD POOL** | 地址池名称（POOLNAME） | testpool | 本端规划 | - |
|  | 地址池类型（POOLTYPE） | EXTERNAL | 固定取值 | - |
|  | 绑定VPN（HASVPN） | ENABLE | 本端规划 | - |
|  | VPN实例名（VPNINSTANCE） | vpn1 | 已配置数据中获取 | 可以使用**LST VPNINST**命令进行查询。 |
| **ADD SECTION** | 地址池名称（POOLNAME） | testpool | 本端规划 | 可以使用**LST POOL**命令进行查询。 |
|  | 地址段号（SECTIONNUM） | 1 | 本端规划 | - |
|  | IP地址类型（IPVERSION） | IPV4 | 本端规划 | - |
|  | 地址段的起始IPv4地址(V4STARTIP) | 10.10.1.1 | 全网规划 | - |
|  | 地址段的终止IPv4地址(V4ENDIP) | 10.10.1.10 | 全网规划 | - |
| **ADD L3VPNINST** | VPN实例名称（VRFNAME） | vpn1 | 本端规划 | - |
| **ADD VPNINSTAF** | 地址族类型（AFTYPE） | ipv4uni | 本端规划 | - |
| **ADD OSPF** | 进程号（PROCID） | 100 | 本端规划 | - |
|  | VPN名称（VRFNAME） | vpn1 | 已配置数据中获取 | 可以使用**LST VPNINST**命令进行查询。 |
|  | 路由器标识（SCHEMAROUID） | 10.10.10.1 | 全网规划 | 须知：  Router ID必须全网唯一。 |
| **ADD OSPFAREA** | 进程号（PROCID） | 100 | 本端规划 | - |
|  | 区域号（AREAID） | 0.0.0.0 | 与对端协商 | - |
| **ADD OSPFNETWORK** | 进程号（PROCID） | 100 | 本端规划 | - |
|  | 区域号（AREAID） | 0.0.0.0 | 与对端协商 | - |
|  | IP地址（IPADDRESS） | 10.13.21.0 | 全网规划 | - |
|  | 反掩码（WILDCARDMASK） | 0.0.0.255 | 全网规划 | - |
| **ADD OSPFIMPORTROUTE** | OSPF进程号（PROCID） | 100 | 本端规划 | - |
|  | 拓扑标识（TOPOID） | 0 | 全网规划 | - |
|  | 协议分类（PROTOCOL） | wlr | 本端规划 | - |

SMF数据：

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD ADDRPOOL** | 地址池名（POOLNAME） | pool01 | 本端规划 | 为采用静态地址分配方式的用户配置对应的地址池。 |
|  | IP地址类型（IPVERSION） | IPV4 | 本端规划 |  |
|  | POOLTYPE（地址池类型） | Radius | 本端规划 |  |
|  | CHECKIPVALID（检查地址合法性） | Enable | 本端规划 |  |
| **ADD SECTION** | Pool名称（POOLNAME） | pool01 | 本端规划 | 配置UDM类型地址池里的地址段。 |
|  | Section序号（SECTIONNUM） | 1 | 本端规划 |  |
|  | IP类型（IPVERSION） | IPv4 | 本端规划 |  |
|  | IPV4开始地址（V4STARTIP） | 10.0.0.0 | 全网规划 |  |
|  | IPV4结束地址（V4ENDIP） | 10.1.2.3 | 全网规划 |  |
| **ADD ADDRPOOLGRP** | POOLGRPNAME（地址池组名称） | poolgroup1 | 本端规划 | 配置地址池组。 |
|  | POOLGRPTYPE（地址池类型） | Radius | 本端规划 |  |
| **ADD POOLBINDGRP** | POOLGRPNAME（地址池组名称） | poolgroup1 | 已配置数据中获取 | 已通过**ADD ADDRPOOLGRP**配置。 |
|  | POOLNAME（地址池名称） | pool01 | 已配置数据中获取 | 已通过**ADD ADDRPOOL**配置。 |
| **ADD UPNODE** | UPF实例名称（NFINSTANCENAME） | UPF\_Instance\_1 | 全网规划 | 配置静态地址用户使用的UPF。  已通过**ADD PNFPROFILE**配置。 |
|  | 地址分配属性（ADDRALLOCMODE） | INHERIT | 本端规划 | - |
| **ADD ADDRUPGROUP** | UPF组名称（UPFGRPNAME） | upfgroup1 | 本端规划 | 配置静态地址用户使用的UPF组。 |
|  | UPF组类型（UPFGRPTYPE） | Radius | 本端规划 | - |
| **ADD UPFBINDGRP** | UPFGRPNAME（UPF组名称） | upfgroup1 | 已配置数据中获取 | 已通过**ADD ADDRUPGROUP**配置。 |
|  | UPFID（UPF实例标识） | UPF\_Instance\_1 | 已配置数据中获取 | 已通过**ADD UPNODE**配置。 |
| **ADD POOLGRPMAP** | MAPPINGNAME（映射名称） | mapping01 | 本端规划 | - |
|  | POOLGRPNAME（地址池组名称） | poolgroup1 | 已配置数据中获取 | 已通过**ADD ADDRPOOLGRP**配置。 |
|  | UPFGRPNAME（UPF组名称） | upfgroup1 | 已配置数据中获取 | 已通过**ADD ADDRUPGROUP**配置。 |

## 操作步骤

1. 在UPF上执行如下命令：
   1. 配置VPN实例。

      **ADD VPNINST**
   2. 配置APN/DNN实例。

      **ADD APN**
   3. 使能该APN/DNN的地址分配属性。

      **SET APNADDRESSATTR**
   4. 配置EXTERNAL类型地址池。

      **ADD POOL**
   5. 配置地址池里的IPv4地址段。

      **ADD SECTION**

      如需配置主机路由，请联系华为技术支持。
2. 在SMF上执行如下命令：
   1. 创建本地静态地址地址池。

      **ADD ADDRPOOL**
   2. 如果需要开启静态地址用户的白名单检查功能，需要配置地址池与APN/DNN的绑定关系。接入该APN的静态地址用户激活时，根据用户地址查找对应的地址池，然后根据地址池为用户选择对应的UPF。

      **ADD POOLBINDAPN**
   3. 配置本地地址池里的地址段。

      **ADD SECTION**

      * 本地地址池：本地负责分配地址的地址池。本地地址池下需要配置地址段，一个本地地址池最多可以配置64个地址段。
      * 配置地址池后，必须配置地址段。如果不配置地址段，将导致用户激活失败。
   4. 配置地址池组名称。

      **ADD ADDRPOOLGRP**
   5. 配置地址池与地址池组绑定。

      **ADD POOLBINDGRP**
   6. 配置静态地址用户使用的UPF。

      **ADD UPNODE**
   7. 配置静态地址用户使用的UPF组。

      **ADD ADDRUPGROUP**
   8. 配置UPF与UPF组绑定。

      **ADD UPFBINDGRP**
   9. 配置地址池组与UPF组绑定。

      **ADD POOLGRPMAP**
   10. 启用RADIUS鉴权功能时，无UDM/HSS/HLR签约静态IP场景中，如果需要优选RADIUS服务器分配的UE IP地址绑定的UPF作为UE主锚点UPF，需要将软参DWORD1014 BIT4设置为1。

       **SET SMFSOFTPARAOFBIT**
3. 在UPF上执行如下命令：
   1. 配置VPN实例。

      **ADD L3VPNINST**

      **ADD VPNINSTAF**
   2. 启动OSPF进程。

      **ADD OSPF**
   3. 添加OSPF区域。

      **ADD OSPFAREA**
   4. 配置运行OSPF协议的接口。

      **ADD OSPFNETWORK**
   5. 引入WLR路由。

      **ADD OSPFIMPORTROUTE**

      采用路由策略方式发布路由时，不能只选择发布WLR\_SP或者WLR\_UD路由，必须选择WLR方式发布所有路由。

## 任务示例

任务描述

某企业用户接入网络时，为用户分配的IP地址采用静态IP地址分配方式。开启静态地址用户的白名单检查功能，需要为10.10.1.1~10.10.1.10地址段内的用户选择到UPF名称为UPF\_Instance\_1的园区UPF。

脚本

UPF上配置如下命令：

//配置UPF上包含该网段的地址池信息。

```
ADD VPNINST:VPNINSTANCE="vpn1";
```

```
ADD APN:APN="apn-test2",HASVPN=ENABLE,VPNINSTANCE="vpn1";
```

```
SET APNADDRESSATTR:APN="apn-test2",SUPPORTIPV4=ENABLE,HOSTROUTEIP=ENABLE;
```

```
ADD POOL:POOLNAME="pool01",POOLTYPE=EXTERNAL,HASVPN=ENABLE,VPNINSTANCE="vpn1";
```

```
ADD SECTION:POOLNAME="pool01",SECTIONNUM=1,IPVERSION=IPV4,V4STARTIP="10.10.1.1",V4ENDIP="10.10.1.10";
```

SMF上配置如下命令：

//创建本地地址池。

```
ADD ADDRPOOL: POOLNAME="pool01", IPVERSION=IPv4, POOLTYPE=Radius, CHECKIPVALID=Enable;
```

//配置地址池与APN/DNN的绑定关系。

```
ADD POOLBINDAPN:APN="huawei.com",POOLNAME="pool01";
```

//配置本地地址池里的IPv4地址段。

```
ADD SECTION: POOLNAME="pool01", SECTIONNUM=1, IPVERSION=IPv4, V4STARTIP="10.10.1.1", V4ENDIP="10.10.1.10";
```

//配置地址池组名称。

```
ADD ADDRPOOLGRP: POOLGRPNAME="poolgroup1", POOLGRPTYPE=Radius;
```

//配置地址池与地址池组绑定。

```
ADD POOLBINDGRP: POOLGRPNAME="poolgroup1", POOLNAME="pool01";
```

//配置静态地址用户使用的UPF。

```
ADD UPNODE: NFINSTANCENAME="UPF_Instance_1", ADDRALLOCMODE=INHERIT;
```

//配置静态地址用户使用的UPF组。

```
ADD ADDRUPGROUP: UPFGRPNAME="upfgroup1", UPFGRPTYPE=Radius;
```

//配置UPF与UPF组绑定。

```
ADD UPFBINDGRP: UPFGRPNAME="upfgroup1", UPFID="UPF_Instance_1";
```

//配置地址池组与UPF组绑定。

```
ADD POOLGRPMAP: MAPPINGNAME="mapping01", POOLGRPNAME="poolgroup1", UPFGRPNAME="upfgroup1";
```

//启用RADIUS鉴权功能时，无UDM/HSS/HLR签约静态IP场景中，如果需要优选RADIUS服务器分配的UE IP地址绑定的UPF作为UE主锚点UPF，需要将软参DWORD1014 BIT4设置为1。

```
SET SMFSOFTPARAOFBIT: DT=Dw, DWORDNUM=1014, VALUE=VALUE_1, POSITION=4;
```

UPF上配置如下命令：

//配置手机下行路由。

```
ADD L3VPNINST:VRFNAME="vpn1";
```

```
ADD VPNINSTAF:VRFNAME="vpn1",AFTYPE=ipv4uni;
```

```
ADD OSPF:PROCID=100,VRFNAME="vpn1",SCHEMAROUID="10.10.10.1",LSAARRMAXINTV=1000,LSAARRSTARINTV=500,LSAARRHLDINTV=500;
```

```
ADD OSPFAREA:PROCID=100,AREAID="0.0.0.0";
```

```
ADD OSPFNETWORK:PROCID=100,AREAID="0.0.0.0", IPADDRESS="10.13.21.0", WILDCARDMASK="0.0.0.255";
```

```
ADD OSPFIMPORTROUTE:PROCID=100,TOPOID=0,PROTOCOL=wlr;
```

版权所有 © 华为技术有限公司
