# 激活基于APN的eMTC终端接入速率控制

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在UDG上激活基于APN的eMTC终端接入速率控制，用于控制该UE的某PDN连接单位时间内可发送的上行和下行数据包数。

适用于SGW-U、PGW-U。

## 必备事项

前提条件

* 请仔细阅读GWFD-110646 基于APN的eMTC终端接入速率控制。
* 完成加载License（本特性完整的功能需要同时在用户面和控制面开启License，如果有需求，请联系华为技术支持工程师处理）。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD APN** | APN名称（APN） | apnespd | 与对端协商 | 控制eMTC终端接入速率所使用的APN，需要与控制面规划一致。 |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**

   需要同时在控制面上打开本特性开关，并配置CCR消息、APN Rate Control等信息。详情请见UNC相关章节。
2. 配置基于APN的eMTC终端接入速率控制使用的APN。

   **ADD APN**

## 任务示例

任务描述

使能基于APN的eMTC终端接入速率控制功能。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM ="LKV3G5AMRC01", SWITCH=ENABLE;
```

//配置基于APN的eMTC终端速率控制功能使用的APN。

```
ADD APN: APN="apnespd";
```

版权所有 © 华为技术有限公司
