# 激活IM类业务无线资源管控

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

在GPRS/UMTS网络无线资源有限的情况下，可以激活IM类业务无线资源管控功能进行无线资源的优化。

适用于PGW-U。

## 必备事项

前提条件

* 请仔细阅读GWFD-020359 IM类业务无线资源管控。
* 完成激活PCC基本功能。
* 完成加载License（如果有需求，请联系华为技术支持工程师处理）。

数据

IM类业务识别，一般使用协议进行识别。三四层过滤条件配置为any。

**表1** 三四层过滤条件

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD FLOWFILTER** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_IM\_01 | 本端规划 | 不同流过滤器之间，该参数不能重复。 |
| **ADD FILTER** | 过滤器名称（FILTERNAME） | filter\_IM\_any | 本端规划 | 不同过滤器之间，该参数不能重复。 |
|  | 三四层IPv4协议输入类型（L34PROTTYPE） | STRING | 本端规划 | - |
|  | 三四层协议类型（L34PROTOCOL） | ANY | 本端规划 | - |
| **ADD FLTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_IM\_01 | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 过滤器名称（FILTERNAME） | filter\_IM\_any | 已配置数据中获取 | 使用**ADD FILTER**命令定义的过滤器名称。 |

**表2** 七层过滤条件

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD PROTBINDFLOWF** | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_IM\_01 | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 协议名称（PROTOCOLNAME） | qq\_im | 本端规划 | 此处的IM类业务以QQ为例。其他业务时，请配置对应的协议名称。 |
| **LOD SIGNATUREDB** | 特征库加载模式（LOADMODE） | LATEST | 本端规划 | 如无特殊需求，使用样例值即可。 |

**表3** IM类业务使用的规则

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD RULE** | 规则名称（RULENAME） | rule\_IM\_01 | 本端规划 | 存在多条数据时，该参数+策略类型不能完全相同。 |
|  | 策略类型（POLICYTYPE） | REMARK\_FPI | 本端规划 | 使用样例值。 |
|  | 流过滤器或流过滤器组选择(FILTERINGMODE) | FLOWFILTER | 本端规划 | - |
|  | 流过滤器名称（FLOWFILTERNAME） | flowfilter\_IM\_01 | 已配置数据中获取 | 使用**ADD FLOWFILTER**命令定义的流过滤器名称。 |
|  | 重标记或FPI选择（REMARKFPISEL） | REMARK | 本端规划 | 使用样例值。 |
|  | Remark配置类型（REMARKCFGTYPE） | CLASS | 本端规划 | 使用样例值。 |
|  | Remark分类类型（REMARKCLASS） | AF12 | 本端规划 | 使用样例值。 |
|  | 全局优先级（PRIORITY） | 20 | 本端规划 | 根据实际处理顺序规划。 |

**表4** IM类业务规则绑定到用户模板

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD USERPROFILE** | 用户模板名称（USERPROFILENAME） | up\_test | 与对端协商 | 与PGW-C上配置的用户模板名称保持一致。 |
| **ADD RULEBINDING** | 用户模板名称（USERPROFILENAME） | up\_test | 已配置数据中获取 | 使用**ADD USERPROFILE**命令定义的用户模板名称。 |
|  | 规则名称（RULENAME） | rule\_IM\_01 | 本端规划 | - |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**
2. 配置流过滤器。

   **ADD FLOWFILTER**
3. 配置三四层过滤条件。
   1. 配置三四层过滤条件。

      **ADD FILTER**
   2. 配置三四层过滤条件与流过滤器的绑定关系。

      **ADD FLTBINDFLOWF**
   3. 将新配置的Filter置为生效。

      **SET REFRESHSRV**
4. （可选）配置七层协议识别数据。

   特征库用于识别IM类业务，如已加载特征库和解析库，请跳过本步骤。

   **LOD SIGNATUREDB**

   **LOD PARSERDB**
5. 配置七层过滤条件。
   1. 配置流过滤器与协议绑定。

      **ADD PROTBINDFLOWF**
   2. 将新配置的七层过滤条件置为生效。

      **SET REFRESHSRV**

      系统自动在60s后将配置的L7Filter置为生效。如果需要将新配置的L7Filter立即生效，可执行本步骤。
6. 配置IM类业务规则。

   **ADD RULE**

   如果运营商希望基于流过滤器组设置过滤条件时，配置“流过滤器或流过滤器组选择(FILTERINGMODE)”为“FLOWFILTERGRP”，并且使用**ADD FLOWFILTERGRP**命令配置流过滤器组。
7. 配置规则与用户模板的绑定关系 。
   1. 创建UserProfile。

      **ADD USERPROFILE**
   2. 将已配置的rule绑定到UserProfile。

      **ADD RULEBINDING**
   3. **可选：**禁用Alias Marking功能。

      **MOD USERPROFILE**

      DSCP方式下，需要禁用Alias Marking功能。因为该功能使能时，报文ToS域的值不会被改写。

## 任务示例

任务描述

在UDG上配置IM类业务的无线资源管控功能。

如下脚本以IM类业务QQ为例，通过DSCP方式实现无线资源管控功能。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH: LICITEM="LKV3G5ITSR01",SWITCH=ENABLE;
```

//配置三四层过滤条件。

```
ADD FILTER: FILTERNAME="filter_IM_any", L34PROTTYPE=STRING, L34PROTOCOL=ANY;
ADD FLOWFILTER:FLOWFILTERNAME="flowfilter_IM_01";
ADD FLTBINDFLOWF:FLOWFILTERNAME="flowfilter_IM_01",FILTERNAME="filter_IM_any";
SET REFRESHSRV:REFRESHTYPE=ALL;
```

//配置七层过滤条件。

//通过报文特征库识别协议。

```
LOD SIGNATUREDB:LOADMODE=LATEST;
LOD PARSERDB:LOADMODE=LATEST;
```

//配置流过滤器与协议绑定（此处根据qq\_im识别IM类业务“QQ”，其他IM类业务时，PROTOCOLNAME需要根据实际业务规划）。

```
ADD PROTBINDFLOWF:FLOWFILTERNAME="flowfilter_IM_01",PROTOCOLNAME="qq_im";
```

//配置IM类业务使用的规则（将QQ业务映射的DSCP值为AF12，其他IM类业务时，REMARKCLASS需要根据实际业务修改）。

```
ADD RULE:RULENAME="rule_IM_01",POLICYTYPE=REMARK_FPI,FILTERINGMODE=FLOWFILTER,FLOWFILTERNAME="flowfilter_IM_01", 
REMARKFPISEL=REMARK,REMARKCFGTYPE=CLASS,REMARKCLASS=AF12,PRIORITY=20;
```

//配置规则与用户模板的绑定关系。

```
ADD USERPROFILE:USERPROFILENAME="up_test";
ADD RULEBINDING:USERPROFILENAME="up_test",RULENAME="rule_IM_01";
```

版权所有 © 华为技术有限公司
