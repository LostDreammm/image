# 激活源地址的NAT64转换

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

当运营商给用户分配了私网IPv6地址，用户需要访问IPv4 Internet业务（默认公网业务）时，需要在NAT app上激活支持NAT64功能。

## 必备事项

前提条件

* 已通过**ADD APN**完成APN的相关配置。
* 已登录OM Portal。
* 已完成配置NAT基本功能License开关。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明  | | | | | | | | |
| --- | --- | --- | --- | ---  | | | | | | | | |
| **ip pool** | pool-name | * testpool1 * testpool2 | 本端规划 | 配置地址池的名称。  | | | | | | | | |
|  | **mode** | pba | 全网规划 | 配置NAT转换地址池的模式，有三种：No-PAT、NAPT和PBA。  | | | | | | | | |
| **vpn-instance** | vpn-instance-name | downvpn | 全网规划 | 配置VPN实例名称，该VPN是数据转发相关的VPN。  | | | | | | | | |
| **section** | section-num | 0 | 本端规划 | 配置地址段的编号。  | | | | | | | | |
|  | start-ip-address | * 10.10.11.0 * 10.10.13.2 | 全网规划 | 配置地址段的起始IPv4地址。  | | | | | | | | |
|  | end-ip-address | * 10.10.11.250 * 10.10.13.254 | 全网规划 | 配置地址段的结束IPv4地址。  | | | | | | | | |
| **nat-ratio** | ratio-value | 2 | 本端规划 | 配置NATratio值。  | | | | | | | | |
| **port** | port-start | 1024 | 本端规划 | 配置地址池的起始端口。  | | | | | | | | |
|  | port-end | 2048 | 本端规划 | 配置地址池的终止端口。  | | | | | | | | |
| **pba block-size** | **pbablock-size** | 1024 | 本端规划 | 配置pba地址池的blocksize的值。  | | | | | | | | |
|  | block-num | 10 | 本端规划 | 配置pba地址池的最大block值。  | | | | | | | | |
| **nap-filter** | nap-filter-name | fnat64 | 本端规划 | 配置过滤器的名称。  | | | | | | | | |
|  | l34-protocol-value | any | 全网规划 | 配置三四层协议类型。  | | | | | | | | |
| **nap-filter-group** | nap-filter-group-name | gnat64 | 本端规划 | 配置过滤器组名称。  | | | | | | | | |
|  | nap-filter-name | fnat64 | 本端规划 | 配置过滤器名称。  | | | | | | | | |
| **nat-policy** | nat-policy-name | pnat64 | 本端规划 | 配置策略的名称。  | | | | | | | | |
|  | nap-filter-group-name | gnat64 | 本端规划 | 配置策略的过滤规则组名称。  | | | | | | | | |
|  | vpn-instance-name | srvvpn | 本端规划 | 配置生效的VPN，该VPN是用户激活的VPN。  | | | | | | | | |
|  | **nat64 nat-address-pool** *nat-address-pool-name* | * testpool1 * testpool2 | 本端规划 | 针对IPv4的报文做源NAT44转换，指定NAT转换使用的IPv4源地址池。  | | | | | | | | |
|  | priority-value | 8 | 本端规划 | 配置该策略的优先级。  | | | | | | | | |
| **nat64 prefix** | prefix-address | 2001:db8:: 32 | 全网规划 | 配置nat64地址的前缀地址。  | | | | | | | | |
| **nap-well-known-port** | port-name | * testknownport-ftp * testknownport-http | 本端规划 | 配置知名端口名称。  | | | | | | | | |
|  | protocol-name | * ftp * http | 本端规划 | 配置子协议类型。  | | | | | | | | |
|  | **trans–proto** | tcp | 本端规划 | 配置传输层协议时TCP。  | | | | | | | | |
|  | operatorport | * eq 21 * eq 80 * eq 22 * eq 81 | 本端规划 | 配置端口范围。  | | | | | | | | |
|  | priority-value | * 20 * 21 * 22 * 23 | 本端规划 | 配置协议识别匹配时优先级。  | | | | | | | | |
| **detect-protocol** | **ftp** | **h323** | **mmsp** | **pptp** | **rsh** | **rtsp** | **sip** | **sqlnet** | **dns** | ftp h323 pptp | 本端规划 | 配置NAT ALG/七层ASPF功能支持的协议类型。 |

## 操作步骤

1. 选择“应用管理 > NAT”，进入NAT的CLI执行界面。
2. 配合NAT64转换地址池。

   1. 进入系统视图。

      **sy****stem-view**
   2. 配置NAT64地址池，有三种模式：No-PAT、NAPT和PBA。

      **ip pool**
   3. 配置NAT64地址池所属的VPN实例。

      **vpn-instance**
   4. **可选：**配置NAT64地址池下pod最大地址个数。

      **pod-max-ip-number**

      * 20.8.2之前版本建议使用**vm-max-ip-number**进行该配置操作。
      * 该配置仅适用于NAPT和PBA类型地址池。
      * 该配置修改会引起回收/分配地址资源，影响当前业务，建议按照现网规划进行对应配置。
   5. 配置NAT64地址池的地址段。

      **section**
   6. **可选：**配置pba地址池的相关信息。

      该步骤为可选，仅配置端口预分配功能时需完成该步骤。

      1. 锁定地址池。

         **lock**
      2. 配置NAT地址池的ratio值。

         **nat-ratio**
      3. 配置地址池的起始端口和终止端口。

         **port**
      4. 配置pba地址池的blocksize和max-block-num 。

         **pba block-size**
      5. 解除锁定的地址池。

         **unlock**
   7. 返回系统视图。

      **quit**
3. 配置NAT64过滤条件。生效NAT64过滤条件。

   1. 进入nap视图。

      **nap****-view**
   2. 配置三四层NAT64过滤条件。

      **nap-filter** *xxx*  **ipv6 l34-protocol** *xxx*
   3. 配置NAT64过滤条件组，可绑定已配置的NAT filter。当配置了多个NAT filter时，满足其中一个过滤条件即可。

      **nap-filter-group** *xxx* **nap-filter** *xxx*
   4. 生效NAT过滤条件。

      **nap-refresh-service**
4. 配置NAT64策略。

   **nat-policy** *xxx* **nap-filter-group** *xxx* **vpn-instance** *xxx* **action nat64 source-nat nat-address-pool** *xxx* **priority** *x*

   此处VPN需要与业务VPN实例名称保持一致。
5. 配置IPv6前缀。

   * 使用**nat64 prefix**的配置内容作为IPv6前缀。
6. 配置NAT-ALG七层协议识别。

   为了确保NAT-ALG功能正常运行，需要配置七层协议识别。NAT支持基于知名端口方式识别用户报文七层协议。如果七层协议具有知名端口特征(如FTP协议对应的知名端口为21和20)，建议配置知名端口可最大限度的保证NAT处理正确，用户业务正常。

   1. 采用知名端口识别协议，配置知名端口识别。

      **nap-well-known-port**
   2. 配置NAT-ALG支持的应用层协议类型。

      **detect-protocol**
7. 配置NAT64支持私网目的IP的地址转换功能开关。

   **debug pfom set nat64-mode 1**

   该步骤为可选，仅需要访问私网目的地址时需完成该步骤。

## 任务示例

任务描述

任务一：NAT64场景，配置NAPT、三元组功能。

任务二：NAT64场景，配置端口预分配功能。

脚本

任务一：

```
<NAT>system-view
[NAT]ip pool testpool1 mode napt   
[NAT-ip-pool-testpool1]vpn-instance downvpn

[NAT-ip-pool-testpool1]section 0 10.10.11.0 10.10.11.250
[NAT-ip-pool-testpool1]q
[NAT]nap-view
[NAT-nap]nap-filter fnat64 ipv6 l34-protocol any
[NAT-nap]nap-refresh-service
[NAT-nap]nap-filter-group gnat64 nap-filter fnat64
[NAT-nap]nat-policy pnat64 nap-filter-group gnat64 vpn-instance srvvpn action nat64 nat-address-pool testpool1 priority 8
[NAT-nap]nat64 prefix 2001:db8:: 32
[NAT-nap]nap-well-known-port testknownport-ftp protocol ftp trans-proto tcp port eq 21 priority 20//可选，开启ALG功能时配置
[NAT-nap]nap-well-known-port testknownport-http protocol http trans-proto tcp port eq 80 priority 21//可选，开启ALG功能时配置
[NAT-nap]detect-protocol ftp h323 pptp//可选，开启ALG功能时配置
```

任务二：

```
<NAT>system-view
[NAT]ip pool testpool2 mode pba
[NAT-ip-pool-testpool2]vpn-instance downvpn
[NAT-ip-pool-testpool2]section 0 10.10.13.2 10.10.13.254
[NAT-ip-pool-testpool2]lock
[NAT-ip-pool-testpool2]nat-ratio 2
[NAT-ip-pool-testpool2]port 1024 2048
[NAT-ip-pool-testpool2]pba block-size 1024 max-block-num 10
[NAT-ip-pool-testpool2]unlock
[NAT-ip-pool-testpool2]q
[NAT]nap-view
[NAT-nap]nap-filter fnat64 ipv6 l34-protocol any
[NAT-nap]nap-refresh-service
[NAT-nap]nap-filter-group gnat64 nap-filter fnat64
[NAT-nap]nat-policy pnat64 nap-filter-group gnat64 vpn-instance srvvpn action nat64 nat-address-pool testpool2 priority 8
[NAT-nap]nat64 prefix 2001:db8:: 32
[NAT-nap]nap-well-known-port testknownport-http protocol http trans-proto tcp port eq 22 priority 22 //可选，开启ALG功能时配置
[NAT-nap]nap-well-known-port testknownport-http protocol http trans-proto tcp port eq 81 priority 23 //可选，开启ALG功能时配置
[NAT-nap]detect-protocol ftp h323 pptp//可选，开启ALG功能时配置
```

版权所有 © 华为技术有限公司
