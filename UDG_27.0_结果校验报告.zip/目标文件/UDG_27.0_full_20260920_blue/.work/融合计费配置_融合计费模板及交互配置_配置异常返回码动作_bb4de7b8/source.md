# 配置异常返回码动作

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本指导描述在UNC上配置NCG/CHF(OCS)响应的异常结果码动作的相关操作过程。

融合计费会话过程中，对于各种异常场景，可以在NCG/CHF(OCS)本地设置一些处理动作对融合计费流程进行干预，以确保业务的正常进行。这里的异常场景，主要是指**NCG/CHF(OCS)响应SMF请求消息的状况**，及**响应消息中携带的返回码值**。处理动作有三种大小不同的粒度：**整个用户的所有计费过程**、**PDU会话**、**RG**。

## 必备事项

前提条件

* 请仔细阅读融合计费原理。
* 完成加载License。
* 已完成融合计费模板创建。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| ****SET FAILHANDLING**** | 融合计费模板名称（CCTMPLTNAME） | cct-test | 从已有配置中获取 | 配置融合计费模板故障处理相关动作。  如果为全局融合计费模板配置故障处理相关动作，则“CCTMPLTNAME”为“global”。 |
|  | FH处理动作（FHACTION） | CONTINUE | 与对端协商 |  |
|  | 支持failover使能开关（FAILOVERSUP） | ENABLE |  |  |
|  | failback使能开关（AUTOFAILBACK） | ENABLE |  |  |
|  | Tx定时器时长(秒)（TXTIMER） | 3 |  |  |
|  | 用户保持时长(分钟)（HOLDINGTIME） | 30 |  |  |
|  | 用户保持调整时长(分钟)（RANGETIME） | 30 |  |  |
|  | 融合计费自动恢复功能开关（CNVCHGRECOVER） | DISABLE |  |  |
|  | 融合计费自动恢复间隔 (分钟)（RECOVERINTERVAL） | 20 |  |  |
|  | Update消息触发业务放通结束计费会话开关（UPDCONTTERM） | DISABLE |  |  |
|  | SCP故障重选开关（SCPFAILOVERSW） | SCP\_NOT\_FAILOVER |  |  |
| ****ADD PDUSCACT**** | CCT名称（CCTMPLTNAME） | cct-test | 本端规划 | 配置当SMF收到NCG/CHF(OCS)的PDU级异常返回码时的动作。基于用户计费过程中的PDU会话进行处理。  如果为全局融合计费模板配置PDU级异常返回码动作，则“CCTMPLTNAME”为“global”。 |
|  | 返回码类型（CODETYPE） | VALUE |  |  |
|  | 状态码（STATUSCODE） | 502 |  |  |
|  | 处理动作（SCACT） | FAILOVER |  |  |
| ****ADD RGRCACT**** | 在线计费模板名称（CCTMPLTNAME） | cct-test | 全网规划 | 配置当SMF收到NCG/CHF(OCS)的响应的RG级异常返回码时的动作。基于计费过程中PDU会话下的RG进行处理。  如果为全局融合计费模板配置RG级异常返回码动作，则“CCTMPLTNAME”为“global”。 |
|  | RG级异常返回码（RCCODE） | QUOTAMNOTAPPL |  |  |
|  | RG级异常返回码动作（RCACT） | BLCK\_IMMED\_RPT |  |  |
|  | RG级阻塞处理时间间隔(分钟)（BLKTIMER） | 30 |  |  |
| ****SET CNVRGDCHGPARA**** | 忽略CHF响应消息的信元列表（IGNORERSPAVP） | FUI | 全网规划 | 配置融合计费全局参数。  本示例以配置CHF(OCS)响应消息的信元列表为FUI以及CHF(OCS)响应消息信元错误的处理动作为TERMINATE为例。请根据实际业务需求参考**SET CNVRGDCHGPARA**命令帮助文档进行配置。 |
|  | CHF响应消息信元错误的处理动作（BADRSPACT） | TERMINATE | 全网规划 |  |

## 操作步骤

1. 进入“MML命令行-UNC”窗口。
2. **可选：**配置当SMF与NCG/CHF(OCS)交互时，SMF超时未收到NCG/CHF(OCS)返回的ChargingDataResponse消息时的动作。

   ****SET FAILHANDLING****
3. **可选：**配置当SMF收到NCG/CHF(OCS)的PDU级异常返回码时的动作。

   ****ADD PDUSCACT****
4. **可选：**配置当SMF收到NCG/CHF(OCS)的响应的RG级异常返回码时的动作。

   ****ADD RGRCACT****
5. **可选：**配置忽略NCG/CHF(OCS)响应消息的信元列表。

   ****SET CNVRGDCHGPARA****

   ****SET CNVRGDCHGPARA****命令的“IGNORERSPAVP”参数的取值范围是位域类型，支持如下参数单独配置或同时配置：

   * 当“IGNORERSPAVP”参数配置为“INVOCATIONNUM”时，表示忽略NCG/CHF(OCS)响应消息中的Invocation Sequence Number，不检查是否跟请求消息一致。
   * 当“IGNORERSPAVP”参数配置为“FUI”时，表示当NCG/CHF(OCS)返回RG级异常返回码和FUI时，忽略NCG/CHF(OCS)响应消息中的FinalUnitIndication，按照对应****ADD RGRCACT****配置的“RCACT”动作执行。当**ADD RGRCACT**未配置时，执行默认动作。
   * 当“IGNORERSPAVP”参数配置为“SESSIONFAILOVER”时，表示忽略NCG/CHF(OCS)响应消息中的SessionFailover，使用对应CCT模板通过****SET FAILHANDLING****配置的“FAILOVERSUP”动作，“FAILOVERSUP”表示主NCG/CHF(OCS)故障时，向备NCG/CHF(OCS)发送计费消息进行处理。
   * 当“IGNORERSPAVP”参数配置为“FAILUREHANDLING”时，表示忽略NCG/CHF(OCS)响应消息中的FailureHandling，使用对应CCT模板通过**SET FAILHANDLING**配置的“FHACTION”动作。

## 任务示例

任务描述

配置SMF超时未收到ChargingDataResponse消息、收到PDU级/RG级异常返回码时的动作。具体要求如下：

1、设置名为“cct-test”的CCT融合计费模板，FH处理动作为CONTINUE，Tx定时器时长3秒，用户保持时长30分钟。

2、增加PDU异常返回码动作，配置的CCT名称为“cct-test”，指定异常返回码为502，动作为FAILOVER。

3、增加RG异常返回码动作，配置的CCT名称为“cct-test”，指定异常返回码为“QUOTAMNOTAPPL”，动作为阻塞业务。

4、配置NCG/CHF(OCS)下发RG级异常返回码和FinalUnitIndication时，SMF忽略NCG/CHF(OCS)下发的FinalUnitIndication。

脚本

//配置SMF超时未收到ChargingDataResponse消息时的动作。

```
SET FAILHANDLING: CCTMPLTNAME="cct-test", FHACTION=CONTINUE, FAILOVERSUP=ENABLE, AUTOFAILBACK=ENABLE, TXTIMER=3, HOLDINGTIME=30;
```

//配置SMF收到PDU级异常返回码时的动作。

```
ADD PDUSCACT: CCTMPLTNAME="cct-test", CODETYPE=VALUE, STATUSCODE=502, SCACT=FAILOVER;
```

//配置SMF收到RG级异常返回码时的动作。

```
ADD RGRCACT: CCTMPLTNAME="cct-test", RCCODE=QUOTAMNOTAPPL, RCACT=BLCK_IMMED_RPT, BLKTIMER=30;
```

//配置NCG/CHF(OCS)下发RG级异常返回码和FinalUnitIndication时，SMF忽略NCG/CHF(OCS)下发的FinalUnitIndication。

```
SET CNVRGDCHGPARA: IGNORERSPAVP=FUI, BADRSPACT=TERMINATE;
```

版权所有 © 华为技术有限公司
