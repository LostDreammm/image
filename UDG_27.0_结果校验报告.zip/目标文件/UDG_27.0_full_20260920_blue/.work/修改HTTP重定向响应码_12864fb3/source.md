# 修改HTTP重定向响应码

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

当用户的http协议的报文需要被重定向时，UDG向用户发送重定向响应报文，报文中的重定向响应码标识了重定向的类型。

适用于PGW-U、UPF。

## 必备事项

前提条件

该操作无需具备特殊条件。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET SRVCOMMONPARA** | HTTP重定向返回码（HTTPREDIRCODE） | RSP\_CODE\_302 | 本端规划 | - |

## 操作步骤

1. 基于全局配置HTTP协议的GET请求回应的重定向响应码。

   **SET SRVCOMMONPARA**

## 任务示例

任务描述

http重定向响应码修改为RSP\_CODE\_302。

脚本

//基于全局配置HTTP协议的GET请求回应的重定向响应码。

```
SET SRVCOMMONPARA:HTTPREDIRCODE=RSP_CODE_302;
```

版权所有 © 华为技术有限公司
