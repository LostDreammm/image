# 配置动态路由OSPFv3+BFD组网（IPv6）

* 操作场景
* 必备事项
* 操作步骤
* 验证方法

## 操作场景

VNF与对端设备可通过OSPF动态路由绑定IPv6动态BFD探测的方式进行组网连接，该方式适用于IPv6组网的网络中。

在网络拓扑结构复杂、设备与IP路由繁多的网络部署时，通常使用OSPF动态路由方式发布路由。同时，利用BFD双向转发检测机制为链路提供双向、轻负荷且持续时间短的快速检测功能，提高链路可靠性。

如图1所示为VNF与周边网元的OSPF动态路由互通组网示意图。VNF与网关运行动态路由协议而接入运营商网络（IP骨干网），网关可以使用DC-GW、EOR（End of Row）交换机或运营商的PE（Provider Edge）交换机。无论哪种方式，VNF的配置相同，没有差异。PE的路由配置请参考运营商的网络规划配置，DC-GW/EOR的配置请参考对应型号设备的产品文档。

**图1** OSPFv3动态路由+IPv6 BFD组网

## 必备事项

前提条件

* 请阅读并熟悉特性IPFD-014001 支持OSPF特性概述和IPFD-012003 BFD特性概述。
* 具备管理员权限的操作人员已经登录华为操作维护系统（登录MAE客户端或登录OM Portal）。

* VNF与网络实体之间的网络环境已经构建完成。

数据

VNF使用OSPFv3动态路由绑定动态BFD检测功能与对端设备建立可靠的IP连接。

* 在VNF上配置OSPFv3动态路由与对端建立链路。
* 在VNF上配置动态IPv6 BFD功能增强链路检测可靠性。
* 在VNF上推荐采用子接口的外联口与外部网络对接。

本文以一组外联口子接口为例进行说明，一组外联口（对应一个逻辑接口）分别在每个CSLB各规划2个子接口负荷分担承载流量，后续扩容CSLB后自动在每个CSLB上扩展2个子接口承载流量。实际场景可根据网设规划进行适配。

**如下数据仅为举例，请注意修改成局点规划的数据。**

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| ****ADD L3VPNINST**** | VPN实例名称（VRFNAME） | VPN\_Access | 参见“5G Core LLD文档 > 业务IP对接设计 > VRF”。  请选中“虚拟机类型”为“ISU”/“ISU\_Cxx”且“子端口”为“group\_isu\_xxxx”的所有行，查找指定“逻辑接口”对应的“VRF”。逻辑接口包括N3if、N4if、N6等接口。此处以N3if为例。 | VPN实例全网统一规划，一条通信路径上所有节点绑定的VPN实例要一致，才能正常通信。 |
| ****ADD VPNINSTAF**** | 地址族名称(AFTYPE) | ipv6uni | - | IPv6组网场景下，该参数选择ipv6uni。 |
|  | 路由标识（VRFRD） | 10.8.25.1:100 | 参见“5G Core LLD文档 > 路由设计 > VRF设计”。 | 不同VPN实例的路由标识必须不同。 |
| ****SET BFD**** | BFD使能标志（BFDENABLE） | TRUE | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > BFD是否使能”。 | 参数“DELAYUPTIMER”（会话延迟UP时间）和“TOSEXP”（动态会话报文优先级）可以不用配置，使用默认值即可。 |
| ****ADD OSPFV3**** | OSPFv3进程号（PROCID） | 6 | 参见“5G Core LLD文档 > 路由设计 > OSPF设计 > Process-ID”。 | - |
|  | 路由器标识（ROUTERID） | 10.8.25.1 | 参见“5G Core LLD文档 > 路由设计 > OSPF设计 > Router ID”。 |  |
|  | VPN名称（VRFNAME） | VPN\_Access | 参见“5G Core LLD文档 > 路由设计 >OSPF设计 > VRF名称”。 |  |
|  | 使能BFD（BFDALLINTFFLG） | TRUE | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > BFD是否使能”。 |  |
|  | 是否配置BFD最小接收报文间隔（BFDRXCFGFLAG） | TRUE | - |  |
|  | 接收BFD包的最小时间间隔（ms）（BFDMINRXINTV） | 500 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > min-rx-interval(毫秒)”。 |  |
|  | 是否配置BFD最小发送报文间隔（BFDTXCFGFLAG） | TRUE | - |  |
|  | 发送BFD包的最小时间间隔（ms）（BFDMINTXINTV） | 500 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > min-tx-interval(毫秒)”。 |  |
|  | BFD检测乘数间隔（DETECTMULINTV） | 4 | 参见“5G Core LLD文档 > 路由设计 > BFD设计 > detect-multiplier”。 |  |
|  | 去使能VPN路由环路检测（VPNINSCAPSIMFLG） | TRUE | - |  |
|  | OSPFv3共网段虚拟系统使能标志（VIRTUALSYSFLAG） | TRUE | - |  |
|  | SPF计算最长间隔时间（ms）（SPFMAXINTERVAL） | 50 | 本端规划 | 单平面组网时需要规划；双平面组网时，不需要规划。  采用智能定时器配置OSPFv3 SPF计算的间隔时间时，采用样例值。 |
|  | SPF计算初始间隔时间（ms）（SPFSTARTINTV） | 50 | 本端规划 |  |
|  | SPF计算基数间隔时间（ms）（SPFHOLDINTERVAL） | 50 | 本端规划 |  |
|  | 取消使用智能定时器配置LSA接收的间隔时间（LSAARRINTVFLAG） | FALSE | 本端规划 | 单平面组网时需要规划；双平面组网时，不需要规划。  采用智能定时器配置LSA接收的间隔时间时，推荐采用样例值。  此处的样例值是组网标准方案的推荐值；如数通设备不采用推荐值，需要与网元协商该参数取值。 |
|  | 接收最长间隔时间（ms）（LSAARRMAXINTV） | 50 | 本端规划 |  |
|  | 接收初始间隔时间（ms）（LSAARRSTARINTV） | 50 | 本端规划 |  |
|  | 接收基数间隔时间（ms）（LSAARRHLDINTV） | 50 | 本端规划 |  |
|  | 是否指定LSA更新的时间间隔为0（LSAORIGINSTFLAG） | FALSE | 本端规划 | 单平面组网时需要规划；双平面组网时，不需要规划。  采用智能定时器配置LSA发送的间隔时间时，推荐采用样例值。  此处的样例值是组网标准方案的推荐值；如数通设备不采用推荐值，需要与网元协商该参数取值。 |
|  | 更新最长间隔时间（ms）（LSAORIGMAXINTV） | 500 | 本端规划 |  |
|  | 更新初始间隔时间（ms）（LSAORIGSTARINTV） | 50 | 本端规划 |  |
|  | 更新基数间隔时间（ms）（LSAORIGHLDINTV） | 100 | 本端规划 |  |
| ****ADD OSPFV3AREA**** | OSPFv3区域标识（AREAID） | 0.0.0.5 | 参见“5G Core LLD文档 > 路由设计 > OSPF设计 > Area ID”。 | 两个接口若要建立邻居关系，则Area ID必须相同。 |
|  | OSPFv3区域类型(AREATYPE) | NSSA | 参见“5G Core LLD文档 > 路由设计 > OSPF设计 > Area Type”。 | 两个接口若要建立邻居关系，则Area Type必须相同。 |
| ****ADD OSPFV3IMPORTROUTE**** | 拓扑标识（TOPOID） | 0 | - | - |
|  | 协议号 （PROTOCOL） | wlr | 参见“5G Core LLD文档 > 路由设计 > OSPF设计 > import route类型”。 |  |
| **ADD AUTOSCALINGETHTRUNK** | 以太Trunk模板ID（ETHTRUNKTMPID） | 1 | 本端规划 | SR-IOV bonding组网需要规划。  只有MAC地址一样的VNIC才能加到同一个TRUNK里。 |
|  | 虚拟网卡ID列表（VNICLIST） | 4  5 | 参见“5G Core LLD文档 > 业务IP对接设计 > 虚拟网口”。  请选中“虚拟机类型”为“ISU”/“ISU\_Cxx”且“子端口”为“group\_isu\_xxxx”的所有行，查找指定“逻辑接口”对应的“虚拟网口”。逻辑接口包括N3if、N4if、N6等接口。此处以N3if为例。 |  |
| **ADD AUTOSCALINGSERVICE** | 服务名称（SERVICENAME） | ServName\_Access\_100  ServName\_Access\_200 | 本端规划 | 如果规划外联口使用IPv4v6双栈地址，则分别执行该命令对同一外联口配置IPv4和IPv6地址。 |
|  | VPN实例名称（VPNNAME） | VPN\_Access | 已规划数据中获取 |  |
|  | 地址族（AFTYPE） | IPv6 | 已规划数据中获取 |  |
|  | 虚拟网卡ID（VNICID） | 4  5 | 参见“5G Core LLD文档 > 业务IP对接设计 > 虚拟网口”。  请选中“虚拟机类型”为“ISU”/“ISU\_Cxx”且“子端口”为“group\_isu\_xxxx”的所有行，查找指定“逻辑接口”对应的“虚拟网口”。逻辑接口包括N3if、N4if、N6等接口。此处以N3if为例。 | 非SR-IOV bonding组网需要规划。 |
|  | 以太Trunk模板ID（ETHTRUNKTMPID） | 1 | 已规划数据中获取 | SR-IOV bonding组网需要规划。 |
|  | VLAN ID（VLANID） | 100  200 | 参见“5G Core LLD文档 > 业务IP对接设计 > VLAN ID（VM）”。  请选中“虚拟机类型”为“ISU”/“ISU\_Cxx”且“子端口”为“group\_isu\_xxxx”的所有行，查找指定“逻辑接口”对应的“VLAN ID（VM）”。逻辑接口包括N3if、N4if、N6等接口。此处以N3if为例。 | 此处以双平面为例，单平面组网时，只需规划一条数据（例如只规划ServName\_Access\_100）。  此处规划的IP地址是与网关互通的外联口IP。  根据ISU VM的数量规划IPv6地址池掩码长度。  此处以121位掩码为例进行介绍，具体以网设规划为准。 |
|  | 起始地址（BEGINADDR6） | FC00::1002  FC00::1082 | 参见“5G Core LLD文档 > 业务IP对接设计 > 起始IP”。  请选中“虚拟机类型”为“ISU”/“ISU\_Cxx”且“子端口”为“group\_isu\_xxxx”的所有行，查找指定“逻辑接口”对应的“起始IP”。逻辑接口包括N3if、N4if、N6等接口。此处以N3if为例。 |  |
|  | 结束地址（ENDADDR6） | FC00::107E  FC00::10FE | 参见“5G Core LLD文档 > 业务IP对接设计 > 结束IP”。  请选中“虚拟机类型”为“ISU”/“ISU\_Cxx”且“子端口”为“group\_isu\_xxxx”的所有行，查找指定“逻辑接口”对应的“结束IP”。逻辑接口包括N3if、N4if、N6等接口。此处以N3if为例。 |  |
|  | 地址池掩码长度（MASKLEN） | 121  121 | 参见“5G Core LLD文档 > 业务IP对接设计 > 子网掩码”。  请选中“虚拟机类型”为“ISU”/“ISU\_Cxx”且“子端口”为“group\_isu\_xxxx”的所有行，查找指定“逻辑接口”对应的“子网掩码”。逻辑接口包括N3if、N4if、N6等接口。此处以N3if为例。 |  |
|  | 使能OSPFv3（OSPFENABLE） | TRUE | 固定取值 | - |
|  | OSPFv3进程ID（OSPFPROCID） | 6 | 已规划数据中获取 |  |
|  | OSPFv3区域ID（OSPFAREAID） | 0.0.0.5 | 已规划数据中获取 |  |
|  | 使能入方向的流量策略（TPINENABLE） | FALSE | - |  |
|  | 使能出方向的流量策略（TPOUTENABLE） | FALSE | - |  |
|  | 网络分组标识（NETWORKINSTID） | 0 | 参见“5G Core LLD文档 > 业务IP对接设计 > 网络分组ID”。  （UPF\_SR-IOV bonding）请选中“虚拟机类型”为“IPU\_*x*”且“子端口”为“group\_isu\_xxxx”的所有行，查找N6/SGi对应的“网络分组ID”。 | 中心云场景+非SDN+SR-IOV bonding组网，通过IPU分组虚机IPU\_*x*/IPU\_*x*\_ARM（*x*取值为B、C、D、E）支持大规格企业专线时需要规划，其他场景使用默认值0。  仅与企业互通的N6/SGi接口需要规划，其他接口不需要规划。  IPU分组虚机和网络分组标识的映射关系如下：  * IPU\_B/IPU\_B\_ARM虚机：1 * IPU\_C/IPU\_C\_ARM虚机：2 * IPU\_D/IPU\_D\_ARM虚机：3 * IPU\_E/IPU\_E\_ARM虚机：4  可通过**DSP NODE**命令查询IPU分组虚机类型。  约束：IPU分组虚机（IPU\_*x*/IPU\_*x*\_ARM），不支持入不转板功能、不支持SDN组网、且与BGP/MPLS VPN方案互斥。 |

文档

获取网设LLD文档。

## 操作步骤

1. 配置外联口的VPN实例。

   ```
   ADD L3VPNINST: VRFNAME="VPN_Access";
   ADD VPNINSTAF: VRFNAME="VPN_Access", AFTYPE=ipv6uni;
   MOD VPNINSTAF: VRFNAME="VPN_Access", AFTYPE=ipv6uni, VRFRD="10.8.25.1:100";
   ```

   一条通信路径上所有节点绑定的VPN实例要一致，才能正常通信，例如VNF逻辑接口、VNF外联口、网关上的VPN，否则从逻辑接口发出去的报文会查询路由失败。
2. 全局激活BFD。

   ```
   SET BFD: BFDENABLE=TRUE;
   ```
3. 配置OSPF路由。

   1. 创建OSPFv3进程。

      //单平面组网时：

      ```
      ADD OSPFV3: PROCID=6, ROUTERID="10.8.25.1", VRFNAME="VPN_Access", BFDALLINTFFLG=TRUE, BFDRXCFGFLAG=TRUE, BFDMINRXINTV=500, BFDTXCFGFLAG=TRUE, BFDMINTXINTV=500, DETECTMULINTV=4, VPNINSCAPSIMFLG=TRUE, VIRTUALSYSFLAG=TRUE, SPFMAXINTERVAL=50, SPFSTARTINTV=50, SPFHOLDINTERVAL=50, LSAARRINTVFLAG=FALSE, LSAARRMAXINTV=50, LSAARRSTARINTV=50, LSAARRHLDINTV=50, LSAORIGINSTFLAG=FALSE, LSAORIGMAXINTV=500, LSAORIGSTARINTV=50, LSAORIGHLDINTV=100;
      ```

      //双平面组网时：

      ```
      ADD OSPFV3: PROCID=6, ROUTERID="10.8.25.1", VRFNAME="VPN_Access", BFDALLINTFFLG=TRUE, BFDRXCFGFLAG=TRUE, BFDMINRXINTV=500, BFDTXCFGFLAG=TRUE, BFDMINTXINTV=500, DETECTMULINTV=4, VPNINSCAPSIMFLG=TRUE, VIRTUALSYSFLAG=TRUE;
      ```

      * VNF支持VPN多实例，因此需要取消环路检查（参数“VPNINSCAPSIMFLG”配置为“TRUE”），否则会导致OSPF路由引入失败。
      * 路由器标识Router ID（“SCHEMAROUID”）的选择策略：优选用户配置的Router ID，如果未配置，则选择OSPFv3进程所在VRF内或者公网内的最大接口IP地址。
      * 如果需要为OSPFv3动态路由绑定BFD会话，则配置参数“BFDALLINTFFLG（使能BFD）”为“TRUE”。
      * 当OSPFv3路由配置共网段时，需要将参数“VIRTUALSYSFLAG（OSPFv3共网段虚拟系统使能标志）”配置为“TRUE”。
   2. 增加OSPFv3区域。

      ```
      ADD OSPFV3AREA:PROCID=6,AREAID="0.0.0.5", AREATYPE=NSSA, NSSADEFAULTROUTEADVERTISE=FALSE;
      ```

      参数“AREATYPE（OSPFv3区域类型）”配置为“NSSA”或“Normal”时，都不需要配置Loopback地址。
   3. 设置OSPFv3引入路由类型。

      ```
      ADD OSPFV3IMPORTROUTE:PROCID=6,TOPOID=0,PROTOCOL=wlr,IMPTCOSTCFG=FALSE,IMPTTAGCFG=FALSE,IMPTTYPECFG=FALSE;
      ```
4. 关闭自动配置开关。

   1. 查询自动配置开关。

      ```
      LST AUTOCONFIG:;
      ```

      如果自动配置开关值为“TRUE”，需要执行如下步骤关闭自动配置开关。
   2. （可选）查询自动部署维护助手“autoscaling\_autoconfig.py”的状态，确保状态为“准备好状态（Ready）”或者查询无该脚本，以保证当前设备不在自动部署过程中。因为若系统当前有正在进行的自动部署，而自动部署生效有时延，此时若关闭自动配置开关，会影响系统配置效果。

      ```
      DSP OPSASSISTSTATE:;
      ```
   3. （可选）关闭自动配置开关。自动化配置命令只有在自动配置开关为关闭的状态下才可执行，因此需要提前关闭。

      ```
      SET AUTOCONFIG:SWITCHFLAG=FALSE;
      ```
5. 接口采用SR-IOV bonding组网时，添加以太网隧道多虚拟网卡自动化配置模板。

   ```
   ADD AUTOSCALINGETHTRUNK: ETHTRUNKTMPID=1, VNICLIST="4 5";
   ```

   * 在SR-IOV Bonding组网场景下，必须配置该模板。非SR-IOV bonding组网场景下，请跳过本步骤。
   * 如果要实现SR-IOV接口bonding功能，那么一个Eth-trunk接口下的两个成员接口必须MAC相同，且ID号连续。即：“VNICLIST”中配置的ID号为MAC相同且连续的两个以太网接口的ID。可使用**LST INTERFACE**命令查询以太网接口的mac地址与以太网接口名称。
6. 配置外联口自动部署模板。
   * 非SR-IOV bonding组网场景下：

     ```
     ADD AUTOSCALINGSERVICE:SERVICENAME="ServName_Access_100",VPNNAME="VPN_Access",AFTYPE=IPv6, IPALLOCTYPE6=USER_CONFIG,AUTOCFGIFTYPE=VNIC,VNICID=4,VLANID=100, BEGINADDR6="FC00::1002", ENDADDR6="FC00::107E", MASKLEN=121, OSPFENABLE=TRUE, OSPFPROCID=6, OSPFAREAID="0.0.0.5", TPINENABLE=FALSE, TPOUTENABLE=FALSE;
     ```

     ```
     ADD AUTOSCALINGSERVICE:SERVICENAME="ServName_Access_200",VPNNAME="VPN_Access",AFTYPE=IPv6, IPALLOCTYPE6=USER_CONFIG,AUTOCFGIFTYPE=VNIC,VNICID=5,VLANID=200, BEGINADDR6="FC00::1082", ENDADDR6="FC00::10FE", MASKLEN=121, OSPFENABLE=TRUE, OSPFPROCID=6, OSPFAREAID="0.0.0.5", TPINENABLE=FALSE, TPOUTENABLE=FALSE;
     ```
   * SR-IOV bonding组网场景下：

     ```
     ADD AUTOSCALINGSERVICE:SERVICENAME="ServName_Access_100", VPNNAME="VPN_Access", AFTYPE=IPv6, IPALLOCTYPE6=USER_CONFIG, AUTOCFGIFTYPE=ETHTRUNK, ETHTRUNKTMPID=1, VLANID=100, BEGINADDR6="FC00::1002", ENDADDR6="FC00::107E", MASKLEN=121, OSPFENABLE=TRUE, OSPFPROCID=6, OSPFAREAID="0.0.0.5", TPINENABLE=FALSE, TPOUTENABLE=FALSE, NETWORKINSTID=0; 
     ADD AUTOSCALINGSERVICE:SERVICENAME="ServName_Access_200", VPNNAME="VPN_Access", AFTYPE=IPv6, IPALLOCTYPE6=USER_CONFIG, AUTOCFGIFTYPE=ETHTRUNK, ETHTRUNKTMPID=1, VLANID=200, BEGINADDR6="FC00::1082", ENDADDR6="FC00::10FE", MASKLEN=121, OSPFENABLE=TRUE, OSPFPROCID=6, OSPFAREAID="0.0.0.5", TPINENABLE=FALSE, TPOUTENABLE=FALSE, NETWORKINSTID=0;
     ```

   如果规划外联口使用IPv4v6双栈地址，则分别执行该命令对同一外联口配置IPv4和IPv6地址。
7. 打开自动配置开关。

   ```
   SET AUTOCONFIG: SWITCHFLAG=TRUE;
   ```

   从自动部署开关打开到自动部署功能生效有时延，因此执行其他操作前（例如手动部署路由互通、关闭自动部署开关），务必先执行****DSP OPSASSISTSTATE****命令查询自动部署维护助手“autoscaling\_autoconfig.py”的状态为“准备好状态（Ready）”，否则结果不可预期。

## 验证方法

若仅调整“网络分组标识（NETWORKINSTID）”参数值，请执行2~5。

1. 查看接口状态及信息是否与规划数据一致。

   ```
   LST INTERFACE:;
   ```

   ```
   LST IFIPV6ADDRESS:;
   ```

   ```
   LST IPBINDVPN:;
   ```

   * 如果一致，请执行3。
   * 如果不一致，请执行2。
2. 修改外联口自动部署模板。
   1. 关闭自动化配置开关。

      ```
      SET AUTOCONFIG: SWITCHFLAG=FALSE;
      ```
   2. 查询需要修改的外联口自动部署模板并记录服务名称、起始地址和结束地址等参数。

      ```
      LST AUTOSCALINGSERVICE:;
      ```
   3. 查询需要修改的子接口并记录查询结果。记录哪些接口的IP地址在2.b中记录的起始地址和结束地址范围内。

      ```
      LST IFIPV6ADDRESS:;
      ```
   4. 删除2.c中记录的相关子接口的OSPF邻居。

      **RMV OSPFV3INTERFACE**
   5. 删除2.c中记录的所有子接口。

      **RMV INTERFACE**

      IPv4v6双栈场景，删除子接口时，会同时删除IPv4和IPv6地址。
   6. 删除错误的外联口自动化配置模板。

      **RMV AUTOSCALINGSERVICE**
   7. 重新配置外联口自动化配置模板。

      **ADD AUTOSCALINGSERVICE**
   8. 打开自动化配置开关。

      ```
      SET AUTOCONFIG: SWITCHFLAG=TRUE;
      ```

      修改配置后，请重新执行1。
3. 调测OSPFv3动态路由。

   1. 检查接口是否已添加到OSPFv3区域中。

      ****DSP OSPFV3INTERFACE****: PROCID=OSPFv3进程号;
      * 如果是，请执行3.b。
      * 如果否，请执行1。
   2. 检查OSPFV3邻居状态是否正常。

      邻居应包括邻居设备的ROUTER ID、接口的IP地址以及邻居的状态。

      ****DSP OSPFV3PEER****: PROCID=OSPFv3进程号;
      * 如果是，请执行4。
      * 如果否，请3.c。
   3. 执行**PING**，查看VNF外联口IP与DCGW接口IP能否互通。

      ```
      PING:IPVERSION=IPv6,VPNNAME="VPN_Access",DESTIPV6ADDRESS="对端网关地址";
      ```

      * 丢包率为0%，请执行5。
      * 丢包率不是0%，请检查物理接口及连线是否正常。正常后重新执行3.b。
4. 检查BFD会话状态是否为up。

   **DSP BFDSESSION**:;

   * 如果状态为up，调测结束。
   * 如果为其他状态，请执行5。
5. 收集信息并寻求技术支持。

   1. 执行**EXP MML**命令将当前配置数据导出为MML脚本文件并保存。
   2. 收集并保存上述所有查询信息。
   3. 查看并收集对端设备配置及接口状态信息。
   4. 收集归纳所有信息并联系华为技术支持解决。

版权所有 © 华为技术有限公司
