# 离线计费配置（4G）

* 操作场景
* 必备事项
* 操作步骤

## 操作场景

配置4G离线计费（NCG通过Ga接口和GGSN-C/SGW-C/PGW-C/SMF对接）话单处理参数。该章节仅针对于组网场景有Ga接口且生成话单为4G话单的计费方案。

## 必备事项

前提条件

* 具备管理员权限的操作人员已经登录华为操作维护系统（登录MAE客户端或登录OM Portal）。

* UNC软件安装已完成。

数据

* BI接口数据

  | 类别 | 参数名称 | 取值样例 | 获取方法 | 说明  | |
  | --- | --- | --- | --- | ---  | |
  | **ADD CDRPROC** | 接入网元分组标识（AGID） | PS2 | 本端规划 | -  | |
  |  | 格式引擎包名（PRFNAME） | PS\_R9\_V940\_CMCC.tar.gz |  | + 格式引擎包文件全名，包括后缀名。例如，“PS\_R9\_V940\_CMCC.tar.gz”。 + 不同的局点话单处理规则不同，需要根据实际情况配置相应的格式引擎包。 + 该参数只能由字母、数字、下划线、点组成。  | |
  | **ADD FMTPKGCFG** | 格式引擎包名（PRFNAME） | PS\_R9\_V940\_CMCC.tar.gz | 本端规划 | “PRFNAME”可以通过**LST CDRPROC**命令查询获取。  | |
  |  | 格式引擎包软参名称（CFGNAME） | + MaxDuration + MaxVolume |  | “CFGNAME”可以通过**DSP FMTSOFTPARA**命令获取，其他名称无法生效。  说明：  不同的格式引擎包对软参的支持情况可能不同，可以通过**DSP FMTSOFTPARA**命令查询对应格式引擎包可配置的软参。如不涉及软参，则不需要配置。  | |
  |  | 格式引擎软参类型（CFGTYPE） | + FEM\_PARA\_UINT + FEM\_PARA\_UINT |  | 需与“CFGNAME”对应的“格式引擎包软参类型”匹配，“格式引擎包软参类型”可以通过**DSP FMTSOFTPARA**命令查询获取。  | |
  |  | 格式引擎软参值（CFG\_UINT\_VALUE） | + 0 + 0 |  | “CFG\_UINT\_VALUE”在“CFGNAME”对应的“格式引擎包软参取值范围”内，“格式引擎包软参取值范围”可以通过**DSP FMTSOFTPARA**命令查询获取。  说明：  软参取值请根据业务实际需要进行配置。  | |
  | **ADD MODULE** | 模块名（MNAME） | AP64\_2  AP65\_2 | 本端规划 | + 首先执行****LST SERVICERUSTATE****命令，查询出当前的RUID。该参数输入格式固定为'AP'接RUID\_APID，APID值为1~4。例如：RUID为64时，该参数可以是“AP64\_1”、“AP64\_2”、“AP64\_3”、“AP64\_4”。 + 不能输入的特殊字符请参考NCG产品文档对应MML帮助。  | |
  |  | 接入网元分组标识（AGID） | PS2 |  | + 该值需要执行****LST CDRPROC****命令查询“接入网元分组标识”。如果没有符合要求的“接入网元分组标识”，还需执行****ADD CDRPROC****命令增加。 不能输入的特殊字符请参考NCG产品文档对应MML帮助。  | |
  | **ADD CDRSTOR** | 话单存储标识（CDRSTORID） | 4G\_second64\_2  4G\_second65\_2 | 本端规划 | 不能输入的特殊字符请参考NCG产品文档对应MML帮助。  | |
  |  | 原始话单文件保存天数（STORDAYS） | 30 |  | + 原始话单储存天数。超过此期限的话单，CG会将其删除。需根据当前局点要求，对此参数进行修改。 + 删除原始话单之前，系统会检查一下该话单是否被处理过，如果没有被处理，超过了期限的话单也不会被删除掉。但是原始话单文件保存天数方式为“按绝对天数”时，没有被处理但是超过期限也会被删除，因此原始话单文件保存天数方式为“按绝对天数”时，原始话单保存天数不允许小于3天。 + 当磁盘剩余空间小于自动清理话单的磁盘空间阈值时，系统为了保证业务的正常运行，会自动清理话单。清理的顺序为首先清理第一份最终话单，之后清理原始话单。但是清理之后，第一份最终话单和原始话单最少保证各有七天的话单。   - 当系统为单分区版本时，话单清理的磁盘剩余空间阈值为800MB。   - 当系统为多分区版本时，话单清理的磁盘剩余空间阈值为600MB。  | |
  |  | 模块名（MNAME） | AP64\_2  AP65\_2 |  | 与**ADD MODULE**中配置保持一致。  | |
  |  | 接入网元分组标识（AGID） | PS2 |  | 与**ADD MODULE**中配置保持一致。  | |
  |  | 最终话单文件名命名规则（NAMINGRULE） | NCG001%B\_%Y%m%d%H%M%S\_%08L.dat |  | + 默认最终话单文件名的配置为“b%08L.dat”，默认的话单文件名为b00000001.dat～b99999999.dat。 + 当“第二份最终话单文件压缩方式”的值为“GZIP”时，需要手动地增加压缩后缀，否则，第二份最终话单文件名中不显示压缩后缀。 + 该参数不能包含“/、\、\*、>、<、|”。 + 最终话单文件的命名规则建议默认增加 "%B" 的描述，否则BOSS获取话单存在重名风险。 + 当本地备份分发ADD CDRDISTR的可选项ISADDAPNAME选否以及模块名填 "AP\_ALL"，第二份最终话单的命名规则必须是带有"%B"的正则表达式。 + 不能输入的特殊字符请参考NCG产品文档对应MML帮助。 |
  | **ADD IPRESOURCE** | IP资源标识（IPRID） | IP\_Ga\_CDRReceive\_1st | 本端规划 | + 该参数只包含数字、字母和下划线。 + 增加话单分发的IP资源。 建议配置为：IP\_Bi\_CDRDistribution\_1st。 + 增加话单备份的IP资源。 建议配置为：IP\_Omi\_CDRBackup\_1st。 + 话单备份与分发采用同一IP资源。 建议配置为：IP\_Backup\_Distribution\_1st。 + 增加话单接收的IP资源。 建议配置为：IP\_Ga\_CDRReceive\_1st。  | |
  |  | IP资源用途（IPRPURPOSE） | Ga |  | -  | |
  |  | IP地址类型（IPTYPE） | IPv6 |  | -  | |
  |  | IPv6地址（IPV6） | fc01:f111:2222:3333:4444:5555:2111:151 |  | -  | |
  |  | 虚拟网络名称（VPNNAME） | Ga-test |  | -  | |
  | **RST VNFC** | 服务实例（SERVICEINSTANCE） | CG\_VNFC\_999 | 本端规划 | 只能填写通过**LST VNFC**命令查询到的管理代理标识。  | |
  |  | 强制操作标志（ISFORCEOPER） | TRUE |  | -  | |
  | **ADD ACTRL** | 接入控制标识（ACID） | R9CDR | 本端规划 | 不能输入的特殊字符请参考NCG产品文档对应MML帮助。  | |
  |  | 接入网元分组标识（AGID） | PS2 | 对端协商 | 与**ADD MODULE**，**ADD CDRSTOR**中配置保持一致。  | |
  |  | IP资源标识（IPRID） | ga | 本端规划 | 与**ADD IPRESOURCE**中配置保持一致。  | |
  |  | 端口（PORT） | 3386 | 本端规划 | 建议配置的端口号大于1024，防止和操作系统使用的端口号冲突。  | |

## 操作步骤

1. 配置4G话单处理的格式引擎包。

   ```
   ADD CDRPROC: AGID="PS2", PRFNAME="PS_R9_V940_CMCC.tar.gz", SHAREFILECSN=OFF, SEQNUMMODE=IE;
   ```
2. **可选：**配置格式引擎包对应的软参。

   * 不同的格式引擎包对软参的支持情况可能不同，可以通过**DSP FMTSOFTPARA**命令查询对应格式引擎包可配置的软参。如不涉及软参，则不需要配置**ADD FMTPKGCFG**命令。
   * 软参取值请根据业务实际需要进行配置。

   ```
   ADD FMTPKGCFG:PRFNAME="PS_R9_V940_CMCC.tar.gz",CFGNAME="MaxDuration",CFGTYPE=FEM_PARA_UINT,
   CFG_UINT_VALUE=0;
   ADD FMTPKGCFG:PRFNAME="PS_R9_V940_CMCC.tar.gz",CFGNAME="MaxVolume",CFGTYPE=FEM_PARA_UINT,
   CFG_UINT_VALUE=0;
   ```
3. 配置4G业务处理模块。

   ```
   ADD MODULE: MNAME="AP64_2", AGID="PS2";
   ADD MODULE: MNAME="AP65_2", AGID="PS2";
   ```

   MNAME格式为APXX\_YY，XX为RUID（从64开始递增），YY为模块ID（4G业务处理模块ID固定为2），国漫的消息量很小，为了简化配置和计费对接，建议只在前两个虚机添加业务模块。
4. 话单处理相关配置。

   ```
   ADD CDRSTOR: CDRSTORID="4G_second64_2", ISSINGLEBI=No, FILETYPE=SecondFinal, AGID="PS2", MNAME="AP64_2", SFSTORDAYS=30, SFSTORDAYSRULE=ByRelativeDays, SFCMRRULE=UNCOMPRESS, CLOSEFILECOND=Unspecify, EMPTYFILE=NO, NAMINGRULE="NCG001%B_%Y%m%d%H%M%S_%08L.dat", ENDSN=99999999, NUMSCHSN=NO;
   ADD CDRSTOR: CDRSTORID="4G_second65_2", ISSINGLEBI=No, FILETYPE=SecondFinal, AGID="PS2", MNAME="AP65_2", SFSTORDAYS=30, SFSTORDAYSRULE=ByRelativeDays, SFCMRRULE=UNCOMPRESS, CLOSEFILECOND=Unspecify, EMPTYFILE=NO, NAMINGRULE="NCG001%B_%Y%m%d%H%M%S_%08L.dat", ENDSN=99999999, NUMSCHSN=NO;
   ```
5. 配置Ga接口服务端端点的IP地址信息。

   ```
   ADD IPRESOURCE: IPRID="IP_Ga_CDRReceive_1st", IPRPURPOSE=Ga, IPTYPE=IPV6, IPV6="fc01:f111:2222:3333:4444:5555:2111:151", VPNNAME="Ga-test";
   ```

   * Ga IP全局仅需配置一个。
   * 复位CG VNFC后，添加的IP资源才能生效。
6. 重启CG服务。

   ```
   RST VNFC: SERVICEINSTANCE="CG_VNFC_999", ISFORCEOPER=TRUE;
   ```
7. 配置4G Ga接口本端接入网元分组的接入控制。

   ```
   ADD ACTRL: ACID="R9CDR", AGID="PS2", IPRID="ga", PORT=3386;
   ```

版权所有 © 华为技术有限公司
