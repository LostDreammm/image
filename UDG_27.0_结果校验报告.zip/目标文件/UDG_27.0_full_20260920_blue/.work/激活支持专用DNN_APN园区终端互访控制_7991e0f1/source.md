# 激活支持专用DNN/APN园区终端互访控制

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

对于UPF下沉到园区的场景，仅在不出园区的情况下允许终端互访，出园区后禁止终端互访时，需要激活本功能。

## 必备事项

前提条件

请仔细阅读支持专用DNN/APN园区终端互访控制功能概述。

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET APNUEMUTACC** | APN名称（APN） | apn-test | 已配置数据中获取 | 可以使用查询APN配置（LST APN）命令进行查询。 |
|  | 同APN内的控制开关（INNERAPNS） | DISABLE | 本端规划 | DISABLE表示允许终端互访。  ENABLE表示禁止终端互访。 |
|  | 不同APN间的控制开关（INTERAPNS） | ENABLE | 本端规划 |  |
|  | 同APN内S5S8口互访控制开关（INNERAPNS\_S5S8P） | ENABLE | 本端规划 | ENABLE表示禁止未命中SGW白名单的终端互访流量。 |
|  | 同APN内N9A口互访控制开关（INNERAPNS\_N9A） | ENABLE | 本端规划 | ENABLE表示禁止未命中I-UPF白名单的终端互访流量。 |
| **ADD UEMUTACCWLIST** | 白名单名称（WLISTNAME） | pawlist | 本端规划 | - |
|  | IP协议版本（IPVERSION） | IPV4 | 全网规划 | 当前也支持IPV6的地址类型。 |
|  | IPV4起始地址（IPV4START） | 192.168.1.1 | 全网规划 | - |
|  | IPV4截止地址（IPV4END） | 192.168.1.100 | 全网规划 | - |
| **ADD UEMUTWLISTBIND** | APN名称（APNNAME） | apn-test | 已配置数据中获取 | 可以使用查询APN配置（LST APN）命令进行查询。 |
|  | 白名单类型（WLISTTYPE） | SGWU | 全网规划 | - |
|  | 白名单名称（WLISTNAME） | pawlist | 已配置数据中获取 | 可以使用**LST UEMUTACCWLIST**命令进行查询。 |

## 操作步骤

1. APN下配置终端互访控制。

   **SET APNUEMUTACC**
2. （可选）配置终端互访白名单。

   **ADD UEMUTACCWLIST**

   **ADD UEMUTWLISTBIND**

## 任务示例

任务描述

针对apn-test的APN配置以下内容：

* 允许同APN内终端互访；
* 针对地址段范围为192.168.1.1~192.168.1.100的SGW接入的场景允许互访，其他N9a及S5-P/S8-P接口禁止终端互访。

脚本

```
SET APNUEMUTACC: APN="apn-test", INNERAPNS=DISABLE, INTERAPNS=ENABLE, INNERAPNS_S5S8P=ENABLE, INNERAPNS_N9A=ENABLE;
ADD UEMUTACCWLIST: WLISTNAME="pawlist", IPVERSION=IPV4, IPV4START="192.168.1.1",IPV4END="192.168.1.100";
ADD UEMUTWLISTBIND: APNNAME="apn-test", WLISTTYPE=SGWU, WLISTNAME="pawlist";
```

版权所有 © 华为技术有限公司
