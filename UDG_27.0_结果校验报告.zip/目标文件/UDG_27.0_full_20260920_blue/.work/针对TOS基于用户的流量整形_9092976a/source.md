# 针对TOS基于用户的流量整形

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

保护带宽资源不被P2P/VoIP流量吞噬，确保应用公平分享带宽资源。

基于TOS作为区分业务的条件时，UDG可以不进行业务的识别和解析，只是根据报文的DSCP就可以确定是否对其进行流量整形。

适用于PGW-U、UPF。

## 必备事项

前提条件

* 请仔细阅读GWFD-020354 基于业务的Shaping。
* UDG与网络实体之间的网络环境已经构建完成。
* 本特性License项依赖于其他特性，需开启依赖特性后才能开启本特性。详细仔细阅读GWFD-110311 基于业务感知的带宽控制。

数据

**表1** 带宽管理业务规划数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD BWMSERVICE** | 带宽控制业务名称（BWMSERVICENAME） | bwmservice\_test | 本端规划 | 存在多条数据时，该参数不能重复。 |
|  | 业务类型（BWMSERVICETYPE） | TOS | 本端规划 | 基于TOS场景，使用样例值。 |
|  | Tos配置类型（TOSCFGTYPE） | TOS\_VALUE | 本端规划 | - |
|  | 服务类型(TOSVALUE) | 0 | 本端规划 | TOS类型业务的类别名称与类别值的对应关系是：BE（0），AF1（1），AF2（2），AF3（3），AF4（4）， EF（5），CS6（6），CS7（7）。 |

**表2** 带宽管理的用户范围及流量整形参数规划数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD BWMUSERGROUP** | 用户组类型（USERGROUPTYPE） | SPECIFIC\_GROUP | 本端规划 | - |
|  | 用户组名称（USERGROUPNAME） | usergroup\_test | 本端规划 | - |
|  | 用户组优先级（USERGROUPPRI） | 2 | 本端规划 | - |
|  | 用户级业务类型（USERLEVSRVTYPE） | TOS | 本端规划 | 基于TOS场景，使用样例值。 |
| **ADD APNBINDBWMUSRG** | 用户组名称（USERGROUPNAME） | usergroup\_test | 已配置数据中获取 | 使用**ADD BWMUSERGROUP**命令定义的用户组名称。 |
|  | APN（APN） | huawei.com | 已配置数据中获取 | 使用**ADD APN**命令定义的APN名称。 |
| **ADD BWMCONTROLLER** | 带宽管理控制器名称（BWMCNAME） | bwmc\_test | 本端规划 | - |
|  | 带宽管理控制类型（CTRLTYPE） | SHAPING | 固定取值 | - |
|  | 速率（千比特每秒）（RATE） | 50 | 本端规划 | 流量整形速率阈值。对于超过该速率的报文，进行流量整形，保证发送速率稳定。 |
|  | 队列深度（报文数）（QUEDEPTH） | 256 | 本端规划 | - |
|  | 最大五元组数（MAXFDNUM） | 2000 | 本端规划 | - |
| **ADD BWMRULE** | 用户组类型（USERGROUPTYPE） | SPECIFIC\_GROUP | 本端规划 | - |
|  | 用户组名称（USERGROUPNAME） | usergroup\_test | 已配置数据中获取 | 使用**ADD BWMUSERGROUP**命令定义的用户组名称。 |
|  | 带宽管理规则类型（BWMRULETYPE） | SUBSCRIBER\_SPECIFIC | 本端规划 | - |
|  | 带宽管理规则名称（BWMRULENAME） | bwmrule\_test | 本端规划 | 该参数在“BWMRULETYPE”配置为“GROUP\_SPECIFIC”、“SUBSCRIBER\_SPECIFIC”时生效。 |
|  | 带宽控制业务名称（BWMSERVICENAME） | bwmservice\_test | 本端规划 | 该参数在“BWMRULETYPE”配置为“GROUP\_SPECIFIC”、“SUBSCRIBER\_SPECIFIC”时生效。 |
|  | 上行带宽管理控制器名称一（UPBWMCTRLNAME1） | bwmc\_test | 已配置数据中获取 | 使用**ADD BWMCONTROLLER**命令定义的带宽管理控制器名称。 |
|  | 下行带宽管理控制器名称一（DNBWMCTRLNAME1） | bwmc\_test | 已配置数据中获取 | 使用**ADD BWMCONTROLLER**命令定义的带宽管理控制器名称。 |
|  | 带宽管理规则优先级（BWMRULEPRI） | 1 | 本端规划 | 同一个用户级、或用户组级下的带宽管理规则优先级不能相同。 |

## 操作步骤

1. 打开本特性的License配置开关。

   **SET LICENSESWITCH**:LICITEM="LKV3G5SBTS01",SWITCH=ENABLE;
2. 配置流过滤器。

   **ADD FLOWFILTER**
3. 使用源IP/Port、目的IP/Port、四层协议类型作为过滤条件时，配置三四层过滤规则。
   1. 配置三四层过滤条件。

      **ADD FILTER**
   2. 配置三四层过滤条件与流过滤器的绑定关系。

      **ADD FLTBINDFLOWF**
   3. 将新配置的Filter置为生效。

      **SET REFRESHSRV**
4. 配置PCC策略组。

   **ADD PCCPOLICYGRP**
5. 配置规则。

   **ADD RULE**

   若需配置多个规则，则需要多次执行步骤 5。
6. 配置BWM使用的UserProfile（规则与用户模板的绑定关系） 。
   1. 创建UserProfile。

      **ADD USERPROFILE**
   2. 将已配置的rule绑定到UserProfile。

      **ADD RULEBINDING**
7. 配置BWM业务。
   1. 增加带宽管理用户组。

      **ADD BWMUSERGROUP**
   2. 配置带宽管理的业务范围。

      **ADD BWMSERVICE**
   3. 绑定带宽管理用户组BwmUserGroup到指定APN下。

      **ADD APNBINDBWMUSRG**
   4. 配置BWM控制器。

      **ADD BWMCONTROLLER**
8. 配置带宽管理规则。

   **ADD BWMRULE**

## 任务示例

任务描述

UDG对一个用户组下的各个用户的指定IP TOS等级的上行、下行用户面数据流量进行流量整形。

脚本

//打开本特性的License配置开关。

```
SET LICENSESWITCH:LICITEM="LKV3G5SBTS01",SWITCH=ENABLE;
```

//配置带宽管理的业务范围。

```
ADD BWMSERVICE:BWMSERVICENAME="bwmservice_test",BWMSERVICETYPE=TOS,TOSCFGTYPE=TOS_VALUE,TOSVALUE=0;
```

//配置带宽管理的用户范围及流量整形参数。

```
ADD BWMUSERGROUP:USERGROUPTYPE=SPECIFIC_GROUP,USERGROUPNAME="usergroup_test",USERGROUPPRI=2,USERLEVSRVTYPE=TOS;
```

```
ADD APNBINDBWMUSRG:USERGROUPNAME="usergroup_test",APN="huawei.com";
```

```
ADD BWMCONTROLLER:BWMCNAME="bwmc_test",CTRLTYPE=SHAPING,RATE=50,QUEDEPTH=256,MAXFDNUM=2000;
```

//配置带宽管理规则。

```
ADD BWMRULE:USERGROUPTYPE=SPECIFIC_GROUP,USERGROUPNAME="usergroup_test",BWMRULETYPE=SUBSCRIBER_SPECIFIC,BWMRULENAME="bwmrule_test",BWMSERVICENAME="bwmservice_test",UPBWMCTRLNAME1="bwmc_test",DNBWMCTRLNAME1="bwmc_test",BWMRULEPRI=1;
```

版权所有 © 华为技术有限公司
