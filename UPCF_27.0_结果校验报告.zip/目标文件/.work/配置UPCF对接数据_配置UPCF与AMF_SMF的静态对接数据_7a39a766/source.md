# 配置UPCF与AMF/SMF的静态对接数据

* 操作场景
* 必备事项
* 操作步骤
* 验证方法

## 操作场景

UPCF需支持通过HTTP协议与AMF（Access and Mobility Management Function）/SMF（Session Management Function）进行交互，在PDU（Packet Data Unit）会话建立或者事件触发时，UPCF能够根据AMF/SMF上报的信息和用户在PCF侧的签约数据进行策略判断，将生成的规则下发给AMF/SMF，为终端用户选择合适的接入方式并进行策略控制。

当UPCF与AMF/SMF直接对接时：

* 如果UPCF对接NRF，即动态对接场景，具体对接配置请参考配置UPCF与NRF的对接数据。**此场景为商用对接方式。**
* 如果UPCF不对接NRF，即静态对接场景，具体对接配置请参考本章节。AMF和SMF对接配置相似，本章节以SMF为例进行配置举例。**此场景仅在测试局下使用。**

当UPCF与AMF/SMF通过SCP间接通信时，具体对接配置请参考配置UPCF与SCP的对接数据。

## 必备事项

前提条件

* 已完成软件安装。
* UPCF侧已完成基础数据配置。
* AMF/SMF侧已完成基础数据配置。
* 已经获得运营商规划的UPCF与AMF/SMF的对接IP地址。

数据

配置前规划的对接数据如表1所示。

**表1** 对接数据规划

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **ADD HLBTLSCFG** | TLSCFGID（TLS配置ID） | 1 | 本端规划。 |
|  | TLSCFGNAME（TLS配置名称） | TLSV1 | 本端规划。 |
|  | PROTOCOLVER（协议版本） | TLS1\_2 | 本端规划。 |
|  | STRONGSUITE（TLS加密套件） | TLS\_DHE\_RSA\_WITH\_AES\_128\_GCM\_SHA256-1 | 本端规划。 |
| **ADD HLBDEVADDR** | DEVAID （设备地址标识） | 2 | 本端规划，取值范围内不允许重复。 |
|  | VPNNAME（VPN名称） | HLB\_VPN | 本端规划，该参数需要与VNRS的**ADD L3VPNINST**和**ADD VPNINSTAF**命令中“VPN实例名称”参数值保持一致。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，根据测试场景来定。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | IP （IPV4地址） | 10.100.100.191 | 全网规划。 |
|  | HTTPSFUNC（HTTPS功能） | ON | 本端规划，根据测试场景来定。  说明：  * 只有在需要测试HTTPS的场景才需要设置为ON，否则的话设置成OFF即可，HTTPS还需要准备配套的TLS证书。 * 当前HTTP端口号默认为8080，HTTPS端口号默认为443。 |
|  | CERTSCENE（证书应用场景） | UPCF\_HLB\_Lcert | 本端规划，仅当“HTTPS功能”配置为“ON(打开)”时该参数可配置且必须配置。 |
|  | TLSCFGID（TLS配置ID） | 1 | 该参数必须先由**ADD HLBTLSCFG**命令定义，然后才能在此处索引。仅当“HTTPS功能”配置为“ON(打开)”时该参数可配置且必须配置，配置值需要与对端协商一致。 |
|  | DESCRIPTION（描述） | HLB\_IPV4 | 本端规划，长度不超过32位的字符串。 |
|  | DSCP（DSCP优先级） | 46 | 本端规划。   * DSCP优先级有64级，为0～63，级别为63时，优先级最高。 * 255表示不设置DSCP。 |
| **SET HTTPCLIENTCFG** | LINKCTLMODE（链路管理模式） | OLD | 本端规划，静态对接场景下固定配置。 |
| **ADD HLBPEER** | PEERID（对端标识） | 0 | 全网规划。 |
|  | NAME（名称） | SMF\_0 | 全网规划。 |
|  | TYPE（对端类型） | SMF | 全网规划。 |
|  | HTTPSFUNC（HTTPS功能） | ON | 本端规划，根据测试场景来定。  说明：  只有在需要测试HTTPS的场景才需要设置为ON，否则的话设置成OFF即可，HTTPS还需要准备配套的TLS证书。 |
|  | CERTSCENE（证书应用场景） | UPCF\_HLB\_Lcert | 本端规划，仅当“HTTPS功能”配置为“ON(打开)”时该参数可配置且必须配置。 |
|  | TLSCFGID（TLS配置ID） | 1 | 该参数必须先由**ADD HLBTLSCFG**命令定义，然后才能在此处索引。仅当“HTTPS功能”配置为“ON(打开)”时该参数可配置且必须配置，配置值需要与对端协商一致。 |
|  | SIGROUTE（信令路由） | OFF | 保持默认值。 |
| **ADD HLBPEERL** | PEERID（对端标识） | 0 | 全网规划。 |
|  | LINKID（链路标识） | 0 | 全网规划。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，根据测试场景来定。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | LOCALIP（本端IPV4地址） | 10.100.100.191 | 本端规划。 |
|  | PEERIP（对端IPV4地址） | 10.0.5.36 | 全网规划。 |
|  | PEERPORT（对端端口号） | 10501 | 全网规划。 |

## 操作步骤

1. 登录“UPCF MML命令”界面。
2. UPCF是否作为客户端与SMF进行静态对接。

   * 是 => 3
   * 否 => 6
3. 执行**LST HLBDEVADDR**命令，查询HLB服务配置的所有设备地址标识。

   ```
   LST HLBDEVADDR:;
   ```

   报文示例如下：

   ```
   %%LST HLBDEVADDR:;%%
   RETCODE = 0  操作成功

   操作结果如下
   ------------
   设备地址标识  =  1
        VPN名称  =  VPN1
         IP版本  =  IPV4
       IPV4地址  =  10.168.0.130
       IPV6地址  =  NULL
      HTTPS功能  =  ON
   证书应用场景  =  UPCF_HLB_Lcert
      TLS配置ID  =  2
           描述  =  NULL
     DSCP优先级  =  46
   (结果个数 = 1)

   ---    END
   ```
4. 执行**ADD HLBTLSCFG**命令，增加HLB TLS配置信息。

   ```
   ADD HLBTLSCFG: TLSCFGID=1, TLSCFGNAME="TLSV1", PROTOCOLVER=TLS1_2, STRONGSUITE=TLS_DHE_RSA_WITH_AES_128_GCM_SHA256-1;
   ```
5. 执行**ADD HLBDEVADDR**命令，增加HLB服务用于与AMF/SMF对接的本端IP地址。

   ```
   ADD HLBDEVADDR: DEVAID=4, VPNNAME="HLB_VPN", IPVER=IPV4, IP="10.100.100.191", HTTPSFUNC=ON, CERTSCENE=UPCF_HLB_Lcert, TLSCFGID=1, DESCRIPTION="HLB_IPV4", TOEDGE=NO;
   ```
6. （仅UPCF作为客户端操作）执行****SET HTTPCLIENTCFG****命令，设置HTTP客户端链路由HLB管理。

   该命令用于设置HTTP客户端配置信息，当UPCF与AMF/SMF静态对接时，务必将“链路管理模式”配置为“OLD(旧模式)”，确保HTTP客户端链路由HLB管理。

   ```
   SET HTTPCLIENTCFG: LINKCTLMODE=OLD;
   ```
7. （仅UPCF作为客户端操作）执行**LST PEERNF**命令，查询对端SMF的信息。

   ```
   LST PEERNF: NFTYPE=SMF;
   ```

   报文示例如下：

   ```
   %%LST PEERNF: NFTYPE=SMF;%%
   RETCODE = 0  操作成功

   操作结果如下
   ------------
         NF标识  =  NA
         NF类型  =  SMF
       对端标识  =  0
       NF优先级  =  1
       协议类型  =  HTTPS
         IP地址  =  10.0.5.36
         端口号  =  10501
           状态  =  在线
       故障时间  =  0
   (结果个数 = 1)

   ---    END
   ```
8. （仅UPCF作为客户端操作）执行**ADD HLBPEER**命令，增加HLB服务用于与SMF建立对接数据。

   ```
   ADD HLBPEER: PEERID=0, NAME="SMF_0", TYPE=SMF, HTTPSFUNC=ON, CERTSCENE=UPCF_HLB_Lcert, TLSCFGID=1, SIGROUTE=OFF;
   ```
9. （仅UPCF作为客户端操作）执行**ADD HLBPEERL**命令，增加HLB服务用于与SMF建立链路数据。

   ```
   ADD HLBPEERL: PEERID=0, LINKID=0, IPVER=IPV4, LOCALIP="10.100.100.191", PEERIP="10.0.5.36", PEERPORT=10501;
   ```

## 验证方法

检查UPCF-AMF/SMF链路。

1. 登录“UPCF MML命令”界面。
2. AMF/SMF本局配置对端UPCF IP地址信息后，是否发起建链请求。
   * 是 => 3
   * 否 => 6
3. 执行**DSP HLBPEERL**命令：参数“对端标识”和“链路标识”与规划数据一致。检查“链路状态”参数项的返回结果。

   * 在线 => UPCF-AMF/SMF链路正常，UPCF-AMF/SMF设备对接调测结束。
   * 离线 => 4
4. 登录OM Portal界面，选择“监控分析 > 告警管理”，查看系统是否有上报“34163 PCF与NF之间的HTTP链路故障”告警。
   * 是 => 根据告警帮助进行处理。
   * 否 => 6
5. 参考用户消息跟踪章节，收集N15/N7消息，查看是否可查看到Npcf\_AMPolicyControl\_Create Response/Npcf\_SMPolicyControl\_Create Response响应成功的消息。
   * 是 => UPCF-AMF/SMF链路正常，UPCF-AMF/SMF设备对接调测结束。
   * 否 => 6
6. 请联系华为技术支持处理。

版权所有 © 华为技术有限公司
