---
id: ''
name: 配置UPCF与AMF/SMF的静态对接数据
ne_type: UPCF
type: feature
description: UPCF需支持通过HTTP协议与AMF（Access and Mobility Management Function）/SMF（Session Management Function）进行交互，在PDU（Packet Data Unit）会话建立或者事件触发时，UPCF能够根据AMF/SMF上报的信息和用户在PCF侧的签约数据进行策略判断，将生成的规则下发给AMF/SMF，为终端用户选择合适的接入方式并进行策略控制。  当UPCF与AMF/SMF直接对接时：  * 如果UPCF对接NRF，即动态对接场景，具体对接配置请参考配置UPCF与NRF的对接数据。**此场景为商用对接方式。** * 如果UPCF不对接NRF，即静态对接场景，具体对接配置请参考本章节。AMF和SMF对接配置相似，本章节以SMF为例进行配置举例。**此场景仅在测试局下使用。**  当UPCF与AMF/SMF通过SCP间接通信时，具体对接配置请参考配置UPCF与SCP的对接数据。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（非SDN）","配置UPCF对接数据","配置UPCF与AMF/SMF的静态对接数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UPCF需支持通过HTTP协议与AMF（Access and Mobility Management Function）/SMF（Session Management Function）进行交互，在PDU（Packet Data Unit）会话建立或者事件触发时，UPCF能够根据AMF/SMF上报的信息和用户在PCF侧的签约数据进行策略判断，将生成的规则下发给AMF/SMF，为终端用户选择合适的接入方式并进行策略控制。当UPCF与AMF/SMF直接对接时：* 如果UPCF对接NRF，即动态对接场景，具体对接配置请参考配置UPCF与NRF的对接数据。**此场景为商用对接方式。*** 如果UPCF不对接NRF，即静态对接场景，具体对接配置请参考本章节。AMF和SMF对接配置相似，本章节以SMF为例进行配置举例。**此场景仅在测试局下使用。**当UPCF与AMF/SMF通过SCP间接通信时，具体对接配置请参考配置UPCF与SCP的对接数据。

## 必备事项
前提条件

* 已完成软件安装。
* UPCF侧已完成基础数据配置。
* AMF/SMF侧已完成基础数据配置。
* 已经获得运营商规划的UPCF与AMF/SMF的对接IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_hlbtlscfg_list:
      type: items
      properties:
        TLSCFGID:
          name: 'TLS配置ID'
          type: integer
          minimum: 1
          maximum: 128
          required: true
          description: '本端规划。'
          data_source: ''
          pattern: ''
          default: ''
        TLSCFGNAME:
          name: 'TLS配置名称'
          type: string
          minLength: 0
          maxLength: 32
          required: true
          description: '本端规划。'
          data_source: ''
          pattern: ''
          default: ''
        PROTOCOLVER:
          name: '协议版本'
          type: string
          enum:
          - TLS1_2
          - TLS1_3
          - TLS1_2+TLS1_3
          required: true
          description: '本端规划。'
          data_source: ''
          pattern: ''
          default: ''
        STRONGSUITE:
          name: 'TLS加密套件'
          type: string
          enum:
          - TLS_DHE_RSA_WITH_AES_128_GCM_SHA256
          - TLS_DHE_RSA_WITH_AES_256_GCM_SHA384
          - TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256
          - TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384
          - TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256
          - TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
          required: false
          description: '本端规划。'
          data_source: ''
          pattern: ''
          default: ''
        STRONGSUITE1_3:
          name: 'TLS1.3加密套件'
          type: string
          enum:
          - TLS_AES_128_GCM_SHA256
          - TLS_AES_256_GCM_SHA384
          - TLS_CHACHA20_POLY1305_SHA256
          - TLS_AES_128_CCM_SHA256
          - TLS_AES_128_CCM_8_SHA256
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_hlbdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 32
          required: true
          description: '本端规划，该参数需要与VNRS的**ADD L3VPNINST**和**ADD VPNINSTAF**命令中“VPN实例名称”参数值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，根据测试场景来定。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划。'
          data_source: ''
          pattern: ''
          default: ''
        HTTPSFUNC:
          name: 'HTTPS功能'
          type: string
          enum:
          - ON
          - OFF
          required: false
          description: '本端规划，根据测试场景来定。  说明：  * 只有在需要测试HTTPS的场景才需要设置为ON，否则的话设置成OFF即可，HTTPS还需要准备配套的TLS证书。 * 当前HTTP端口号默认为8080，HTTPS端口号默认为443。'
          data_source: ''
          pattern: ''
          default: ON
        CERTSCENE:
          name: '证书应用场景'
          type: string
          enum:
          - UPCF_HLB_Lcert
          required: false
          description: '本端规划，仅当“HTTPS功能”配置为“ON(打开)”时该参数可配置且必须配置。'
          data_source: ''
          pattern: ''
          default: ''
        TLSCFGID:
          name: 'TLS配置ID'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: '该参数必须先由**ADD HLBTLSCFG**命令定义，然后才能在此处索引。仅当“HTTPS功能”配置为“ON(打开)”时该参数可配置且必须配置，配置值需要与对端协商一致。'
          data_source: ''
          pattern: ''
          default: ''
        DESCRIPTION:
          name: '描述'
          type: string
          minLength: 0
          maxLength: 32
          required: false
          description: '本端规划，长度不超过32位的字符串。'
          data_source: ''
          pattern: ''
          default: ''
        TOEDGE:
          name: '对接边缘'
          type: string
          enum:
          - NO
          - YES
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: NO
        DSCP:
          name: 'DSCP优先级'
          type: integer
          minimum:
          - 0
          - 255
          maximum:
          - 63
          - 255
          required: false
          description: '本端规划。   * DSCP优先级有64级，为0～63，级别为63时，优先级最高。 * 255表示不设置DSCP。'
          data_source: ''
          pattern: ''
          default: 46
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_upcf_as_client:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '（仅UPCF作为客户端操作）执行****SET HTTPCLIENTCFG****命令，设置HTTP客户端链路由HLB管理。'
      data_source: ''
      pattern: ''
      default: TRUE
    set_httpclientcfg_list:
      type: items
      properties:
        LINKCTLMODE:
          name: '链路管理模式'
          type: string
          enum:
          - OLD
          - NEW
          required: false
          description: '本端规划，静态对接场景下固定配置。'
          data_source: ''
          pattern: ''
          default: NEW
        LINKALMFILTER:
          name: '链路告警过滤方式'
          type: string
          enum:
          - DISABLE
          - WHITELIST
          - BLACKLIST
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        NRFLINKPING:
          name: 'NRF链路探测'
          type: string
          enum:
          - NO
          - YES
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SYNCLINKTIME:
          name: '链路状态同步时长'
          type: integer
          minimum:
          - 0
          - 30
          maximum:
          - 0
          - 3600
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_hlbpeer_list:
      type: items
      properties:
        PEERID:
          name: '对端标识'
          type: integer
          minimum: 0
          maximum: 63
          required: true
          description: '全网规划。'
          data_source: ''
          pattern: ''
          default: ''
        NAME:
          name: '名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '全网规划。'
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: '对端类型'
          type: string
          enum:
          - NRF
          - AMF
          - SMF
          - BSF
          - CHF
          required: true
          description: '全网规划。'
          data_source: ''
          pattern: ''
          default: ''
        HTTPSFUNC:
          name: 'HTTPS功能'
          type: string
          enum:
          - ON
          - OFF
          required: false
          description: '本端规划，根据测试场景来定。  说明：  只有在需要测试HTTPS的场景才需要设置为ON，否则的话设置成OFF即可，HTTPS还需要准备配套的TLS证书。'
          data_source: ''
          pattern: ''
          default: ON
        CERTSCENE:
          name: '证书应用场景'
          type: string
          enum:
          - UPCF_HLB_Lcert
          required: false
          description: '本端规划，仅当“HTTPS功能”配置为“ON(打开)”时该参数可配置且必须配置。'
          data_source: ''
          pattern: ''
          default: ''
        TLSCFGID:
          name: 'TLS配置ID'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: '该参数必须先由**ADD HLBTLSCFG**命令定义，然后才能在此处索引。仅当“HTTPS功能”配置为“ON(打开)”时该参数可配置且必须配置，配置值需要与对端协商一致。'
          data_source: ''
          pattern: ''
          default: ''
        SIGROUTE:
          name: '信令路由'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: '保持默认值。'
          data_source: ''
          pattern: ''
          default: OFF
        LINKMODE:
          name: '链路模式'
          type: string
          enum:
          - WEIGHT
          - PRIORITY
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LINKNUM:
          name: '链路数'
          type: integer
          minimum: 2
          maximum: 4
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        STREAMNUM:
          name: '最大流数目'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_hlbpeerl_list:
      type: items
      properties:
        PEERID:
          name: '对端标识'
          type: integer
          minimum: 0
          maximum: 63
          required: true
          description: '全网规划。'
          data_source: ''
          pattern: ''
          default: ''
        LINKID:
          name: '链路标识'
          type: integer
          minimum: 0
          maximum: 0
          required: true
          description: '全网规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，根据测试场景来定。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        LOCALIP:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '本端规划。'
          data_source: ''
          pattern: ''
          default: ''
        PEERIP:
          name: '对端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划。'
          data_source: ''
          pattern: ''
          default: ''
        PEERPORT:
          name: '对端端口号'
          type: integer
          minimum: 1
          maximum: 65535
          required: true
          description: '全网规划。'
          data_source: ''
          pattern: ''
          default: ''
        LOCALIPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PEERIPV6:
          name: '对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_hlbtlscfg_list:
    - TLSCFGID: 1
      TLSCFGNAME: 'TLSV1'
      PROTOCOLVER: TLS1_2
      STRONGSUITE: TLS_DHE_RSA_WITH_AES_128_GCM_SHA256-1
      STRONGSUITE1_3: ''
    add_hlbdevaddr_list:
    - DEVAID: 4
      VPNNAME: 'HLB_VPN'
      IPVER: IPV4
      IP: '10.100.100.191'
      HTTPSFUNC: ON
      CERTSCENE: UPCF_HLB_Lcert
      TLSCFGID: 1
      DESCRIPTION: 'HLB_IPV4'
      TOEDGE: NO
      DSCP: 46
      IPV6: ''
    is_scenario_upcf_as_client: TRUE
    set_httpclientcfg_list:
    - LINKCTLMODE: OLD
      LINKALMFILTER: ''
      NRFLINKPING: ''
      SYNCLINKTIME: ''
    add_hlbpeer_list:
    - PEERID: 0
      NAME: 'SMF_0'
      TYPE: SMF
      HTTPSFUNC: ON
      CERTSCENE: UPCF_HLB_Lcert
      TLSCFGID: 1
      SIGROUTE: OFF
      LINKMODE: ''
      LINKNUM: ''
      STREAMNUM: ''
    add_hlbpeerl_list:
    - PEERID: 0
      LINKID: 0
      IPVER: IPV4
      LOCALIP: '10.100.100.191'
      PEERIP: '10.0.5.36'
      PEERPORT: 10501
      LOCALIPV6: ''
      PEERIPV6: ''
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录“UPCF MML命令”界面。

### 2 UPCF是否作为客户端与SMF进行静态对接。

#### 2.1 是 => 3

#### 2.2 否 => 6

### 3 执行**LST HLBDEVADDR**命令，查询HLB服务配置的所有设备地址标识。

### 报文示例如下：

### %%LST HLBDEVADDR:;%%

### RETCODE = 0  操作成功

### 操作结果如下

### ------------

### 设备地址标识  =  1

### VPN名称  =  VPN1

### IP版本  =  IPV4

### IPV4地址  =  10.168.0.130

### IPV6地址  =  NULL

### HTTPS功能  =  ON

### 证书应用场景  =  UPCF_HLB_Lcert

### TLS配置ID  =  2

### 描述  =  NULL

### DSCP优先级  =  46

### (结果个数 = 1)

### ---    END

### 4 执行**ADD HLBTLSCFG**命令，增加HLB TLS配置信息。

```jinja2
{%- for item in add_hlbtlscfg_list -%}
    ADD HLBTLSCFG:
    {#- --- 必选参数 --- -#}
    TLSCFGID={{item.TLSCFGID}},
    TLSCFGNAME="{{item.TLSCFGNAME}}",
    PROTOCOLVER={{item.PROTOCOLVER}},
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：PROTOCOLVER=TLS1_2/TLS1_2+TLS1_3 时可选 --- -#}
    {%- if item.PROTOCOLVER in ['TLS1_2', 'TLS1_2+TLS1_3'] -%}
        {%- if item.STRONGSUITE is not none -%}
            STRONGSUITE={{item.STRONGSUITE}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：PROTOCOLVER=TLS1_3/TLS1_2+TLS1_3 时可选 --- -#}
    {%- if item.PROTOCOLVER in ['TLS1_3', 'TLS1_2+TLS1_3'] -%}
        {%- if item.STRONGSUITE1_3 is not none -%}
            STRONGSUITE1_3={{item.STRONGSUITE1_3}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 5 执行**ADD HLBDEVADDR**命令，增加HLB服务用于与AMF/SMF对接的本端IP地址。

```jinja2
{%- for item in add_hlbdevaddr_list -%}
    ADD HLBDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNNAME="{{item.VPNNAME}}",
    IPVER={{item.IPVER}},
    {#- --- 可选参数 --- -#}
    {%- if item.HTTPSFUNC is not none -%}
        HTTPSFUNC={{item.HTTPSFUNC}},
    {%- endif -%}
    {%- if item.DESCRIPTION is not none -%}
        DESCRIPTION="{{item.DESCRIPTION}}",
    {%- endif -%}
    {%- if item.TOEDGE is not none -%}
        TOEDGE={{item.TOEDGE}},
    {%- endif -%}
    {%- if item.DSCP is not none -%}
        DSCP={{item.DSCP}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：HTTPSFUNC=ON 时必选 --- -#}
    {%- if item.HTTPSFUNC == 'ON' -%}
        CERTSCENE={{item.CERTSCENE}},
    {%- endif -%}
    {#- --- 条件必选：HTTPSFUNC=ON 时必选 --- -#}
    {%- if item.HTTPSFUNC == 'ON' -%}
        TLSCFGID={{item.TLSCFGID}},
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 6 （仅UPCF作为客户端操作）执行****SET HTTPCLIENTCFG****命令，设置HTTP客户端链路由HLB管理。

### 该命令用于设置HTTP客户端配置信息，当UPCF与AMF/SMF静态对接时，务必将“链路管理模式”配置为“OLD(旧模式)”，确保HTTP客户端链路由HLB管理。

```jinja2
{%- if is_scenario_upcf_as_client -%}
    {%- for item in set_httpclientcfg_list -%}
        SET HTTPCLIENTCFG:
        {#- --- 可选参数 --- -#}
        {%- if item.LINKCTLMODE is not none -%}
            LINKCTLMODE={{item.LINKCTLMODE}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：LINKCTLMODE=NEW 时可选 --- -#}
        {%- if item.LINKCTLMODE == 'NEW' -%}
            {%- if item.LINKALMFILTER is not none -%}
                LINKALMFILTER={{item.LINKALMFILTER}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：LINKCTLMODE=NEW 时可选 --- -#}
        {%- if item.LINKCTLMODE == 'NEW' -%}
            {%- if item.NRFLINKPING is not none -%}
                NRFLINKPING={{item.NRFLINKPING}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：LINKCTLMODE=NEW 时可选 --- -#}
        {%- if item.LINKCTLMODE == 'NEW' -%}
            {%- if item.SYNCLINKTIME is not none -%}
                SYNCLINKTIME={{item.SYNCLINKTIME}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 7 （仅UPCF作为客户端操作）执行**LST PEERNF**命令，查询对端SMF的信息。

### 报文示例如下：

### %%LST PEERNF: NFTYPE=SMF;%%

### RETCODE = 0  操作成功

### 操作结果如下

### ------------

### NF标识  =  NA

### NF类型  =  SMF

### 对端标识  =  0

### NF优先级  =  1

### 协议类型  =  HTTPS

### IP地址  =  10.0.5.36

### 端口号  =  10501

### 状态  =  在线

### 故障时间  =  0

### (结果个数 = 1)

### ---    END

### 8 （仅UPCF作为客户端操作）执行**ADD HLBPEER**命令，增加HLB服务用于与SMF建立对接数据。

```jinja2
{%- if is_scenario_upcf_as_client -%}
    {%- for item in add_hlbpeer_list -%}
        ADD HLBPEER:
        {#- --- 必选参数 --- -#}
        PEERID={{item.PEERID}},
        TYPE={{item.TYPE}},
        {#- --- 可选参数 --- -#}
        {%- if item.NAME is not none -%}
            NAME="{{item.NAME}}",
        {%- endif -%}
        {%- if item.HTTPSFUNC is not none -%}
            HTTPSFUNC={{item.HTTPSFUNC}},
        {%- endif -%}
        {%- if item.SIGROUTE is not none -%}
            SIGROUTE={{item.SIGROUTE}},
        {%- endif -%}
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：HTTPSFUNC=ON 时必选 --- -#}
        {%- if item.HTTPSFUNC == 'ON' -%}
            CERTSCENE={{item.CERTSCENE}},
        {%- endif -%}
        {#- --- 条件必选：HTTPSFUNC=ON 时必选 --- -#}
        {%- if item.HTTPSFUNC == 'ON' -%}
            TLSCFGID={{item.TLSCFGID}},
        {%- endif -%}
        {#- --- 条件必选：SIGROUTE=ON 时必选 --- -#}
        {%- if item.SIGROUTE == 'ON' -%}
            LINKMODE={{item.LINKMODE}},
        {%- endif -%}
        {#- --- 条件必选：SIGROUTE=ON 时必选 --- -#}
        {%- if item.SIGROUTE == 'ON' -%}
            LINKNUM={{item.LINKNUM}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：SIGROUTE=ON 时可选 --- -#}
        {%- if item.SIGROUTE == 'ON' -%}
            {%- if item.STREAMNUM is not none -%}
                STREAMNUM="{{item.STREAMNUM}}",
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 9 （仅UPCF作为客户端操作）执行**ADD HLBPEERL**命令，增加HLB服务用于与SMF建立链路数据。

```jinja2
{%- if is_scenario_upcf_as_client -%}
    {%- for item in add_hlbpeerl_list -%}
        ADD HLBPEERL:
        {#- --- 必选参数 --- -#}
        PEERID={{item.PEERID}},
        LINKID={{item.LINKID}},
        IPVER={{item.IPVER}},
        PEERPORT={{item.PEERPORT}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            LOCALIP="{{item.LOCALIP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            PEERIP="{{item.PEERIP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            LOCALIPV6="{{item.LOCALIPV6}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            PEERIPV6="{{item.PEERIPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

