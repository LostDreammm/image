---
id: ''
name: 配置UPCF与OCS（基于Diameter协议）的对接数据
ne_type: UPCF
type: feature
description: 当UPCF需要通过Sy接口从OCS（Online Charging System）获取配额状态信息进行统计时，UPCF需要对接OCS，从OCS上获取配额状态完成PCC（Policy and Charging Control）策略控制功能。  当UPCF通过DRA与OCS对接，参考配置UPCF与DRA的对接数据。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（SDN）","配置UPCF对接数据","配置UPCF与OCS（基于Diameter协议）的对接数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当UPCF需要通过Sy接口从OCS（Online Charging System）获取配额状态信息进行统计时，UPCF需要对接OCS，从OCS上获取配额状态完成PCC（Policy and Charging Control）策略控制功能。当UPCF通过DRA与OCS对接，参考配置UPCF与DRA的对接数据。

## 必备事项
前提条件

* 已完成软件安装。
* 已完成基础数据配置。
* OCS侧已完成基础数据配置。
* UPCF与OCS的网络连接正常。
* 已经获得运营商规划的UPCF与OCS的对接IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    mod_insp_list:
      type: items
      properties:
        INSPN:
          name: '参数名'
          type: string
          enum:
          - VRM_MAXIPCANSESNUMPERSPU
          - VRM_MAXAFSESNUMPERSPU
          - VRM_MAXSUBNUMPERSPU
          - VRM_UPGRADE
          - VRM_MAXRATBEARIDPERSES
          - VRM_SRVNUMPERUSR
          - VRM_MAXPAFNUM
          - VRM_MAXPCEFNUM
          - VRM_MAXRADIUSSRVNUM
          - VRM_MAXCONNECTIONPERPAF
          - VRM_MAXCONNECTIONPERPCEF
          - VRM_MAXLINKRADIUSSRV
          - VRM_SUBSRCIPTIONIDTYPE
          - VRM_GLBREFLASHINTERVAL
          - VRM_NOTIFYMSGMAXRECORDPERSUB
          - VRM_NOTIFYMSGMAXDAYPERSUB
          - VRM_REVALIDATIONTIMEMETHOD
          - VRM_NOSUBSCRIPTIONERRORCODE
          - VRM_NOTIFYMSGMAXWAITEDRECORDS
          - VRM_PRINTLOCALLOG
          - VRM_USRREVALIHRANGE
          - VRM_ONLINECHECK
          - VRM_TIMEZONEENHANCE
          - VRM_GXIMEIFORMAT
          - VRM_NOTIFYMSGMAXRECORDPERDSU
          - VRM_CLEARALLDYNCREATEDUSER
          - VRM_PEELDOMAINSWITCH
          - VRM_NOTIFYRCVER
          - VRM_FIRSTDAYOFWEEK
          - VRM_UPDATESPRSUBACTIVE
          - VRM_SUBCTRLRESULT
          - VRM_SPRSUBMAXOFFLINEDAYS
          - VRM_CHECKSUBSCRIBEDSERVICE
          - VRM_SUBACTCTRL
          - VRM_SESSIONCHECKINTERVAL
          - VRM_CHKSUBSRVSYTYPE
          - VRM_RARSENDSPEED
          - VRM_DIAREDIRECTSWITCH
          - VRM_PERIODVALUE
          - VRM_PROTECTTIMER
          - VRM_SENDUSERNUM
          - VRM_POLICYCASESENSITIVE
          - VRM_SESSIONRESTORATION
          - VRM_RXRPMAPRELATION
          - VRM_NOTIFYUSAGEUNITCONVERT
          - VRM_TIMEACCUMODE
          - VRM_SYSWITCH
          - VRM_PLMNMATCHPRIORITY
          - VRM_RESETNOTIFYRPT
          - VRM_REPORTINGLEVEL
          - VRM_RATINGGROUP
          - VRM_SERVICEIDENTIFIER
          - VRM_DFTCHARGINGPARA
          - VRM_LOGPRINTPERIOD
          - VRM_MAXBBERFNUM
          - VRM_MAXCONNECTIONPERBBERF
          - VRM_SPNOTIFYDOMAIN
          - VRM_EXSPRNOTIFICATION
          - VRM_SESSIONBACKUPSWITCH
          - VRM_DIAMHBINTERVAL
          - VRM_DIAMHBTIMES
          - VRM_EDRACCESSFORMATE
          - VRM_IPCANTERMSWITCH
          - VRM_DELBEAROPTION
          - VRM_LDAPREVBUFFERSIZE
          - VRM_NOTIFYOPTIMIZE
          - VRM_RESULTCODESWITCH
          - VRM_FMTIPADDR
          - VRM_GROUPDIAREDIRECTSWITCH
          - VRM_RMVSUBWITHOUTRAR
          - VRM_GRPMBRUSAGECACHE1
          - VRM_GRPMBRUSAGECACHE2
          - VRM_DYNRULEFORMAT
          - VRM_IPV6HASHLENGTH
          - VRM_DURATIONMKMATCH
          - VRM_SNRRECSPEED
          - VRM_DIAMTIMETHRD
          - VRM_LDAPTIMETHRD
          - VRM_RELGXBYRAATIMEOUT
          - VRM_SETHOMESRVZONE
          - VRM_MAXTDFNUM
          - VRM_TDFCCRUSPD
          - VRM_TDFCCRTSPD
          - VRM_PROCHEARTBEATTIMEOUT
          - VRM_MAXAUXILIARYAREA
          - VRM_AADIAREDIRECTSWITCH
          - VRM_DIAMFAILOVERSWITCH
          - VRM_DYNSMSMSISDN
          - VRM_SUBGRPCREATESUB
          - VRM_QUOTACROSSSERVICE
          - VRM_SYSUBIDTYPE
          - VRM_DEACTIVESERVICETIMER
          - VRM_QUOTALOGSWITCH
          - VRM_SIMPLEPOLICYSTATISTIC
          - VRM_GXTRIGGERCMP
          - VRM_QOSNEGOTIATIONSWITCH
          - VRM_IPFLOWANYCVT
          - VRM_SUBLISTNORULE
          - VRM_NTFOVERDUEMODE
          - VRM_DESTPEERMODE
          - VRM_SYNDATASWITCH
          - VRM_SYNDATAINTERVAL
          - VRM_TAIECGIMATCHMODE
          - VRM_SYCARRYSUBID
          - VRM_SYRESENDTIMES
          - VRM_DYNQUOTATIMEZONE
          - VRM_FIRSTGXSESSIONATTR
          - VRM_SESSIONIDHASHMODE
          - VRM_PEERFCDURATION
          - VRM_AFPOLICYRECALCULATE
          - VRM_SGWRESTORETIME
          - VRM_QUOTAUSEPRIORITY
          - VRM_SESSIONIDSWITCH
          - VRM_REPORTUSAGE
          - VRM_IMEIQUERYSERVICE
          - VRM_MCITRIGGERUDR
          - VRM_RXMAXUL
          - VRM_RXMAXDL
          - VRM_SYSESSIONCONTROLATTRIBUTE
          - VRM_SYSESSIONCONTROLVALUE
          - VRM_AUTORECUSRLOC
          - VRM_LINKDSPMODE
          - VRM_RXSTAINCAUTHAPPID
          - VRM_MAXAREANUM
          - VRM_GXSESSIONONLYVOLTE
          - VRM_LDAPDBTIMEOUT
          - VRM_OFFSETTIME
          - VRM_APNSENSITIVE
          - VRM_DYNGROUPNUMBERPERUSER
          - VRM_SYSESSIONBACKUP
          - VRM_NOTIFYATTRRESTRICTION
          - VRM_UNKNOWNRULEPROC
          - VRM_FORCEUPGRADEQOS
          - VRM_RMVGRPMEMBERACT
          - VRM_SYNUSRDATASPEED
          - VRM_SYCHARGINGCHARSWITCH
          - VRM_LICDSPMODE
          - VRM_GRPMBRPARENTSTATUSFLAG
          - VRM_TERMSESSNOTIFICATIONFLAG
          - VRM_DCIPRIORITY
          - VRM_SERVICEINFOSTATUSMODE
          - VRM_RXARPMAPPINGMODE
          - VRM_NOTIFYATTRENUMVALUEMODE
          - VRM_GLBSESDATAREFRESH
          - VRM_MAXPOCSCPNUM
          - VRM_SPUAUTOSWITCHOVER
          - VRM_PRAIDCODECMODE
          - VRM_DFTROAMINGSTATUS
          - VRM_MCIPROCMODE
          - VRM_VMSTORAGEFAULTRMSWITCH
          - VRM_PREBINDFORSESSIONBACKUP
          - VRM_SHARESYQUOTAMODE
          - VRM_MEMCHECKALARMSWITCH
          - VRM_QUOTASTATUSSTATISTIC
          - VRM_SUBIDCHOOSESWITCH
          - VRM_MCCMNCROAMREGION
          - VRM_TERMFIRSTSESSIONSWITCH
          - VRM_RECORDMEMSWITCH
          - VRM_Q922ERRMSGSWITCH
          - VRM_MEMFREERECORDSTKSWITCH
          - VRM_MEMFREERECORDSTKPOLICY
          - VRM_MSGFREERECORDSTKSWITCH
          - VRM_MSGFREERECORDSTKPOLICY
          - VRM_MEMALLOCFAILEDHOOKSWITCH
          - VRM_LOADINGALLAREADATA
          - VRM_MAXMSGTEMPLATENUM
          - VRM_PCEFHOSTTOGROUP
          - VRM_LINKBASEAPN
          - VRM_CBOVERRUNALMTH
          - VRM_CBRECOVERYALMTH
          - VRM_VOLTESESSINDEPENDENT
          - VRM_MEWORKROLE
          - VRM_RESETFORALLOCMEMFAILED
          - VRM_RESETFORALLOCMSGFAILED
          - VRM_ENABLEVOLTEAPNGXFLOWCTRL
          - VRM_CBWATCHTIME
          - VRM_DIAMMSGRELAYSWITCH
          - VRM_SYNTIMER
          - VRM_DEVAUDITACCELERATION
          - VRM_PENDINGTRANSACTIONNUM
          - VRM_VOLTEQRYSPR
          - VRM_TRIGGERRESTRICTTYPE
          - BLC_UPMUSERREQ
          - BLC_BEARUPDATE
          - BLC_WAITBEARTERM
          - BLC_ZONETYPE
          - BLC_SECPDPQOSCONTROL
          - RM_RATINGVOLRNDUNIT
          - RM_USGVOLRNDUNIT
          - RM_USGVOLRNDTHRESH
          - RM_RUSGVOLRNDUNIT
          - RM_RUSGVOLRNDTHRESH
          - RM_PLMNANDSGSNALM
          - RM_ALMCLRPERIOD
          - BLC_NOTIFYSENDINTERVAL
          - VRM_OCSCHARGEFLAGFORPRE
          - VRM_OCSCHARGEFLAGFORPOS
          - VRM_OCSCHARGEFLAGFOROTHER
          - BLC_DELSSINVALIDINTERVAL
          - BLC_DELSSINTERVAL
          - BLC_DELSSNUM
          - VRM_CHECKAPNIP
          - VRM_QCIUPGRADE
          - VRM_UNDERCONTROLTHRESHOLD
          - VRM_NORMALVALUE
          - UPM_SUBCTRL
          - UPM_ACCRARTIMEOUT
          - UPM_TIMERPLYCNTREQ
          - VRM_KPIMONITORINGSWITCH
          - VRM_TDFPOLICYMODE
          - VRM_RXBEARWITH5002
          - LIC_PREALMTH
          - VRM_QRYSPRPRIORITY
          - VRM_SDUROUTECONFILICTRAR
          - VRM_DBTIMERVALIDPERIOD
          - VRM_FORCERECOVERYSESSION
          - ALC_WAITAFTERM
          - VRM_RARWITHTRIGGER
          - VRM_RELEASERXTRIGGER
          - VRM_MAXIPCANNUMPERUSR
          - VRM_RETENTION_NOTIFYLOG
          - VRM_RETENTION_MNTLOG
          - VRM_RETENTION_EXPORT
          - VRM_MAXSESSBACKUPNUMPERSUB
          - VRM_SAVESYORGSTATUS
          - VRM_SNRSUPPORTSUBID
          - VRM_AUDITFAILEDCODE
          - VRM_ADJUSTSERVICEMODE
          - VRM_SYORIGINSTATEID
          - VRM_NOTRARWITHSAMEINSTALLRULE
          - VRM_CALCPRIBYSRVNAME
          - VRM_PENDINGTIME2LOCALTIME
          - VRM_MAXPCEFRADIUSNUM
          - VRM_RTPDRNOFLOW
          - VRM_SYDRASLRITIMEOUTSTRCTRL
          - VRM_GXREDIRECTACTION
          - VRM_GXRULEDEDUP
          - VRM_MCITOPGWSPEED
          - VRM_NRIPV6HASHLENGTH
          - VRM_SDCHARGINGCHARSWITCH
          - VRM_OFFLINESRVSWITCH
          - VRM_OFFLINEREDOLOG
          - VRM_VOLTESESSIONNOTUPDATE
          - VRM_BSFONLYVOLTE
          - VRM_BSFRESENDTIMES
          - VRM_BSFTIMEOUT
          - VRM_CHRGIDFMT
          - VRM_LONGTERMNTYRECORDPERSUB
          - VRM_GXQRYCHARINGSYSMODE
          - VRM_RECREATERULENOTIFICATION
          - VRM_PACKETFILTER
          - VRM_SNRWITHOUTHOSTMODE
          - VRM_SYCOUNTERTRANSMODE
          - VRM_MAXCONDITIONNUM
          - VRM_MAXQUOTANUM
          - VRM_RMVSYSRVBYRESULTCODE
          - VRM_VIRTUALSUBIDSWITCH
          - VRM_VOLTEPDPQRYSY
          - VRM_PACKETERRRATETYPE
          - VRM_IPDOMAINSENSITIVE
          - VRM_NRCOMBINEPRIORITYMODE
          - VRM_N15COMPATIBILITYSWITCH
          - VRM_HASHAUDITSWITCH
          - VRM_RECUSRLOCBASERAT
          - VRM_MULTIPCEFQRYDB
          - VRM_DEVAUDITSTARTTIME
          - VRM_MCIDELOLDSES
          - VRM_MCIDELOLDSESSPEED
          - VRM_CHECKSUBSRV
          - VRM_MASTERSLAVENOTIFYENHANCE
          - VRM_NEPEERSTATUS
          - VRM_NONOVERLOADERRORCODESW
          - VRM_AMFRESELECTSWITCH
          - VRM_REDIRECTSWITCH
          - VRM_POLICYASSOCIATESWITCH
          - VRM_DIAMDIRECTPATH
          - VRM_SMFALMWITHIPPORT
          - VRM_REGWITHINSTANCENAME
          - VRM_VIRTUALQUOTAREPORTUSAGE
          - VRM_SPONSORDYNRULEFORMAT
          - VRM_SRVTOKENNUM
          - VRM_UPDSMFSTA
          - VRM_N7CHGNORULESWITCH
          - VRM_QUOTAOBJNOTEXISTCALCMODE
          - VRM_SDRRELIABTRANSSWITCH
          - VRM_CALCULBYNR
          - VRM_GXSESSIONCHARGE
          - VRM_RARSPEEDDOWNCPU
          - VRM_RARSPEEDUPCPU
          - VRM_SUBSCRIBERGROUPMATCHMODE
          - VRM_SCANSTARTTIME
          - VRM_DISTRIQUERYMAXRECORD
          - VRM_GLBPARTITIONLOADINGSWITCH
          - VRM_COMPARECCRIUQOS
          - VRM_AUTORECUSRLOCEX
          - VRM_AVGCHILDPERPARENT
          - VRM_AVGPARENTPERCHILD
          - VRM_SELECTNTSMETHOD
          - VRM_QUOTADEDUCTMODE
          - VRM_MAXBEARNUMPERIPCAN
          - VRM_SDSESSIONBACKUP
          - VRM_SERVICEZONEAREAMATCHTYPE
          - VRM_USRLOCATION_VALUE
          - VRM_RULESUFFIXLENAPPMODE
          - VRM_TAIMATCHINGMODE
          - VRM_N7PCCNOCHGANINFOSW
          - VRM_N5SESSIONBACKUP
          - VRM_PROFILEUPDATEBASERULEPRI
          - VRM_AFSELBINDCFG
          - VRM_ROUTEQUERYRETRYTIMES
          - VRM_ROUTEQUERYRETRYINTERVAL
          - VRM_NOTIFYBEFOREEXPIRE
          - VRM_N36INTERFACESW
          - VRM_N36SUBSCRIPTIONSW
          - VRM_PCFLIPSELECTMODE
          - VRM_PESSRVDISCTIMER
          - VRM_EXATTR1DEFAULTVALUE
          - VRM_HTTPCLIENTREDIRECTTIMES
          - VRM_N23SWITCH
          - VRM_DIAMGETAPPID
          - VRM_N23SESSIONBACKUP
          - VRM_GLBDATAIDMAPSWITCH
          - VRM_PEERNFDEFAULTPRIORITY
          - VRM_N23SESADTMSGSPEED
          - VRM_IPDOMAINSRCFORGX
          - VRM_N15VIRTUALSUBIDSWITCH
          - VRM_SESSIONCOMPRESSTYPE
          - VRM_UPDAMFSTA
          - VRM_N23TIMEOUT
          - VRM_MAXAMSAUNUMPERSPU
          - VRM_N24AMSWITCH
          - VRM_N24AMTIMEOUT
          - VRM_CALLRXFIRSTSW
          - VRM_BACKFILLSESRULE
          - VRM_N7NWDAFLINKDOWNSW
          - VRM_N7POLICYCHGN23SW
          - VRM_RSTSYQUOTASW
          - VRM_HTTPLOCFILLMODE
          - VRM_DRALINKSTAMPUPTMODE
          - VRM_TRACECACHECHKSW
          - VRM_N15AREACODESW
          - VRM_USELASTPLMNIFNOTMATCHED
          - VRM_AUTORESETSWITCH4FSM
          - VRM_N23HDPCFIDMODE
          - VRM_CALCREDPRIBYNAME
          - VRM_STATEXTERNALRESTORATION
          - VRM_BSFBINDINGUPDATESW
          - VRM_SBICALLBACKVALUE
          - VRM_NGPOLICYCASESENSITIVE
          - VRM_N15QRYCHARINGSYSMODE
          - VRM_AFUPDATEUMMODE
          - VRM_HSRCTRLSW
          - VRM_CALCMEDRULEPRIBYNAME
          - VRM_DATAVIRTUALSUBIDSWITCH
          - VRM_INTRANETSESSEFFMODE
          - VRM_N28PENDINGTIME2LOCAL
          - VRM_MIDNIGHTGLBREFRESHSWITCH
          - VRM_SCANFROZENUSER
          - VRM_N1NOTIFYTIMER
          - VRM_MAXNWDAFSESNUMPERSPU
          - VRM_PCEFPARAMATCHMODE
          - VRM_N5VIRTUALMEDIA
          - VRM_SYQTAINSTMODE
          - VRM_N7UPDATECAFCRXMODE
          - VRM_N7ACTN23POLICYMODE
          - VRM_N23BAKCOMPATIBILITYSW
          - VRM_N7MAXDYNRULENUM
          - VRM_N7FAILRCPROCMETHOD
          - VRM_DELAYSTATAUTOENABLEDSW
          - VRM_AUTHSRVENCODEMODE
          - VRM_SUBLOCNUM
          - VRM_HPCFDELIVERLOCCHSW
          - VRM_N15RMVSPCMCCFROMGPSI
          - VRM_MODULERSTPROTECTTIME
          - VRM_N15DYNMATCHMODE
          - VRM_NESTATUSREFRESHCYCLE
          - VRM_SYCCFROMN7SWITCH
          - VRM_MAXSESSRESTOREDELAYTIME
          - VRM_SESSIONNUMCOUNTMODE
          - VRM_UEINITRESOURCEBYSMFSWITCH
          - VRM_SATT2TVOICESW
          - VRM_ROLLBACKN7LINKDOWN
          - VRM_DEVAUDITAUTO
          - VRM_N24NFSETRESENTTIMES
          - VRM_UNKNOWNLOCPROC
          - VRM_N15SUBCTRL
          - VRM_UPMUSERREQTIMERLEN
          - VRM_SYSLRIDATIME
          - VRM_MAXNXSESNUMPERSPU
          - VRM_NXNASTIMEOUT
          - VRM_NXNASRETRYTIMES
          - VRM_NZTIMEOUT
          - VRM_NZRETRYTIMES
          - VRM_NXPENDINGRETRYTIMES
          - VRM_NXNWDAFDICMODE
          - VRM_NXNZSESSIONBACKUP
          - VRM_SLRURESENDTIMES
          - VRM_CHECKNTSLINKSTATUS
          - VRM_ABSVALPRDSRVAUTOSW
          - VRM_N23USETAIDISCMODE
          - VRM_SYTOGXRCMODE
          - VRM_VONRLICSTATMODE
          - VRM_PROFILEUPTTIMELEN
          - VRM_SYNASSOCDATAINTERVAL
          - VRM_N7NWDAFLINKDOWNCYCLE
          - VRM_N7NWDAFLINKDOWNMAXTIMES
          - VRM_RXIPV6PCEFGROUPID
          - VRM_DLBPRQTIMERLEN
          - VRM_CLIENTPORTVERIFY
          - VRM_RECHARGENOTIFIRESTRAIN
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '参数值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    add_dlbvpn_list:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 31
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    is_optional_upcf_ocs_ip_address:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '添加UPCF与OCS对接的IP地址。'
      data_source: ''
      pattern: ''
      default: TRUE
    add_dlbdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '网元安装完成后，由运营商对已部署的VPN进行统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。 只有当“IPVER”为“IPV4”时，才会规划IPv4地址。 当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划，由运营商提供。 当“IPVER”为“IPV4”时，才需要规划和配置IPv4地址。'
          data_source: ''
          pattern: ''
          default: ''
        DESCRIPTION:
          name: '描述'
          type: string
          minLength: 0
          maxLength: 32
          required: false
          description: '本端规划。 用于描述设备IP地址的用途。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pocscp_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: '登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        CPID:
          name: '接入点标识'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        CPN:
          name: '接入点名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '对端域名'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '对端主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        DASWITCH:
          name: '审计开关'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: '推荐使用样例值。 当对端能力有特殊要求时，需要由运营商根据实际的业务场景提供。'
          data_source: ''
          pattern: ''
          default: OFF
        DATIME:
          name: '设备间审计时长'
          type: integer
          minimum: 15
          maximum: 1440
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    add_pocsl_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: '登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        CPID:
          name: '接入点标识'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        LNKID:
          name: '链路标识'
          type: integer
          minimum: 0
          maximum: 67
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        TPTYPE:
          name: '传输协议类型'
          type: string
          enum:
          - TCP
          - SCTP
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        LIP:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '登录“UPCF MML命令”界面执行**ADD DLBDEVADDR**命令定义后，在此引用。 只有当“DIPVER”为“IPV4”时，才会规划此参数。 当“DIPVER”为“IPV6”时，此处规划的参数应为“LIPV6”。'
          data_source: ''
          pattern: ''
          default: ''
        LPT:
          name: '本地端口'
          type: integer
          minimum: 0
          maximum: 65534
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PIP:
          name: '对端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商提供，从对端配置中获取。 只有当“DIPVER”为“IPV4”时，才会规划此参数。 当“DIPVER”为“IPV6”时，此处规划的参数应为“PIPV6”。'
          data_source: ''
          pattern: ''
          default: ''
        PPT:
          name: '对端端口'
          type: integer
          minimum: 1
          maximum: 65534
          required: true
          description: '由运营商提供，从对端配置中获取。'
          data_source: ''
          pattern: ''
          default: ''
        ADSTS:
          name: '链路管理状态'
          type: string
          enum:
          - DISABLE
          - ENABLE
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ENABLE
        DUALHOME:
          name: '双归属开关'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        CROSSPATH:
          name: '交叉路径'
          type: string
          enum:
          - ON
          - OFF
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: OFF
        DIPVER:
          name: '双归属地址IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        DLIP:
          name: '双归属本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。 只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划此参数。 当“DUALHOME”为“ON”以及“DIPVER”为“IPV6”时，此处规划的参数应为“DLIPV6”。'
          data_source: ''
          pattern: ''
          default: ''
        DPIP:
          name: '双归属对端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商提供，从对端配置中获取。 只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划此参数。 当“DUALHOME”为“ON”以及“DIPVER”为“IPV6”时，此处规划的参数应为“DPIPV6”。'
          data_source: ''
          pattern: ''
          default: ''
        DLIPV6:
          name: '双归属本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DPIPV6:
          name: '双归属对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LIPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PIPV6:
          name: '对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - mod_insp_list:
    - INSPN: VRM_SYSWITCH
      INSPV: 1
    add_dlbvpn_list:
    - VPNINDEX: 1
      VPNNAME: 'VPN_1'
    is_optional_upcf_ocs_ip_address: TRUE
    add_dlbdevaddr_list:
    - DEVAID: 5
      VPNINDEX: 1
      IPVER: IPV4
      IP: '192.168.0.133'
      DESCRIPTION: 'OCS IP'
      IPV6: ''
    add_pocscp_list:
    - PCRFID: 1
      CPID: 0
      CPN: 'UPCF_OCS'
      DN: 'huawei.com'
      HN: 'ocs.huawei.com'
      DASWITCH: ON
      DATIME: 720
    add_pocsl_list:
    - PCRFID: 1
      CPID: 0
      LNKID: 0
      TPTYPE: SCTP
      LIP: '192.168.0.133'
      LPT: 1200
      IPVER: IPV4
      PIP: '192.168.0.30'
      PPT: 1233
      ADSTS: ENABLE
      DUALHOME: ON
      CROSSPATH: ON
      DIPVER: IPV4
      DLIP: '192.168.1.133'
      DPIP: '192.168.1.30'
      DLIPV6: ''
      DPIPV6: ''
      LIPV6: ''
      PIPV6: ''
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录“UPCF MML命令”界面。

### 2 参考如下命令，修改软参“VRM\_SYSWITCH”，开启Sy接口功能。

```jinja2
{%- for item in mod_insp_list -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    ;
{%- endfor -%}
```

### 当UPCF仅需要根据OCS上的配额状态发生变化进行策略控制时，开启标准Sy接口功能即可，命令中的**参数值**取值设置为1。

### 当UPCF需要通过Sy接口获取Sy配额数据，通过Sy配额名称为用户匹配对应的签约，最后匹配规则并下发给对端PCEF时，命令中的**参数值**取值设置为2。

### 修改参数值后立即生效。

### 3 执行**ADD DLBVPN**命令增加UPCF与OCS对接的VPN地址。

```jinja2
{%- for item in add_dlbvpn_list -%}
    ADD DLBVPN:
    {#- --- 必选参数 --- -#}
    VPNINDEX={{item.VPNINDEX}},
    VPNNAME="{{item.VPNNAME}}",
    ;
{%- endfor -%}
```

### 4 添加UPCF与OCS对接的IP地址。

### 执行**ADD DLBDEVADDR**命令增加UPCF与OCS对接的IP地址。以参数“IPVER”值为“IPV4”为例：

```jinja2
{%- if is_optional_upcf_ocs_ip_address -%}
    {%- for item in add_dlbdevaddr_list -%}
        ADD DLBDEVADDR:
        {#- --- 必选参数 --- -#}
        DEVAID={{item.DEVAID}},
        VPNINDEX={{item.VPNINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 可选参数 --- -#}
        {%- if item.DESCRIPTION is not none -%}
            DESCRIPTION="{{item.DESCRIPTION}}",
        {%- endif -%}
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IP="{{item.IP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6="{{item.IPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 若UPCF与OCS对接的IP地址已通过**ADD DLBDEVADDR**增加，则跳过此步骤。

### 5 执行**ADD POCSCP**命令增加对端OCS实体。

```jinja2
{%- for item in add_pocscp_list -%}
    ADD POCSCP:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    CPID={{item.CPID}},
    DN="{{item.DN}}",
    HN="{{item.HN}}",
    {#- --- 可选参数 --- -#}
    {%- if item.CPN is not none -%}
        CPN="{{item.CPN}}",
    {%- endif -%}
    {%- if item.DASWITCH is not none -%}
        DASWITCH={{item.DASWITCH}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：DASWITCH=ON 时必选 --- -#}
    {%- if item.DASWITCH == 'ON' -%}
        DATIME={{item.DATIME}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 6 执行**ADD POCSL**命令增加UPCF与对端OCS的链路。以参数“IPVER”值为“IPV4”为例：

```jinja2
{%- for item in add_pocsl_list -%}
    ADD POCSL:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    CPID={{item.CPID}},
    LNKID={{item.LNKID}},
    TPTYPE={{item.TPTYPE}},
    LPT={{item.LPT}},
    PPT={{item.PPT}},
    {#- --- 可选参数 --- -#}
    {%- if item.ADSTS is not none -%}
        ADSTS={{item.ADSTS}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
    {%- if item.DIPVER == 'IPV4' -%}
        LIP="{{item.LIP}}",
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- elif item.IPVER == 'IPV4' -%}
        LIP="{{item.LIP}}",
    {%- endif -%}
    {#- --- 条件必选：TPTYPE=TCP 时必选 --- -#}
    {%- if item.TPTYPE == 'TCP' -%}
        IPVER={{item.IPVER}},
    {#- --- 条件必选：DUALHOME=OFF 时必选 --- -#}
    {%- elif item.DUALHOME == 'OFF' -%}
        IPVER={{item.IPVER}},
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
    {%- if item.DIPVER == 'IPV4' -%}
        PIP="{{item.PIP}}",
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- elif item.IPVER == 'IPV4' -%}
        PIP="{{item.PIP}}",
    {%- endif -%}
    {#- --- 条件必选：DUALHOME=ON 时必选 --- -#}
    {%- if item.DUALHOME == 'ON' -%}
        DIPVER={{item.DIPVER}},
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
    {%- if item.DIPVER == 'IPV4' -%}
        DLIP="{{item.DLIP}}",
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
    {%- if item.DIPVER == 'IPV6' -%}
        DLIPV6="{{item.DLIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
    {%- if item.DIPVER == 'IPV4' -%}
        DPIP="{{item.DPIP}}",
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
    {%- if item.DIPVER == 'IPV6' -%}
        DPIPV6="{{item.DPIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：TPTYPE=SCTP 时必选 --- -#}
    {%- if item.TPTYPE == 'SCTP' -%}
        DUALHOME={{item.DUALHOME}},
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
    {%- if item.DIPVER == 'IPV6' -%}
        LIPV6="{{item.LIPV6}}",
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- elif item.IPVER == 'IPV6' -%}
        LIPV6="{{item.LIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
    {%- if item.DIPVER == 'IPV6' -%}
        PIPV6="{{item.PIPV6}}",
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- elif item.IPVER == 'IPV6' -%}
        PIPV6="{{item.PIPV6}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：DUALHOME=ON 时可选 --- -#}
    {%- if item.DUALHOME == 'ON' -%}
        {%- if item.CROSSPATH is not none -%}
            CROSSPATH={{item.CROSSPATH}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 若使用SCTP双归属功能，则“传输协议类型”必须选择“SCTP(流量控制传输协议)”且“双归属开关”值必须为“ON(打开)”。

