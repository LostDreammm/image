# 配置UPCF与OCS（基于Diameter协议）的对接数据

* 操作场景
* 必备事项
* 操作步骤
* 验证方法

## 操作场景

当UPCF需要通过Sy接口从OCS（Online Charging System）获取配额状态信息进行统计时，UPCF需要对接OCS，从OCS上获取配额状态完成PCC（Policy and Charging Control）策略控制功能。

当UPCF通过DRA与OCS对接，参考配置UPCF与DRA的对接数据。

## 必备事项

前提条件

* 已完成软件安装。
* 已完成基础数据配置。
* OCS侧已完成基础数据配置。
* UPCF与OCS的网络连接正常。
* 已经获得运营商规划的UPCF与OCS的对接IP地址。

数据

配置前规划的对接数据如表1所示。

**表1** 对接数据

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **MOD INSP** | INSPN（参数名） | VRM\_SYSWITCH | 全网规划，由运营商提供。 |
|  | INSPV（参数值） | 1 | 全网规划，由运营商提供。 |
| ****ADD DLBVPN**** | VPNINDEX （VPN索引） | 1 | 本端规划，取值范围内不允许重复。 |
|  | VPNNAME（VPN名称） | VPN\_1 | 全网规划，由运营商提供。 |
| **ADD DLBDEVADDR** | DEVAID （设备地址标识） | 5 | 本端规划，取值范围内不允许重复。 |
|  | VPNINDEX （VPN索引） | 1 | 网元安装完成后，由运营商对已部署的VPN进行统一规划。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，由运营商提供。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | IP （IPV4地址） | 192.168.0.133 | 全网规划，由运营商提供。  当“IPVER”为“IPV4”时，才需要规划和配置IPv4地址。 |
|  | DESCRIPTION（描述） | OCS IP | 本端规划。  用于描述设备IP地址的用途。 |
| **ADD POCSCP** | PCRFID（PCRF标识） | 1 | 登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。 |
|  | CPID （接入点标识） | 0 | 本端规划，取值范围内不允许重复。 |
|  | CPN（接入点名称） | UPCF\_OCS | 全网规划，由运营商提供。 |
|  | DN（对端域名） | huawei.com | 全网规划，由运营商提供。 |
|  | HN（对端主机名） | ocs.huawei.com | 全网规划，由运营商提供。 |
|  | DASWITCH（审计开关） | ON | 推荐使用样例值。  当对端能力有特殊要求时，需要由运营商根据实际的业务场景提供。 |
|  | DATIME（设备间审计时长） | 720 | 全网规划，由运营商提供。 |
| **ADD POCSL** | PCRFID（PCRF标识） | 1 | 登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。 |
|  | CPID （接入点标识） | 0 | 本端规划，取值范围内不允许重复。 |
|  | LNKID（链路标识） | 0 | 本端规划，取值范围内不允许重复。 |
|  | TPTYPE（传输协议类型） | SCTP | 全网规划，由运营商提供。 |
|  | DUALHOME（双归属开关） | ON | 全网规划，由运营商提供。 |
|  | CROSSPATH（交叉路径） | ON | 全网规划，由运营商提供。 |
|  | DIPVER（双归属地址IP版本） | IPV4 | 全网规划，由运营商提供。 |
|  | DLIP（双归属本端IPV4地址） | 192.168.1.133 | 登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。  只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划此参数。  当“DUALHOME”为“ON”以及“DIPVER”为“IPV6”时，此处规划的参数应为“DLIPV6”。 |
|  | LIP（本端IPV4地址） | 192.168.0.133 | 登录“UPCF MML命令”界面执行**ADD DLBDEVADDR**命令定义后，在此引用。  只有当“DIPVER”为“IPV4”时，才会规划此参数。  当“DIPVER”为“IPV6”时，此处规划的参数应为“LIPV6”。 |
|  | LPT（本地端口） | 1200 | 全网规划，由运营商提供。 |
|  | DPIP（双归属对端IPV4地址） | 192.168.1.30 | 由运营商提供，从对端配置中获取。  只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划此参数。  当“DUALHOME”为“ON”以及“DIPVER”为“IPV6”时，此处规划的参数应为“DPIPV6”。 |
|  | PIP（对端IPV4地址） | 192.168.0.30 | 由运营商提供，从对端配置中获取。  只有当“DIPVER”为“IPV4”时，才会规划此参数。  当“DIPVER”为“IPV6”时，此处规划的参数应为“PIPV6”。 |
|  | PPT（对端端口） | 1233 | 由运营商提供，从对端配置中获取。 |
|  | ADSTS（链路管理状态） | ENABLE | 全网规划，由运营商提供。 |

## 操作步骤

1. 登录“UPCF MML命令”界面。
2. 参考如下命令，修改软参“VRM\_SYSWITCH”，开启Sy接口功能。

   ```
   MOD INSP:INSPN=VRM_SYSWITCH, INSPV=参数值;
   ```

   * 当UPCF仅需要根据OCS上的配额状态发生变化进行策略控制时，开启标准Sy接口功能即可，命令中的**参数值**取值设置为1。
   * 当UPCF需要通过Sy接口获取Sy配额数据，通过Sy配额名称为用户匹配对应的签约，最后匹配规则并下发给对端PCEF时，命令中的**参数值**取值设置为2。
   * 修改参数值后立即生效。
3. 执行**ADD DLBVPN**命令增加UPCF与OCS对接的VPN地址。

   ```
   ADD DLBVPN: VPNINDEX=VPN索引, VPNNAME=VPN名称;
   ```
4. 添加UPCF与OCS对接的IP地址。

   执行**ADD DLBDEVADDR**命令增加UPCF与OCS对接的IP地址。以参数“IPVER”值为“IPV4”为例：

   ```
   ADD DLBDEVADDR: DEVAID=设备地址标识, VPNINDEX=VPN索引, IPVER=IPV4, IP=IPV4地址, DESCRIPTION=描述;
   ```

   若UPCF与OCS对接的IP地址已通过**ADD DLBDEVADDR**增加，则跳过此步骤。
5. 执行**ADD POCSCP**命令增加对端OCS实体。

   ```
   ADD POCSCP: PCRFID=PCRF标识, CPID=接入点标识, CPN=接入点名称, DN=对端域名, HN=对端主机名, DASWITCH=审计开关, DATIME=设备间审计时长;
   ```
6. 执行**ADD POCSL**命令增加UPCF与对端OCS的链路。以参数“IPVER”值为“IPV4”为例：

   ```
   ADD POCSL: PCRFID=PCRF标识, CPID=接入点标识, LNKID=链路标识, TPTYPE=传输协议类型, LIP=本端IPV4地址, LPT=本端端口, IPVER=IPV4, PIP=对端IPV4地址, PPT=对端端口, ADSTS=链路管理状态;
   ```

   若使用SCTP双归属功能，则“传输协议类型”必须选择“SCTP(流量控制传输协议)”且“双归属开关”值必须为“ON(打开)”。

## 验证方法

检查UPCF-OCS链路。

检查链路前需要对端已经完成配置对接UPCF的数据。

1. 登录“UPCF MML命令”界面。
2. 执行**DSP POCSL**  命令，查询“链路状态”是否为“在线”。

   ```
   DSP POCSL:;
   ```

   * 是 => UPCF-OCS链路正常，检查完成。
   * 否 => 请联系华为技术支持处理。

版权所有 © 华为技术有限公司
