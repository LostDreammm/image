---
id: ''
name: 支持RFSP下发选择频点特性配置
ne_type: UPCF
type: feature
description: 当频谱资源紧张，运营商希望通过RFSP ID区分不同用户群，通过RFSP ID策略控制资源使用，以达到保证VIP用户的体验时，需要部署此特性。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-608004 支持RFSP下发选择频点","WHFD-608004 支持RFSP下发选择频点特性配置","支持RFSP下发选择频点特性配置"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当频谱资源紧张，运营商希望通过RFSP ID区分不同用户群，通过RFSP ID策略控制资源使用，以达到保证VIP用户的体验时，需要部署此特性。

## 必备事项
前提条件

如下License已申请并完成加载。

| 控制项名称 | 交互说明 |
| --- | --- |
| 82403223 LRM0PCFNX92 N15接口(使用HTTP协议)策略控制 | 依赖该特性实现N15接口基本功能。 |
| 82403854 LRM0PCFRFSP111 支持RFSP下发选择频点 | 依赖该特性实现RFSP下发选择频点基本功能。 |
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCATEGORY:
          name: 'USRCATEGORY'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: 1234567****
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRCATEGORY: VIP
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: eMBB-SA
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: S_RFSP
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录UPCF Web UI界面。

### 2 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 详细参数说明请参见表2。

### **表2** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组 | 基本信息 | 名称 | RFSP\_vip |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | RFSP |

### |  |  | 对象属性 | * 对象：Subscriber * 属性：Category |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | VIP  说明：  该条件用于标识VIP用户。 |

### 3 配置5G动作组。

### 导航入口为“策略管理 > 策略 > 5G动作组”。

### 5G动作组的数据规划如表3所示，详细参数说明请参见5G动作组参数说明。

### **表3** 5G动作组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 5G动作组1 | 基本信息 | 名称 | AG\_RFSP |

### |  |  | 类型 | AmPolicyAction |

### |  | 属性 | rfsp | * 类型：Value * 值：1 |

### 4 配置规则

### 导航入口为“策略管理 > 策略 > 规则”。

### 此场景，规则的“类型”需要配置为“5G Amf Pcc Rule”。

### 规则的数据规划如表4所示，详细参数说明请参见规则参数说明。

### **表4** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则 | 基本信息 | 名称 | Rule\_RFSP |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Amf Pcc Rule |

### |  | 条件组 | 关系 | AND |

### |  |  | 条件组 | RFSP\_vip  说明：  已在表2中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_RFSP  说明：  已在表3中定义。 |

### 5 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表5所示，详细参数说明请参见策略参数说明。

### **表5** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略 | 基本信息 | 名称 | Policy\_RFSP |

### |  |  | 策略类型 | N15 Policy |

### |  | 触发器 | 名称 | AMPolicyCreateRequest |

### |  | 规则 | 名称 | Rule\_RFSP  说明：  已在表4中定义。 |

### 6 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 业务的数据规划如表6所示，详细参数说明请参见业务参数说明。

### **表6** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | S\_RFSP |

### |  |  | 类型 | VALUE\_ADDED\_SERVICE |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  该业务优先级配置须保证是当前用户所有签约业务中的最高优先级。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | Policy\_RFSP  说明：  已在表5中定义。 |

### 7 登录“UPCF 业务管理”窗口。

### 8 发放业务。

#### 8.1 执行**ADD PSUB**增加一个VIP用户。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=8.1 -->
```

#### 8.2 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=8.2 -->
```

