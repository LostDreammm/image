# 灵活的配额转移特性配置（2G/3G）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

灵活的配额转移特性，是与基于使用量的动态策略控制特性配合使用，为用户提供更加客户化、个性化的服务。

当用户通过签约业务获得的配额剩余较多时，用户可以登录运营商的配额转移网站，通过自助方式请求进行配额转移操作，以避免配额浪费。

灵活的配额转移主要包含如下应用场景：

* 不同用户的配额之间转移：需要配置两个不同的用户。
* 同一个用户不同配额之间转移：需要为一个用户配置两个业务。

如上两种场景的配置方法类似。下面以配置用户A的典型上网流量包月业务，及用户A将配额转移给用户B，且UPCF对接华为GGSN为例：

* 配额为2000MB。
* 每月1号01:00:00进行配额复位，剩余配额采用清零方式。
* 用户A给用户B转移1500M配额。
* 带宽控制：
  + 当配额消耗小于60%时，上行带宽为1 Mbit/s，下行带宽为2 Mbit/s。
  + 当配额消耗大于等于60%但小于100%时，上行带宽降为500 kbit/s，下行带宽降为1 Mbit/s。
  + 当配额消耗大于等于100%时，上行带宽降为250 kbit/s，下行带宽降为500 kbit/s。
* UPCF进行配额累积。
* 配置消息通知。
* 配置动态规则。

#### 对系统的影响

对系统正常运行没有影响。

#### 必备事项

**前提条件**

* 已配置UPCF与短消息中心的对接数据。
* 操作员已了解WHFD-611062 灵活的配额转移特性描述。

**数据**

根据应用场景，参考业务拆解总体原则，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 业务Transfer\_Service | 此包月业务即为一个独立的业务（service）。 | - |
| 配额Transfer\_Quota | * 配置用户的配额类型、配额值、复位时间、阈值及配额转移信息等。 * 此场景配额类型为会话级，阈值配置level1=60%。 | * “类型”表示配额的累计级别。   + “业务级”表示收集并计算特定业务的使用情况。   + “会话级 ”表示不区分业务，收集并计算整个IP会话中所有业务的使用量总和。 * 配额转移信息中必须选择支持配额转移。 |
| 策略Policy\_Transfer | 此策略在用户上线和流量消耗的过程中被调用，触发器分别为IPCANSessionEstablish和UsageReport，包含所有规则。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配并下发策略给PCEF（Policy and Charging Enforcement Function）。 |
| 规则Rule\_Transfer | * 条件：流量消耗小于60%。 * 动作：    + QoSAction：上行带宽为1 Mbit/s，下行带宽为2 Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。   + UsageReport：“MonitorKey”与配额中的“监控键值”相等。 | * 条件中“对象属性”的配置：   + 当使用配额状态（对应于**LST PQUOTA**中的“Status”）做条件控制时，条件“对象属性”选用对象Quota下的QuotaStatus属性。   + 当使用业务状态（对应于**LST PSRV**中的“Usage level”）做条件控制时，条件“对象属性”选用对象Subscription下的UsageStatus属性。 说明：  因配额阈值只能配置为整数，故当阈值设置不能满足场景需求时，条件“对象属性”可选用对象Quota下的QuotaBalance或QuotaConsumption属性。 * 若对端为华为GGSN，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。“RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。 * 当配额类型为“会话级”或“业务级”，且UPCF和对端PCEF遵循3GPP R9协议定义的FUP上报模式时，UPCF侧需要配置UsageReport动作。 * 业务流：若不区分各业务的数据流，统一只根据会话流量控制带宽，则规则中上下行业务流均取默认值“Any IP Protocol”。 |
| 规则Rule\_Transfer1 | * 条件：流量消耗大于等于60%但小于100%。 * 动作：    + QoSAction：上行带宽降为500 kbit/s，下行带宽降为1 Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。   + UsageReport：“MonitorKey”与配额中的“监控键值”相等。 |  |
| 规则Rule\_Transfer2 | * 条件：流量耗尽。 * 动作：    + QoSAction：上行带宽降为250 kbit/s，下行带宽降为500 kbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。   + UsageReport：“MonitorKey”与配额中的“监控键值”相等。 |  |

#### 操作流程

此特性的配置流程图如图2所示。

**图2** 业务配置流程图

#### 操作步骤

1. 配置软参。

   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD INSP**命令，配置参数VRM\_QUOTAUSEPRIORITY，用于设置接收转移配额的用户配额使用的优先级。

      当UPCF上的用户存在基础配额、累积配额和转移配额，在对配额进行扣减时，可以通过该软参确定配额扣减使用的优先级。

      命令举例：

      ```
      MOD INSP: INSPN=VRM_QUOTAUSEPRIORITY, INSPV=0;
      ```
2. 修改对端PCEF能力字典项。
   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其不支持R8标准的QoS。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=R8QoS, ABLITYVALUE=UnsupportedR8QoS;
      ```

      在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”需设置为“67”。实际的值可以通过如下方式查询：
      * 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。
      * 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
   3. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持基于3GPP R9标准的Usage Monitoring机制。

      当配置的FUP业务需使用3GPP R9标准的Usage Monitoring机制时，才需配置“UsageMonitor3GPPR9”的能力，否则，略过此步骤。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=UsageMonitor, ABLITYVALUE=UsageMonitor3GPPR9;	
      ```
   4. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，设置Monitor Key以哪种字节长度处理。

      Monitor Key的长度处理方式有如下三种：
      * FourBytesHex：MonitorKey按照十六进制4字节处理。
      * MaxFourBytesHex：MonitorKey按照十六进制最大4字节处理。
      * ASCIIMode：MonitorKey按照ASCII码处理。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=MonitorKeyCodecModeForR9, ABLITYVALUE=ASCIIMode;	
      ```
3. 登录UPCF Web UI界面。
4. 增加短信/邮件模板。

   导航入口为“通知管理 > 消息配置 > 短信/邮件模板”。

   短信/邮件模版的数据规划如表2所示，详细参数说明请参见短信/邮件模板参数值。

   若用户需要修改短信通知的默认语言类型，或配置多种语言类型，请在配置短信/邮件模版之前参考短信语言配置语言类型。

   **表2** 短信/邮件模板

   | 类别 | 参数 | 取值样例 |
   | --- | --- | --- |
   | 短信/邮件模板1 | 名称 | Notify\_Template\_TransOutSub |
   |  | 标题 | exhaust\_template |
   |  | 类型 | 短信/邮件 |
   |  | 内容 | 尊敬的{OBJ.Quota.TransOutSubMSISDN}，您已转出{OBJ.Quota.TransferQtaValue}配额给{OBJ.Quota.TransInSubMSISDN}。 |
   | 短信/邮件模板2 | 名称 | Notify\_Template\_TransInSub |
   |  | 标题 | exhaust\_template |
   |  | 类型 | 短信/邮件 |
   |  | 内容 | 尊敬的{OBJ.Quota.TransInSubMSISDN}，您已收到{OBJ.Quota.TransOutSubMSISDN}的转让配额{OBJ.Quota.TransferQtaValue}，请在{OBJ.Quota.TransferQtaStartTime}和{OBJ.Quota.TransferQtaEndTime}时间段内使用。 |
5. 增加消息通知。

   导航入口为“策略管理 > 策略 > 消息通知”。

   消息通知的数据规划如表3所示，详细参数说明请参见消息通知参数表。

   **表3** 消息通知

   | 类别 | 参数 | 取值样例 |
   | --- | --- | --- |
   | 消息通知1 | 名称 | Notify\_TransOutSub |
   |  | 短信/邮件 | Notify\_Template\_TransOutSub  说明：  已在短信/邮件模板中定义。 |
   |  | 发送抑制 | No |
   | 消息通知2 | 名称 | Notify\_TransInSub |
   |  | 短信/邮件 | Notify\_Template\_TransInSub  说明：  已在短信/邮件模板中定义。 |
   |  | 发送抑制 | No |
6. 配置配额。

   导航入口为“业务管理 > 业务 > 配额”。

   配额（Quota）是指一个指定周期内供用户使用的流量或时长额度，也可指单个会话内供用户使用的时长额度。当业务的使用与流量、时长相关时，需要配置配额。

   配额的数据规划如表4所示，详细参数说明请参见配额参数表。

   **表4** 配额

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 配额 | 基本信息 | 名称 | Transfer\_Quota |
   |  |  | 配额管理归属 | UPCC |
   |  |  | 配额类型 | 流量 |
   |  |  | 类型 | 会话级 |
   |  |  | 监控键值 | 101 |
   |  |  | 值(KB) | 2048000 |
   |  |  | 分片类型 | 百分比 |
   |  |  | 分片(%) | 10 |
   |  | 复位设置 | 结帐模式 | 自然日历 |
   |  |  | 复位周期类型 | 月 |
   |  |  | 复位日期 | 1 |
   |  |  | 复位时间 | 01:00:00 |
   |  |  | 剩余额处理方式 | 清零 |
   |  | 阈值设置 | Level1(%) | 60 |
   |  | 扩展信息 | 是否支持配额转移 | 是 |
   |  |  | 单次最大转出值 | 1536000 |
   |  |  | 最小保留值 | 512000 |
   |  |  | 每天最大转出次数 | 2 |
   |  |  | 每周期最大转出次数 | 6 |
   |  |  | 转出方通知 | Notify\_TransOutSub |
   |  |  | 转入方通知 | Notify\_TransInSub |
7. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置三个条件组，用于判断配额消耗小于60%，大于等于60%但未耗尽或配额耗尽。条件组的数据规划如表5所示，详细参数说明请参见条件组参数表。

   **表5** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_Transfer |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | Condition\_Basic |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Transfer\_Quota  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Normal  说明：  “Normal”：表示配额消耗小于Level1。 |
   | 条件组2 | 基本信息 | 名称 | CG\_Transfer1 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | CG1\_Con1 |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Transfer\_Quota  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Level1  说明：  “Level1”：表示配额消耗大于等于Level1、但未耗尽。 |
   | 条件组3 | 基本信息 | 名称 | CG\_Transfer2 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | CG2\_Con1 |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Transfer\_Quota  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示配额耗尽。 |
8. 配置动作组。

   导航入口为“策略管理 > 策略 > 动作组”。

   * 若配置的规则为动态规则，则必须配置动作组。
   * 此场景配置动态规则且需要考虑调整带宽、计费动作和流量上报，则每个动作组需配置动作：QoSAction、ChargingAction和UsageReport。相关应用场景如下：

     + QoSAction：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制QoS。
     + ChargingAction：当需要做计费策略控制时，配置此动作（若对端为华为GGSN，此动作必须配置）。
     + UsageReport：当需要进行流量上报时，配置此动作。

   需要配置三个动作组，用于在配额消耗小于60%，大于等于60%但未耗尽或配额耗尽时动作的下发。动作组的数据规划如表6所示，详细参数说明请参见动作组参数表。

   **表6** 动作组

   | 类别 | 参数 |  |  | 取值样例 |
   | --- | --- | --- | --- | --- |
   | 动作组1 | 基本信息 | 名称 |  | AG\_Transfer |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示不计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   |  | 动作3 | 动作 |  | UsageReport |
   |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |
   | 动作组2 | 基本信息 | 名称 |  | AG\_Transfer1 |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：500 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：500 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示不计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   |  | 动作3 | 动作 |  | UsageReport |
   |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |
   | 动作组3 | 基本信息 | 名称 |  | AG\_Transfer2 |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：250 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：500 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：250 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：500 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示不计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   |  | 动作3 | 动作 |  | UsageReport |
   |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |
9. 配置业务流。

   导航入口为“策略管理 > 策略 > 业务流”。

   当对端为华为GGSN时，所有的动态规则都必须配置业务流。

   业务流的数据规划如表7所示，详细参数说明请参见业务流参数表。

   **表7** 业务流

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务流 | 基本信息 | 名称 | Flow\_Filter |
   |  | 流过滤器1 | 名称 | up\_pass |
   |  |  | 流方向 | Up |
   |  |  | 协议 | Any IP Protocol |
   |  | 流过滤器2 | 名称 | down\_pass |
   |  |  | 流方向 | Down |
   |  |  | 协议 | Any IP Protocol |
10. 配置规则。

    导航入口为“策略管理 > 策略 > 规则”。

    规则的数据规划如表8所示，详细参数说明请参见规则参数表。

    **表8** 规则

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 规则1 | 基本信息 | 名称 | Rule\_Transfer |
    |  |  | 操作类型 | Change Rule |
    |  |  | 类型 | Dynamic |
    |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
    |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
    |  |  | 条件组 | CG\_Transfer  说明：  已在条件组中定义。 |
    |  | 动作组 | 动作组 | AG\_Transfer  说明：  已在动作组中定义。 |
    | 规则2 | 基本信息 | 名称 | Rule\_Transfer1 |
    |  |  | 操作类型 | Change Rule |
    |  |  | 类型 | Dynamic |
    |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
    |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
    |  |  | 条件组 | CG\_Transfer1  说明：  已在条件组中定义。 |
    |  | 动作组 | 动作组 | AG\_Transfer1  说明：  已在动作组中定义。 |
    | 规则3 | 基本信息 | 名称 | Rule\_Transfer2 |
    |  |  | 操作类型 | Change Rule |
    |  |  | 类型 | Dynamic |
    |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
    |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
    |  |  | 条件组 | CG\_Transfer2  说明：  已在条件组中定义。 |
    |  | 动作组 | 动作组 | AG\_Transfer2  说明：  已在动作组中定义。 |
11. 配置策略。

    导航入口为“策略管理 > 策略 > 策略”。

    策略的数据规划如表9所示，详细参数说明请参见策略参数表。

    **表9** 策略

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 策略 | 基本信息 | 名称 | Policy\_Transfer |
    |  | 触发器 | 名称 | IPCANSessionEstablish  UsageReport |
    |  | 规则 | 名称 | * Rule\_Transfer * Rule\_Transfer1 * Rule\_Transfer2 说明：  已在规则中定义。 |
12. 配置业务。

    导航入口为“业务管理 > 业务 > 业务”。

    完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

    业务的数据规划如表10所示，详细参数说明请参见业务参数表。

    **表10** 业务

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 业务 | 基本信息 | 名称 | Transfer\_Service |
    |  |  | 类型 | BASIC\_SERVICE |
    |  |  | 是否记入基本配额 | 是 |
    |  |  | 激活方式 | PCEF |
    |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
    |  |  | QoS模式 | 替换 |
    |  |  | 签约后才能使用 | 是 |
    |  | 策略 | 名称 | Policy\_Transfer  说明：  已在策略中定义。 |
    |  | 配额 | 名称 | Transfer\_Quota  说明：  已在配额中定义。 |
13. 登录“UPCF 业务管理”窗口。
14. 发放业务。
    1. 执行**ADD PSUB**增加用户A和B。

       “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

       ```
       ADD PSUB: USRIDENTIFIER="46010381012****", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB;
       ```

       ```
       ADD PSUB: USRIDENTIFIER="46010381012****", USRMSISDN="12345678902", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB;
       ```
    2. 执行**ADD PSRV**给用户A和用户B签约业务。

       ```
       ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="Transfer_Service", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
       ```

       ```
       ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="Transfer_Service", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
       ```
15. 执行**TSF PQUOTA**转移用户配额。

    ```
    TSF PQUOTA: USRIDENTIFIER="46010381012****", QTANAME="Transfer_Quota", TRANSINUSRIDENTIFIER="46010381012****", TRANSINQTANAME="Transfer_Quota", TRANSFERREDVALUE=1536000, STARTDATETIME=2015&01&15&19&18&54, ENDDATETIME=2015&03&15&19&18&56, NOTIFYINDICATION=All;
    ```

    * “TRANSFERREDVALUE”这个参数值必须小于等于配置“配额”时设置的“单次最大转出值”。
    * “NOTIFYINDICATION”取值为“All”表示转入用户和转出用户均能接收消息通知。若只需给一方发送通知，可设置“NOTIFYINDICATION”为“TransIn Only”或“TransOut Only”。

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
