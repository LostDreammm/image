# 基于APN的动态策略控制特性配置（2G/3G）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

当运营商需对2G/3G网络中不同APN（Access Point Name）接入的用户实现不同的策略控制时，UPCF可实现基于单个APN或者APN组定制不同的业务策略，从而对不同APN接入的用户进行差异化控制。

一个APN组由一个或多个APN组成，一个APN组里的多个APN可采用相同的控制策略。

UPCF也支持根据APN和IP地址来唯一标识用户的会话（通过SET BINDCFG命令设置），避免出现不同企业网用户的私网地址重叠，导致IP地址相同的用户上线发生冲突的情况。

以运营商规划公网用户（以公网APN接入的用户）和企业网用户（以企业网APN接入的用户）为例：当用户以公网APN接入时，使用低带宽的控制策略；当用户以企业网APN接入时，使用高带宽的控制策略。具体如表1所示。

**表1** 业务场景

| 用户 | 接入APN | APN组 | 控制策略 |
| --- | --- | --- | --- |
| 公网用户 | APN01 | Internet\_APNList | 上行带宽为500kbit/s，下行带宽为1Mbit/s |
|  | APN02 |  |  |
| A企业网用户 | APN11 | Enterprise\_APNList | 上行带宽为1Mbit/s，下行带宽为2Mbit/s |
| B企业网用户 | APN12 |  |  |

基于APN的动态策略控制特性配置可参考**操作步骤**配置，也可根据实际场景选择业务特性模板配置，业务特性模板的配置过程请参见模板向导。

#### 对系统的影响

本特性对系统无影响。

#### 必备事项

**前提条件**

* 操作员已了解WHFD-611034 基于APN的动态策略控制特性概述。
* PCEF上已配置预定义规则RG\_Internet和RG\_Enterprise。

**数据**

根据应用场景，参考业务拆解总体原则，分解的业务配置关系如图1所示，控制策略在PCEF上配置，UPCF下发对应的预定义规则组名给PCEF。详细解释如表2所示。

**图1** 业务配置关系

**表2** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 业务APNList\_Service | 此业务为一个完整的基于APN的动态策略的业务。 | - |
| 策略Policy\_APNList | 基于APN的策略在用户上线时被调用，触发器为IPCANSessionEstablish。 | - |
| 规则Rule\_Internet | * 条件：携带公网APN上线。 * 预定义组名：RG\_Internet。 | * 当使用用户接入APN类别作为条件时，条件“对象属性”选用对象IPSession下的APNList属性。 * 用户的接入APN通过CCR消息中的Called-Station-ID AVP携带。 * UPCF支持在一个规则中配置多个条件组，各个条件组之间是AND或者OR的关系。 |
| 规则Rule\_Enterprise | * 条件：携带企业网APN（包括A企业网和B企业网）上线。 * 预定义组名：RG\_Enterprise。 |  |

#### 操作流程

此特性的配置流程图如图2所示。

**图2** 业务配置流程图

#### 操作步骤

1. 配置MML。

   当UPCF需要根据用户的IP地址和APN的两者组合标识会话的唯一性时，需要配置此MML（默认不基于APN的IP检查），否则跳过此步骤。

   1. 登录“UPCF MML命令”界面。
   2. 执行**SET BINDCFG**命令，配置参数“IPv4Dnn”或“IPv6Dnn”，用于指定是否基于APN检查用户的IP。

      命令举例：

      ```
      SET BINDCFG: ID=1, IPV4DNN=Support, IPV6DNN=Support;
      ```
2. 修改对端PCEF能力字典项。
   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其不支持R8标准的QoS。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=R8QoS, ABLITYVALUE=UnsupportedR8QoS;
      ```

      在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”需设置为“67”。实际的值可以通过如下方式查询：
      * 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。
      * 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
3. 登录UPCF Web UI界面。
4. 配置APN列表。

   导航入口为“系统配置管理 > 系统配置 > APN列表”。

   需要配置两个APN列表，用于判断接入APN属于企业网列表或公网列表。其中“APN名称”即为用户接入的APN，在CCR消息的Called-Station-ID AVP中携带。

   支持配置APN列表中的APN最大前缀匹配，降低策略配置的复杂度。

   需要配置的数据如表3所示，详细参数说明请参见APN列表参数表。

   **表3** APN列表

   | 列表 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | APN列表1 | 基本信息 | 名称 | Internet\_APNList |
   |  |  | 描述 | 公网用户 |
   |  | APN1 | APN名称 | APN01 |
   |  |  | 描述 | - |
   |  | APN2 | APN名称 | APN02 |
   |  |  | 描述 | - |
   | APN列表2 | 基本信息 | 名称 | Enterprise\_APNList |
   |  |  | 描述 | 企业网用户 |
   |  | APN1 | APN名称 | APN11 |
   |  |  | 描述 | - |
   |  | APN2 | APN名称 | APN12 |
   |  |  | 描述 | - |
5. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置两个条件组，用于判断用户访问公网和企业网。需要配置的数据如表4所示，详细参数说明请参见条件组参数表。

   **表4** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_Internet\_APNList |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_Internet\_APNList |
   |  |  | 对象属性 | * 对象：IPSession * 属性：APNList |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Internet\_APNList |
   | 条件组2 | 基本信息 | 名称 | CG\_Enterprise\_APNList |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_Enterprise\_APNList |
   |  |  | 对象属性 | * 对象：IPSession * 属性：APNList |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Enterprise\_APNList |
6. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   需要配置两组预定义规则组，用于在用户访问公网和企业网时下发不同的预定义规则组。需要配置的数据如表5所示，详细参数说明请参见规则参数表。

   **表5** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | Rule\_Internet |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Predefined Group |
   |  |  | 预定义组名 | RG\_Internet  说明：  已在PCEF侧定义。 |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Internet\_APNList |
   | 规则2 | 基本信息 | 名称 | Rule\_Enterprise |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Predefined Group |
   |  |  | 预定义组名 | RG\_Enterprise  说明：  已在PCEF侧定义。 |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Enterprise\_APNList |
7. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   基于APN的策略控制，只需要在用户上线时匹配下发即可。需要配置的数据如表6所示，详细参数说明请参见策略参数表。

   **表6** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略 | 基本信息 | 名称 | Policy\_APNList |
   |  |  | 触发器 | IPCANSessionEstablish |
   |  | 规则 | 名称 | * Rule\_Internet * Rule\_Enterprise 说明：  已在规则中定义。 |
8. 配置业务。

   导航入口为“业务管理 > 业务 > 业务”。

   需要配置的数据如表7所示，详细参数说明请参见业务参数表。

   完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

   **表7** 业务

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务 | 基本信息 | 名称 | APNList\_Service |
   |  |  | 类型 | VALUE\_ADDED\_SERVICE |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 优先级 | 0 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  |  | 结帐日失效 | 否 |
   |  | 策略 | 名称 | Policy\_APNList  说明：  已在策略中定义。 |
9. 发放业务。

   发放业务有两种方式：一、执行命令逐条增加；二、批处理。

   如下以执行命令逐条增加为例，批处理的详细操作请参考**BAT**。

   1. 登录“UPCF 业务管理”窗口。
   2. 执行**ADD PSUB**增加一个用户。

      “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

      ```
      ADD PSUB:USRIDENTIFIER="46010381012****", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB;
      ```
   3. 执行**ADD PSRV**给用户签约业务。

      ```
      ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="APNList_Service", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
      ```

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
