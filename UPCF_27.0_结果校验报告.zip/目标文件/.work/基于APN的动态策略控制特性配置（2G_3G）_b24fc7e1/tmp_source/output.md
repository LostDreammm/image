---
id: ''
name: 基于APN的动态策略控制特性配置（2G/3G）
ne_type: UPCF
type: feature
description: 当运营商需对2G/3G网络中不同APN（Access Point Name）接入的用户实现不同的策略控制时，UPCF可实现基于单个APN或者APN组定制不同的业务策略，从而对不同APN接入的用户进行差异化控制。  一个APN组由一个或多个APN组成，一个APN组里的多个APN可采用相同的控制策略。  UPCF也支持根据APN和IP地址来唯一标识用户的会话（通过SET BINDCFG命令设置），避免出现不同企业网用户的私网地址重叠，导致IP地址相同的用户上线发生冲突的情况。  以运营商规划公网用户（以公网APN接入的用户）和企业网用户（以企业网APN接入的用户）为例：当用户以公网APN接入时，使用低带宽的控制策略；当用户以企业网APN接入时，使用高带宽的控制策略。具体如表1所示。  **表1** 业务场景  | 用户 | 接入APN | APN组 | 控制策略 | | --- | --- | --- | --- | | 公网用户 | APN01 | Internet\_APNList | 上行带宽为500kbit/s，下行带宽为1Mbit/s | |  | APN02 |  |  | | A企业网用户 | APN11 | Enterprise\_APNList | 上行带宽为1Mbit/s，下行带宽为2Mbit/s | | B企业网用户 | APN12 |  |  |  基于APN的动态策略控制特性配置可参考**操作步骤**配置，也可根据实际场景选择业务特性模板配置，业务特性模板的配置过程请参见模板向导。
risk_level: ''
doc_source: ["特性","特性部署","UPCF基础特性","WHFD-611034 基于APN的动态策略控制","WHFD-611034 基于APN的动态策略控制特性配置","基于APN的动态策略控制特性配置（2G/3G）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当运营商需对2G/3G网络中不同APN（Access Point Name）接入的用户实现不同的策略控制时，UPCF可实现基于单个APN或者APN组定制不同的业务策略，从而对不同APN接入的用户进行差异化控制。一个APN组由一个或多个APN组成，一个APN组里的多个APN可采用相同的控制策略。UPCF也支持根据APN和IP地址来唯一标识用户的会话（通过SET BINDCFG命令设置），避免出现不同企业网用户的私网地址重叠，导致IP地址相同的用户上线发生冲突的情况。以运营商规划公网用户（以公网APN接入的用户）和企业网用户（以企业网APN接入的用户）为例：当用户以公网APN接入时，使用低带宽的控制策略；当用户以企业网APN接入时，使用高带宽的控制策略。具体如表1所示。**表1** 业务场景| 用户 | 接入APN | APN组 | 控制策略 || --- | --- | --- | --- || 公网用户 | APN01 | Internet\_APNList | 上行带宽为500kbit/s，下行带宽为1Mbit/s ||  | APN02 |  |  || A企业网用户 | APN11 | Enterprise\_APNList | 上行带宽为1Mbit/s，下行带宽为2Mbit/s || B企业网用户 | APN12 |  |  |基于APN的动态策略控制特性配置可参考**操作步骤**配置，也可根据实际场景选择业务特性模板配置，业务特性模板的配置过程请参见模板向导。

## 必备事项
前提条件

* 操作员已了解WHFD-611034 基于APN的动态策略控制特性概述。
* PCEF上已配置预定义规则RG\_Internet和RG\_Enterprise。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    is_optional_configure_mml:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '配置MML。'
      data_source: ''
      pattern: ''
      default: TRUE
    set_bindcfg_list:
      type: items
      properties:
        ID:
          name: '类型'
          type: string
          enum:
          - Default
          - Data
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4DNN:
          name: 'IPv4Dnn'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6DNN:
          name: 'IPv6Dnn'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4ADDR:
          name: 'IPv4Addr'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IMSI:
          name: 'IPv4IMSI'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IPDOMAIN:
          name: 'IPv4IPDomain'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MSISDN:
          name: 'IPv4MSISDN'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4PCEFGROUP:
          name: 'IPv4PcefGroup'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IMSI:
          name: 'IPv6IMSI'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IPDOMAIN:
          name: 'IPv6IPDomain'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MSISDN:
          name: 'IPv6MSISDN'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6PCEFGROUP:
          name: 'IPv6PcefGroup'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6PREFIX:
          name: 'IPv6Prefix'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pcefabiitem_list:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - is_optional_configure_mml: TRUE
    set_bindcfg_list:
    - ID: '1'
      IPV4DNN: Support
      IPV6DNN: Support
      IPV4ADDR: ''
      IPV4IMSI: ''
      IPV4IPDOMAIN: ''
      IPV4MSISDN: ''
      IPV4PCEFGROUP: ''
      IPV6IMSI: ''
      IPV6IPDOMAIN: ''
      IPV6MSISDN: ''
      IPV6PCEFGROUP: ''
      IPV6PREFIX: ''
    mod_pcefabiitem_list:
    - ABILITYDICTID: 67
      ABILITYITEMID: R8QoS
      ABLITYVALUE: UnsupportedR8QoS
    add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: '12345678901'
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: MBB
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: APNList_Service
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 配置MML。

### 当UPCF需要根据用户的IP地址和APN的两者组合标识会话的唯一性时，需要配置此MML（默认不基于APN的IP检查），否则跳过此步骤。

#### 1.1 登录“UPCF MML命令”界面。

#### 1.2 执行**SET BINDCFG**命令，配置参数“IPv4Dnn”或“IPv6Dnn”，用于指定是否基于APN检查用户的IP。

#### 命令举例：

```jinja2
{%- if is_optional_configure_mml -%}
    {%- for item in set_bindcfg_list -%}
        SET BINDCFG:
        {#- --- 必选参数 --- -#}
        ID={{item.ID}},
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV4DNN is not none -%}
                IPV4DNN={{item.IPV4DNN}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV6DNN is not none -%}
                IPV6DNN={{item.IPV6DNN}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV4ADDR is not none -%}
                IPV4ADDR={{item.IPV4ADDR}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV4IMSI is not none -%}
                IPV4IMSI={{item.IPV4IMSI}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV4IPDOMAIN is not none -%}
                IPV4IPDOMAIN={{item.IPV4IPDOMAIN}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV4MSISDN is not none -%}
                IPV4MSISDN={{item.IPV4MSISDN}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV4PCEFGROUP is not none -%}
                IPV4PCEFGROUP={{item.IPV4PCEFGROUP}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default 时可选 --- -#}
        {%- if item.ID == 'Default' -%}
            {%- if item.IPV6IMSI is not none -%}
                IPV6IMSI={{item.IPV6IMSI}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV6IPDOMAIN is not none -%}
                IPV6IPDOMAIN={{item.IPV6IPDOMAIN}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default 时可选 --- -#}
        {%- if item.ID == 'Default' -%}
            {%- if item.IPV6MSISDN is not none -%}
                IPV6MSISDN={{item.IPV6MSISDN}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Data 时可选 --- -#}
        {%- if item.ID == 'Data' -%}
            {%- if item.IPV6PCEFGROUP is not none -%}
                IPV6PCEFGROUP={{item.IPV6PCEFGROUP}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：ID=Default/Data 时可选 --- -#}
        {%- if item.ID in ['Default', 'Data'] -%}
            {%- if item.IPV6PREFIX is not none -%}
                IPV6PREFIX={{item.IPV6PREFIX}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 2 修改对端PCEF能力字典项。

#### 2.1 登录“UPCF MML命令”界面。

#### 2.2 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其不支持R8标准的QoS。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”需设置为“67”。实际的值可以通过如下方式查询：

#### 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。

#### 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。

### 3 登录UPCF Web UI界面。

### 4 配置APN列表。

### 导航入口为“系统配置管理 > 系统配置 > APN列表”。

### 需要配置两个APN列表，用于判断接入APN属于企业网列表或公网列表。其中“APN名称”即为用户接入的APN，在CCR消息的Called-Station-ID AVP中携带。

### 支持配置APN列表中的APN最大前缀匹配，降低策略配置的复杂度。

### 需要配置的数据如表3所示，详细参数说明请参见APN列表参数表。

### **表3** APN列表

### | 列表 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | APN列表1 | 基本信息 | 名称 | Internet\_APNList |

### |  |  | 描述 | 公网用户 |

### |  | APN1 | APN名称 | APN01 |

### |  |  | 描述 | - |

### |  | APN2 | APN名称 | APN02 |

### |  |  | 描述 | - |

### | APN列表2 | 基本信息 | 名称 | Enterprise\_APNList |

### |  |  | 描述 | 企业网用户 |

### |  | APN1 | APN名称 | APN11 |

### |  |  | 描述 | - |

### |  | APN2 | APN名称 | APN12 |

### |  |  | 描述 | - |

### 5 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 需要配置两个条件组，用于判断用户访问公网和企业网。需要配置的数据如表4所示，详细参数说明请参见条件组参数表。

### **表4** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | CG\_Internet\_APNList |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_Internet\_APNList |

### |  |  | 对象属性 | * 对象：IPSession * 属性：APNList |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Internet\_APNList |

### | 条件组2 | 基本信息 | 名称 | CG\_Enterprise\_APNList |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_Enterprise\_APNList |

### |  |  | 对象属性 | * 对象：IPSession * 属性：APNList |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Enterprise\_APNList |

### 6 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 需要配置两组预定义规则组，用于在用户访问公网和企业网时下发不同的预定义规则组。需要配置的数据如表5所示，详细参数说明请参见规则参数表。

### **表5** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | Rule\_Internet |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined Group |

### |  |  | 预定义组名 | RG\_Internet  说明：  已在PCEF侧定义。 |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Internet\_APNList |

### | 规则2 | 基本信息 | 名称 | Rule\_Enterprise |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined Group |

### |  |  | 预定义组名 | RG\_Enterprise  说明：  已在PCEF侧定义。 |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Enterprise\_APNList |

### 7 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 基于APN的策略控制，只需要在用户上线时匹配下发即可。需要配置的数据如表6所示，详细参数说明请参见策略参数表。

### **表6** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略 | 基本信息 | 名称 | Policy\_APNList |

### |  |  | 触发器 | IPCANSessionEstablish |

### |  | 规则 | 名称 | * Rule\_Internet * Rule\_Enterprise 说明：  已在规则中定义。 |

### 8 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 需要配置的数据如表7所示，详细参数说明请参见业务参数表。

### 完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

### **表7** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | APNList\_Service |

### |  |  | 类型 | VALUE\_ADDED\_SERVICE |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 优先级 | 0 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  |  | 结帐日失效 | 否 |

### |  | 策略 | 名称 | Policy\_APNList  说明：  已在策略中定义。 |

### 9 发放业务。

### 发放业务有两种方式：一、执行命令逐条增加；二、批处理。

### 如下以执行命令逐条增加为例，批处理的详细操作请参考**BAT**。

#### 9.1 登录“UPCF 业务管理”窗口。

#### 9.2 执行**ADD PSUB**增加一个用户。

#### “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=9.2 -->
```

#### 9.3 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=9.3 -->
```

