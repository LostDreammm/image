# 配置UPCF与PCEF的对接数据

* 操作场景
* 必备事项
* 操作步骤

## 操作场景

UPCF和PCEF（Policy and Charging Enforcement Function）对接的应用场景如下：

* Gx接口的策略控制与授权应用

其中Gx接口的策略控制与授权应用场景的配置说明如下：

* 根据标准符合度不同，UPCF支持对接的设备类型包括：华为GGSN（支持R7/R8标准协议的GGSN、SIG）、ALLOT和GGSN-R9（支持R9标准协议的GGSN）。
* 在多PCEF场景下，UPCF根据对端类别区分下发策略给相应的PCEF，包括GGSN和DPI（Deep Packet Inspection）两种对端类别。

当UPCF通过DRA与PCEF对接，参考配置UPCF与DRA的对接数据。

## 必备事项

前提条件

* 已完成软件安装。
* 已完成基础数据配置。
* PCEF侧已完成基础数据配置。
* UPCF与PCEF的网络连接正常。
* 已经获得运营商规划的UPCF与PCEF的对接IP地址。

数据

配置前规划的对接数据如表1所示。对接数据

**表1** 对接数据规划

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **ADD DLBVPN** | VPNINDEX (VPN索引) | 1 | 本端规划，取值范围内不允许重复。 |
|  | VPNNAME（VPN名称） | VPN\_1 | 全网规划，由运营商提供。 |
| **ADD DLBDEVADDR** | DEVAID （设备地址标识） | 5 | 本端规划，取值范围内不允许重复。 |
|  | VPNINDEX （VPN索引） | 1 | 网元安装完成后，由运营商对已部署的VPN进行统一规划。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，由运营商提供。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | IP （IPV4地址） | 192.168.0.133 | 全网规划，由运营商提供。  当“IPVER”为“IPV4”时，才需要规划和配置IPv4地址。 |
| **ADD PCEFABIDICT** | ABILITYDICTID（能力字典ID） | 0 | 全网规划，需根据运营商实际的业务场景和遵循的协议版本进行规划。 |
|  | ABILITYDICTNAME（能力字典名） | GGSN | 本端规划。 |
| **ADD PPCEF** | PCRFID （PCRF标识） | 1 | 登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。 |
|  | PCEFID (对端PCEF标识) | 0 | 本端规划，取值范围内不允许重复。 |
|  | PN （对端名称） | PCEF0 | 全网规划，由运营商提供。 |
|  | PT （协议类型） | Diameter协议 | 全网规划，由运营商提供。  说明：  当固网用户接入时，此处“协议类型”应选“RADIUS”。 |
|  | DN （对端域名） | PCEF0domain | 全网规划，由运营商提供。 |
|  | HN （对端主机名） | PCEF0host | 全网规划，由运营商提供。 |
|  | SKA （业务保活时长） | 90 | 可使用样例值。  当对端能力有特殊要求时，需要运营商根据实际的业务场景提供。 |
|  | DASWITCH （审计开关） | 打开定时审计 | 可使用样例值。  当对端能力有特殊要求时，需要运营商根据实际的业务场景提供。 |
|  | DATIME （设备间审计时长 ） | 720 | 可使用样例值。  当对端能力有特殊要求时，需要运营商根据实际的业务场景提供。 |
|  | ABILITYDICTID（能力字典标识） | 0 | 登录“UPCF MML命令”界面执行**ADD PCEFABIDICT**命令定义后在此引用。 |
|  | PCEFCAT（对端PCEF类别） | DPI | 登录“UPCF MML命令”界面执行**ADD PPCEFCAT**命令定义后在此引用。  当支持多PCEF时才需要配置该参数。 |
|  | PPCEFGROUP（对端PCEF组） | Group1 | 可使用样例值。  当支持Group分组时才需要配置该参数。 |
| **ADD PPCEFL** | PCRFID （PCRF标识） | 1 | 登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。 |
|  | PCEFID (对端PCEF标识) | 0 | 和**ADD PPCEF**命令的对应参数“PCEFID (对端PCEF标识)”保持一致。 |
|  | LNKID （对端链路标识） | 0 | 本端规划，取值范围内不允许重复。 |
|  | DISPMODE（分发模式） | SpecialQuintuple | 枚举类型：   * 固定五元组转发（SpecialQuintuple） * 知名端口分发（WellKnownPort） |
|  | TPTYPE（传输协议类型） | SCTP | 全网规划，由运营商提供。  说明：  通过RADIUS接入的固网用户接入场景中，此“传输协议类型”为“UDP”。 |
|  | DUALHOME（双归属开关） | ON | 全网规划，由运营商提供。 |
|  | CROSSPATH（交叉路径） | ON | 全网规划，由运营商提供。 |
|  | DIPVER（双归属地址IP版本） | IPV4 | 全网规划，由运营商提供。  当“DIPVER”为“IPV4”时，才会规划：   * 双归属本端IPV4地址 * 本端IPV4地址 * 本地侦听端口 * 双归属对端IPV4地址 * 对端IPV4地址 * 对端端口   当“DIPVER”为“IPV6”时，才会规划：   * 双归属本端IPV6地址 * 本端IPV6地址 * 本地侦听端口 * 双归属对端IPV6地址 * 对端IPV6地址 * 对端端口 |
|  | DLIP（双归属本端IPV4地址） | 192.168.1.133 | 登录“UPCF MML命令”界面执行**ADD DLBDEVADDR**命令定义后，在此引用。  只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划IPV4地址。  当“DUALHOME”为“ON”以及“DIPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | LIP （本端IPV4地址） | 192.168.0.133 | 登录“UPCF MML命令”界面执行**ADD DLBDEVADDR**命令定义后，在此引用。  只有当“DIPVER”为“IPV4”时，才会规划IPv4地址。  当“DIPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | LPT （本地侦听端口） | 1100 | 全网规划，由运营商提供。 |
|  | DPIP（双归属对端IPV4地址） | 192.168.1.10 | 由运营商提供，从对端配置中获取。  只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划IPv4地址。  当“DUALHOME”为“ON”“DIPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | PIP （对端IPV4地址） | 192.168.0.10 | 由运营商提供，从对端配置中获取。  只有当“DIPVER”为“IPV4”时，才会规划IPv4地址。  当“DIPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | PPT （对端端口） | 0 | 由运营商提供，从对端配置中获取。  当对端端口为0时，表示不对对端端口做限制，可以接受对端任意端口的连接。建议将此参数固定配置为“0”。  说明：  当对端网元是华为GGSN时，此参数固定配置为“0”，表示UPCF侧不指定对端网元的端口号。 |
|  | ADSTS （链路管理状态） | ENABLE | 全网规划，由运营商提供。 |
|  | LPTMODE（本地端口模式） | MultiplePorts | 全网规划，由运营商提供。 |
|  | LKSID （链路集标识）  说明：  该参数已废弃。 | 0 | 本端规划，用于标识LKSID实体。 |

## 操作步骤

1. 登录“UPCF MML命令”界面。
2. 执行**ADD DLBVPN**命令增加UPCF与PCEF对接的VPN地址。

   ```
   ADD DLBVPN: VPNINDEX=VPN索引, VPNNAME=VPN名称;
   ```
3. 若UPCF与PCEF对接的IP地址已通过**ADD DLBDEVADDR**增加，则跳过此步骤。

   执行**ADD DLBDEVADDR**命令增加UPCF与PCEF对接的IP地址。以参数“IPVER”值为“IPV4”为例：

   ```
   ADD DLBDEVADDR: DEVAID=设备地址标识, VPNINDEX=VPN索引, IPVER=IPV4, IP=IPV4地址, DESCRIPTION=描述;
   ```
4. 如果对接的设备不是“HuaweiGGSN”或“AllotPCEF”等系统预置数据，则需要配置能力字典。

   如果对接设备不是“协议类型”为“RADIUS”、“工作模式”为“Account”的对端时，则需配置能力字典。

   执行**ADD PCEFABIDICT**命令增加对端PCEF能力字典。

   ```
   ADD PCEFABIDICT: ABILITYDICTID=能力字典ID, ABILITYDICTNAME=能力字典名;
   ```
5. 在链路闪断时，“SKA”参数设置过小会影响业务处理。

   执行**ADD PPCEF**命令增加对端PCEF实体。

   * 在Gx接口策略控制与授权应用景下配置此步骤

     ```
     ADD PPCEF: PCRFID=PCRF标识, PCEFID=对端PCEF标识, PN=对端名称, PT=DIAMETER, DN=对端域名, HN=对端主机名, SKA=业务保活时长, DASWITCH=审计开关, DATIME=设备间审计时长, ABILITYDICTID=能力字典标识, PCEFCAT=对端PCEF类别, PPCEFGROUP=对端PCEF组;
     ```

   上述场景中，UPCF允许配置的最多对端PCEF实体个数通过****VRM\_MAXPCEFNUM****软参来控制。当需要增加的对端PCEF实体个数超过此软参设置值时，可通过**MOD INSP**命令调整该软参以扩大对端PCEF实体个数。调整之后需重启UPCF服务生效。此操作要求在华为工程师的指导下进行。

   参数“PPCEFGROUP（对端PCEF组）”表示对端PCEF的分组信息，用于支持不同对端PCEF组之间IP地址的重用。
6. 执行**ADD PPCEFL**命令增加UPCF与对端PCEF的链路。以参数“IPVER”值为“IPV4”为例：

   * 在Gx接口策略控制与授权应用场景下配置此步骤

     ```
     ADD PPCEFL: PCRFID=PCRF标识, PCEFID=对端PCEF标识, LNKID=对端链路标识, DISPMODE=SpecialQuintuple, TPTYPE=传输协议类型, IPVER=IPV4, LIP=本端IPV4地址, LPT=本地侦听端口, PIP=对端IPV4地址, PPT=对端端口, ADSTS=链路管理状态, LPTMODE=本地端口模式, LKSID=链路集标识;
     ```

   UPCF允许配置的最多对端PCEF链路数通过****VRM\_MAXCONNECTIONPERPCEF****软参来控制。当需要增加的对端PCEF的链路数超过此软参设置值时，可通过**MOD INSP**命令调整该软参以扩大对端PCEF链路数，调整之后需重启UPCF服务生效。此操作要求在华为工程师的指导下操作。

   * 应用场景为Gx接口策略控制与授权应用：“传输协议类型”可任意选择，不需配置“RADIUS服务类型”。
   * 若使用SCTP双归属功能，则“传输协议类型”必须选择“SCTP(流量控制传输协议)”且“双归属开关”值必须为“ON(打开)”。

版权所有 © 华为技术有限公司
