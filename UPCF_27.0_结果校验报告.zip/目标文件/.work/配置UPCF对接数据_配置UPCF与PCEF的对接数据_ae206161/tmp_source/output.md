---
id: ''
name: 配置UPCF与PCEF的对接数据
ne_type: UPCF
type: feature
description: UPCF和PCEF（Policy and Charging Enforcement Function）对接的应用场景如下：  * Gx接口的策略控制与授权应用  其中Gx接口的策略控制与授权应用场景的配置说明如下：  * 根据标准符合度不同，UPCF支持对接的设备类型包括：华为GGSN（支持R7/R8标准协议的GGSN、SIG）、ALLOT和GGSN-R9（支持R9标准协议的GGSN）。 * 在多PCEF场景下，UPCF根据对端类别区分下发策略给相应的PCEF，包括GGSN和DPI（Deep Packet Inspection）两种对端类别。  当UPCF通过DRA与PCEF对接，参考配置UPCF与DRA的对接数据。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（SDN）","配置UPCF对接数据","配置UPCF与PCEF的对接数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UPCF和PCEF（Policy and Charging Enforcement Function）对接的应用场景如下：* Gx接口的策略控制与授权应用其中Gx接口的策略控制与授权应用场景的配置说明如下：* 根据标准符合度不同，UPCF支持对接的设备类型包括：华为GGSN（支持R7/R8标准协议的GGSN、SIG）、ALLOT和GGSN-R9（支持R9标准协议的GGSN）。* 在多PCEF场景下，UPCF根据对端类别区分下发策略给相应的PCEF，包括GGSN和DPI（Deep Packet Inspection）两种对端类别。当UPCF通过DRA与PCEF对接，参考配置UPCF与DRA的对接数据。

## 必备事项
前提条件

* 已完成软件安装。
* 已完成基础数据配置。
* PCEF侧已完成基础数据配置。
* UPCF与PCEF的网络连接正常。
* 已经获得运营商规划的UPCF与PCEF的对接IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_dlbvpn_list:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 31
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    add_dlbdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '网元安装完成后，由运营商对已部署的VPN进行统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。 只有当“IPVER”为“IPV4”时，才会规划IPv4地址。 当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划，由运营商提供。 当“IPVER”为“IPV4”时，才需要规划和配置IPv4地址。'
          data_source: ''
          pattern: ''
          default: ''
        DESCRIPTION:
          name: '描述'
          type: string
          minLength: 0
          maxLength: 32
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pcefabidict_list:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: '全网规划，需根据运营商实际的业务场景和遵循的协议版本进行规划。'
          data_source: ''
          pattern: ''
          default: ''
        ABILITYDICTNAME:
          name: '能力字典名'
          type: string
          minLength: 0
          maxLength: 32
          required: true
          description: '本端规划。'
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_gx_policy_control:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '在Gx接口策略控制与授权应用景下配置此步骤'
      data_source: ''
      pattern: ''
      default: TRUE
    add_ppcef_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: '登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        PCEFID:
          name: '对端PCEF标识'
          type: integer
          minimum: 0
          maximum: 1023
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        PN:
          name: '对端名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        PT:
          name: '协议类型'
          type: string
          enum:
          - DIAMETER
          required: true
          description: '全网规划，由运营商提供。 说明： 当固网用户接入时，此处“协议类型”应选“RADIUS”。'
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '对端域名'
          type: string
          minLength: 0
          maxLength: 64
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '对端主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        SKA:
          name: '业务保活时长'
          type: integer
          minimum: 0
          maximum: 3600
          required: false
          description: '可使用样例值。 当对端能力有特殊要求时，需要运营商根据实际的业务场景提供。'
          data_source: ''
          pattern: ''
          default: 90@90
        DASWITCH:
          name: '审计开关'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: '可使用样例值。 当对端能力有特殊要求时，需要运营商根据实际的业务场景提供。'
          data_source: ''
          pattern: ''
          default: ''
        DATIME:
          name: '设备间审计时长'
          type: integer
          minimum: 720
          maximum: 1440
          required: false
          description: '可使用样例值。 当对端能力有特殊要求时，需要运营商根据实际的业务场景提供。'
          data_source: ''
          pattern: ''
          default: ''
        ABILITYDICTID:
          name: '能力字典标识'
          type: integer
          minimum: 0
          maximum: 127
          required: false
          description: '登录“UPCF MML命令”界面执行**ADD PCEFABIDICT**命令定义后在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        PCEFCAT:
          name: '对端PCEF类别'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '登录“UPCF MML命令”界面执行**ADD PPCEFCAT**命令定义后在此引用。 当支持多PCEF时才需要配置该参数。'
          data_source: ''
          pattern: ''
          default: ''
        PPCEFGROUP:
          name: '对端PCEF组'
          type: string
          enum:
          - 'NULL'
          - Group1
          - Group2
          - Group3
          - Group4
          - Group5
          - Group6
          - Group7
          - Group8
          - Group9
          - Group10
          - Group11
          - Group12
          - Group13
          - Group14
          - Group15
          - Group16
          - Group17
          - Group18
          - Group19
          - Group20
          - Group21
          - Group22
          - Group23
          - Group24
          - Group25
          - Group26
          - Group27
          - Group28
          - Group29
          - Group30
          - Group31
          - Group32
          - Group33
          - Group34
          - Group35
          - Group36
          - Group37
          - Group38
          - Group39
          - Group40
          - Group41
          - Group42
          - Group43
          - Group44
          - Group45
          - Group46
          - Group47
          - Group48
          - Group49
          - Group50
          - Group51
          - Group52
          - Group53
          - Group54
          - Group55
          - Group56
          - Group57
          - Group58
          - Group59
          - Group60
          - Group61
          - Group62
          - Group63
          - Group64
          required: false
          description: '可使用样例值。 当支持Group分组时才需要配置该参数。'
          data_source: ''
          pattern: ''
          default: ''
    add_ppcefl_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: '登录“UPCF MML命令”界面执行**ADD PCRF**命令定义后，在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        PCEFID:
          name: '对端PCEF标识'
          type: integer
          minimum: 0
          maximum: 1023
          required: true
          description: '和**ADD PPCEF**命令的对应参数“PCEFID (对端PCEF标识)”保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        LNKID:
          name: '对端链路标识'
          type: integer
          minimum: 0
          maximum: 3
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        DISPMODE:
          name: '分发模式'
          type: string
          enum:
          - SpecialQuintuple
          - WellKnownPort
          required: true
          description: '枚举类型： * 固定五元组转发（SpecialQuintuple） * 知名端口分发（WellKnownPort）'
          data_source: ''
          pattern: ''
          default: ''
        TPTYPE:
          name: '传输协议类型'
          type: string
          enum:
          - SCTP
          - TCP
          required: true
          description: '全网规划，由运营商提供。 说明： 通过RADIUS接入的固网用户接入场景中，此“传输协议类型”为“UDP”。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LIP:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '登录“UPCF MML命令”界面执行**ADD DLBDEVADDR**命令定义后，在此引用。 只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划IPV4地址。 当“DUALHOME”为“ON”以及“DIPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        LPT:
          name: '本地侦听端口'
          type: integer
          minimum: 1
          maximum: 65534
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        PIP:
          name: '对端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商提供，从对端配置中获取。 只有当“DIPVER”为“IPV4”时，才会规划IPv4地址。 当“DIPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        PPT:
          name: '对端端口'
          type: integer
          minimum: 0
          maximum: 65534
          required: true
          description: '由运营商提供，从对端配置中获取。 当对端端口为0时，表示不对对端端口做限制，可以接受对端任意端口的连接。建议将此参数固定配置为“0”。 说明： 当对端网元是华为GGSN时，此参数固定配置为“0”，表示UPCF侧不指定对端网元的端口号。'
          data_source: ''
          pattern: ''
          default: ''
        ADSTS:
          name: '链路管理状态'
          type: string
          enum:
          - DISABLE
          - ENABLE
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ENABLE
        LPTMODE:
          name: '本地端口模式'
          type: string
          enum:
          - WellKnownPort
          - MultiplePorts
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: MultiplePorts
        LKSID:
          name: '链路集标识'
          type: integer
          minimum: 0
          maximum: 511
          required: false
          description: '本端规划，用于标识LKSID实体。'
          data_source: ''
          pattern: ''
          default: ''
        DUALHOME:
          name: '双归属开关'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        CROSSPATH:
          name: '交叉路径'
          type: string
          enum:
          - ON
          - OFF
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: OFF
        DIPVER:
          name: '双归属地址IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: '全网规划，由运营商提供。 当“DIPVER”为“IPV4”时，才会规划： * 双归属本端IPV4地址 * 本端IPV4地址 * 本地侦听端口 * 双归属对端IPV4地址 * 对端IPV4地址 * 对端端口 当“DIPVER”为“IPV6”时，才会规划： * 双归属本端IPV6地址 * 本端IPV6地址 * 本地侦听端口 * 双归属对端IPV6地址 * 对端IPV6地址 * 对端端口'
          data_source: ''
          pattern: ''
          default: ''
        DLIP:
          name: '双归属本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '登录“UPCF MML命令”界面执行**ADD DLBDEVADDR**命令定义后，在此引用。 只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划IPV4地址。 当“DUALHOME”为“ON”以及“DIPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        DPIP:
          name: '双归属对端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商提供，从对端配置中获取。 只有当“DUALHOME”为“ON”以及“DIPVER”为“IPV4”时，才会规划IPv4地址。 当“DUALHOME”为“ON”“DIPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        DLIPV6:
          name: '双归属本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DPIPV6:
          name: '双归属对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LIPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PIPV6:
          name: '对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_dlbvpn_list:
    - VPNINDEX: 1
      VPNNAME: 'VPN_1'
    add_dlbdevaddr_list:
    - DEVAID: 5
      VPNINDEX: 1
      IPVER: IPV4
      IP: '192.168.0.133'
      DESCRIPTION: '描述'
      IPV6: ''
    add_pcefabidict_list:
    - ABILITYDICTID: 0
      ABILITYDICTNAME: 'GGSN'
    is_scenario_gx_policy_control: TRUE
    add_ppcef_list:
    - PCRFID: 1
      PCEFID: 0
      PN: 'PCEF0'
      PT: DIAMETER
      DN: 'PCEF0domain'
      HN: 'PCEF0host'
      SKA: 90
      DASWITCH: 打开定时审计
      DATIME: 720
      ABILITYDICTID: 0
      PCEFCAT: 'DPI'
      PPCEFGROUP: Group1
    add_ppcefl_list:
    - PCRFID: 1
      PCEFID: 0
      LNKID: 0
      DISPMODE: SpecialQuintuple
      TPTYPE: SCTP
      IPVER: IPV4
      LIP: '192.168.0.133'
      LPT: 1100
      PIP: '192.168.0.10'
      PPT: 0
      ADSTS: ENABLE
      LPTMODE: MultiplePorts
      LKSID: 0
      DUALHOME: ON
      CROSSPATH: ON
      DIPVER: IPV4
      DLIP: '192.168.1.133'
      DPIP: '192.168.1.10'
      DLIPV6: ''
      DPIPV6: ''
      LIPV6: ''
      PIPV6: ''
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录“UPCF MML命令”界面。

### 2 执行**ADD DLBVPN**命令增加UPCF与PCEF对接的VPN地址。

```jinja2
{%- for item in add_dlbvpn_list -%}
    ADD DLBVPN:
    {#- --- 必选参数 --- -#}
    VPNINDEX={{item.VPNINDEX}},
    VPNNAME="{{item.VPNNAME}}",
    ;
{%- endfor -%}
```

### 3 若UPCF与PCEF对接的IP地址已通过**ADD DLBDEVADDR**增加，则跳过此步骤。

### 执行**ADD DLBDEVADDR**命令增加UPCF与PCEF对接的IP地址。以参数“IPVER”值为“IPV4”为例：

```jinja2
{%- for item in add_dlbdevaddr_list -%}
    ADD DLBDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNINDEX={{item.VPNINDEX}},
    IPVER={{item.IPVER}},
    {#- --- 可选参数 --- -#}
    {%- if item.DESCRIPTION is not none -%}
        DESCRIPTION="{{item.DESCRIPTION}}",
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 4 如果对接的设备不是“HuaweiGGSN”或“AllotPCEF”等系统预置数据，则需要配置能力字典。

### 如果对接设备不是“协议类型”为“RADIUS”、“工作模式”为“Account”的对端时，则需配置能力字典。

### 执行**ADD PCEFABIDICT**命令增加对端PCEF能力字典。

```jinja2
{%- for item in add_pcefabidict_list -%}
    ADD PCEFABIDICT:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYDICTNAME="{{item.ABILITYDICTNAME}}",
    ;
{%- endfor -%}
```

### 5 在链路闪断时，“SKA”参数设置过小会影响业务处理。

### 执行**ADD PPCEF**命令增加对端PCEF实体。

#### 5.1 在Gx接口策略控制与授权应用景下配置此步骤

```jinja2
{%- if is_scenario_gx_policy_control -%}
    {%- for item in add_ppcef_list -%}
        ADD PPCEF:
        {#- --- 必选参数 --- -#}
        PCRFID={{item.PCRFID}},
        PCEFID={{item.PCEFID}},
        PT={{item.PT}},
        HN="{{item.HN}}",
        {#- --- 可选参数 --- -#}
        {%- if item.PN is not none -%}
            PN="{{item.PN}}",
        {%- endif -%}
        {%- if item.PCEFCAT is not none -%}
            PCEFCAT="{{item.PCEFCAT}}",
        {%- endif -%}
        {%- if item.PPCEFGROUP is not none -%}
            PPCEFGROUP={{item.PPCEFGROUP}},
        {%- endif -%}
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：PT=DIAMETER 时必选 --- -#}
        {%- if item.PT == 'DIAMETER' -%}
            DN="{{item.DN}}",
        {%- endif -%}
        {#- --- 条件必选：DASWITCH=ON 时必选 --- -#}
        {%- if item.DASWITCH == 'ON' -%}
            DATIME={{item.DATIME}},
        {%- endif -%}
        {#- --- 条件必选：PT=DIAMETER 时必选 --- -#}
        {%- if item.PT == 'DIAMETER' -%}
            ABILITYDICTID={{item.ABILITYDICTID}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：PT=DIAMETER 时可选 --- -#}
        {%- if item.PT == 'DIAMETER' -%}
            {%- if item.SKA is not none -%}
                SKA={{item.SKA}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：PT=DIAMETER 时可选 --- -#}
        {%- if item.PT == 'DIAMETER' -%}
            {%- if item.DASWITCH is not none -%}
                DASWITCH={{item.DASWITCH}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 上述场景中，UPCF允许配置的最多对端PCEF实体个数通过****VRM\_MAXPCEFNUM****软参来控制。当需要增加的对端PCEF实体个数超过此软参设置值时，可通过**MOD INSP**命令调整该软参以扩大对端PCEF实体个数。调整之后需重启UPCF服务生效。此操作要求在华为工程师的指导下进行。

#### 参数“PPCEFGROUP（对端PCEF组）”表示对端PCEF的分组信息，用于支持不同对端PCEF组之间IP地址的重用。

### 6 执行**ADD PPCEFL**命令增加UPCF与对端PCEF的链路。以参数“IPVER”值为“IPV4”为例：

#### 6.1 在Gx接口策略控制与授权应用场景下配置此步骤

```jinja2
{%- if is_scenario_gx_policy_control -%}
    {%- for item in add_ppcefl_list -%}
        ADD PPCEFL:
        {#- --- 必选参数 --- -#}
        PCRFID={{item.PCRFID}},
        PCEFID={{item.PCEFID}},
        LNKID={{item.LNKID}},
        DISPMODE={{item.DISPMODE}},
        TPTYPE={{item.TPTYPE}},
        PPT={{item.PPT}},
        {#- --- 可选参数 --- -#}
        {%- if item.ADSTS is not none -%}
            ADSTS={{item.ADSTS}},
        {%- endif -%}
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：TPTYPE=TCP 时必选 --- -#}
        {%- if item.TPTYPE == 'TCP' -%}
            IPVER={{item.IPVER}},
        {#- --- 条件必选：DUALHOME=OFF 时必选 --- -#}
        {%- elif item.DUALHOME == 'OFF' -%}
            IPVER={{item.IPVER}},
        {%- endif -%}
        {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
        {%- if item.DIPVER == 'IPV4' -%}
            LIP="{{item.LIP}}",
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- elif item.IPVER == 'IPV4' -%}
            LIP="{{item.LIP}}",
        {%- endif -%}
        {#- --- 条件必选：DISPMODE=SpecialQuintuple 时必选 --- -#}
        {%- if item.DISPMODE == 'SpecialQuintuple' -%}
            LPT={{item.LPT}},
        {%- endif -%}
        {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
        {%- if item.DIPVER == 'IPV4' -%}
            PIP="{{item.PIP}}",
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- elif item.IPVER == 'IPV4' -%}
            PIP="{{item.PIP}}",
        {%- endif -%}
        {#- --- 条件必选：DUALHOME=ON 时必选 --- -#}
        {%- if item.DUALHOME == 'ON' -%}
            DIPVER={{item.DIPVER}},
        {%- endif -%}
        {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
        {%- if item.DIPVER == 'IPV4' -%}
            DLIP="{{item.DLIP}}",
        {%- endif -%}
        {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
        {%- if item.DIPVER == 'IPV6' -%}
            DLIPV6="{{item.DLIPV6}}",
        {%- endif -%}
        {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
        {%- if item.DIPVER == 'IPV4' -%}
            DPIP="{{item.DPIP}}",
        {%- endif -%}
        {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
        {%- if item.DIPVER == 'IPV6' -%}
            DPIPV6="{{item.DPIPV6}}",
        {%- endif -%}
        {#- --- 条件必选：TPTYPE=SCTP 时必选 --- -#}
        {%- if item.TPTYPE == 'SCTP' -%}
            DUALHOME={{item.DUALHOME}},
        {%- endif -%}
        {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
        {%- if item.DIPVER == 'IPV6' -%}
            LIPV6="{{item.LIPV6}}",
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- elif item.IPVER == 'IPV6' -%}
            LIPV6="{{item.LIPV6}}",
        {%- endif -%}
        {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
        {%- if item.DIPVER == 'IPV6' -%}
            PIPV6="{{item.PIPV6}}",
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- elif item.IPVER == 'IPV6' -%}
            PIPV6="{{item.PIPV6}}",
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：DISPMODE=SpecialQuintuple 时可选 --- -#}
        {%- if item.DISPMODE == 'SpecialQuintuple' -%}
            {%- if item.LPTMODE is not none -%}
                LPTMODE={{item.LPTMODE}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：DISPMODE=SpecialQuintuple 时可选 --- -#}
        {%- if item.DISPMODE == 'SpecialQuintuple' -%}
            {%- if item.LKSID is not none -%}
                LKSID={{item.LKSID}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：DUALHOME=ON 时可选 --- -#}
        {%- if item.DUALHOME == 'ON' -%}
            {%- if item.CROSSPATH is not none -%}
                CROSSPATH={{item.CROSSPATH}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### UPCF允许配置的最多对端PCEF链路数通过****VRM\_MAXCONNECTIONPERPCEF****软参来控制。当需要增加的对端PCEF的链路数超过此软参设置值时，可通过**MOD INSP**命令调整该软参以扩大对端PCEF链路数，调整之后需重启UPCF服务生效。此操作要求在华为工程师的指导下操作。

#### 应用场景为Gx接口策略控制与授权应用：“传输协议类型”可任意选择，不需配置“RADIUS服务类型”。

#### 若使用SCTP双归属功能，则“传输协议类型”必须选择“SCTP(流量控制传输协议)”且“双归属开关”值必须为“ON(打开)”。

