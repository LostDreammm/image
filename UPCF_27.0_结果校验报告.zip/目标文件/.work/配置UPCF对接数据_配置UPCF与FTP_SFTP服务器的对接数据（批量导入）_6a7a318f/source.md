# 配置UPCF与FTP/SFTP服务器的对接数据（批量导入）

* 操作场景
* 必备事项
* 操作步骤
* 验证方法

## 操作场景

用于维护局点，当需要批量导入区域、服务区等策略信息时，需要配置UPCF与FTP/SFTP服务器的对接数据。

## 必备事项

前提条件

* 已完成软件安装。
* 已获取网元的模块配置信息，详细请参见获取网元的模块配置信息。
* 已完成基础数据配置。
* UPCF与FTP/SFTP服务器的网络连接正常。
* 已经获得运营商规划的UPCF与FTP/SFTP服务器的对接IP地址。

数据

配置前规划的对接数据如表1所示。

**表1** 对接数据

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **ADD PMSVPN** | VPNINDEX (VPN索引) | 20 | 本端规划，取值范围内不允许重复。 |
|  | VPNNAME（VPN名称） | VPN\_20 | 全网规划，由运营商提供。 |
| **ADD PMSDEVADDR** | DEVAID （设备地址标识） | 1 | 本端规划，取值范围内不允许重复。 |
|  | VPNINDEX (VPN索引) | 20 | 执行**ADD PMSVPN**命令定义后，在此引用。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，由运营商提供。 |
|  | IP （IPV4地址） | 192.168.0.132 | 全网规划，由运营商提供。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | DESCRIPTION（描述） | for FTP/SFTP | 本端规划。  当运营商需要补充IP的用途时，由运营商提供。 |
| **ADD PMSPEER** | PEERID (对端服务器ID) | 8 | 本端规划，取值范围内不允许重复。 |
|  | PEERNAME (对端服务器名称) | FTPServer | 本端规划。 |
|  | PEERTYPE (对端服务器类型) | SFTP | 全网规划，由运营商提供。 |
| **ADD PMSPEERLINKCFG** | LINKID (链路ID) | 9 | 本端规划，取值范围内不允许重复。 |
|  | PEERID (对端服务器ID) | 8 | 执行**ADD PMSPEER**命令定义后，在此引用。 |
|  | LOCALROLE (本地角色) | FTPClient | 全网规划，由运营商提供。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，由运营商提供。 |
|  | LOCALIP（本地IP地址） | 10.185.208.111 | 全网规划，由运营商提供。 |
|  | PEERIP (对端IP地址) | 10.185.208.116 | 由运营商提供，从对端配置中获取。 |
|  | PEERPORT (对端端口) | 32117 | 由运营商提供，从对端配置中获取。 |
|  | USRNAME（用户名） | upcf | 全网规划，由运营商提供。 |
|  | PASSWD（密码） | Huawei10! | 全网规划，由运营商提供。 |
|  | CFM（确认密码） | Huawei10! | 此参数取值应和“密码”取值保持一致。 |
|  | ADSTS（链路管理状态） | ENABLE | 全网规划，由运营商提供。 |

## 操作步骤

1. 在OM Portal界面选择“应用管理 > MML”，进入MML命令界面，并选择UPCF网元。
2. 执行**ADD PMSVPN**命令增加UPCF与FTP/SFTP服务器对接的VPN地址。

   ```
   ADD PMSVPN: VPNINDEX=VPN索引, VPNNAME=VPN名称;
   ```
3. 执行**ADD PMSDEVADDR**命令增加UPCF与FTP/SFTP服务器对接的IP地址。

   以参数“IPVER”值为“IPV4”为例：

   ```
   ADD PMSDEVADDR: DEVAID=设备地址标识, VPNINDEX=VPN索引, IPVER=IPV4, IP=IPV4地址, DESCRIPTION=描述;
   ```
4. 执行**ADD PMSPEER**命令增加UPCF作为客户端与FTP/SFTP服务器对接的一条实体记录。

   ```
   ADD PMSPEER: PEERID=对端服务器ID, PEERNAME=对端服务器名称, PEERTYPE=SFTP;
   ```
5. 执行**ADD PMSPEERLINKCFG**命令增加UPCF与FTP/SFTP服务器对接的链路信息。

   ```
   ADD PMSPEERLINKCFG: LINKID=链路ID, PEERID=对端服务器ID, LOCALROLE=FTPClient, IPVER=IP版本,LOCALIP=本地IP地址, PEERIP=对端IP地址, PEERPORT=对端端口, USRNAME=用户名, PASSWD=密码, CFM=确认密码, ADSTS=链路管理状态;
   ```

   UPCF与FTP/SFTP服务器对接时，配置参数如下：

   * 参数“Link ID(链路ID)”包含4条系统缺省配置记录，所以此对接链路从“4”开始根据规划值进行配置。
   * 参数“LOCALROLE（本端角色）”选择“FTPClient（FTP客户端）”。

## 验证方法

在FTP/SFTP服务器上，使用**ping**命令检查UPCF与FTP/SFTP服务器联通情况是否正常。

* 是 => 检查完成。
* 否 => 检查是否能够通过FTP/SFTP服务器登录UPCF。如果不能，请联系华为技术支持。

版权所有 © 华为技术有限公司
