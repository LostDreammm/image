---
id: ''
name: 配置UPCF与FTP/SFTP服务器的对接数据（批量导入）
ne_type: UPCF
type: feature
description: 用于维护局点，当需要批量导入区域、服务区等策略信息时，需要配置UPCF与FTP/SFTP服务器的对接数据。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（非SDN）","配置UPCF对接数据","配置UPCF与FTP/SFTP服务器的对接数据（批量导入）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
用于维护局点，当需要批量导入区域、服务区等策略信息时，需要配置UPCF与FTP/SFTP服务器的对接数据。

## 必备事项
前提条件

* 已完成软件安装。
* 已获取网元的模块配置信息，详细请参见获取网元的模块配置信息。
* 已完成基础数据配置。
* UPCF与FTP/SFTP服务器的网络连接正常。
* 已经获得运营商规划的UPCF与FTP/SFTP服务器的对接IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_pmsvpn_list:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 32
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    add_pmsdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '执行**ADD PMSVPN**命令定义后，在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划，由运营商提供。 只有当“IPVER”为“IPV4”时，才会规划IPv4地址。 当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        DESCRIPTION:
          name: '描述'
          type: string
          minLength: 0
          maxLength: 32
          required: false
          description: '本端规划。 当运营商需要补充IP的用途时，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pmspeer_list:
      type: items
      properties:
        PEERID:
          name: '对端服务器ID'
          type: integer
          minimum: 1
          maximum: 255
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        PEERNAME:
          name: '对端服务器名称'
          type: string
          minLength: 0
          maxLength: 128
          required: true
          description: '本端规划。'
          data_source: ''
          pattern: ''
          default: ''
        PEERTYPE:
          name: '对端服务器类型'
          type: string
          enum:
          - FTP
          - SFTP
          - SOAP
          - REST
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    add_pmspeerlinkcfg_list:
      type: items
      properties:
        LINKID:
          name: '链路ID'
          type: integer
          minimum: 1
          maximum: 255
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        PEERID:
          name: '对端服务器ID'
          type: integer
          minimum: 1
          maximum: 255
          required: true
          description: '执行**ADD PMSPEER**命令定义后，在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        LOCALROLE:
          name: '本地角色'
          type: string
          enum:
          - SOAPClient
          - FTPClient
          - POPFTPClient
          - PMS4AClient
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        LOCALIP:
          name: '本地IP地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        PEERIP:
          name: '对端IP地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商提供，从对端配置中获取。'
          data_source: ''
          pattern: ''
          default: ''
        PEERPORT:
          name: '对端端口'
          type: integer
          minimum: 1
          maximum: 65534
          required: true
          description: '由运营商提供，从对端配置中获取。'
          data_source: ''
          pattern: ''
          default: ''
        USRNAME:
          name: '用户名'
          type: string
          minLength: 0
          maxLength: 96
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        PASSWD:
          name: '密码'
          type: string
          minLength: 1
          maxLength: 32
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        CFM:
          name: '确认密码'
          type: string
          minLength: 1
          maxLength: 32
          required: false
          description: '此参数取值应和“密码”取值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        ADSTS:
          name: '链路管理状态'
          type: string
          enum:
          - DISABLE
          - ENABLE
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        WSDL:
          name: 'WSDL文件'
          type: string
          enum:
          - PPMSOAP
          - POP
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LOCALIPV6:
          name: '本地IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PEERIPV6:
          name: '对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CERTSCENE:
          name: '证书应用场景'
          type: string
          enum:
          - UPCF_PMS_certForPOPSOAP
          - 'NULL'
          - UPCF_PMS_certFor4A
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FTPLOGPATH:
          name: 'FTP服务器日志路径'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LOGONURL:
          name: '认证服务器URL'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TLSCFGID:
          name: 'TLS配置ID'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        URLPREFIX:
          name: 'URL前缀'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_pmsvpn_list:
    - VPNINDEX: 20
      VPNNAME: 'VPN_20'
    add_pmsdevaddr_list:
    - DEVAID: 1
      VPNINDEX: 20
      IPVER: IPV4
      IP: '192.168.0.132'
      DESCRIPTION: 'for FTP/SFTP'
      IPV6: ''
    add_pmspeer_list:
    - PEERID: 8
      PEERNAME: 'FTPServer'
      PEERTYPE: SFTP
    add_pmspeerlinkcfg_list:
    - LINKID: 9
      PEERID: 8
      LOCALROLE: FTPClient
      IPVER: IPV4
      LOCALIP: '10.185.208.111'
      PEERIP: '10.185.208.116'
      PEERPORT: 32117
      USRNAME: 'upcf'
      PASSWD: 'Huawei10!'
      CFM: 'Huawei10!'
      ADSTS: ENABLE
      WSDL: ''
      LOCALIPV6: ''
      PEERIPV6: ''
      CERTSCENE: ''
      FTPLOGPATH: ''
      LOGONURL: ''
      TLSCFGID: ''
      URLPREFIX: ''
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 在OM Portal界面选择“应用管理 > MML”，进入MML命令界面，并选择UPCF网元。

### 2 执行**ADD PMSVPN**命令增加UPCF与FTP/SFTP服务器对接的VPN地址。

```jinja2
{%- for item in add_pmsvpn_list -%}
    ADD PMSVPN:
    {#- --- 必选参数 --- -#}
    VPNINDEX={{item.VPNINDEX}},
    VPNNAME="{{item.VPNNAME}}",
    ;
{%- endfor -%}
```

### 3 执行**ADD PMSDEVADDR**命令增加UPCF与FTP/SFTP服务器对接的IP地址。

### 以参数“IPVER”值为“IPV4”为例：

```jinja2
{%- for item in add_pmsdevaddr_list -%}
    ADD PMSDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNINDEX={{item.VPNINDEX}},
    IPVER={{item.IPVER}},
    {#- --- 可选参数 --- -#}
    {%- if item.DESCRIPTION is not none -%}
        DESCRIPTION="{{item.DESCRIPTION}}",
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 4 执行**ADD PMSPEER**命令增加UPCF作为客户端与FTP/SFTP服务器对接的一条实体记录。

```jinja2
{%- for item in add_pmspeer_list -%}
    ADD PMSPEER:
    {#- --- 必选参数 --- -#}
    PEERID={{item.PEERID}},
    PEERNAME="{{item.PEERNAME}}",
    PEERTYPE={{item.PEERTYPE}},
    ;
{%- endfor -%}
```

### 5 执行**ADD PMSPEERLINKCFG**命令增加UPCF与FTP/SFTP服务器对接的链路信息。

```jinja2
{%- for item in add_pmspeerlinkcfg_list -%}
    ADD PMSPEERLINKCFG:
    {#- --- 必选参数 --- -#}
    LINKID={{item.LINKID}},
    PEERID={{item.PEERID}},
    LOCALROLE={{item.LOCALROLE}},
    IPVER={{item.IPVER}},
    PEERPORT={{item.PEERPORT}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        LOCALIP="{{item.LOCALIP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        PEERIP="{{item.PEERIP}}",
    {%- endif -%}
    {#- --- 条件必选：LOCALROLE=FTPClient/POPFTPClient 时必选 --- -#}
    {%- if item.LOCALROLE in ['FTPClient', 'POPFTPClient'] -%}
        ADSTS={{item.ADSTS}},
    {%- endif -%}
    {#- --- 条件必选：LOCALROLE=POPFTPClient 时必选 --- -#}
    {%- if item.LOCALROLE == 'POPFTPClient' -%}
        FTPLOGPATH="{{item.FTPLOGPATH}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        LOCALIPV6="{{item.LOCALIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：LOCALROLE=PMS4AClient 时必选 --- -#}
    {%- if item.LOCALROLE == 'PMS4AClient' -%}
        LOGONURL="{{item.LOGONURL}}",
    {#- --- 条件必选：WSDL=POP 时必选 --- -#}
    {%- elif item.WSDL == 'POP' -%}
        LOGONURL="{{item.LOGONURL}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        PEERIPV6="{{item.PEERIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：LOCALROLE=SOAPClient 时必选 --- -#}
    {%- if item.LOCALROLE == 'SOAPClient' -%}
        WSDL={{item.WSDL}},
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：LOCALROLE=PMS4AClient 时可选 --- -#}
    {%- if item.LOCALROLE == 'PMS4AClient' -%}
        {%- if item.URLPREFIX is not none -%}
            URLPREFIX="{{item.URLPREFIX}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件必选/可选参数 --- -#}
    {#- --- 用户名: 条件必选(本地角色=FTPClient|POPFTPClient) / 条件可选(WSDL文件=POP) --- -#}
    {%- if (item.LOCALROLE in ['FTPClient', 'POPFTPClient']) -%}
        USRNAME="{{item.USRNAME}}",
    {%- elif (item.WSDL == 'POP') -%}
        {%- if item.USRNAME is not none -%}
            USRNAME="{{item.USRNAME}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 密码: 条件必选(本地角色=FTPClient|POPFTPClient) / 条件可选(WSDL文件=POP) --- -#}
    {%- if (item.LOCALROLE in ['FTPClient', 'POPFTPClient']) -%}
        PASSWD="{{item.PASSWD}}",
    {%- elif (item.WSDL == 'POP') -%}
        {%- if item.PASSWD is not none -%}
            PASSWD="{{item.PASSWD}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 确认密码: 条件必选(本地角色=FTPClient|POPFTPClient) / 条件可选(WSDL文件=POP) --- -#}
    {%- if (item.LOCALROLE in ['FTPClient', 'POPFTPClient']) -%}
        CFM="{{item.CFM}}",
    {%- elif (item.WSDL == 'POP') -%}
        {%- if item.CFM is not none -%}
            CFM="{{item.CFM}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 证书应用场景: 条件必选(本地角色=PMS4AClient) / 条件可选(WSDL文件=POP) --- -#}
    {%- if (item.LOCALROLE == 'PMS4AClient') -%}
        CERTSCENE={{item.CERTSCENE}},
    {%- elif (item.WSDL == 'POP') -%}
        {%- if item.CERTSCENE is not none -%}
            CERTSCENE={{item.CERTSCENE}},
        {%- endif -%}
    {%- endif -%}
    {#- --- TLS配置ID: 条件必选(本地角色=PMS4AClient) / 条件可选(WSDL文件=POP|PPMSOAP) --- -#}
    {%- if (item.LOCALROLE == 'PMS4AClient') -%}
        TLSCFGID={{item.TLSCFGID}},
    {%- elif (item.WSDL in ['POP', 'PPMSOAP']) -%}
        {%- if item.TLSCFGID is not none -%}
            TLSCFGID={{item.TLSCFGID}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### UPCF与FTP/SFTP服务器对接时，配置参数如下：

### 参数“Link ID(链路ID)”包含4条系统缺省配置记录，所以此对接链路从“4”开始根据规划值进行配置。

### 参数“LOCALROLE（本端角色）”选择“FTPClient（FTP客户端）”。

