---
id: ''
name: 配置会话备份和恢复数据实例
ne_type: UPCF
type: feature
description: 该任务指导工程师通过OM portal完成Gx会话、Sd会话、Sy会话、N7会话、Rx会话、N15会话、N5会话、N23会话、N24会话和N28会话备份功能的数据配置。  本实例的配置场景如下：  * 支持100万并发会话-600万静态用户。 * 实现Gx会话、Sd会话、Sy会话、N7会话、Rx会话、N15会话、N5会话、N23会话、N24会话和N28会话备份功能。  当局点的建链模式为奇偶模式（通过**SET DSGSCTPPARA**设置），操作员在配置会话备份功能时，DSG链路条数（通过**SET LINKNUM**设置）必须设置成16。
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾部署","2*FE互备+2*BE主备地理容灾方案","安装和调测容灾系统","配置容灾局","配置会话备份和恢复数据实例"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
该任务指导工程师通过OM portal完成Gx会话、Sd会话、Sy会话、N7会话、Rx会话、N15会话、N5会话、N23会话、N24会话和N28会话备份功能的数据配置。本实例的配置场景如下：* 支持100万并发会话-600万静态用户。* 实现Gx会话、Sd会话、Sy会话、N7会话、Rx会话、N15会话、N5会话、N23会话、N24会话和N28会话备份功能。当局点的建链模式为奇偶模式（通过**SET DSGSCTPPARA**设置），操作员在配置会话备份功能时，DSG链路条数（通过**SET LINKNUM**设置）必须设置成16。

## 必备事项
前提条件

* 已完成UPCF基础数据配置。
* 已完成配置对接数据实例。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_srvipaddr_list:
      type: items
      properties:
        SRVINDEX:
          name: '业务IP索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVIPTYPE:
          name: '业务IP类型'
          type: string
          enum:
          - DSG
          - PGW
          - DMA
          - PRV
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICETYPE:
          name: '业务类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DPUMID:
          name: 'DPU模块号'
          type: integer
          minimum: 1
          maximum: 4080
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPQOSVALUE:
          name: 'IP QoS值'
          type: string
          enum:
          - BIT0
          - BIT1
          - BIT2
          - BIT3
          - BIT4
          - BIT5
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_cluster_list:
      type: items
      properties:
        CID:
          name: 'Cluster标识'
          type: integer
          minimum: 0
          maximum: 4096
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ROLE:
          name: '主备标识'
          type: string
          enum:
          - ACTIVE
          - REDUNDANCY
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    act_feplug_list:
      type: items
      properties:
        FETYPENAME:
          name: 'FE类型名称'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rdsg_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGMID:
          name: '远端DSG模块号'
          type: integer
          minimum: 1
          maximum: 2047
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ripaddr_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ID:
          name: '远端DPU模块号/远端业务IP索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '远端Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '远端Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDPUST:
          name: '远端IP地址业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '远端Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '远端Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    act_ipdisp_list:
      type: items
      properties: {}
    add_rpcrf_list:
      type: items
      properties:
        PCRFID:
          name: '本端PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RPCRFID:
          name: '容灾PCRF标识'
          type: integer
          minimum: 0
          maximum: 5
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PN:
          name: '对端名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '对端域名'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '对端主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        WMODE:
          name: '工作模式'
          type: string
          enum:
          - CLIENT
          - SERVER
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: CLIENT
        RTYPE:
          name: '容灾类型'
          type: string
          enum:
          - Active_Standby
          - N.Active_1.Standby
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: Active_Standby
        LSTATUS:
          name: '本地PCRF容灾状态'
          type: string
          enum:
          - ACTIVE
          - STANDBY
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rpcrfl_list:
      type: items
      properties:
        PCRFID:
          name: '本端PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RPCRFID:
          name: '容灾PCRF标识'
          type: integer
          minimum: 0
          maximum: 5
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LNKID:
          name: '链路标识'
          type: integer
          minimum: 0
          maximum: 65
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TPTYPE:
          name: '传输协议类型'
          type: string
          enum:
          - TCP
          - SCTP
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LPT:
          name: '本地端口'
          type: integer
          minimum: 0
          maximum: 65534
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LIP:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PIP:
          name: '对端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PPT:
          name: '对端端口'
          type: integer
          minimum: 0
          maximum: 65534
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DUALHOME:
          name: '双归属开关'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DIPVER:
          name: '双归属地址IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LIPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PIPV6:
          name: '对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_direct_to_af:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '/*当UPCF与AF采用直连方式对接时,配置Rx链路上消息的转发对端*/'
      data_source: ''
      pattern: ''
      default: TRUE
    mod_pafl_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        AFID:
          name: '对端AF标识'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LNKID:
          name: '对端链路标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RPCRFID:
          name: '容灾PCRF标识'
          type: integer
          minimum: 0
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_quasi_direct_via_dra:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '/*当UPCF通过DRA与AF采用准直连方式对接时,配置Rx链路上消息的转发对端*/'
      data_source: ''
      pattern: ''
      default: TRUE
    mod_peerl_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PT:
          name: '对端类型'
          type: string
          enum:
          - DRA
          - TDF
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PEERID:
          name: '对端标识'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LNKID:
          name: '对端链路标识'
          type: integer
          minimum: 0
          maximum: 135
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RPCRFID:
          name: '容灾PCRF标识'
          type: integer
          minimum: 0
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DISPMODE:
          name: '分发模式'
          type: string
          enum:
          - SpecialQuintuple
          - WellKnownPort
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list:
      type: items
      properties:
        INSPN:
          name: '参数名'
          type: string
          enum:
          - VRM_MAXIPCANSESNUMPERSPU
          - VRM_MAXAFSESNUMPERSPU
          - VRM_MAXSUBNUMPERSPU
          - VRM_UPGRADE
          - VRM_MAXRATBEARIDPERSES
          - VRM_SRVNUMPERUSR
          - VRM_MAXPAFNUM
          - VRM_MAXPCEFNUM
          - VRM_MAXRADIUSSRVNUM
          - VRM_MAXCONNECTIONPERPAF
          - VRM_MAXCONNECTIONPERPCEF
          - VRM_MAXLINKRADIUSSRV
          - VRM_SUBSRCIPTIONIDTYPE
          - VRM_GLBREFLASHINTERVAL
          - VRM_NOTIFYMSGMAXRECORDPERSUB
          - VRM_NOTIFYMSGMAXDAYPERSUB
          - VRM_REVALIDATIONTIMEMETHOD
          - VRM_NOSUBSCRIPTIONERRORCODE
          - VRM_NOTIFYMSGMAXWAITEDRECORDS
          - VRM_PRINTLOCALLOG
          - VRM_USRREVALIHRANGE
          - VRM_ONLINECHECK
          - VRM_TIMEZONEENHANCE
          - VRM_GXIMEIFORMAT
          - VRM_NOTIFYMSGMAXRECORDPERDSU
          - VRM_CLEARALLDYNCREATEDUSER
          - VRM_PEELDOMAINSWITCH
          - VRM_NOTIFYRCVER
          - VRM_FIRSTDAYOFWEEK
          - VRM_UPDATESPRSUBACTIVE
          - VRM_SUBCTRLRESULT
          - VRM_SPRSUBMAXOFFLINEDAYS
          - VRM_CHECKSUBSCRIBEDSERVICE
          - VRM_SUBACTCTRL
          - VRM_SESSIONCHECKINTERVAL
          - VRM_CHKSUBSRVSYTYPE
          - VRM_RARSENDSPEED
          - VRM_DIAREDIRECTSWITCH
          - VRM_PERIODVALUE
          - VRM_PROTECTTIMER
          - VRM_SENDUSERNUM
          - VRM_POLICYCASESENSITIVE
          - VRM_SESSIONRESTORATION
          - VRM_RXRPMAPRELATION
          - VRM_NOTIFYUSAGEUNITCONVERT
          - VRM_TIMEACCUMODE
          - VRM_SYSWITCH
          - VRM_PLMNMATCHPRIORITY
          - VRM_RESETNOTIFYRPT
          - VRM_REPORTINGLEVEL
          - VRM_RATINGGROUP
          - VRM_SERVICEIDENTIFIER
          - VRM_DFTCHARGINGPARA
          - VRM_LOGPRINTPERIOD
          - VRM_MAXBBERFNUM
          - VRM_MAXCONNECTIONPERBBERF
          - VRM_SPNOTIFYDOMAIN
          - VRM_EXSPRNOTIFICATION
          - VRM_SESSIONBACKUPSWITCH
          - VRM_DIAMHBINTERVAL
          - VRM_DIAMHBTIMES
          - VRM_EDRACCESSFORMATE
          - VRM_IPCANTERMSWITCH
          - VRM_DELBEAROPTION
          - VRM_LDAPREVBUFFERSIZE
          - VRM_NOTIFYOPTIMIZE
          - VRM_RESULTCODESWITCH
          - VRM_FMTIPADDR
          - VRM_GROUPDIAREDIRECTSWITCH
          - VRM_RMVSUBWITHOUTRAR
          - VRM_GRPMBRUSAGECACHE1
          - VRM_GRPMBRUSAGECACHE2
          - VRM_DYNRULEFORMAT
          - VRM_IPV6HASHLENGTH
          - VRM_DURATIONMKMATCH
          - VRM_SNRRECSPEED
          - VRM_DIAMTIMETHRD
          - VRM_LDAPTIMETHRD
          - VRM_RELGXBYRAATIMEOUT
          - VRM_SETHOMESRVZONE
          - VRM_MAXTDFNUM
          - VRM_TDFCCRUSPD
          - VRM_TDFCCRTSPD
          - VRM_PROCHEARTBEATTIMEOUT
          - VRM_MAXAUXILIARYAREA
          - VRM_AADIAREDIRECTSWITCH
          - VRM_DIAMFAILOVERSWITCH
          - VRM_DYNSMSMSISDN
          - VRM_SUBGRPCREATESUB
          - VRM_QUOTACROSSSERVICE
          - VRM_SYSUBIDTYPE
          - VRM_DEACTIVESERVICETIMER
          - VRM_QUOTALOGSWITCH
          - VRM_SIMPLEPOLICYSTATISTIC
          - VRM_GXTRIGGERCMP
          - VRM_QOSNEGOTIATIONSWITCH
          - VRM_IPFLOWANYCVT
          - VRM_SUBLISTNORULE
          - VRM_NTFOVERDUEMODE
          - VRM_DESTPEERMODE
          - VRM_SYNDATASWITCH
          - VRM_SYNDATAINTERVAL
          - VRM_TAIECGIMATCHMODE
          - VRM_SYCARRYSUBID
          - VRM_SYRESENDTIMES
          - VRM_DYNQUOTATIMEZONE
          - VRM_FIRSTGXSESSIONATTR
          - VRM_SESSIONIDHASHMODE
          - VRM_PEERFCDURATION
          - VRM_AFPOLICYRECALCULATE
          - VRM_SGWRESTORETIME
          - VRM_QUOTAUSEPRIORITY
          - VRM_SESSIONIDSWITCH
          - VRM_REPORTUSAGE
          - VRM_IMEIQUERYSERVICE
          - VRM_MCITRIGGERUDR
          - VRM_RXMAXUL
          - VRM_RXMAXDL
          - VRM_SYSESSIONCONTROLATTRIBUTE
          - VRM_SYSESSIONCONTROLVALUE
          - VRM_AUTORECUSRLOC
          - VRM_LINKDSPMODE
          - VRM_RXSTAINCAUTHAPPID
          - VRM_MAXAREANUM
          - VRM_GXSESSIONONLYVOLTE
          - VRM_LDAPDBTIMEOUT
          - VRM_OFFSETTIME
          - VRM_APNSENSITIVE
          - VRM_DYNGROUPNUMBERPERUSER
          - VRM_SYSESSIONBACKUP
          - VRM_NOTIFYATTRRESTRICTION
          - VRM_UNKNOWNRULEPROC
          - VRM_FORCEUPGRADEQOS
          - VRM_RMVGRPMEMBERACT
          - VRM_SYNUSRDATASPEED
          - VRM_SYCHARGINGCHARSWITCH
          - VRM_LICDSPMODE
          - VRM_GRPMBRPARENTSTATUSFLAG
          - VRM_TERMSESSNOTIFICATIONFLAG
          - VRM_DCIPRIORITY
          - VRM_SERVICEINFOSTATUSMODE
          - VRM_RXARPMAPPINGMODE
          - VRM_NOTIFYATTRENUMVALUEMODE
          - VRM_GLBSESDATAREFRESH
          - VRM_MAXPOCSCPNUM
          - VRM_SPUAUTOSWITCHOVER
          - VRM_PRAIDCODECMODE
          - VRM_DFTROAMINGSTATUS
          - VRM_MCIPROCMODE
          - VRM_VMSTORAGEFAULTRMSWITCH
          - VRM_PREBINDFORSESSIONBACKUP
          - VRM_SHARESYQUOTAMODE
          - VRM_MEMCHECKALARMSWITCH
          - VRM_QUOTASTATUSSTATISTIC
          - VRM_SUBIDCHOOSESWITCH
          - VRM_MCCMNCROAMREGION
          - VRM_TERMFIRSTSESSIONSWITCH
          - VRM_RECORDMEMSWITCH
          - VRM_Q922ERRMSGSWITCH
          - VRM_MEMFREERECORDSTKSWITCH
          - VRM_MEMFREERECORDSTKPOLICY
          - VRM_MSGFREERECORDSTKSWITCH
          - VRM_MSGFREERECORDSTKPOLICY
          - VRM_MEMALLOCFAILEDHOOKSWITCH
          - VRM_LOADINGALLAREADATA
          - VRM_MAXMSGTEMPLATENUM
          - VRM_PCEFHOSTTOGROUP
          - VRM_LINKBASEAPN
          - VRM_CBOVERRUNALMTH
          - VRM_CBRECOVERYALMTH
          - VRM_VOLTESESSINDEPENDENT
          - VRM_MEWORKROLE
          - VRM_RESETFORALLOCMEMFAILED
          - VRM_RESETFORALLOCMSGFAILED
          - VRM_ENABLEVOLTEAPNGXFLOWCTRL
          - VRM_CBWATCHTIME
          - VRM_DIAMMSGRELAYSWITCH
          - VRM_SYNTIMER
          - VRM_DEVAUDITACCELERATION
          - VRM_PENDINGTRANSACTIONNUM
          - VRM_VOLTEQRYSPR
          - VRM_TRIGGERRESTRICTTYPE
          - BLC_UPMUSERREQ
          - BLC_BEARUPDATE
          - BLC_WAITBEARTERM
          - BLC_ZONETYPE
          - BLC_SECPDPQOSCONTROL
          - RM_RATINGVOLRNDUNIT
          - RM_USGVOLRNDUNIT
          - RM_USGVOLRNDTHRESH
          - RM_RUSGVOLRNDUNIT
          - RM_RUSGVOLRNDTHRESH
          - RM_PLMNANDSGSNALM
          - RM_ALMCLRPERIOD
          - BLC_NOTIFYSENDINTERVAL
          - VRM_OCSCHARGEFLAGFORPRE
          - VRM_OCSCHARGEFLAGFORPOS
          - VRM_OCSCHARGEFLAGFOROTHER
          - BLC_DELSSINVALIDINTERVAL
          - BLC_DELSSINTERVAL
          - BLC_DELSSNUM
          - VRM_CHECKAPNIP
          - VRM_QCIUPGRADE
          - VRM_UNDERCONTROLTHRESHOLD
          - VRM_NORMALVALUE
          - UPM_SUBCTRL
          - UPM_ACCRARTIMEOUT
          - UPM_TIMERPLYCNTREQ
          - VRM_KPIMONITORINGSWITCH
          - VRM_TDFPOLICYMODE
          - VRM_RXBEARWITH5002
          - LIC_PREALMTH
          - VRM_QRYSPRPRIORITY
          - VRM_SDUROUTECONFILICTRAR
          - VRM_DBTIMERVALIDPERIOD
          - VRM_FORCERECOVERYSESSION
          - ALC_WAITAFTERM
          - VRM_RARWITHTRIGGER
          - VRM_RELEASERXTRIGGER
          - VRM_MAXIPCANNUMPERUSR
          - VRM_RETENTION_NOTIFYLOG
          - VRM_RETENTION_MNTLOG
          - VRM_RETENTION_EXPORT
          - VRM_MAXSESSBACKUPNUMPERSUB
          - VRM_SAVESYORGSTATUS
          - VRM_SNRSUPPORTSUBID
          - VRM_AUDITFAILEDCODE
          - VRM_ADJUSTSERVICEMODE
          - VRM_SYORIGINSTATEID
          - VRM_NOTRARWITHSAMEINSTALLRULE
          - VRM_CALCPRIBYSRVNAME
          - VRM_PENDINGTIME2LOCALTIME
          - VRM_MAXPCEFRADIUSNUM
          - VRM_RTPDRNOFLOW
          - VRM_SYDRASLRITIMEOUTSTRCTRL
          - VRM_GXREDIRECTACTION
          - VRM_GXRULEDEDUP
          - VRM_MCITOPGWSPEED
          - VRM_NRIPV6HASHLENGTH
          - VRM_SDCHARGINGCHARSWITCH
          - VRM_OFFLINESRVSWITCH
          - VRM_OFFLINEREDOLOG
          - VRM_VOLTESESSIONNOTUPDATE
          - VRM_BSFONLYVOLTE
          - VRM_BSFRESENDTIMES
          - VRM_BSFTIMEOUT
          - VRM_CHRGIDFMT
          - VRM_LONGTERMNTYRECORDPERSUB
          - VRM_GXQRYCHARINGSYSMODE
          - VRM_RECREATERULENOTIFICATION
          - VRM_PACKETFILTER
          - VRM_SNRWITHOUTHOSTMODE
          - VRM_SYCOUNTERTRANSMODE
          - VRM_MAXCONDITIONNUM
          - VRM_MAXQUOTANUM
          - VRM_RMVSYSRVBYRESULTCODE
          - VRM_VIRTUALSUBIDSWITCH
          - VRM_VOLTEPDPQRYSY
          - VRM_PACKETERRRATETYPE
          - VRM_IPDOMAINSENSITIVE
          - VRM_NRCOMBINEPRIORITYMODE
          - VRM_N15COMPATIBILITYSWITCH
          - VRM_HASHAUDITSWITCH
          - VRM_RECUSRLOCBASERAT
          - VRM_MULTIPCEFQRYDB
          - VRM_DEVAUDITSTARTTIME
          - VRM_MCIDELOLDSES
          - VRM_MCIDELOLDSESSPEED
          - VRM_CHECKSUBSRV
          - VRM_MASTERSLAVENOTIFYENHANCE
          - VRM_NEPEERSTATUS
          - VRM_NONOVERLOADERRORCODESW
          - VRM_AMFRESELECTSWITCH
          - VRM_REDIRECTSWITCH
          - VRM_POLICYASSOCIATESWITCH
          - VRM_DIAMDIRECTPATH
          - VRM_SMFALMWITHIPPORT
          - VRM_REGWITHINSTANCENAME
          - VRM_VIRTUALQUOTAREPORTUSAGE
          - VRM_SPONSORDYNRULEFORMAT
          - VRM_SRVTOKENNUM
          - VRM_UPDSMFSTA
          - VRM_N7CHGNORULESWITCH
          - VRM_QUOTAOBJNOTEXISTCALCMODE
          - VRM_SDRRELIABTRANSSWITCH
          - VRM_CALCULBYNR
          - VRM_GXSESSIONCHARGE
          - VRM_RARSPEEDDOWNCPU
          - VRM_RARSPEEDUPCPU
          - VRM_SUBSCRIBERGROUPMATCHMODE
          - VRM_SCANSTARTTIME
          - VRM_DISTRIQUERYMAXRECORD
          - VRM_GLBPARTITIONLOADINGSWITCH
          - VRM_COMPARECCRIUQOS
          - VRM_AUTORECUSRLOCEX
          - VRM_AVGCHILDPERPARENT
          - VRM_AVGPARENTPERCHILD
          - VRM_SELECTNTSMETHOD
          - VRM_QUOTADEDUCTMODE
          - VRM_MAXBEARNUMPERIPCAN
          - VRM_SDSESSIONBACKUP
          - VRM_SERVICEZONEAREAMATCHTYPE
          - VRM_USRLOCATION_VALUE
          - VRM_RULESUFFIXLENAPPMODE
          - VRM_TAIMATCHINGMODE
          - VRM_N7PCCNOCHGANINFOSW
          - VRM_N5SESSIONBACKUP
          - VRM_PROFILEUPDATEBASERULEPRI
          - VRM_AFSELBINDCFG
          - VRM_ROUTEQUERYRETRYTIMES
          - VRM_ROUTEQUERYRETRYINTERVAL
          - VRM_NOTIFYBEFOREEXPIRE
          - VRM_N36INTERFACESW
          - VRM_N36SUBSCRIPTIONSW
          - VRM_PCFLIPSELECTMODE
          - VRM_PESSRVDISCTIMER
          - VRM_EXATTR1DEFAULTVALUE
          - VRM_HTTPCLIENTREDIRECTTIMES
          - VRM_N23SWITCH
          - VRM_DIAMGETAPPID
          - VRM_N23SESSIONBACKUP
          - VRM_GLBDATAIDMAPSWITCH
          - VRM_PEERNFDEFAULTPRIORITY
          - VRM_N23SESADTMSGSPEED
          - VRM_IPDOMAINSRCFORGX
          - VRM_N15VIRTUALSUBIDSWITCH
          - VRM_SESSIONCOMPRESSTYPE
          - VRM_UPDAMFSTA
          - VRM_N23TIMEOUT
          - VRM_MAXAMSAUNUMPERSPU
          - VRM_N24AMSWITCH
          - VRM_N24AMTIMEOUT
          - VRM_CALLRXFIRSTSW
          - VRM_BACKFILLSESRULE
          - VRM_N7NWDAFLINKDOWNSW
          - VRM_N7POLICYCHGN23SW
          - VRM_RSTSYQUOTASW
          - VRM_HTTPLOCFILLMODE
          - VRM_DRALINKSTAMPUPTMODE
          - VRM_TRACECACHECHKSW
          - VRM_N15AREACODESW
          - VRM_USELASTPLMNIFNOTMATCHED
          - VRM_AUTORESETSWITCH4FSM
          - VRM_N23HDPCFIDMODE
          - VRM_CALCREDPRIBYNAME
          - VRM_STATEXTERNALRESTORATION
          - VRM_BSFBINDINGUPDATESW
          - VRM_SBICALLBACKVALUE
          - VRM_NGPOLICYCASESENSITIVE
          - VRM_N15QRYCHARINGSYSMODE
          - VRM_AFUPDATEUMMODE
          - VRM_HSRCTRLSW
          - VRM_CALCMEDRULEPRIBYNAME
          - VRM_DATAVIRTUALSUBIDSWITCH
          - VRM_INTRANETSESSEFFMODE
          - VRM_N28PENDINGTIME2LOCAL
          - VRM_MIDNIGHTGLBREFRESHSWITCH
          - VRM_SCANFROZENUSER
          - VRM_N1NOTIFYTIMER
          - VRM_MAXNWDAFSESNUMPERSPU
          - VRM_PCEFPARAMATCHMODE
          - VRM_N5VIRTUALMEDIA
          - VRM_SYQTAINSTMODE
          - VRM_N7UPDATECAFCRXMODE
          - VRM_N7ACTN23POLICYMODE
          - VRM_N23BAKCOMPATIBILITYSW
          - VRM_N7MAXDYNRULENUM
          - VRM_N7FAILRCPROCMETHOD
          - VRM_DELAYSTATAUTOENABLEDSW
          - VRM_AUTHSRVENCODEMODE
          - VRM_SUBLOCNUM
          - VRM_HPCFDELIVERLOCCHSW
          - VRM_N15RMVSPCMCCFROMGPSI
          - VRM_MODULERSTPROTECTTIME
          - VRM_N15DYNMATCHMODE
          - VRM_NESTATUSREFRESHCYCLE
          - VRM_SYCCFROMN7SWITCH
          - VRM_MAXSESSRESTOREDELAYTIME
          - VRM_SESSIONNUMCOUNTMODE
          - VRM_UEINITRESOURCEBYSMFSWITCH
          - VRM_SATT2TVOICESW
          - VRM_ROLLBACKN7LINKDOWN
          - VRM_DEVAUDITAUTO
          - VRM_N24NFSETRESENTTIMES
          - VRM_UNKNOWNLOCPROC
          - VRM_N15SUBCTRL
          - VRM_UPMUSERREQTIMERLEN
          - VRM_SYSLRIDATIME
          - VRM_MAXNXSESNUMPERSPU
          - VRM_NXNASTIMEOUT
          - VRM_NXNASRETRYTIMES
          - VRM_NZTIMEOUT
          - VRM_NZRETRYTIMES
          - VRM_NXPENDINGRETRYTIMES
          - VRM_NXNWDAFDICMODE
          - VRM_NXNZSESSIONBACKUP
          - VRM_SLRURESENDTIMES
          - VRM_CHECKNTSLINKSTATUS
          - VRM_ABSVALPRDSRVAUTOSW
          - VRM_N23USETAIDISCMODE
          - VRM_SYTOGXRCMODE
          - VRM_VONRLICSTATMODE
          - VRM_PROFILEUPTTIMELEN
          - VRM_SYNASSOCDATAINTERVAL
          - VRM_N7NWDAFLINKDOWNCYCLE
          - VRM_N7NWDAFLINKDOWNMAXTIMES
          - VRM_RXIPV6PCEFGROUPID
          - VRM_DLBPRQTIMERLEN
          - VRM_CLIENTPORTVERIFY
          - VRM_RECHARGENOTIFIRESTRAIN
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '参数值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_srvipaddr_list:
    - SRVINDEX: 2
      SRVIPTYPE: DSG
      IPVER: IPV4
      IP1VPNNAME: 'DSG_VPN'
      IPV4IP1: '192.168.200.76'
      IPV4MASK1: '255.255.0.0'
      IP2VPNNAME: 'DSG_VPN'
      IPV4IP2: '192.168.200.77'
      IPV4MASK2: '255.255.0.0'
      SERVICETYPE: 'UPCF-SESSION'
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
      DPUMID: ''
      IPQOSVALUE: ''
    mod_cluster_list:
    - CID: 0
      ROLE: REDUNDANCY
    act_feplug_list:
    - FETYPENAME: 'UPCF-SESSION'
    add_rdsg_list:
    - RLOCID: 81
      RDSGMID: 6
      RDSGST: 'UPCF-SESSION'
    add_ripaddr_list:
    - RLOCID: 81
      ID: 8
      IPVER: IPV4
      IPV4IP1: '192.168.200.46'
      IPV4IP2: '192.168.200.47'
      RDPUST: 'UPCF-SESSION'
      IPV6IP1: ''
      IPV6IP2: ''
    act_ipdisp_list:
    - {}
    add_rpcrf_list:
    - PCRFID: 1
      RPCRFID: 1
      PN: 'RPCRF'
      DN: 'huawei.com'
      HN: 'pcrf_zy.huawei.com'
      WMODE: CLIENT
      RTYPE: Active_Standby
      LSTATUS: Standby
    add_rpcrfl_list:
    - PCRFID: 1
      RPCRFID: 1
      LNKID: 0
      TPTYPE: TCP
      IPVER: IPV4
      LPT: 6661
      LIP: '192.168.200.70'
      PIP: '192.168.200.40'
      PPT: 6661
      DUALHOME: ''
      DIPVER: ''
      LIPV6: ''
      PIPV6: ''
    is_scenario_direct_to_af: TRUE
    mod_pafl_list:
    - PCRFID: 1
      AFID: 0
      LNKID: 0
      RPCRFID: 1
    is_scenario_quasi_direct_via_dra: TRUE
    mod_peerl_list:
    - PCRFID: 1
      PT: DRA
      PEERID: 0
      LNKID: 0
      RPCRFID: 1
      DISPMODE: ''
    mod_insp_list:
    - INSPN: VRM_SESSIONBACKUPSWITCH
      INSPV: 3
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 **任务描述**

### 完成UPCF Gx会话、Sd会话、Sy会话、N7会话、Rx会话、N15会话、N5会话、N23会话、N24会话和N28会话备份功能的数据配置。

### **脚本**

### **配置容灾局USCDB基础数据**

#### 1.1 /*登录到USCDB MML命令界面*/

#### 1.2 /*增加Session平面IP*/

```jinja2
{%- for item in add_srvipaddr_list -%}
    ADD SRVIPADDR:
    {#- --- 必选参数 --- -#}
    SRVINDEX={{item.SRVINDEX}},
    SRVIPTYPE={{item.SRVIPTYPE}},
    IPVER={{item.IPVER}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
    {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
        IP1VPNNAME="{{item.IP1VPNNAME}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4IP1="{{item.IPV4IP1}}",
    {%- endif -%}
    {#- --- 条件必选：SRVIPTYPE=DSG 时必选 --- -#}
    {%- if item.SRVIPTYPE == 'DSG' -%}
        SERVICETYPE="{{item.SERVICETYPE}}",
    {%- endif -%}
    {#- --- 条件必选：SRVIPTYPE=PGW/DMA 时必选 --- -#}
    {%- if item.SRVIPTYPE in ['PGW', 'DMA'] -%}
        DPUMID={{item.DPUMID}},
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6IP1="{{item.IPV6IP1}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6MASK1={{item.IPV6MASK1}},
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4MASK1 is not none -%}
            IPV4MASK1="{{item.IPV4MASK1}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
    {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
        {%- if item.IP2VPNNAME is not none -%}
            IP2VPNNAME="{{item.IP2VPNNAME}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4IP2 is not none -%}
            IPV4IP2="{{item.IPV4IP2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4MASK2 is not none -%}
            IPV4MASK2="{{item.IPV4MASK2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SRVIPTYPE=PGW/DMA/PRV 时可选 --- -#}
    {%- if item.SRVIPTYPE in ['PGW', 'DMA', 'PRV'] -%}
        {%- if item.IPQOSVALUE is not none -%}
            IPQOSVALUE={{item.IPQOSVALUE}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4GW1 is not none -%}
            IPV4GW1="{{item.IPV4GW1}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4GW2 is not none -%}
            IPV4GW2="{{item.IPV4GW2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6GW1 is not none -%}
            IPV6GW1="{{item.IPV6GW1}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6GW2 is not none -%}
            IPV6GW2="{{item.IPV6GW2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6IP2 is not none -%}
            IPV6IP2="{{item.IPV6IP2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6MASK2 is not none -%}
            IPV6MASK2={{item.IPV6MASK2}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 1.3 /*修改容灾USCDB全局的CLUSTER为Redundancy*/

```jinja2
{%- for item in mod_cluster_list -%}
    MOD CLUSTER:
    {#- --- 必选参数 --- -#}
    CID={{item.CID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ROLE is not none -%}
        ROLE={{item.ROLE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 1.4 /*激活FE插件包*/

```jinja2
{%- for item in act_feplug_list -%}
    ACT FEPLUG:
    {#- --- 必选参数 --- -#}
    FETYPENAME="{{item.FETYPENAME}}",
    ;
{%- endfor -%}
```

### 2 **配置容灾局USCDB的容灾数据**

#### 2.1 /*登录到容灾局USCDB MML命令界面*/

#### 2.2 /*配置远端主用局USCDB的DSG数据*/

```jinja2
{%- for item in add_rdsg_list -%}
    ADD RDSG:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RDSGMID={{item.RDSGMID}},
    RDSGST="{{item.RDSGST}}",
    ;
{%- endfor -%}
```

#### 2.3 /*配置远端主用局USCDB的网元IP数据*/

```jinja2
{%- for item in add_ripaddr_list -%}
    ADD RIPADDR:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    ID={{item.ID}},
    IPVER={{item.IPVER}},
    RDPUST="{{item.RDPUST}}",
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4IP1="{{item.IPV4IP1}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6IP1="{{item.IPV6IP1}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4IP2 is not none -%}
            IPV4IP2="{{item.IPV4IP2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6IP2 is not none -%}
            IPV6IP2="{{item.IPV6IP2}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 2.4 /*激活链路*/

```jinja2
ACT IPDISP:
;
```

### 3 **配置容灾局UPCF对接数据**

#### 3.1 /*登录到容灾局UPCF MML命令界面*/

#### 3.2 /*配置容灾PCRF实体与主用PCRF实体的对接数据*/

```jinja2
{%- for item in add_rpcrf_list -%}
    ADD RPCRF:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    RPCRFID={{item.RPCRFID}},
    DN="{{item.DN}}",
    HN="{{item.HN}}",
    LSTATUS={{item.LSTATUS}},
    {#- --- 可选参数 --- -#}
    {%- if item.PN is not none -%}
        PN="{{item.PN}}",
    {%- endif -%}
    {%- if item.WMODE is not none -%}
        WMODE={{item.WMODE}},
    {%- endif -%}
    {%- if item.RTYPE is not none -%}
        RTYPE={{item.RTYPE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

```jinja2
{%- for item in add_rpcrfl_list -%}
    ADD RPCRFL:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    RPCRFID={{item.RPCRFID}},
    LNKID={{item.LNKID}},
    TPTYPE={{item.TPTYPE}},
    LPT={{item.LPT}},
    PPT={{item.PPT}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：TPTYPE=TCP 时必选 --- -#}
    {%- if item.TPTYPE == 'TCP' -%}
        IPVER={{item.IPVER}},
    {#- --- 条件必选：DUALHOME=OFF 时必选 --- -#}
    {%- elif item.DUALHOME == 'OFF' -%}
        IPVER={{item.IPVER}},
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
    {%- if item.DIPVER == 'IPV4' -%}
        LIP="{{item.LIP}}",
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- elif item.IPVER == 'IPV4' -%}
        LIP="{{item.LIP}}",
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
    {%- if item.DIPVER == 'IPV4' -%}
        PIP="{{item.PIP}}",
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- elif item.IPVER == 'IPV4' -%}
        PIP="{{item.PIP}}",
    {%- endif -%}
    {#- --- 条件必选：DUALHOME=ON 时必选 --- -#}
    {%- if item.DUALHOME == 'ON' -%}
        DIPVER={{item.DIPVER}},
    {%- endif -%}
    {#- --- 条件必选：TPTYPE=SCTP 时必选 --- -#}
    {%- if item.TPTYPE == 'SCTP' -%}
        DUALHOME={{item.DUALHOME}},
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
    {%- if item.DIPVER == 'IPV6' -%}
        LIPV6="{{item.LIPV6}}",
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- elif item.IPVER == 'IPV6' -%}
        LIPV6="{{item.LIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
    {%- if item.DIPVER == 'IPV6' -%}
        PIPV6="{{item.PIPV6}}",
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- elif item.IPVER == 'IPV6' -%}
        PIPV6="{{item.PIPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 3.3 /*当UPCF与AF采用直连方式对接时,配置Rx链路上消息的转发对端*/

```jinja2
{%- if is_scenario_direct_to_af -%}
    {%- for item in mod_pafl_list -%}
        MOD PAFL:
        {#- --- 必选参数 --- -#}
        PCRFID={{item.PCRFID}},
        AFID={{item.AFID}},
        LNKID={{item.LNKID}},
        {#- --- 可选参数 --- -#}
        {%- if item.RPCRFID is not none -%}
            RPCRFID={{item.RPCRFID}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 3.4 /*当UPCF通过DRA与AF采用准直连方式对接时,配置Rx链路上消息的转发对端*/

```jinja2
{%- if is_scenario_quasi_direct_via_dra -%}
    {%- for item in mod_peerl_list -%}
        MOD PEERL:
        {#- --- 必选参数 --- -#}
        PCRFID={{item.PCRFID}},
        PT={{item.PT}},
        PEERID={{item.PEERID}},
        LNKID={{item.LNKID}},
        {#- --- 可选参数 --- -#}
        {%- if item.RPCRFID is not none -%}
            RPCRFID={{item.RPCRFID}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：PT=DRA/TDF 时可选 --- -#}
        {%- if item.PT in ['DRA', 'TDF'] -%}
            {%- if item.DISPMODE is not none -%}
                DISPMODE={{item.DISPMODE}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 3.5 /*设置Gx会话、Sd会话、Sy会话、N7会话、Rx会话、N15会话、N5会话、N23会话、N24会话和N28会话备份功能开关*/

```jinja2
{%- for item in mod_insp_list -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    ;
{%- endfor -%}
```

