# 实例化CSP网元

* 操作场景
* 必备事项
* 操作步骤

## 操作场景

实例化网元是根据现网的网络具体情况，将前期上传的VNFD文件、NSD文件、镜像和业务软件包安装配置成网元的过程，网元完成实例化后，才可以正常工作。

部署UPCF网元时，需要先部署CSP子网元，待CSP部署完成后，继续部署USCDB和UPCF。

## 必备事项

前提条件

* 已上传VNFD文件、NSD文件和软件包。
* 当网元通过一键式部署功能配置VNF实例化时，CSP应为CSP 24.0.0及以上版本，PaaS应为NFV\_FusionStage 24.0.0及以上版本，LCM应为MAE-CN VNF-LCM V100R023C10SPC220及以上版本。

数据

在进行各子网元部署时，需要根据LLD的规划，若部署场景为软SDN场景，在NFVO界面输入对应参数，如表1所示。若部署场景为硬SDN或硬SDN异构部署场景时，请参考表2。

VNFD入参即根据LLD规划，主要包含了网元部署的区域（云服务、主机组等）、规划部署的VM、网络互通使用的逻辑网络等关键信息。

* 参数样例标注为“**黑色**”时，表示参数固定配置为样例取值，通常无需修改。
* 参数样例标注为“**红色**”时，表示参数配置源自运营商规划（多为外部网络地址、部署模式等）。
* 参数样例标注为“**蓝色**”时，表示参数配置依赖产品设计规划和LLD 网络设计（多为逻辑网络、内部私网地址段等），可以结合网设数据，进一步了解入参取值原则。

**软SDN场景部署输入参数如****表1**所示。

**表1** 输入参数

| 参数名 | 含义 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| Language | 安装版本的语言类型。 | **chinese** | 根据需要填写，可选择“chinese/english”。 |
| Cloud service:service VPC | * “Cloud service”为MANO上添加的部署CSP虚拟机所在FusionSphere OpenStack云服务的名称。 * “service VPC”为部署CSP虚拟机所使用的业务VPC的名称。 * “:”为云服务名称和业务VPC名称之间的分隔符。 | **dc1\_FS01\_Srv:Srv\_VPC\_CC** | * “Cloud service”参见：“NFV LLD” > **云管理设计** > “MAE-VNF LCM与FusionSphere对接数据规划”表 > 部署UPCF的域名所对应的“云服务名称”。 * “service VPC”参见： “NFV LLD” > **计算资源设计** > “VNF规划”表 > VPC名称。 |
| Region id | 隔离域ID。 | **nfv-az-zjhz-04b-hw-01** | 如果存在多个隔离域ID，则需要填写，在MAE-VNF LCM界面，选择“NFVI资源 > 云资源 > 网络”，查看云资源对接云服务的“区域”；否则，不需要填写。 |
| Compute availability zone | 部署虚拟机对应的计算可用分区（计算AZ名称）。 | **az1.dc1** | 参见“NFV LLD” > **计算资源设计** > “DC配置规划”表 > 计算AZ名称。 |
| Storage availability zone | 部署虚拟机对应的存储可用分区（存储AZ名称）。 | **az1.dc1** | 参见“NFV LLD” > **存储资源设计** > 获取存储资源设计中的“存储AZ名称”。 |
| Disk type 1 | 部署网元虚拟机对应的磁盘类型。  仅能填写一种磁盘类型。 | **VolumeService01** | 参见“NFV LLD” > **存储资源设计** > “磁阵侧规划”表 > 根据“备注”列选择部署UPCF所对应的“磁盘类型”。  说明：  在软SDN场景部署时，需要在FusionSphere OM上创建“带宽上限”为580MB/s，“IOPS上限”为1000的QoS策略，并新建磁盘类型，绑定该创建的QoS策略。该磁盘类型用于Disk type 1，Disk type 2，Disk type 3参数取值。  Disk type未规划时，禁止填写“\*”，请联系运营商进行规划或复用已规划的磁盘类型。 |
| Disk type 2 | 部署网元虚拟机对应的磁盘类型。  仅能填写一种磁盘类型。 | **VolumeService02** |  |
| Disk type 3 | 部署网元虚拟机对应的磁盘类型。  仅能填写一种磁盘类型。 | **VolumeService03** |  |
| Volume backend name value1 | 承载本网元的后端存储名称。 | **StorageService01** | * 当配套FusionSphere版本为FusionSphere 24.1.0之前的版本。参见“NFV LLD” > **存储资源设计** > “磁阵侧规划”表 > 根据“网元”或“备注”列选择部署UPCF所对应的“后端存储名称”，或通过查询“FusionSphere OpenStack OM（管理员视图）：资源 > 存储 > 后端存储 > 名称”获取。 * 当配套FusionSphere版本为FusionSphere 24.1.0及之后的版本。参见“NFV LLD” > **存储资源设计** > “磁阵侧规划”表 > 根据“网元”或“备注”列选择部署UPCF所对应的“后端存储名称”，或通过查询“FusionSphere OpenStack OM：资源 > 资源管理 > 存储 > 后端存储 > 名称”获取。 |
| Volume backend name value2 | 承载本网元的后端存储名称。 | **StorageService02** |  |
| Volume backend name value3 | 承载本网元的后端存储名称。 | **StorageService03** |  |
| VNF name | 物理网元名称。  说明：  该参数为长度不超过32位的字符串，仅支持包含ａ-z，A-Z，0-9，下划线(\_)，中划线(-)和点(.)，仅能以ａ-z和A-Z开头，不能以点(.)结尾，且不允许包含连续两个及以上的点(.)。 | **dc1imsomu** | 参见““NFV LLD”文档 > “CloudCore业务IP对接设计”页签”。  说明：  该参数在环境部署完成后，可通过命令**MOD ME**进行修改。 |
| CPU Mode | CPU模式。   * 当服务器的物理CPU为X86且型号为V3或V4时，本参数无需填写，保留空白。 * 当服务器的物理CPU为ARM且型号为Kunpeng920 5250T时，本参数无需填写，保留空白。 * 当服务器的物理CPU其他类型时，本参数填写为custom。 | **custom** | 本端规划。 |
| CPU Model | CPU型号。   * 当服务器的物理CPU为X86且型号为V3或V4时，本参数无需填写，保留空白。 * 当服务器的物理CPU为X86且型号不是V3或V4时，根据CPU的具体型号判断属于Skylake或者CascadeLake代系。 * 当服务器的物理CPU为ARM且型号为Kunpeng920 5250T时，本参数无需填写，保留空白。 * 当服务器的物理CPU为ARM且型号为Kunpeng-920时，本参数填写为Kunpeng-920。并且注意填写值的大小写。 | **Kunpeng-920** | 本端规划。  说明：  该参数“取值样例”以ARM场景举例。  实际填写时以网设工具输出的VNFD为准。 |
| CPU policy Value | CPU策略值。 | **dedicated** | 本端规划。 |
| Host aggregate label key 001 | 部署虚拟机的主机组属性标签key值。 | **aggregate\_instance\_extra\_specs:type** | 固定取值。 |
| Host aggregate label value 001 | 部署虚拟机的主机组属性标签value值。 | **TrustPlane01** | * 管理域主机，填写“MgmtPlane+HA命名最后两位数字”，例如MgmtPlane01。 * 业务域主机，填写“TrustPlane+HA命名最后两位数字”，例如TrustPlane01。 * DMZ区主机，填写“DmzPlane+HA命名最后两位数字”，例如DmzPlane01。 |
| Host aggregate label key 002 | 部署虚拟机的主机组属性标签key值。 | **aggregate\_instance\_extra\_specs:ovs** | 固定取值。 |
| Host aggregate label value 002 | 部署虚拟机的主机组属性标签value值。 | **C-plane** | * VM组网采用OVS，填写C-plane。 * VM组网不采用OVS时，填写false。 |
| Host aggregate label key 003 | 部署虚拟机的主机组属性标签key值。 | **aggregate\_instance\_extra\_specs:sriov** | 固定取值。 |
| Host aggregate label value 003 | 部署虚拟机的主机组属性标签value值。 | **false** | 固定取值。 |
| trait\_custom\_1\_key | trait方案下部署虚拟机的主机组属性标签key值。 | **trait:CUSTOM\_TRUSTPLANE01** | * 如果使用trait方案，则以下参数值全部置空： Host aggregate label key 001  Host aggregate label value 001  Host aggregate label key 002  Host aggregate label value 002  Host aggregate label key 003  Host aggregate label value 003 * 如果不使用trait方案，则以下参数值全部置空： trait\_custom\_1\_key  trait\_custom\_1\_value  trait\_custom\_2\_key  trait\_custom\_2\_value  trait\_custom\_3\_key  trait\_custom\_3\_value  trait\_custom\_4\_key  trait\_custom\_4\_value |
| trait\_custom\_1\_value | trait方案下部署虚拟机的主机组属性标签value值。 | **required** |  |
| trait\_custom\_2\_key | trait方案下部署虚拟机的主机组属性标签key值。 | **trait:CUSTOM\_CPLANE** |  |
| trait\_custom\_2\_value | trait方案下部署虚拟机的主机组属性标签value值。 | **required** |  |
| trait\_custom\_3\_key | trait方案下部署虚拟机的主机组属性标签key值。 | **trait:CUSTOM\_SRIOV** |  |
| trait\_custom\_3\_value | trait方案下部署虚拟机的主机组属性标签value值。 | **forbidden** |  |
| trait\_custom\_4\_key | trait方案下部署虚拟机的主机组属性标签key值。 | **trait:CUSTOM\_OVS** |  |
| trait\_custom\_4\_value | trait方案下部署虚拟机的主机组属性标签value值。 | **required** |  |
| Network subnet enable dhcp | 用于同时控制以下网络的逻辑网络子网是否开启DHCP。   * vBase虚拟网络平面 * vFabric1虚拟网络平面 * vFabric2虚拟网络平面 * OM虚拟网络平面 * PaaS Mng虚拟网络平面 | **true** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > 根据“地址获取方式”列确认各网络平面是否开启DHCP。 |
| PaaS Mng | PaaS Mng虚拟网络平面的逻辑网络名称。 | **app\_om\_plane** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“app\_om\_plane”的网络名称及对应的IP网段和IP Version。  非SDN组网下，PaaS Mng是部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| Cidr of CSP PaaS Mng Subnet | 用于表示Paas纳管网络平面子网的IP地址。 | * **IPv4样例：172.26.0.0/24** * **IPv6样例：fc00:0db8::0:113:2/88-123** |  |
| Ip Version of CSP PaaS Mng Subnet | 表示PaaS纳管网络平面子网的IP类型。 | * **IPv4样例：4** * **IPv6样例：6** |  |
| Enable Update OM Virtual Ip | 用于控制是否强制修改OM浮动IP。 | **false**  说明：  该参数设置为“true”会导致用户配置数据丢失，且执行**SET OMIP**和**MOD VIRTUALIP**命令会返回失败，无法对系统OM IP进行修改。 | 本端规划，此处配置建议使用默认值。 |
| vBase | vBase虚拟网络平面的逻辑网络名称。 | **Inner\_Plane1\_Base01****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane1\_Base01”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| vBase2 | vBase2虚拟网络平面的逻辑网络名称。 | **Inner\_Plane1\_Base02****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane1\_Base02”的网络名称。  说明：  仅软SDN三层组网部署场景涉及该参数。 |
| OM | OM虚拟网络平面的逻辑网络名称。 | **S\_OM\_Network\_VM\_CSP01** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| vFabric1 | vFabric1虚拟网络平面的逻辑网络名称。 | **Inner\_Plane2\_Fabric01****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane2\_Fabric01”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| vFabric2 | vFabric2虚拟网络平面的逻辑网络名称。 | **Inner\_Plane2\_Fabric02****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane2\_Fabric02”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| CSP Inner Network IP Version | CSP内部网络IP版本，取值：   * 4，标识IPv4 * 6，标识IPv6 | **4** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane1\_Base01”，“Inner\_Plane2\_Fabric01”与“Inner\_Plane2\_Fabric02”的网络平面的“子网掩码”，“子网网关”，“IP网段”，“IP起始”以及“IP结束”。 |
| vBase dhcp cidr | Base面子网掩码 | **172.16.128.0/21** |  |
| vBase dhcp gateway | Base面子网网关 | **172.16.128.254** |  |
| vBase dhcp pools start | Base面网络地址池起始地址 | **172.16.128.10** |  |
| vBase dhcp pools end | Base面网络地址池结束地址 | **172.16.128.200** |  |
| vFabric1 dhcp cidr | vFabric1面子网掩码 | **172.16.144.0/21** |  |
| vFabric1 dhcp gateway | vFabric1面子网网关 | **172.16.144.254** |  |
| vFabric1 dhcp pools start | vFabric1面网络地址池起始地址 | **172.16.144.10** |  |
| vFabric1 dhcp pools end | vFabric1面网络地址池结束地址 | **172.16.144.200** |  |
| vFabric2 dhcp cidr | vFabric2面子网掩码 | **172.16.152.0/21** |  |
| vFabric2 dhcp gateway | vFabric2面子网网关 | **172.16.152.254** |  |
| vFabric2 dhcp pools start | vFabric2面网络地址池起始地址 | **172.16.152.10** |  |
| vFabric2 dhcp pools end | vFabric2面网络地址池结束地址 | **172.16.152.200** |  |
| PaaS Internal floating IP | PaaS虚拟机内部网络浮动IP地址。  说明：  PaaS Internal floating IP需要填写为PaaS的App\_Manage\_Plane网络平面浮动IP。 | * **IPv4样例：172.18.1.5** * **IPv6样例：fc00:0db8::0:2** | 参见“NFV LLD” > **I层IP对接设计** > “CloudOS IP设计 ”表 > PaaS的App\_Manage\_Plane网络平面内部互通的浮动IP。 |
| SWR Registry address | 获取软件仓库镜像的域名或地址。   * IPv4场景为PaaS虚拟机内部网络浮动IP地址，与PaaS Internal floating IP参数取值相同。 * IPv6场景为FusionStage镜像仓库域名，可以从镜像仓库中查看某个镜像拉取地址获取，该参数填写为拉取地址中端口号前的域名信息。 例如，查看某个镜像的拉取地址为“registry.fusionstage.local:20202/csp/cspupgradetool:20.3.0”，则该参数填写为端口号20202前的域名“registry.fusionstage.local”。 | * **IPv4样例：172.18.1.5** * **IPv6样例：registry.fusionstage.local** | 参见FusionStage的“软件中心 > 软件仓库 > 镜像仓库”页签，单击“镜像名称”，在“拉取地址”获取。 |
| OM gateway IPV4 | OM网段IPv4地址网关。  OM双栈或者OM IPv4单栈时填写。OM IPv6单栈时填写NULL。 | **192.168.1.254** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称对应“网关”及“IP地址段掩码”。 |
| CSP subnet mask IPV4 | OM网段IPv4地址的子网掩码。  OM双栈或者OM IPv4单栈时填写。OM IPv6单栈时填写NULL。 | **255.255.255.0** |  |
| CSP floating IPV4 | CSP虚拟机外部浮动IPv4地址。  OM双栈或者OM IPv4单栈时填写。OM IPv6单栈时填写NULL。 | **192.168.1.8** | 参见“NFV LLD” > **5G Core业务IP对接设计** > “逻辑网络”列中包含关键字“S\_OM\_Network”，“IP类型”为“Floating IP”的IP地址。 |
| CSP floating IPV6 | CSP虚拟机外部浮动IPv6地址。  OM双栈或者OM IPv6单栈时填写。OM IPv4单栈时填写NULL。 | **fc00:0db8::22** |  |
| OM gateway IPV6 | OM网络的IPv6地址网关。  OM双栈或者OM IPv6单栈时填写。OM IPv4单栈时填写NULL。 | **fc00:0db8::23** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称对应“网关”及“IP地址段掩码”。 |
| CSP prefix length IPV6 | OM网络的IPv6地址的前缀长度。  OM双栈或者OM IPv6单栈时填写。OM IPv4单栈时填写NULL。 | **64** |  |
| Registering to CAAS user name | PAAS虚拟机镜像登录名。 | **paas** | EulerOS的初始帐号密码。  参见“NFV LLD” > **账号管理设计** > “NFVI账户管理”表获取PaaS登录类型为“PuTTY”所对应的“账户”与“密码”。 |
| Registering to CAAS password | PAAS虚拟机镜像登录密码。 | **QAZ2wsx@123!** |  |
| CAAS ID | 对接的PAAS名，与同步的云服务名称保持一致。 | **FusionStage2.3** | 在MAE-VNF LCM“NFVI资源 > 云服务”查看对接的FusionStage名称。  或参见“NFV LLD” > **云管理设计** > “VNFM/MAE-CN与FusionStage告警对接数据规划”表 > 云服务名称。 |
| Tenant password | PAAS的租户密码。 | **Changeme\_123** | 参见“NFV LLD” > **云管理设计** > “VNFM/MAE-CN与FusionStage对接数据规划”表 > 获取“密码”。 |
| Project name | paas的项目名称。  说明：  Project name参数名称不能超过50个字符，只能包含ａ-z，0-9，中划线(-)。 | **CSP** | 参见“NFV LLD” > 计算资源设计 > “PaaS Lite资源设计”表 > Project/Namespace名称 |
| Node Max Num | paas项目的节点资源配额。  说明：  取值范围为：1-2000。 | **2000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“节点总数配额”。 |
| Pod Max Num | paas项目的Pod资源配额。  说明：  取值范围为：1-20000。 | **20000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“实例总数配额”。 |
| Node CPU Max Num(cores) | paas项目的CPU资源配额。  说明：  取值范围为：1-100000。 | **100000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“动态节点CPU总量配额(核)”。 |
| Node Memory Max Num(GB) | paas项目的内存资源配额。  说明：  取值范围为：1-700000。 | **700000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 >获取“动态节点内存总量配额(GB)”。 |
| Caas Region Name | 分权分域的区域名称。  说明：  此处指FusionStage的分权分域。 | **QWE** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 >获取“PaaS区域名称”。 |
| Network For Node | 对节点业务通信网段进行配置。  说明：  部署时需填写所有需要的网段，最多支持填写10个网段，多个网段填写格式为“网段1,网段2,网段3”。 | **fc00:0db9::/24,127.0.0.1/16** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 >获取“逻辑网络”列中包含关键字“app\_om\_plane01”的网络名称对应的“网络地址”和“子网掩码”，将网络地址和掩码长度进行拼接。 |
| Cert Private Key Password | Pod间通信证书私钥解密使用的密码。 | **Huawei12#$**  须知：  * 请谨慎填写确保密码填写正确。 * 安装阶段，若此密码填写错误，会导致安装任务运行失败，安装任务整体耗时50分钟左右；安装失败后需要先执行回退操作，然后填写正确的密码，重新创建部署任务。 | * 密码内容来源于“inner-comm-cert.yaml”文件中“privKeyPwd”对应的值。获取路径为：从软件包UPCF\_2\*.\*\*\*.\*\*\*.\*\*\*\_VNFD\_X86/ARM.zip中获取Secret文件（即inner-comm-cert.yaml文件）。 * 密码首次部署后不可更新。 |
| CSP pod PaaS Mng subnet | CSP PaaS Mng容器网络平面子网。  说明：  部署多套网元时，对于不同的Project name可以填写相同的CSP pod PaaS Mng subnet。 | * **IPv4样例：172.25.0.0/16** * **IPv6样例：fc00:0db8::113:1/88-123** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_Paas\_MNG”的网络名称所对应的IP网段。 |
| CSP pod vbase subnet | CSP vbase pod容器网络平面子网。  说明：  部署多套网元时，对于不同的Project name可以填写相同的CSP pod vbase subnet。 | * **IPv4样例：172.30.0.0/16** * **IPv6样例：fc00:0db8::113:5/88** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_vBase\_Plane1”的网络名称所对应的IP网段。 |
| IP Version of pod | CSP容器网络平面的IP版本。 | * **IPV4样例：4** * **IPV6样例：6** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_vBase\_Plane1”的网络名称所对应的IP Version。 |
| PaaS IP Version of pod | Paas管理面容器网络IP类型。 | * **IPV4样例：4** * **IPV6样例：6** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_Paas\_MNG”的网络名称所对应的IP Version。 |
| CSP pod PaaS Mng subnet Extend | 容器网络扩容场景CSP PaaS Mng容器网络平面子网。 | **-** | * 该参数仅适用于容器网络扩容场景，初始部署场景必须保持默认值，即空值。 * 该参数配置的IP网段不能与该网元其他网络平面的IP网段互相包含或者重叠。 * 如果没有足够的剩余IP地址可规划，且FusionStage的版本为23.0.RC1及以上，则“CSP pod vbase subnet Extend”参数可复用其他VNF的Base容器网络地址空间。 |
| CSP pod vbase subnet Extend | 容器网络扩容场景CSP vbase pod容器网络平面子网。 | **-** |  |
| Feature type | 表示是否部署扩展域协议。 | **NULL** | 部署CSP时，如果初始部署包括扩展域，需要填写为“LI”，否则保持默认值。 |
| OM\_EX | 扩展域OM虚拟网络平面的逻辑网络名称。 | **S\_OM\_Network\_GL001** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”和“GL”的网络名称。 |
| OM gateway IPV4 Ex | 扩展域OM网段IPv4地址的网关。  扩展域OM双栈或者OM IPv4单栈时填写。OM IPv6单栈时填写NULL。 | **192.168.2.254** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的扩展域网络名称对应“网关”及“IP地址段掩码”。 |
| CSP subnet mask IPV4 Ex | 扩展域OM网段IPv4地址的子网掩码。  扩展域OM双栈或者OM IPv4单栈时填写。OM IPv6单栈时填写NULL。 | **255.255.255.0** |  |
| CSP floating IPV4 Ex | 扩展域OM浮动IPv4地址。  扩展域OM双栈或者OM IPv4单栈时填写。OM IPv6单栈时填写NULL。 | **192.168.2.8** | 参考“NFV LLD” > **5G Core业务IP对接设计** > “逻辑网络”列包含“S\_OM\_Network”，“IP类型”为“Floating IP”的扩展域IP地址。 |
| CSP floating IPV6 Ex | 扩展域OM浮动IPv6地址。  扩展域OM双栈或者OM IPv6单栈时填写。OM IPv4单栈时填写NULL。 | **fc00:0db8::22** |  |
| OM gateway IPV6 Ex | 扩展域OM网络的IPv6网关。  扩展域OM双栈或者OM IPv6单栈时填写。OM IPv4单栈时填写NULL。 | **fc00:0da8::23** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的扩展域网络名称对应“网关”及“IP地址段掩码”。 |
| CSP prefix length IPV6 Ex | 扩展域OM网络的IPv6地址前缀长度。  扩展域OM双栈或者OM IPv6单栈时填写。OM IPv4单栈时填写NULL。 | **64** |  |
| Initialize CSP OM\_ex Stack | 是否初始创建扩展堆栈。   * true：初始创建扩展堆栈 * false：初始不创建扩展堆栈。 | **false** | 本端规划。 |
| Initialize CSP OM\_ex VM Group | 是否初始创建扩展虚拟机组。   * 0：初始部署时不创建扩展虚拟机组 * 1：初始部署时创建扩展虚拟机组 | **0** | 本端规划。 |
| Storage Bypass Mode | 软件安装支持的存储Bypass模式。建议保持默认值（None）。   * LocalDiskMode (本地磁盘存储Bypass模式) * MemoryDiskMode (内存存储Bypass模式) * None (非存储Bypass模式) | **MemoryDiskMode** | 本端规划。  其中“LocalDiskMode”枚举值为预留字段暂不支持。 |
| 4A Network | OM虚拟网络平面的逻辑网络名称，用于4A安全扫描。 | **OM\_Plane**  说明：  此项必填，且必须与OM参数保持一致，不能填写为NULL。 | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络所对应的“逻辑网络”、“网络地址”、“子网掩码”、“IP起始”与“IP结束”。  当需要进行4A安全扫描时，  * OM单栈IPV4场景，需要输入“4A Network”、“CSP 4A Subnet IPV4 Cidr”、“CSP 4A subnet IPV4 Pools Start”和“CSP 4A subnet IPV4 Pools End”。且子网模式为DHCP时，地址池起始范围不能和浮动IP地址“CSP floating IPV4”冲突。 * OM单栈IPV6场景，需要输入“4A Network”、“CSP 4A subnet IPV6 Cidr”。 * OM双栈场景，参数均需要输入。 |
| CSP 4A Subnet IPV4 Cidr | OM网络IPv4地址的子网/掩码位，用于4A安全扫描。其中“掩码位”需要和“CSP subnet mask IPV4”对应。 | **192.168.1.0/24** |  |
| CSP 4A subnet IPV4 Pools Start | OM网络IPv4地址池的开始范围，用于4A安全扫描。 | **192.168.1.20** |  |
| CSP 4A subnet IPV4 Pools End | OM网络IPv4地址池的终止范围，用于4A安全扫描。 | **192.168.1.240** |  |
| CSP 4A subnet IPV6 Cidr | OM网络IPv6地址的子网/前缀长度，用于4A安全扫描。其中“前缀长度”需要和“CSP subnet mask IPV6”对应。  OM IPv4单栈时填写NULL。 | **NULL** |  |
| Security Boot Enable | Guest OS启动校验开关。   * false：启动Guest OS前，不校验操作系统。 * true：启动Guest OS前，校验操作系统，避免被篡改。 | **false** | 本端规划。  开启该参数对系统性能有一定影响，具体影响程度需要根据话务模型和实施的业务特性进行评估。 |
| Flow Table | 流表部署功能是否生效。   * CMCC:flows（不生效） * capabilities:flows（生效） | **CMCC:flows** | * 当配套FusionSphere版本为8.0.0.SPC20.B095之前版本，该参数需保持默认值“CMCC:flows”。 * 当配套FusionSphere版本为8.0.0.SPC20.B095及之后版本，该参数可以选择“capabilities:flows”或“CMCC:flows”。 |
| Disable\_4A\_Network | 用于控制是否禁用4A网络。 | **false** | 本端规划。 |
| EXTOM\_GW | 4A口网关的IP地址，双栈场景IPv4和IPv6通过逗号分隔。 | * **IPV4样例：172.18.1.5** * **IPV6样例：fc00:0db8::2** * **双栈样例：****172.18.1.6****,****fc00:0db8::6** | 参见“NFV LLD”文档 > **逻辑网络设计** > “UPCF逻辑网络设计 ”表。 |
| EXTOM\_NETMASK | 4A口子网掩码/前缀，双栈场景IPv4和IPv6通过逗号分隔。 | * **IPV4样例：255.255.255.0** * **IPV6样例：64** * **双栈样例：255.255.255.0,64** |  |
| VDU\_CPU\_NUM | 用于表示普通域虚机CPU核数。 | * **非x86\_7285CPU：8** * **x86\_7285CPU：16** | 本端规划。  说明：  仅x86模板显示该部分参数，部署后不支持修改。 |
| VDU\_CPU\_NUM\_EX | 用于表示扩展域虚机CPU核数。 | * **非x86\_7285CPU：4** * **x86\_7285CPU：8** |  |
| VMROUTE\_BASE\_IPV4\_SUBNET\_CIDR\_1 | 第一个IPv4 Base平面目标网段。 | **192.168.1.0/24** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane1\_Base01”且“IP Version”为“IPv4”的网络所对应的“IP网段”、“网关”。  说明：  仅软SDN三层组网部署场景涉及该参数。 |
| VMROUTE\_BASE\_IPV4\_GW\_1 | 第一个IPv4 Base平面目标网段网关。 | **192.168.1.254** |  |
| VMROUTE\_BASE\_IPV4\_SUBNET\_CIDR\_2 | 第二个IPv4 Base平面目标网段。 | **192.168.1.0/24** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane4\_Base01”且“IP Version”为“IPv4”的网络所对应的“IP网段”、“网关”。  说明：  仅软SDN三层组网部署场景涉及该参数。 |
| VMROUTE\_BASE\_IPV4\_GW\_2 | 第二个IPv4 Base平面目标网段网关。 | **192.168.1.254** |  |
| VMROUTE\_BASE\_IPV6\_SUBNET\_CIDR\_1 | 第一个IPv6 Base平面目标网段。 | **fc00::44da:1:0/112** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane1\_Base01”且“IP Version”为“IPv6”的网络所对应的“IP网段”、“网关”。  说明：  仅软SDN三层组网部署场景涉及该参数。 |
| VMROUTE\_BASE\_IPV6\_GW\_1 | 第一个IPv6 Base平面目标网段网关。 | **fc00::44da:1:254** |  |
| VMROUTE\_BASE\_IPV6\_SUBNET\_CIDR\_2 | 第二个IPv6 Base平面目标网段。 | **fc00::44da:2:0/112** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane4\_Base01”且“IP Version”为“IPv6”的网络所对应的“IP网段”、“网关”。  说明：  仅软SDN三层组网部署场景涉及该参数。 |
| VMROUTE\_BASE\_IPV6\_GW\_2 | 第二个IPv6 Base平面目标网段网关。 | **fc00::44da:2:254** |  |
| Measured\_Boot\_Support | 用于表示是否创建支持度量启动的虚拟机。 | **false** | 本端规划。  开启度量启动对系统启动性能有一定影响。 |
| Smartnic\_Enable | 智能网卡卸载标识。   * true：支持智能网卡卸载。 * false：不支持智能网卡卸载。 | **false** | 本端规划。  说明：  * 仅ARM模板显示该参数。 * 该参数仅在MAE VNF LCM V100R024C10CP1802及之后版本生效。 * 该参数仅在FusionSphere OpenStack 24.1.0.SPC10及之后版本生效。 |
| service pmscalc expand label | 控制话统指标计算能力的标签。 | **NA** | 请根据实际使用场景填写，若话统指标量较大，需部署4个PMSCalc服务实例，该参数填写“OM”；若话统指标量较小，可部署2个PMSCalc服务实例，该参数为默认值“NA”。如无法判断，请联系华为技术支持。  说明：  仅5节点模板显示该参数。 |
| service pmscalc instance num | 话统指标计算的实例数量。 | **2** | 请根据实际使用场景填写，若话统指标量较大，需部署4个PMSCalc服务实例，该参数填写4；若话统指标量较小，可部署2个PMSCalc服务实例，该参数为默认值2。如无法判断，请联系华为技术支持。  说明：  仅5节点模板显示该参数。 |

**硬SDN及硬SDN异构场景部署输入参数****如****表2****所示**。

**表2** CSP输入参数

| 参数名 | 含义 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| Language | 安装版本的语言类型。 | **chinese** | 根据需要填写，可选择“chinese/english”。 |
| Cloud service:service VPC | * “Cloud service”为MANO上添加的部署CSP虚拟机所在FusionSphere OpenStack云服务的名称。 * “service VPC”为部署CSP虚拟机所使用的业务VPC的名称。 * “:”为云服务名称和业务VPC名称之间的分隔符。 | **dc1\_FS01\_Srv:Srv\_VPC\_CC** | * “Cloud service”参见：“NFV LLD” > **云管理设计** > “MAE-VNF LCM与FusionSphere对接数据规划”表 > 部署UPCF的域名所对应的“云服务名称”。 * “service VPC”参见： “NFV LLD” > **计算资源设计** > “VNF规划”表 > VPC名称。 |
| Region id | 隔离域ID。  非SDN场景可以不填写。 | **az1.dc1** | 在MAE-VNF LCM界面，选择“NFVI资源 > 云资源 > 网络”，查看云资源对接云服务的“区域”。 |
| VNF name | 物理网元名称。  说明：  该参数为长度不超过64位的字符串，仅支持包含ａ-z，A-Z，0-9，下划线(\_)，中划线(-)和点(.)，仅能以ａ-z和A-Z开头，不能以点(.)结尾，且不允许包含连续两个及以上的点(.)。 | **dc1imsomu** | 参见“NFV LLD” > **计算资源设计** > “PaaS Lite资源设计 ”表 > 在“VNF名称”列获取规划的CSP VNF名称。 |
| HA name | 网元虚拟机所在的主机组名称。 | **Service\_HA01** | 参见“NFV LLD” > **计算资源设计** > “DC配置规划”表 > Host Aggregate名称。  说明：  * 仅NFV\_FusionSphere 24.1.0.SPH35及之后版本ARM场景支持跨HA扩容扩展域虚拟机，或3节点跨HA扩容5节点场景。 * 扩容时此参数表示新增的虚拟机所在的主机组名称。 |
| Compute availability zone | 部署虚拟机对应的计算可用分区（计算AZ名称）。 | **az1.dc1** | 参见“NFV LLD” > **计算资源设计** > “DC配置规划”表 > 计算AZ名称。 |
| Storage availability zone | 部署虚拟机对应的存储可用分区（存储AZ名称）。 | **az1.dc1** | 参见“NFV LLD” > **存储资源设计** > 获取存储资源设计中的“存储AZ名称”。 |
| Disk type 1 | 部署网元虚拟机对应的磁盘类型。 | **VolumeService01**  **(仅填写一种磁盘类型)** | 参见“NFV LLD” > **存储资源设计** > “磁阵侧规划”表 > 根据“备注”列选择部署UPCF所对应的“磁盘类型”。  说明：  Disk type未规划时，禁止填写“\*”，请联系运营商进行规划或复用已规划的磁盘类型。 |
| Disk type 2 | 部署网元虚拟机对应的磁盘类型。 | **VolumeService02**  **(仅填写一种磁盘类型)** |  |
| Disk type 3 | 部署网元虚拟机对应的磁盘类型。 | **VolumeService03**  **(仅填写一种磁盘类型)** |  |
| Disk type 4,5 | 部署网元虚拟机对应的磁盘类型。  （该参数仅在部署5节点时显示。） | **VolumeService04,VolumeService05**  **(两种磁盘类型以','分隔轮询使用)** |  |
| PaaS Mng | PaaS Mng虚拟网络平面的逻辑网络名称。 | **app\_om\_plane** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“app\_om\_plane”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| OM | OM虚拟网络平面的逻辑网络名称。 | **S\_OM\_Network\_VM\_CSP01** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| Enable Update OM Virtual Ip | 用于控制是否强制修改OM浮动IP。 | **false**  说明：  该参数设置为“true”会导致用户配置数据丢失，且执行**SET OMIP**和**MOD VIRTUALIP**命令会返回失败，无法对系统OM IP进行修改。 | 本端规划，此处配置建议使用默认值。 |
| vBase | vBase虚拟网络平面的逻辑网络名称。 | **Inner\_Plane1\_Base01****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane1\_Base01”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| vFabric1 | vFabric1虚拟网络平面的逻辑网络名称。 | **Inner\_Plane2\_Fabric01****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane2\_Fabric01”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| vFabric2 | vFabric2虚拟网络平面的逻辑网络名称。 | **Inner\_Plane2\_Fabric02****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane2\_Fabric02”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| Network subnet enable dhcp | 用于控制OM虚拟网络平面的逻辑网络子网是否开启DHCP。 | **true** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > 根据“地址获取方式”列确认OM网络平面是否开启DHCP。 |
| PaaS Internal floating IP | PaaS虚拟机内部网络浮动IP地址。  说明：  PaaS Internal floating IP需要填写为PaaS的App\_Manage\_Plane网络平面浮动IP。 | * **IPV4样例：172.18.1.5** * **IPV6样例：fc00:0db8::2** | 参见“NFV LLD” > **I层IP对接设计** > “CloudOS IP设计 ”表 > >PaaS的App\_Manage\_Plane网络平面内部互通的浮动IP。 |
| SWR Registry address | 获取软件仓库镜像的域名或地址。   * IPV4场景为PaaS虚拟机内部网络浮动IP地址，与PaaS Internal floating IP参数取值相同。 * IPV6场景为FusionStage镜像仓库域名，可以从镜像仓库中查看某个镜像拉取地址获取，该参数填写为拉取地址中端口号前的域名信息。 例如，查看某个镜像的拉取地址为“registry.fusionstage.local:20202/csp/cspupgradetool:20.3.0”，则该参数填写为端口号20202前的域名“registry.fusionstage.local”。 | * **IPV4样例：172.18.1.5** * **IPV6样例：registry.fusionstage.local** | 参见FusionStage的“软件中心 > 软件仓库 > 镜像仓库”页签，单击“镜像名称”，在“拉取地址”获取。 |
| OM gateway IPV4 | OM网段IPV4地址的网关。  OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **192.168.1.254** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称对应“网关”及“IP地址段掩码”。 |
| CSP subnet mask IPV4 | OM网段IPV4地址的子网掩码。  OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **255.255.255.0** |  |
| CSP floating IPV4 | CSP虚拟机外部浮动IPV4地址。  OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **192.168.1.8** | 参见“NFV LLD” > **5G Core业务IP对接设计** > “逻辑网络”列中包含关键字“S\_OM\_Network”，“IP类型”为“Floating IP”的IP地址。 |
| CSP floating IPV6 | CSP虚拟机外部浮动IPV6地址。  OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写为NULL。 | **fc00:0db8::22** |  |
| OM gateway IPV6 | OM网络的IPV6地址的网关。  OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写为NULL。 | **fc00:0db8::23** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称对应“网关”及“IP地址段掩码”。 |
| CSP prefix length IPV6 | OM网络的IPV6地址的前缀长度。  OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写为NULL。 | **64** |  |
| Registering to CAAS user name | PAAS虚拟机镜像登录名。 | **paas** | 参见“NFV LLD” > **账号管理设计** > “NFVI账户管理”表获取PaaS登录类型为“PuTTY”所对应的“账户”与“密码”。  EulerOS的初始帐号密码。 |
| Registering to CAAS password | PAAS虚拟机镜像登录密码。 | **QAZ2wsx@123!** |  |
| CAAS ID | 对接的PAAS名，与同步的云服务名称保持一致。 | **FusionStage2.3** | 在MAE-VNF LCM“NFVI资源 > 云服务”查看对接的FusionStage名称。  或参见“NFV LLD” > **云管理设计** > “VNFM/MAE-CN与FusionStage告警对接数据规划”表 > 云服务名称。 |
| Tenant password | PAAS租户的密码。 | **Changeme\_123** | 参见“NFV LLD” > **云管理设计** > “VNFM/MAE-CN与FusionStage对接数据规划”表 > 获取“密码”。 |
| Project name | paas的项目名称。  说明：  Project name参数名称不能超过50个字符，只能包含ａ-z，0-9，中划线(-)。 | **csp** | 参见“NFV LLD” > 计算资源设计 > “PaaS Lite资源设计”表 > Project/Namespace名称。 |
| Node Max Num | paas项目的节点资源配额。  说明：  取值范围为：1-2000。 | **2000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“节点总数配额”。 |
| Pod Max Num | paas项目的Pod资源配额。  说明：  取值范围为：1-20000。 | **20000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“实例总数配额”。 |
| Node CPU Max Num(cores) | paas项目的CPU资源配额。  说明：  取值范围为：1-100000。 | **100000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“动态节点CPU总量配额(核)”。 |
| Node Memory Max Num(GB) | paas项目的内存资源配额。  说明：  取值范围为：1-700000。 | **700000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 >获取“动态节点内存总量配额(GB)”。 |
| Caas Region Name | 分权分域的区域名称。  说明：  此处指FusionStage的分权分域。 | **QWE** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 >获取“PaaS区域名称”。 |
| Network For Node | 对节点业务通信网段进行配置。  说明：  部署时需填写所有需要的网段，最多支持填写10个网段，多个网段填写格式为“网段1,网段2,网段3”。 | **fc00:0db9::/24,127.0.0.1/16** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 >获取“逻辑网络”列中包含关键字“app\_om\_plane01”的网络名称对应的“网络地址”和“子网掩码”，将网络地址和掩码长度进行拼接。 |
| Cert Private Key Password | Pod间通信证书私钥解密使用的密码。 | **Huawei12#$**  须知：  * 请谨慎填写确保密码填写正确。 * 安装阶段，若此密码填写错误，会导致安装任务运行失败，安装任务整体耗时50分钟左右；安装失败后需要先执行回退操作，然后填写正确的密码，重新创建部署任务。 | * 密码内容来源于“inner-comm-cert.yaml”文件中“privKeyPwd”对应的值。获取路径为：从软件包UPCF\_2\*.\*\*\*.\*\*\*.\*\*\*\_VNFD\_X86/ARM.zip中获取Secret文件（即inner-comm-cert.yaml文件）。 * 密码首次部署后不可更新。 |
| CSP pod PaaS Mng subnet | CSP PaaS Mng容器网络平面子网。  说明：  部署多套网元时，对于不同的Project name可以填写相同的CSP pod PaaS Mng subnet。 | * **IPV4样例：172.25.0.0/16** * **IPV6样例：fc00:0db8::113:1/88-123** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_Paas\_MNG”的网络名称所对应的IP网段。 |
| CSP pod vbase subnet | CSP vbase pod容器网络平面子网。  说明：  部署多套网元时，对于不同的Project name可以填写相同的CSP pod vbase subnet。 | * **IPV4样例：172.30.0.0/16** * **IPV6样例：fc00:0db8::113:5/88** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_vBase\_Plane1”的网络名称所对应的IP网段。 |
| CSP pod PaaS Mng subnet Extend | 容器网络扩容场景CSP PaaS Mng容器网络平面子网。 | - | * 该参数仅适用于容器网络扩容场景，初始部署场景必须保持默认值，即空值。 * 该参数配置的IP网段不能与该网元其他网络平面的IP网段互相包含或者重叠。 * 如果没有足够的剩余IP地址可规划，且FusionStage的版本为23.0.RC1及以上，则“CSP pod vbase subnet Extend”参数可复用其他VNF的Base容器网络地址空间。 |
| CSP pod vbase subnet Extend | 容器网络扩容场景CSP vbase pod容器网络平面子网。 | - |  |
| IP Version of pod | CSP vbase容器网络平面的IP版本。 | * **IPV4样例：4** * **IPV6样例：6** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_vBase\_Plane1”的网络名称所对应的IP Version。 |
| PaaS IP Version of pod | Paas管理面容器网络IP类型。 | * **IPV4样例：4** * **IPV6样例：6** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_Paas\_MNG”的网络名称所对应的IP Version。 |
| Feature type | 表示是否部署扩展域协议。 | **NULL** | 部署CSP时，如果部署扩展域，需要填写为“LI”，否则保持默认值。 |
| OM\_EX | 扩展域OM虚拟网络平面的逻辑网络名称。 | **S\_OM\_Network\_GL001** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”和“GL”的网络名称。 |
| OM gateway IPV4 Ex | 扩展域OM网段IPV4地址的网关。  扩展域OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **192.168.2.254** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的扩展域网络名称对应“网关”及“IP地址段掩码”。 |
| CSP subnet mask IPV4 Ex | 扩展域OM网段IPV4地址的子网掩码。  扩展域OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **255.255.255.0** |  |
| CSP floating IPV4 Ex | 扩展域OM浮动IPV4地址。  扩展域OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **192.168.2.8** | 参考“NFV LLD” > **5G Core业务IP对接设计** > “逻辑网络”列包含“S\_OM\_Network”，“IP类型”为“Floating IP”的扩展域IP地址。 |
| CSP floating IPV6 Ex | 扩展域OM浮动IPV6地址。  扩展域OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写NULL。 | **fc00:0db8::22** |  |
| OM gateway IPV6 Ex | 扩展域OM网络的IPV6网关。  扩展域OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写NULL。 | **fc00:0da8::23** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的扩展域网络名称对应“网关”及“IP地址段掩码”。 |
| CSP prefix length IPV6 Ex | 扩展域OM网络的IPV6地址的前缀长度。  扩展域OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写NULL。 | **64** |  |
| Initialize CSP OM\_ex Stack | 是否初始创建扩展堆栈。   * true：初始创建扩展堆栈 * false：初始不创建扩展堆栈。 | **false** | 本端规划。 |
| Initialize CSP OM\_ex VM Group | 是否初始创建扩展虚拟机组。   * 0：初始部署时不创建扩展虚拟机组 * 1：初始部署时创建扩展虚拟机组 | **0** | 本端规划。 |
| Storage Bypass Mode | 软件安装支持的存储Bypass模式。建议保持默认值（MemoryDiskMode ）。   * LocalDiskMode (本地磁盘存储Bypass模式) * MemoryDiskMode (内存存储Bypass模式) * None (非存储Bypass模式) | **MemoryDiskMode** | 本端规划。  其中“LocalDiskMode”枚举值为预留字段暂不支持。 |
| Resource Naming Rule | 用于标明网元的资源命名规则。 | **None** | 预留参数，根据需要填写，若无则建议保持空值。 |
| Resource Naming Prefix | 用于标明网元的资源命名的前缀。 | **None** | 预留参数，根据需要填写，若无则建议保持空值。 |
| Resource Category And Supplier | 用于标明网元的资源用途和所属厂商。 | **None** | 预留参数，根据需要填写，若无则建议保持空值。 |
| 4A Network | OM虚拟网络平面的逻辑网络名称，用于4A安全扫描。 | **OM\_Plane**  说明：  此项必填，且必须与OM参数保持一致，不能填写为NULL。 | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络所对应的“逻辑网络”、“网络地址”、“子网掩码”、“IP起始”与“IP结束”。  当需要进行4A安全扫描时，  * OM单栈IPV4场景，需要输入“4A Network”、“CSP 4A Subnet IPV4 Cidr”、“CSP 4A subnet IPV4 Pools Start”和“CSP 4A subnet IPV4 Pools End”。且子网模式为DHCP时，地址池起始范围不能和浮动IP地址“CSP floating IPV4”冲突。 * OM单栈IPV6场景，需要输入“4A Network”、“CSP 4A subnet IPV6 Cidr”。 * OM双栈场景，参数均需要输入。 |
| CSP 4A Subnet IPV4 Cidr | OM网络IPV4地址的子网/掩码位，用于4A安全扫描。其中“掩码位”需要和“CSP subnet mask IPV4”对应。 | **192.168.1.0/24** |  |
| CSP 4A subnet IPV4 Pools Start | OM网络IPV4地址池的开始范围，用于4A安全扫描。 | **192.168.1.20** |  |
| CSP 4A subnet IPV4 Pools End | OM网络IPV4地址池的终止范围，用于4A安全扫描。 | **192.168.1.240** |  |
| CSP 4A subnet IPV6 Cidr | OM网络IPV6地址的子网/前缀长度，用于4A安全扫描。其中“前缀长度”需要和“CSP prefix length IPV6”对应。  OM IPV4单栈时填写NULL。 | **NULL** |  |
| Security Boot Enable | Guest OS启动校验开关。   * false：启动Guest OS前，不校验操作系统。 * true：启动Guest OS前，校验操作系统，避免被篡改。 | **false** | 本端规划。  开启该参数对系统性能有一定影响，具体影响程度需要根据话务模型和实施的业务特性进行评估。 |
| Optimal\_Deployment\_Switch | 最优化部署总开关。   * false：关闭。 * true：开启。 | **true** | 本端规划。  说明：  仅在轻量化核心网场景下显示该参数。 |
| Optimal Expansion | 是否允许最优部署VM和非最优部署的VM部署在同一个刀片。   * false：否。 * true：是。 | **true** |  |
| Disable\_4A\_Network | 用于控制是否禁用4A网络。 | **false** | 本端规划。 |
| EXTOM\_GW | 4A口网关的IP地址，双栈场景IPv4和IPv6通过逗号分隔。 | * **IPV4样例：172.18.1.5** * **IPV6样例：fc00:0db8::2** * **双栈样例：****172.18.1.6****,****fc00:0db8::6** | 参见“NFV LLD”文档 > **逻辑网络设计** > “UPCF逻辑网络设计 ”表。 |
| EXTOM\_NETMASK | 4A口子网掩码/前缀，双栈场景IPv4和IPv6通过逗号分隔。 | * **IPV4样例：255.255.255.0** * **IPV6样例：64** * **双栈样例：255.255.255.0,64** |  |
| VDU\_CPU\_NUM | 用于表示普通域虚机CPU核数。 | * **非x86\_7285CPU：8** * **x86\_7285CPU：16** | 本端规划。  说明：  仅x86模板显示该部分参数，部署后不支持修改。 |
| VDU\_CPU\_NUM\_EX | 用于表示扩展域虚机CPU核数。 | * **非x86\_7285CPU：4** * **x86\_7285CPU：8** |  |
| Deploy Mode | 用于表示部署模式。 | * **X86部署模式：**   + **同构场景：X86**   + **异构场景：X86-ARM** * **ARM部署模式：**   + **同构****场景****：ARM**   + **异构：X86-ARM** | 本端规划。  说明：  同构场景，使用iMaster MAE-CN V100R022C10SPC220+CP2202+HP2203之前的版本部署需要同时上传X86及ARM的软件包。 |
| Measured\_Boot\_Support | 用于表示是否创建支持度量启动的虚拟机。 | **false** | 本端规划。  开启度量启动对系统启动性能有一定影响。 |
| service pmscalc expand label | 控制话统指标计算能力的标签。 | **NA** | 请根据实际使用场景填写，若话统指标量较大，需部署4个PMSCalc服务实例，该参数填写“OM”；若话统指标量较小，可部署2个PMSCalc服务实例，该参数为默认值“NA”。如无法判断，请联系华为技术支持。  说明：  仅5节点模板显示该参数。 |
| service pmscalc instance num | 话统指标计算的实例数量。 | **2** | 请根据实际使用场景填写，若话统指标量较大，需部署4个PMSCalc服务实例，该参数填写4；若话统指标量较小，可部署2个PMSCalc服务实例，该参数为默认值2。如无法判断，请联系华为技术支持。  说明：  仅5节点模板显示该参数。 |

## 操作步骤

1. 在浏览器地址栏中输入地址“https://NFVO运维面的IP地址:31943”，登录NFVO客户端。

   登录用户为组织管理员或VNF运维人员或具有查询NFV Catalog和NS管理操作权限的用户。
2. （可选）仅当使用二级租户进行创建网元时，实例化网元前需要创建VNF管理配额，具体步骤如下：
   1. 在MAE主界面的“应用”区域，单击“Orchestrator”，进入“Orchestrator”界面。在主菜单中选择“NFVI资源 > NFVI资源规划 > 租户管理”。
   2. 在左侧导航栏中选择“租户”，单击租户导航树中的目标二级租户名称，然后选择该租户详情页面的“VNF配额”页签。
   3. 单击“新增”，在“新增VNF配额”弹出框中设置配额信息，单击“确定”。
   4. 在弹出框中查看结果。成功后，点击“确认”，VNF配额创建成功后，部署VNF、NS时可以选择该VNF配额。

      * VNF管理配额创建需要登录用户为一级组织管理员用户。
      * 请根据实际需求新增VNF配额，一个VNF对应一个VNF配额。

      **表3** VNF配额参数

      | 参数 | 说明 | 举例 | 数据来源 |
      | --- | --- | --- | --- |
      | 名称 | 自定义VNF配额名称。  说明：  为方便后续部署VNF、NS业务，建议此处的VNF配额名称和VNF名称保持一致。 | APP-HNGZgdAMF001BHW-05AHW011 | - |
      | vCPU | vCPU取值范围=当前租户配额中vCPU-VNF配额中已分配vCPU | 100 | 网设规划LLD文件中虚拟机资源的CPU核数。  说明：  * 网设规划LLD文件中CPU核数为物理CPU，需转换为vCPU后填写。 * X86和ARM服务器的CPU换算模型不同，根据VNF部署在X86还是ARM资源池，按照对应换算模型转换后再进行填写。 |
      | 内存 | 内存取值范围=当前租户配额中内存-VNF配额中已分配内存 | 1000 | 网设规划LLD文件中虚拟机资源的内存大小。 |
      | 磁盘 | 磁盘取值范围=当前租户配额中磁盘-VNF配额中已分配磁盘 | 10000 | 网设规划LLD文件中虚拟机资源的磁盘容量。 |
3. 在MAE主界面的“应用”区域，单击“Orchestrator”，进入“Orchestrator”界面。在主菜单中选择“NFVO > NS管理 ”。
4. 在“NS实例”页面，单击“部署”。
5. 在“基本信息”页面，设置“NSD模板”、“规划列表”和“服务名称”，请参考表4。

   **表4** 服务名称与规划列表

   | 参数 | 参数说明 | 示例 |
   | --- | --- | --- |
   | NSD模板 | 定义了NS使用的模型、模板及业务规格和描述等信息。  在“选择模板”界面中勾选“拷贝”可以选择一个已创建CSP NS实例所使用的模板。 | - |
   | 规划列表 | 选择规划类型。NSD模板中已定义，具体参数信息根据具体模板而定。 | - |
   | 服务名称 | 用户自定义服务的名称。 | CSP\_NS |
6. “高级配置”通常无需手动配置，参数配置为空时默认为无限制，“高级配置”参数输入参考表5。

   **表5** 配额参数说明

   | 参数 | 参数说明 | 示例 |
   | --- | --- | --- |
   | 最大vCPU数量 (核) | 创建一个网络服务分配的最大vCPU上限。 | 5000 |
   | 最大内存数量 (GB) | 创建一个网络服务分配的最大内存上限。 | 8000 |
   | 最大磁盘数量 (GB) | 创建一个网络服务分配的最大硬盘上限。 | 10000 |
7. 单击“下一步”，进入“NS参数”页面。
8. 在弹出的“配置区域”页面，选择使用的实际区域和VPC后点击“确定”。

   如果当前租户存在预留资源，则可以选择是否使用预留资源，否则无法选择。
9. 在弹出的“批量配置详情”页面，可以检查和修改VNF的部署参数，在VNFs页签下部署计划右侧点击修改按钮：
   1. 设置“VNF名称”（系统会默认生成VNF名称，用户也可以自行定义）。
   2. 单击“部署计划”的下拉框，选择待部署VNF对应的规格，随之界面参数会随VNFD模板自动加载到本页面。

      在VNF的部署界面，选择部署计划Plan的时候，可用的部署Plan用户可以单击选择，不可用的部署Plan显示为灰色，用户只能查看不能选择。
   3. （可选）单击“配额”的下拉框，选择步骤2中已创建的VNF配额。
   4. 调整输入参数取值。请参考输入参数表。

      针对华为规范和中国区规范的VNF，也可以通过：单击“导入VNF部署参数”，根据界面提示导入网设数据中获取的定制.yaml格式的VNF部署参数plan文件，导入VNF部署参数，导入成功后，覆盖界面已有参数。

      在NFVO界面可以修改VNFD模板数据，选择“输入参数”区域框，在对应的参数后输入设置值。参数输入原则：

      * 密码类参数：允许输入~!@#$?()\_-+|:./特殊字符、数字字符、英文字符（包括大小写）。
      * 非密码类参数：限定长度 150个字符。允许输入\_\*:/-,.特殊字符 、数字字符、英文字符（包括大小写）。
      * emsName：当部署的是中国区规范包，可通过将VNFD参数“emsName”配置为VNF归属的EMS，完成在MAE上管理VNF；若不需要在MAE上管理VNF则填写“NULL”。
   5. 单击“确认”，开始对参数进行校验。
10. 在“批量配置详情”页面继续检查，“网络”和“路由”页签下检查网络和路由信息无误后关闭配置页面。

    检查路由信息时，需要检查子网，确保“开通路由”设置为“是”，“发布路由”设置为“否”。
11. 点击“下一步”，还会进行参数校验，如果校验失败会弹出“确认”窗口，里面会显示失败原因，根据失败的调整参数后进行下一步，如果校验成功则会直接进入下一步。
12. NS配置页面(可选)，目前不填写，直接点击“部署”后页面跳转至NS实例化页面，开始创建网络、路由，待网络、路由创建完成后创建VNF后就可以在LCM上看到对应的网元实例化进度。

    如果部署失败，进入“VNF管理”页面，单击展开“状态信息变更列表”，单击操作列的，查看日志信息。若日志信息为“查询FusionStage云服务project异常，请检查FusionStage租户是否正确”，说明项目不存在且不支持一键式部署。请手动创建项目，或升级CSP版本为CSP 24.0.0及以上；PaaS版本为NFV\_FusionStage 24.0.0及以上；LCM版本为MAE-CN VNF-LCM V100R023C10SPC220及以上来支持一键式部署功能。
13. 待实例化完成后（进度为100%），在“NS实例”页面，NS实例状态显示为“完成”或“Active”。

    实际VNF实例化的过程用时与网络状况有关系。一般情况下3节点部署大约需要30分钟左右，5节点部署大约需要50分钟左右。

版权所有 © 华为技术有限公司
