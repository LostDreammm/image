---
id: ''
name: 配置基础数据实例
ne_type: UPCF
type: feature
description: 该任务指导工程师在UPCF开局时，通过OM portal完成基础数据的配置。配置基础数据一般在执行预安装生成的配置脚本环节已完成。  本实例的配置场景如下：  * 支持4\*300万并发会话-5400万静态用户。 * 实现USCDB与UPCF网元的对接。 * 实现本端IP地址配置，用于后续与对端网元对接。
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾部署","（N+1）*FE+2*BE主备地理容灾方案","安装和调测容灾系统","配置主用局","配置基础数据实例"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
该任务指导工程师在UPCF开局时，通过OM portal完成基础数据的配置。配置基础数据一般在执行预安装生成的配置脚本环节已完成。本实例的配置场景如下：* 支持4\*300万并发会话-5400万静态用户。* 实现USCDB与UPCF网元的对接。* 实现本端IP地址配置，用于后续与对端网元对接。

## 必备事项
前提条件

已完成网元安装和FE/BE的CSLB基础数据配置，具体配置参考：**初始配置与调测** > **配置基础数据** > **配置CSLB基础数据**。

执行操作前需要根据LLD和运营商统一规划信息规划参数取值。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    is_scenario_uscdb_upcf_combined:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '**USCDB网元和UPCF网元合一部署**'
      data_source: ''
      pattern: ''
      default: TRUE
    add_srvipaddr_list:
      type: items
      properties:
        SRVINDEX:
          name: '业务IP索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVIPTYPE:
          name: '业务IP类型'
          type: string
          enum:
          - DSG
          - PGW
          - DMA
          - PRV
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICETYPE:
          name: '业务类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DPUMID:
          name: 'DPU模块号'
          type: integer
          minimum: 1
          maximum: 4080
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPQOSVALUE:
          name: 'IP QoS值'
          type: string
          enum:
          - BIT0
          - BIT1
          - BIT2
          - BIT3
          - BIT4
          - BIT5
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list:
      type: items
      properties:
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_1:
      type: items
      properties:
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_2:
      type: items
      properties:
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_4:
      type: items
      properties:
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_5:
      type: items
      properties:
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_6:
      type: items
      properties:
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_sysno_list:
      type: items
      properties:
        SYSTEMNO:
          name: '系统序列号'
          type: integer
          minimum: 1
          maximum: 255
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_scansw_list:
      type: items
      properties:
        SW1:
          name: '离线配额复位'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW2:
          name: '离线帐户复位'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW3:
          name: '离线业务生效发通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW4:
          name: '离线业务失效发通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW5:
          name: '默认PCC临时数据清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW6:
          name: '抑制短信记录超期清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW7:
          name: '业务或套餐过期前通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW8:
          name: '静态用户清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW9:
          name: '无签约用户清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_fesn_list:
      type: items
      properties:
        SN:
          name: 'FE序号'
          type: integer
          minimum:
          - 0
          - 255
          maximum:
          - 20
          - 255
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pcrf_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        EN:
          name: '实体名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '本地域名'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '本地主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_dbslocation_list:
      type: items
      properties:
        LOCID:
          name: 'Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsserviceno_list:
      type: items
      properties:
        PODNAME:
          name: 'POD名称'
          type: string
          minLength: 0
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICENO:
          name: '服务模块号'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list_1:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    pmsdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: 'DEVAID'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IP'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IPVER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPNINDEX'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbvpn_list:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_hlbdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: 'DEVAID'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IP'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IPVER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPNNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_7:
      type: items
      properties:
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_upcf_standalone:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '**UPCF网元单独部署**'
      data_source: ''
      pattern: ''
      default: TRUE
    set_scansw_list_1:
      type: items
      properties:
        SW1:
          name: '离线配额复位'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW2:
          name: '离线帐户复位'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW3:
          name: '离线业务生效发通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW4:
          name: '离线业务失效发通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW5:
          name: '默认PCC临时数据清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW6:
          name: '抑制短信记录超期清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW7:
          name: '业务或套餐过期前通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW8:
          name: '静态用户清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW9:
          name: '无签约用户清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_fesn_list_1:
      type: items
      properties:
        SN:
          name: 'FE序号'
          type: integer
          minimum:
          - 0
          - 255
          maximum:
          - 20
          - 255
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pcrf_list_1:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        EN:
          name: '实体名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '本地域名'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '本地主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_dbslocation_list_1:
      type: items
      properties:
        LOCID:
          name: 'Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsserviceno_list_5:
      type: items
      properties:
        PODNAME:
          name: 'POD名称'
          type: string
          minLength: 0
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICENO:
          name: '服务模块号'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list_2:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list_3:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pmsdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbvpn_list_1:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbdevaddr_list_1:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_hlbdevaddr_list_1:
      type: items
      properties:
        DEVAID:
          name: 'DEVAID'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IP'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IPVER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPNINDEX'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPNNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_8:
      type: items
      properties:
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_scansw_list_2:
      type: items
      properties:
        SW1:
          name: '离线配额复位'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW2:
          name: '离线帐户复位'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW3:
          name: '离线业务生效发通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW4:
          name: '离线业务失效发通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW5:
          name: '默认PCC临时数据清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW6:
          name: '抑制短信记录超期清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW7:
          name: '业务或套餐过期前通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW8:
          name: '静态用户清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW9:
          name: '无签约用户清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_fesn_list_2:
      type: items
      properties:
        SN:
          name: 'FE序号'
          type: integer
          minimum:
          - 0
          - 255
          maximum:
          - 20
          - 255
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pcrf_list_2:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        EN:
          name: '实体名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '本地域名'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '本地主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_dbslocation_list_2:
      type: items
      properties:
        LOCID:
          name: 'Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsserviceno_list_10:
      type: items
      properties:
        PODNAME:
          name: 'POD名称'
          type: string
          minLength: 0
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICENO:
          name: '服务模块号'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list_4:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list_5:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pmsdevaddr_list_1:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbvpn_list_2:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbdevaddr_list_2:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_hlbdevaddr_list_2:
      type: items
      properties:
        DEVAID:
          name: 'DEVAID'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IP'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IPVER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPNINDEX'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPNNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_9:
      type: items
      properties:
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_scansw_list_3:
      type: items
      properties:
        SW1:
          name: '离线配额复位'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW2:
          name: '离线帐户复位'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW3:
          name: '离线业务生效发通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW4:
          name: '离线业务失效发通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW5:
          name: '默认PCC临时数据清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW6:
          name: '抑制短信记录超期清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW7:
          name: '业务或套餐过期前通知'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW8:
          name: '静态用户清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SW9:
          name: '无签约用户清理'
          type: string
          enum:
          - ENABLE
          - DISABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_fesn_list_3:
      type: items
      properties:
        SN:
          name: 'FE序号'
          type: integer
          minimum:
          - 0
          - 255
          maximum:
          - 20
          - 255
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pcrf_list_3:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        EN:
          name: '实体名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '本地域名'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '本地主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_dbslocation_list_3:
      type: items
      properties:
        LOCID:
          name: 'Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsserviceno_list_15:
      type: items
      properties:
        PODNAME:
          name: 'POD名称'
          type: string
          minLength: 0
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICENO:
          name: '服务模块号'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list_6:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list_7:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pmsdevaddr_list_2:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbvpn_list_3:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbdevaddr_list_3:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_hlbdevaddr_list_3:
      type: items
      properties:
        DEVAID:
          name: 'DEVAID'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IP'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IPVER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPNINDEX'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPNNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_10:
      type: items
      properties:
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rdsg_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGMID:
          name: '远端DSG模块号'
          type: integer
          minimum: 1
          maximum: 2047
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGTYPE:
          name: '远端DSG类型'
          type: string
          enum:
          - DSG
          - DBS
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: DSG
    add_ripaddr_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ID:
          name: '远端DPU模块号/远端业务IP索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '远端Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '远端Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDPUST:
          name: '远端IP地址业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '远端Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '远端Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_notifycfg_list:
      type: items
      properties:
        FETYPE:
          name: '订阅通知的FE类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REMOTEID:
          name: '订阅通知对端的ID'
          type: integer
          minimum: 1
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FEID:
          name: 'FE标识'
          type: integer
          minimum: 1
          maximum: 100
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INFTYPE:
          name: '订阅通知的接口类型'
          type: string
          enum:
          - MCI
          - SOAP
          - FILE
          - THIRDPARTY
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SYNCHROSWITCH:
          name: '同步开关'
          type: string
          enum:
          - ASYNC
          - SYNC
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        WAITTIMEOUT:
          name: '超时时长'
          type: integer
          minimum: 1
          maximum: 60
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LOCATIONID:
          name: '订阅通知发送的Location标识'
          type: integer
          minimum: 0
          maximum: 512
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PID:
          name: 'Partition标识'
          type: integer
          minimum: 0
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        NOTIFYDEST:
          name: '通知目标'
          type: integer
          minimum: 0
          maximum: 2
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PERIOD:
          name: '文件生成周期'
          type: integer
          minimum: 5
          maximum: 86400
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RBKLOCATIONID:
          name: '回退时订阅通知发送的Location标识'
          type: integer
          minimum: 0
          maximum: 512
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SAVEPATH:
          name: '文件保存路径'
          type: string
          maxLength: 20
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SAVEPERIOD:
          name: '文件保存周期'
          type: integer
          minimum: 1
          maximum: 30
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SUBERGRPID:
          name: '订阅组'
          type: integer
          minimum: 1
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsrlocation_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          enum:
          - USCDB
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsrdsg_list:
      type: items
      properties:
        RDSGMID:
          name: '远端DSG模块号'
          type: integer
          minimum: 1
          maximum: 2047
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsripaddr_list:
      type: items
      properties:
        ID:
          name: '远端业务IP的索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '远端Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '远端Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '远端Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '远端Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    act_feplug_list:
      type: items
      properties:
        FETYPENAME:
          name: 'FE类型名称'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    act_ipdisp_list:
      type: items
      properties: {}
    act_dbsipdisp_list:
      type: items
      properties: {}
    add_sysno_list:
      type: items
      properties:
        SYSNO:
          name: 'SYSNO'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SYSNAME:
          name: 'SYSNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        STATUS:
          name: 'STATUS'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - is_scenario_uscdb_upcf_combined: TRUE
    add_srvipaddr_list:
    - SRVINDEX: 1
      SRVIPTYPE: DSG
      IPVER: IPV4
      IP1VPNNAME: 'DSG_VPN'
      IPV4IP1: '192.168.200.30'
      IPV4MASK1: '255.255.0.0'
      IP2VPNNAME: 'DSG_VPN'
      IPV4IP2: '192.168.200.31'
      IPV4MASK2: '255.255.0.0'
      SERVICETYPE: 'UPCF'
      DPUMID: 3
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
      IPQOSVALUE: ''
    mod_insp_list:
    - INSPT: PGW
      INSPN: APPLICATIONTYPE
      INSPV: 0
      FETYPEN: ''
    mod_insp_list_1:
    - INSPT: FE
      INSPN: PROVRIGHTSWITCH
      INSPV: 2
      FETYPEN: 'UPCF'
    mod_insp_list_2:
    - INSPT: FE
      INSPN: REDUNDANCYSWITCH
      INSPV: 0
      FETYPEN: 'UPCF'
    mod_insp_list_4:
    - INSPT: PGW
      INSPN: GLOBALDATAREFRESHCYCLE
      INSPV: 20
      FETYPEN: ''
    mod_insp_list_5:
    - INSPT: PGW
      INSPN: MVNOSWITCH
      INSPV: 1
      FETYPEN: ''
    mod_insp_list_6:
    - INSPT: PGW
      INSPN: PGWSNDDCIMSGMODE
      INSPV: 1
      FETYPEN: ''
    set_sysno_list:
    - SYSTEMNO: 1
    set_scansw_list:
    - SW1: ENABLE
      SW2: ENABLE
      SW3: ENABLE
      SW4: ENABLE
      SW5: ENABLE
      SW6: ENABLE
      SW7: ENABLE
      SW8: ENABLE
      SW9: ENABLE
    set_fesn_list:
    - SN: 0
    add_pcrf_list:
    - PCRFID: 1
      EN: 'FE01'
      DN: 'huawei.com'
      HN: 'FE01_zy.huawei.com'
    set_dbslocation_list:
    - LOCID: 231
    add_dbsserviceno_list:
    - PODNAME: 'pcf-dbbroker1-pod231-0'
      SERVICENO: 1
    add_dbsipaddr_list:
    - DBSIPINDEX: 91
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '192.168.200.44'
      IPV4IP2: '192.168.200.45'
      IPV4MASK1: '255.255.0.0'
      IPV4MASK2: '255.255.0.0'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    add_dbsipaddr_list_1:
    - DBSIPINDEX: 92
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '192.168.200.46'
      IPV4IP2: '192.168.200.47'
      IPV4MASK1: '255.255.0.0'
      IPV4MASK2: '255.255.0.0'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    pmsdevaddr_list:
    - DEVAID: '1'
      IP: 192.168.200.68
      IPVER: IPV4
      VPNINDEX: '4'
    add_dlbvpn_list:
    - VPNINDEX: 4
      VPNNAME: 'DLB_VPN'
    add_dlbdevaddr_list:
    - DEVAID: 1
      IP: '192.168.200.136'
      IPVER: IPV4
      VPNINDEX: 4
      IPV6: ''
    add_hlbdevaddr_list:
    - DEVAID: '1'
      IP: 192.168.200.134
      IPVER: IPV4
      VPNNAME: SBA_VPN
    mod_insp_list_7:
    - INSPN: VRM_OFFLINESRVSWITCH
      INSPV: 1
      INSPT: ''
      FETYPEN: ''
    is_scenario_upcf_standalone: TRUE
    set_scansw_list_1:
    - SW1: DISABLE
      SW2: DISABLE
      SW3: DISABLE
      SW4: DISABLE
      SW5: DISABLE
      SW6: DISABLE
      SW7: DISABLE
      SW8: DISABLE
      SW9: DISABLE
    set_fesn_list_1:
    - SN: 1
    add_pcrf_list_1:
    - PCRFID: 1
      EN: 'FE02'
      DN: 'huawei.com'
      HN: 'FE02_zy.huawei.com'
    set_dbslocation_list_1:
    - LOCID: 233
    add_dbsserviceno_list_5:
    - PODNAME: 'pcf-dbbroker1-pod233-0'
      SERVICENO: 5
    add_dbsipaddr_list_2:
    - DBSIPINDEX: 93
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '192.168.200.48'
      IPV4IP2: '192.168.200.49'
      IPV4MASK1: '255.255.0.0'
      IPV4MASK2: '255.255.0.0'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    add_dbsipaddr_list_3:
    - DBSIPINDEX: 94
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '192.168.200.50'
      IPV4IP2: '192.168.200.51'
      IPV4MASK1: '255.255.0.0'
      IPV4MASK2: '255.255.0.0'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    add_pmsdevaddr_list:
    - DEVAID: 1
      IP: '192.168.202.68'
      IPVER: IPV4
      VPNINDEX: 4
      IPV6: ''
    add_dlbvpn_list_1:
    - VPNINDEX: 4
      VPNNAME: 'DLB_VPN'
    add_dlbdevaddr_list_1:
    - DEVAID: 1
      IP: '192.168.200.136'
      IPVER: IPV4
      VPNINDEX: 4
      IPV6: ''
    add_hlbdevaddr_list_1:
    - DEVAID: '1'
      IP: 192.168.200.134
      IPVER: IPV4
      VPNINDEX: '5'
      VPNNAME: SBA_VPN
    mod_insp_list_8:
    - INSPN: VRM_OFFLINESRVSWITCH
      INSPV: 1
      INSPT: ''
      FETYPEN: ''
    set_scansw_list_2:
    - SW1: DISABLE
      SW2: DISABLE
      SW3: DISABLE
      SW4: DISABLE
      SW5: DISABLE
      SW6: DISABLE
      SW7: DISABLE
      SW8: DISABLE
      SW9: DISABLE
    set_fesn_list_2:
    - SN: 2
    add_pcrf_list_2:
    - PCRFID: 1
      EN: 'FE03'
      DN: 'huawei.com'
      HN: 'FE03_zy.huawei.com'
    set_dbslocation_list_2:
    - LOCID: 235
    add_dbsserviceno_list_10:
    - PODNAME: 'pcf-dbbroker1-pod235-0'
      SERVICENO: 9
    add_dbsipaddr_list_4:
    - DBSIPINDEX: 95
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '192.168.200.52'
      IPV4IP2: '192.168.200.53'
      IPV4MASK1: '255.255.0.0'
      IPV4MASK2: '255.255.0.0'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    add_dbsipaddr_list_5:
    - DBSIPINDEX: 96
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '192.168.200.54'
      IPV4IP2: '192.168.200.55'
      IPV4MASK1: '255.255.0.0'
      IPV4MASK2: '255.255.0.0'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    add_pmsdevaddr_list_1:
    - DEVAID: 1
      IP: '192.168.204.68'
      IPVER: IPV4
      VPNINDEX: 4
      IPV6: ''
    add_dlbvpn_list_2:
    - VPNINDEX: 4
      VPNNAME: 'DLB_VPN'
    add_dlbdevaddr_list_2:
    - DEVAID: 1
      IP: '192.168.200.136'
      IPVER: IPV4
      VPNINDEX: 4
      IPV6: ''
    add_hlbdevaddr_list_2:
    - DEVAID: '1'
      IP: 192.168.200.134
      IPVER: IPV4
      VPNINDEX: '5'
      VPNNAME: SBA_VPN
    mod_insp_list_9:
    - INSPN: VRM_OFFLINESRVSWITCH
      INSPV: 1
      INSPT: ''
      FETYPEN: ''
    set_scansw_list_3:
    - SW1: DISABLE
      SW2: DISABLE
      SW3: DISABLE
      SW4: DISABLE
      SW5: DISABLE
      SW6: DISABLE
      SW7: DISABLE
      SW8: DISABLE
      SW9: DISABLE
    set_fesn_list_3:
    - SN: 3
    add_pcrf_list_3:
    - PCRFID: 1
      EN: 'FE04'
      DN: 'huawei.com'
      HN: 'FE04_zy.huawei.com'
    set_dbslocation_list_3:
    - LOCID: 237
    add_dbsserviceno_list_15:
    - PODNAME: 'pcf-dbbroker1-pod237-0'
      SERVICENO: 13
    add_dbsipaddr_list_6:
    - DBSIPINDEX: 97
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '192.168.200.56'
      IPV4IP2: '192.168.200.57'
      IPV4MASK1: '255.255.0.0'
      IPV4MASK2: '255.255.0.0'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    add_dbsipaddr_list_7:
    - DBSIPINDEX: 98
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '192.168.200.58'
      IPV4IP2: '192.168.200.59'
      IPV4MASK1: '255.255.0.0'
      IPV4MASK2: '255.255.0.0'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    add_pmsdevaddr_list_2:
    - DEVAID: 1
      IP: '192.168.204.68'
      IPVER: IPV4
      VPNINDEX: 4
      IPV6: ''
    add_dlbvpn_list_3:
    - VPNINDEX: 4
      VPNNAME: 'DLB_VPN'
    add_dlbdevaddr_list_3:
    - DEVAID: 1
      IP: '192.168.200.136'
      IPVER: IPV4
      VPNINDEX: 4
      IPV6: ''
    add_hlbdevaddr_list_3:
    - DEVAID: '1'
      IP: 192.168.200.134
      IPVER: IPV4
      VPNINDEX: '5'
      VPNNAME: SBA_VPN
    mod_insp_list_10:
    - INSPN: VRM_OFFLINESRVSWITCH
      INSPV: 1
      INSPT: ''
      FETYPEN: ''
    add_rlocation_list:
    - RLOCID: 231
      RMT: 'UPCF'
      LP: 1
      REDUNFLAG: No
    add_rdsg_list:
    - RLOCID: 231
      RDSGMID: 171
      RDSGST: 'UPCF'
      RDSGTYPE: DBS
    add_ripaddr_list:
    - RLOCID: 231
      ID: 91
      IPVER: IPV4
      IPV4IP1: '192.168.200.44'
      IPV4IP2: '192.168.200.45'
      RDPUST: 'UPCF'
      IPV6IP1: ''
      IPV6IP2: ''
    add_notifycfg_list:
    - FETYPE: 'UPCF'
      REMOTEID: 1
      FEID: 4
      INFTYPE: MCI
      SYNCHROSWITCH: ASYNC
      WAITTIMEOUT: 25
      LOCATIONID: 237
      PID: 0
      IPVER: ''
      NOTIFYDEST: ''
      PERIOD: ''
      RBKLOCATIONID: ''
      SAVEPATH: ''
      SAVEPERIOD: ''
      SUBERGRPID: ''
    add_dbsrlocation_list:
    - RLOCID: 81
      RMT: USCDB
      LP: 1
    add_dbsrdsg_list:
    - RDSGMID: 1
      RLOCID: 81
    add_dbsripaddr_list:
    - ID: 81
      IPV4IP1: '192.168.200.30'
      IPV4IP2: '192.168.200.31'
      IPVER: IPV4
      RLOCID: 81
      IPV6IP1: ''
      IPV6IP2: ''
    act_feplug_list:
    - FETYPENAME: 'UPCF'
    act_ipdisp_list:
    - {}
    act_dbsipdisp_list:
    - {}
    add_sysno_list:
    - SYSNO: '1'
      SYSNAME: MASTER01
      STATUS: MASTER
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 **任务描述**

### 完成USCDB与UPCF基础数据的配置及USCDB与UPCF对接数据的配置，使USCDB与UPCF之间互通正常。

### 2 **脚本**

### 3 **USCDB网元和UPCF网元合一部署**

#### 3.1 **配置主用局USCDB基础数据**

##### 3.1.1 /*登录到USCDB MML命令界面*/

##### 3.1.2 /*增加数据平面IP*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in add_srvipaddr_list -%}
        ADD SRVIPADDR:
        {#- --- 必选参数 --- -#}
        SRVINDEX={{item.SRVINDEX}},
        SRVIPTYPE={{item.SRVIPTYPE}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：SRVIPTYPE=DSG 时必选 --- -#}
        {%- if item.SRVIPTYPE == 'DSG' -%}
            SERVICETYPE="{{item.SERVICETYPE}}",
        {%- endif -%}
        {#- --- 条件必选：SRVIPTYPE=PGW/DMA 时必选 --- -#}
        {%- if item.SRVIPTYPE in ['PGW', 'DMA'] -%}
            DPUMID={{item.DPUMID}},
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：SRVIPTYPE=PGW/DMA/PRV 时可选 --- -#}
        {%- if item.SRVIPTYPE in ['PGW', 'DMA', 'PRV'] -%}
            {%- if item.IPQOSVALUE is not none -%}
                IPQOSVALUE={{item.IPQOSVALUE}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.1.3 /*修改软参*/

##### 3.1.4 /*设置PGW为简单模式，这样登录PGW Web LMT界面时无需输入参数SYSNO*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in mod_insp_list -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPT={{item.INSPT}},
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.1.5 /*设置对来自SOAP端口的命令不需要权限检查，但需要对来自MML端口的命令进行权限检查*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in mod_insp_list_1 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPT={{item.INSPT}},
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.1.6 /*设置容灾开关*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in mod_insp_list_2 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPT={{item.INSPT}},
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.1.7 /*设置全局数据刷新周期*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in mod_insp_list_4 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPT={{item.INSPT}},
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.1.8 /*设置MVNOSWITCH权限开关*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in mod_insp_list_5 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPT={{item.INSPT}},
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.1.9 /*设置PGW发送DCI消息模式*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in mod_insp_list_6 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPT={{item.INSPT}},
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.1.10 /*设置OM Portal界面上USCDB的系统SYSNO*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in set_sysno_list -%}
        SET SYSNO:
        {#- --- 必选参数 --- -#}
        SYSTEMNO={{item.SYSTEMNO}},
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 3.2 **配置主用局UPCF1基础数据**

##### 3.2.1 /*登录到UPCF MML命令界面*/

##### 3.2.2 /*设置离线业务参数*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in set_scansw_list -%}
        SET SCANSW:
        {#- --- 可选参数 --- -#}
        {%- if item.SW1 is not none -%}
            SW1={{item.SW1}},
        {%- endif -%}
        {%- if item.SW2 is not none -%}
            SW2={{item.SW2}},
        {%- endif -%}
        {%- if item.SW3 is not none -%}
            SW3={{item.SW3}},
        {%- endif -%}
        {%- if item.SW4 is not none -%}
            SW4={{item.SW4}},
        {%- endif -%}
        {%- if item.SW5 is not none -%}
            SW5={{item.SW5}},
        {%- endif -%}
        {%- if item.SW6 is not none -%}
            SW6={{item.SW6}},
        {%- endif -%}
        {%- if item.SW7 is not none -%}
            SW7={{item.SW7}},
        {%- endif -%}
        {%- if item.SW8 is not none -%}
            SW8={{item.SW8}},
        {%- endif -%}
        {%- if item.SW9 is not none -%}
            SW9={{item.SW9}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.2.3 /*设置FE序号*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in set_fesn_list -%}
        SET FESN:
        {#- --- 必选参数 --- -#}
        SN={{item.SN}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.2.4 /*增加PCRF实体*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in add_pcrf_list -%}
        ADD PCRF:
        {#- --- 必选参数 --- -#}
        PCRFID={{item.PCRFID}},
        DN="{{item.DN}}",
        HN="{{item.HN}}",
        {#- --- 可选参数 --- -#}
        {%- if item.EN is not none -%}
            EN="{{item.EN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.2.5 /*设置FE Location信息*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in set_dbslocation_list -%}
        SET DBSLOCATION:
        {#- --- 必选参数 --- -#}
        LOCID={{item.LOCID}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.2.6 /*增加服务模块号*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in add_dbsserviceno_list -%}
        ADD DBSSERVICENO:
        {#- --- 必选参数 --- -#}
        PODNAME="{{item.PODNAME}}",
        SERVICENO={{item.SERVICENO}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.2.7 /*增加数据IP地址*/

##### 3.2.8 /*增加UPCF_UPCF231_UPSRV-S_0虚拟机的数据平面IP，IP为运营商规划*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in add_dbsipaddr_list -%}
        ADD DBSIPADDR:
        {#- --- 必选参数 --- -#}
        DBSIPINDEX={{item.DBSIPINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.2.9 /*增加UPCF_UPCF231_UPSRV-S_1虚拟机的数据平面IP，IP为运营商规划*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in add_dbsipaddr_list_1 -%}
        ADD DBSIPADDR:
        {#- --- 必选参数 --- -#}
        DBSIPINDEX={{item.DBSIPINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.2.10 /*增加设备IP地址*/

##### 3.2.11 /*增加UPCF与UPCF Web UI的对接IP*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该pmsdevaddr_list的变量区（command: PMSDEVADDR） -#}
<!-- MISSING_MACRO: command=PMSDEVADDR list_name=pmsdevaddr_list step_id=3.2.11 -->
```

##### 3.2.12 /*增加UPCF Diameter接口的对接IP*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in add_dlbvpn_list -%}
        ADD DLBVPN:
        {#- --- 必选参数 --- -#}
        VPNINDEX={{item.VPNINDEX}},
        VPNNAME="{{item.VPNNAME}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in add_dlbdevaddr_list -%}
        ADD DLBDEVADDR:
        {#- --- 必选参数 --- -#}
        DEVAID={{item.DEVAID}},
        IPVER={{item.IPVER}},
        VPNINDEX={{item.VPNINDEX}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IP="{{item.IP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6="{{item.IPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 3.2.13 /*增加UPCF Http接口的对接IP*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_hlbdevaddr_list的变量区（command: ADD HLBDEVADDR） -#}
<!-- MISSING_MACRO: command=ADD HLBDEVADDR list_name=add_hlbdevaddr_list step_id=3.2.13 -->
```

##### 3.2.14 /*设置UPCF1支持离线业务处理*/

```jinja2
{%- if is_scenario_uscdb_upcf_combined -%}
    {%- for item in mod_insp_list_7 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        INSPT={{item.INSPT}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 4 **UPCF网元单独部署**

#### 4.1 **配置主用局UPCF2基础数据**

##### 4.1.1 /*登录到UPCF MML命令界面*/

##### 4.1.2 /*设置离线业务参数*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_scansw_list_1 -%}
        SET SCANSW:
        {#- --- 可选参数 --- -#}
        {%- if item.SW1 is not none -%}
            SW1={{item.SW1}},
        {%- endif -%}
        {%- if item.SW2 is not none -%}
            SW2={{item.SW2}},
        {%- endif -%}
        {%- if item.SW3 is not none -%}
            SW3={{item.SW3}},
        {%- endif -%}
        {%- if item.SW4 is not none -%}
            SW4={{item.SW4}},
        {%- endif -%}
        {%- if item.SW5 is not none -%}
            SW5={{item.SW5}},
        {%- endif -%}
        {%- if item.SW6 is not none -%}
            SW6={{item.SW6}},
        {%- endif -%}
        {%- if item.SW7 is not none -%}
            SW7={{item.SW7}},
        {%- endif -%}
        {%- if item.SW8 is not none -%}
            SW8={{item.SW8}},
        {%- endif -%}
        {%- if item.SW9 is not none -%}
            SW9={{item.SW9}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.3 /*设置FE序号*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_fesn_list_1 -%}
        SET FESN:
        {#- --- 必选参数 --- -#}
        SN={{item.SN}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.4 /*增加PCRF实体*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_pcrf_list_1 -%}
        ADD PCRF:
        {#- --- 必选参数 --- -#}
        PCRFID={{item.PCRFID}},
        DN="{{item.DN}}",
        HN="{{item.HN}}",
        {#- --- 可选参数 --- -#}
        {%- if item.EN is not none -%}
            EN="{{item.EN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.5 /*设置FE Location信息*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_dbslocation_list_1 -%}
        SET DBSLOCATION:
        {#- --- 必选参数 --- -#}
        LOCID={{item.LOCID}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.6 /*增加服务模块号*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsserviceno_list_5 -%}
        ADD DBSSERVICENO:
        {#- --- 必选参数 --- -#}
        PODNAME="{{item.PODNAME}}",
        SERVICENO={{item.SERVICENO}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.7 /*增加数据IP地址*/

##### 4.1.8 /*增加UPCF_UPCF233_UPSRV-S_2虚拟机的数据平面IP，IP为运营商规划*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsipaddr_list_2 -%}
        ADD DBSIPADDR:
        {#- --- 必选参数 --- -#}
        DBSIPINDEX={{item.DBSIPINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.9 /*增加UPCF_UPCF233_UPSRV-S_3虚拟机的数据平面IP，IP为运营商规划*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsipaddr_list_3 -%}
        ADD DBSIPADDR:
        {#- --- 必选参数 --- -#}
        DBSIPINDEX={{item.DBSIPINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.10 /*增加设备IP地址*/

##### 4.1.11 /*增加UPCF与UPCF Web UI的对接IP*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_pmsdevaddr_list -%}
        ADD PMSDEVADDR:
        {#- --- 必选参数 --- -#}
        DEVAID={{item.DEVAID}},
        IPVER={{item.IPVER}},
        VPNINDEX={{item.VPNINDEX}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IP="{{item.IP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6="{{item.IPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.12 /*增加UPCF Diameter接口的对接IP*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dlbvpn_list_1 -%}
        ADD DLBVPN:
        {#- --- 必选参数 --- -#}
        VPNINDEX={{item.VPNINDEX}},
        VPNNAME="{{item.VPNNAME}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dlbdevaddr_list_1 -%}
        ADD DLBDEVADDR:
        {#- --- 必选参数 --- -#}
        DEVAID={{item.DEVAID}},
        IPVER={{item.IPVER}},
        VPNINDEX={{item.VPNINDEX}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IP="{{item.IP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6="{{item.IPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.1.13 /*增加UPCF Http接口的对接IP*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_hlbdevaddr_list_1的变量区（command: ADD HLBDEVADDR） -#}
<!-- MISSING_MACRO: command=ADD HLBDEVADDR list_name=add_hlbdevaddr_list_1 step_id=4.1.13 -->
```

##### 4.1.14 /*设置UPCF2支持离线业务处理*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in mod_insp_list_8 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        INSPT={{item.INSPT}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 4.2 **配置主用局UPCF3基础数据**

##### 4.2.1 /*登录到UPCF MML命令界面*/

##### 4.2.2 /*设置离线业务参数*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_scansw_list_2 -%}
        SET SCANSW:
        {#- --- 可选参数 --- -#}
        {%- if item.SW1 is not none -%}
            SW1={{item.SW1}},
        {%- endif -%}
        {%- if item.SW2 is not none -%}
            SW2={{item.SW2}},
        {%- endif -%}
        {%- if item.SW3 is not none -%}
            SW3={{item.SW3}},
        {%- endif -%}
        {%- if item.SW4 is not none -%}
            SW4={{item.SW4}},
        {%- endif -%}
        {%- if item.SW5 is not none -%}
            SW5={{item.SW5}},
        {%- endif -%}
        {%- if item.SW6 is not none -%}
            SW6={{item.SW6}},
        {%- endif -%}
        {%- if item.SW7 is not none -%}
            SW7={{item.SW7}},
        {%- endif -%}
        {%- if item.SW8 is not none -%}
            SW8={{item.SW8}},
        {%- endif -%}
        {%- if item.SW9 is not none -%}
            SW9={{item.SW9}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.3 /*设置FE序号*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_fesn_list_2 -%}
        SET FESN:
        {#- --- 必选参数 --- -#}
        SN={{item.SN}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.4 /*增加PCRF实体*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_pcrf_list_2 -%}
        ADD PCRF:
        {#- --- 必选参数 --- -#}
        PCRFID={{item.PCRFID}},
        DN="{{item.DN}}",
        HN="{{item.HN}}",
        {#- --- 可选参数 --- -#}
        {%- if item.EN is not none -%}
            EN="{{item.EN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.5 /*设置FE Location信息*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_dbslocation_list_2 -%}
        SET DBSLOCATION:
        {#- --- 必选参数 --- -#}
        LOCID={{item.LOCID}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.6 /*增加服务模块号*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsserviceno_list_10 -%}
        ADD DBSSERVICENO:
        {#- --- 必选参数 --- -#}
        PODNAME="{{item.PODNAME}}",
        SERVICENO={{item.SERVICENO}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.7 /*增加数据IP地址*/

##### 4.2.8 /*增加UPCF_UPCF235_UPSRV-S_4虚拟机的数据平面IP，IP为运营商规划*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsipaddr_list_4 -%}
        ADD DBSIPADDR:
        {#- --- 必选参数 --- -#}
        DBSIPINDEX={{item.DBSIPINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.9 /*增加UPCF_UPCF235_UPSRV-S_5虚拟机的数据平面IP，IP为运营商规划*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsipaddr_list_5 -%}
        ADD DBSIPADDR:
        {#- --- 必选参数 --- -#}
        DBSIPINDEX={{item.DBSIPINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.10 /*增加设备IP地址*/

##### 4.2.11 /*增加UPCF与UPCF Web UI的对接IP*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_pmsdevaddr_list_1 -%}
        ADD PMSDEVADDR:
        {#- --- 必选参数 --- -#}
        DEVAID={{item.DEVAID}},
        IPVER={{item.IPVER}},
        VPNINDEX={{item.VPNINDEX}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IP="{{item.IP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6="{{item.IPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.12 /*增加UPCF Diameter接口的对接IP*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dlbvpn_list_2 -%}
        ADD DLBVPN:
        {#- --- 必选参数 --- -#}
        VPNINDEX={{item.VPNINDEX}},
        VPNNAME="{{item.VPNNAME}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dlbdevaddr_list_2 -%}
        ADD DLBDEVADDR:
        {#- --- 必选参数 --- -#}
        DEVAID={{item.DEVAID}},
        IPVER={{item.IPVER}},
        VPNINDEX={{item.VPNINDEX}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IP="{{item.IP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6="{{item.IPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.2.13 /*增加UPCF Http接口的对接IP*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_hlbdevaddr_list_2的变量区（command: ADD HLBDEVADDR） -#}
<!-- MISSING_MACRO: command=ADD HLBDEVADDR list_name=add_hlbdevaddr_list_2 step_id=4.2.13 -->
```

##### 4.2.14 /*设置UPCF3支持离线业务处理*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in mod_insp_list_9 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        INSPT={{item.INSPT}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 4.3 **配置主用局UPCF4基础数据**

##### 4.3.1 /*登录到UPCF MML命令界面*/

##### 4.3.2 /*设置离线业务参数*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_scansw_list_3 -%}
        SET SCANSW:
        {#- --- 可选参数 --- -#}
        {%- if item.SW1 is not none -%}
            SW1={{item.SW1}},
        {%- endif -%}
        {%- if item.SW2 is not none -%}
            SW2={{item.SW2}},
        {%- endif -%}
        {%- if item.SW3 is not none -%}
            SW3={{item.SW3}},
        {%- endif -%}
        {%- if item.SW4 is not none -%}
            SW4={{item.SW4}},
        {%- endif -%}
        {%- if item.SW5 is not none -%}
            SW5={{item.SW5}},
        {%- endif -%}
        {%- if item.SW6 is not none -%}
            SW6={{item.SW6}},
        {%- endif -%}
        {%- if item.SW7 is not none -%}
            SW7={{item.SW7}},
        {%- endif -%}
        {%- if item.SW8 is not none -%}
            SW8={{item.SW8}},
        {%- endif -%}
        {%- if item.SW9 is not none -%}
            SW9={{item.SW9}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.3 /*设置FE序号*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_fesn_list_3 -%}
        SET FESN:
        {#- --- 必选参数 --- -#}
        SN={{item.SN}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.4 /*增加PCRF实体*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_pcrf_list_3 -%}
        ADD PCRF:
        {#- --- 必选参数 --- -#}
        PCRFID={{item.PCRFID}},
        DN="{{item.DN}}",
        HN="{{item.HN}}",
        {#- --- 可选参数 --- -#}
        {%- if item.EN is not none -%}
            EN="{{item.EN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.5 /*设置FE Location信息*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in set_dbslocation_list_3 -%}
        SET DBSLOCATION:
        {#- --- 必选参数 --- -#}
        LOCID={{item.LOCID}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.6 /*增加服务模块号*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsserviceno_list_15 -%}
        ADD DBSSERVICENO:
        {#- --- 必选参数 --- -#}
        PODNAME="{{item.PODNAME}}",
        SERVICENO={{item.SERVICENO}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.7 /*增加数据IP地址*/

##### 4.3.8 /*增加UPCF_UPCF237_UPSRV-S_6虚拟机的数据平面IP，IP为运营商规划*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsipaddr_list_6 -%}
        ADD DBSIPADDR:
        {#- --- 必选参数 --- -#}
        DBSIPINDEX={{item.DBSIPINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.9 /*增加UPCF_UPCF237_UPSRV-S_7虚拟机的数据平面IP，IP为运营商规划*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dbsipaddr_list_7 -%}
        ADD DBSIPADDR:
        {#- --- 必选参数 --- -#}
        DBSIPINDEX={{item.DBSIPINDEX}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.10 /*增加设备IP地址*/

##### 4.3.11 /*增加UPCF与UPCF Web UI的对接IP*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_pmsdevaddr_list_2 -%}
        ADD PMSDEVADDR:
        {#- --- 必选参数 --- -#}
        DEVAID={{item.DEVAID}},
        IPVER={{item.IPVER}},
        VPNINDEX={{item.VPNINDEX}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IP="{{item.IP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6="{{item.IPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.12 /*增加UPCF Diameter接口的对接IP*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dlbvpn_list_3 -%}
        ADD DLBVPN:
        {#- --- 必选参数 --- -#}
        VPNINDEX={{item.VPNINDEX}},
        VPNNAME="{{item.VPNNAME}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in add_dlbdevaddr_list_3 -%}
        ADD DLBDEVADDR:
        {#- --- 必选参数 --- -#}
        DEVAID={{item.DEVAID}},
        IPVER={{item.IPVER}},
        VPNINDEX={{item.VPNINDEX}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IP="{{item.IP}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6="{{item.IPV6}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 4.3.13 /*增加UPCF Http接口的对接IP*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_hlbdevaddr_list_3的变量区（command: ADD HLBDEVADDR） -#}
<!-- MISSING_MACRO: command=ADD HLBDEVADDR list_name=add_hlbdevaddr_list_3 step_id=4.3.13 -->
```

##### 4.3.14 /*设置UPCF4支持离线业务处理*/

```jinja2
{%- if is_scenario_upcf_standalone -%}
    {%- for item in mod_insp_list_10 -%}
        MOD INSP:
        {#- --- 必选参数 --- -#}
        INSPN={{item.INSPN}},
        INSPV={{item.INSPV}},
        INSPT={{item.INSPT}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
        {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
            FETYPEN="{{item.FETYPEN}}",
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 5 **USCDB网元和UPCF网元合一部署或UPCF网元单独部署**

#### 5.1 **配置主用局USCDB和UPCF的对接数据**

##### 5.1.1 /*登录到USCDB MML命令界面*/

##### 5.1.2 /*增加远端Location信息，对端UPCF的Location标识已经在VNFD中自动规划添加，可以在UPCF MML命令界面通过LST LOCATION命令进行查询。这里给出的RLOCID取值仅作参考示例。*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    {%- for item in add_rlocation_list -%}
        ADD RLOCATION:
        {#- --- 必选参数 --- -#}
        RLOCID={{item.RLOCID}},
        RMT="{{item.RMT}}",
        LP={{item.LP}},
        REDUNFLAG={{item.REDUNFLAG}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 5.1.3 /*增加远端服务DBS，RDSGMID已经在VNFD中规划添加，可以在UPCF MML命令界面通过LST DBSSERVICENO命令进行查询。这里给出的RDSGMID取值仅作参考示例。*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    {%- for item in add_rdsg_list -%}
        ADD RDSG:
        {#- --- 必选参数 --- -#}
        RLOCID={{item.RLOCID}},
        RDSGMID={{item.RDSGMID}},
        RDSGST="{{item.RDSGST}}",
        {#- --- 可选参数 --- -#}
        {%- if item.RDSGTYPE is not none -%}
            RDSGTYPE={{item.RDSGTYPE}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 5.1.4 /*增加远端网元IP*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    {%- for item in add_ripaddr_list -%}
        ADD RIPADDR:
        {#- --- 必选参数 --- -#}
        RLOCID={{item.RLOCID}},
        ID={{item.ID}},
        IPVER={{item.IPVER}},
        RDPUST="{{item.RDPUST}}",
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 5.1.5 /*增加订阅通知*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    {%- for item in add_notifycfg_list -%}
        ADD NOTIFYCFG:
        {#- --- 必选参数 --- -#}
        FETYPE="{{item.FETYPE}}",
        FEID={{item.FEID}},
        INFTYPE={{item.INFTYPE}},
        {#- --- 可选参数 --- -#}
        {%- if item.REMOTEID is not none -%}
            REMOTEID={{item.REMOTEID}},
        {%- endif -%}
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：INFTYPE=SOAP 时必选 --- -#}
        {%- if item.INFTYPE == 'SOAP' -%}
            IPVER={{item.IPVER}},
        {%- endif -%}
        {#- --- 条件必选：INFTYPE=THIRDPARTY 时必选 --- -#}
        {%- if item.INFTYPE == 'THIRDPARTY' -%}
            SUBERGRPID={{item.SUBERGRPID}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.SYNCHROSWITCH is not none -%}
                SYNCHROSWITCH={{item.SYNCHROSWITCH}},
            {%- endif -%}
        {#- --- 条件可选：INFTYPE=MCI/THIRDPARTY 时可选 --- -#}
        {%- elif item.INFTYPE in ['MCI', 'THIRDPARTY'] -%}
            {%- if item.SYNCHROSWITCH is not none -%}
                SYNCHROSWITCH={{item.SYNCHROSWITCH}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.WAITTIMEOUT is not none -%}
                WAITTIMEOUT={{item.WAITTIMEOUT}},
            {%- endif -%}
        {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
        {%- elif item.INFTYPE == 'MCI' -%}
            {%- if item.WAITTIMEOUT is not none -%}
                WAITTIMEOUT={{item.WAITTIMEOUT}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
        {%- if item.INFTYPE == 'MCI' -%}
            {%- if item.LOCATIONID is not none -%}
                LOCATIONID={{item.LOCATIONID}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
        {%- if item.INFTYPE == 'MCI' -%}
            {%- if item.PID is not none -%}
                PID={{item.PID}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
        {%- if item.INFTYPE == 'MCI' -%}
            {%- if item.NOTIFYDEST is not none -%}
                NOTIFYDEST={{item.NOTIFYDEST}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
        {%- if item.INFTYPE == 'FILE' -%}
            {%- if item.PERIOD is not none -%}
                PERIOD={{item.PERIOD}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
        {%- if item.INFTYPE == 'MCI' -%}
            {%- if item.RBKLOCATIONID is not none -%}
                RBKLOCATIONID={{item.RBKLOCATIONID}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
        {%- if item.INFTYPE == 'FILE' -%}
            {%- if item.SAVEPATH is not none -%}
                SAVEPATH="{{item.SAVEPATH}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
        {%- if item.INFTYPE == 'FILE' -%}
            {%- if item.SAVEPERIOD is not none -%}
                SAVEPERIOD={{item.SAVEPERIOD}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 5.1.6 /*主用局UPCF1增加远端Location信息、远端DSG、远端网元IP和激活链路*/

##### 5.1.7 /*增加远端Location信息*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    {%- for item in add_dbsrlocation_list -%}
        ADD DBSRLOCATION:
        {#- --- 必选参数 --- -#}
        RLOCID={{item.RLOCID}},
        RMT={{item.RMT}},
        LP={{item.LP}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 5.1.8 /*增加远端DSG*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    {%- for item in add_dbsrdsg_list -%}
        ADD DBSRDSG:
        {#- --- 必选参数 --- -#}
        RDSGMID={{item.RDSGMID}},
        RLOCID={{item.RLOCID}},
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 5.1.9 /*增加远端网元IP*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    {%- for item in add_dbsripaddr_list -%}
        ADD DBSRIPADDR:
        {#- --- 必选参数 --- -#}
        ID={{item.ID}},
        IPVER={{item.IPVER}},
        RLOCID={{item.RLOCID}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 5.1.10 /*激活FE插件包*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    {%- for item in act_feplug_list -%}
        ACT FEPLUG:
        {#- --- 必选参数 --- -#}
        FETYPENAME="{{item.FETYPENAME}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 5.1.11 /*激活链路*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    ACT IPDISP:
    ;
{%- endif -%}
```

##### 5.1.12 /*登录到UPCF MML命令界面*/

##### 5.1.13 /*激活链路*/

```jinja2
{%- if (is_scenario_uscdb_upcf_combined) or (is_scenario_upcf_standalone) -%}
    ACT DBSIPDISP:
    ;
{%- endif -%}
```

##### 5.1.14 /*登录PGW Web LMT系统管理界面*/

##### 5.1.15 /*设置USCDB的系统SYSNO*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_sysno_list的变量区（command: ADD SYSNO） -#}
<!-- MISSING_MACRO: command=ADD SYSNO list_name=add_sysno_list step_id=5.1.15 -->
```

