---
id: ''
name: 激活端到端用户跟踪
ne_type: UPCF
type: feature
description: 本操作指导介绍在运行网络中激活端到端用户跟踪的操作过程。  ALL，端到端跟踪
risk_level: ''
doc_source: ["特性","特性部署","UPCF Service Fabric特性","ServiceFabric公共特性","SFFD-106101 端到端用户跟踪","4G网络端到端用户跟踪","激活端到端用户跟踪"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
本操作指导介绍在运行网络中激活端到端用户跟踪的操作过程。ALL，端到端跟踪

## 必备事项
前提条件

* 请仔细阅读端到端用户跟踪特性概述（适用于4G）
* 完成加载License
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    set_licenseswitch_list:
      type: items
      properties:
        LICITEM:
          name: 'LICITEM'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SWITCH:
          name: 'SWITCH'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_e2etrccfg_list:
      type: items
      properties:
        SGS:
          name: '是否上报SGs接口消息'
          type: string
          required: false
          description: '对其他接口消息的跟踪仅取决于本特性license是否开启，不涉及额外命令控制。'
          data_source: '全网规划'
          pattern: ''
          default: ''
        SV:
          name: '是否上报SV接口消息'
          type: string
          required: false
          description: ''
          data_source: '全网规划'
          pattern: ''
          default: ''
  examples:
  - set_licenseswitch_list:
    - LICITEM: LKV2E2ETRACE02
      SWITCH: ENABLE
    set_e2etrccfg_list:
    - SGS: YES
      SV: YES
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 打开本功能的License配置开关。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该set_licenseswitch_list的变量区（command: SET LICENSESWITCH） -#}
<!-- MISSING_MACRO: command=SET LICENSESWITCH list_name=set_licenseswitch_list step_id=1 -->
```

### 2 打开SGs、Sv接口消息跟踪控制开关。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该set_e2etrccfg_list的变量区（command: SET E2ETRCCFG） -#}
<!-- MISSING_MACRO: command=SET E2ETRCCFG list_name=set_e2etrccfg_list step_id=2 -->
```

