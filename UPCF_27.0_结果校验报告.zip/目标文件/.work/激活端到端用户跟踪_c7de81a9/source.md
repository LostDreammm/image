# 激活端到端用户跟踪

* 操作场景
* 必备事项
* 操作步骤
* 任务示例

## 操作场景

本操作指导介绍在运行网络中激活端到端用户跟踪的操作过程。

ALL，端到端跟踪

## 必备事项

前提条件

* 请仔细阅读端到端用户跟踪特性概述（适用于4G）
* 完成加载License

数据

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **SET E2ETRCCFG** | 是否上报SGs接口消息（SGS） | YES | 全网规划 | 对其他接口消息的跟踪仅取决于本特性license是否开启，不涉及额外命令控制。 |
|  | 是否上报SV接口消息（SV） | YES | 全网规划 |  |

## 操作步骤

1. 打开本功能的License配置开关。

   **SET LICENSESWITCH**
2. 打开SGs、Sv接口消息跟踪控制开关。

   **SET E2ETRCCFG**

## 任务示例

任务描述

开启端到端用户跟踪特性，并设置系统支持对SGs、Sv接口消息的跟踪及上报。

脚本

//打开License配置开关

```
SET LICENSESWITCH: LICITEM="LKV2E2ETRACE02", SWITCH=ENABLE;
```

//打开SGs、Sv接口消息跟踪控制开关。

```
SET E2ETRCCFG: SGS=YES, SV=YES;
```

版权所有 © 华为技术有限公司
