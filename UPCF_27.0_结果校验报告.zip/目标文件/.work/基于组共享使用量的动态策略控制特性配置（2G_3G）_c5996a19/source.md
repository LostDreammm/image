# 基于组共享使用量的动态策略控制特性配置（2G/3G）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

2G/3G网络下，基于组共享使用量的动态策略控制主要有如下两种应用场景：

* 运营商为企业创建一个组，给此组签约100GB的包月流量业务，初始带宽为10 Mbit/s，超过流量配额后带宽下降为128 Kbit/s。运营商设置流量使用量通知给组用户。组用户把500名成员加入此组中，设置每个成员的最大流量限额，对于流量消耗多的成员设置500MB最大流量，对于流量消耗少的成员设置100MB最大流量。
* 运营商创建一个家庭组，给此家庭组签约10GB的包月流量业务，初始带宽为10 Mbit/s，超过流量配额后带宽下降为128 Kbit/s。运营商设置流量使用量通知给家庭组用户。组用户把5名成员加入此组中，设置每个成员的最大流量限额，对于流量消耗多的成员设置2GB最大流量，对于流量消耗少的成员设置1GB最大流量。

以一个企业部门签约上网流量包月业务，组用户设置每个成员的最大流量限额，UPCF对接华为GGSN场景为例：

* 组的配额：100 GB。
* 每月1号01:00:00进行总配额复位，剩余配额采用清零方式。
* 组内所有用户共用同一带宽，带宽控制策略：
  + 组成员虚拟配额和总配额均未耗尽，上行带宽为2 Mbit/s，下行带宽为10 Mbit/s。
  + 某组成员虚拟配额耗尽但总配额未耗尽，该组成员上行和下行带宽分别为500 Kbit/s和1 Mbit/s，UPCF发送通知给该组成员。
  + 总配额耗尽后，上行带宽下降为64 Kbit/s，下行带宽下降为128 Kbit/s。

  总配额并不一定等于虚拟配额之和，当总配额耗尽后，如果某组成员的虚拟配额未耗尽，UPCF也会下发总配额耗尽后的规则。
* 当总配额消耗完，发送通知给组用户。
* 组用户把500名员工加入此组中：
  + 为每个组用户设置100MB的流量限额。
  + 组用户不设置限额，默认可以使用组签约的所有流量。

组用户开户并签约业务后，可执行ADD PGRPMBR命令，增加组成员并设定组成员的最大流量限额。

#### 对系统的影响

本特性对系统无影响。

#### 必备事项

**前提条件**

* UPCF和对端PCEF（Policy and Charging Enforcement Function）遵循3GPP R9协议定义的FUP（Fair Usage Policy）上报模式。
* 操作员已了解WHFD-611053 基于组共享使用量的动态策略控制特性概述。
* 用户没有签约WHFD-611006 基于共享使用量的动态策略控制特性配置。若用户已签约WHFD-611006 基于共享使用量的动态策略控制特性配置，则该用户属于主从用户组，不能加入组共享使用组业务。

**数据**

根据应用场景，参考业务拆解总体原则，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系

配置建议：

* 当总配额耗尽时，建议不使用流量阻断策略而是使用降低带宽等策略。因为UPCF按照性能处理能力采用排队方式给所有在线成员通过RAR下发策略，策略下发有延时，这样导致配额耗尽后，未更新策略的成员继续在使用流量，这样最终用户使用流量会超过总配额，不能做到精确控制。
* 总配额复位时UPCF会给在线成员都下发RAR消息更新策略，PCRF按照性能处理能力采用排队方式给所有在线成员通过RAR下发策略，策略下发有延时，使得在配额复位时间点上报的成员消耗的配额分片可能统计到新的周期。
* 营帐对总配额的查询、充值、修改操作时，不考虑正在处理的配额分片。
* 如果一个组内有超过100个组成员，需要营帐系统管理成员列表。因为营帐SOAP消息长度的限制，如果组成员个数小于等于100，则查询命令的返回消息中携带用户组下所有成员的标识。如果组成员个数超过100，则命令返回消息中只携带用户组下的成员个数。操作员可通过ADD EXPTASK命令添加导出任务导出组用户标识和组成员标识列表。

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 组用户  Share\_Group | 用户开户身份为Group的用户。组用户可以对组进行设置修改。 | 组用户签约需共享的业务，组成员只需加入组中即可使用组用户共享的业务。 |
| 组成员  Group\_Member | 组内所有成员。 | 组成员可以设置限额。如果不设置，默认使用组用户共享的所有流量。 |
| 业务  Group\_Service | 组签约的业务，共享给组成员使用。 | 根据业务规划，设置此业务为组业务，只能给组用户签约。 |
| 配额  Share\_Quota | 配置组的配额类型、配额值、复位时间及阈值等。配额类型为会话级，监控键值为1。 | 配额是组签约业务的总流量，所有组成员使用的流量均在此配额上扣减。  当采用3GPP R9协议定义的FUP上报模式时，必须配置“监控键值”。 |
| 策略  Policy\_Group | 此策略在组成员上线和流量消耗的过程中被调用，触发器分别为IPCANSessionEstablish和UsageReport，包含所有规则。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配并下发策略给PCEF。 |
| 规则  Rule\_Normal | * 条件：组成员虚拟配额和总配额均未耗尽。 * 动作：  CmdQoSAction：上行带宽为2 Mbit/s，下行带宽为10 Mbit/s。  ChargingAction：“RatingGroup”为1（1代表不计费）。  UsageReport：“MonitorKey”取值为1。 | * 若对端为华为GGSN，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。“RatingGroup”的取值需与在线/离线计费系统协商一致。 * 业务流：若不区分各业务的数据流，统一只根据会话流量控制带宽，则规则中上下行业务流均取默认值“Any IP Protocol”。 * 当用户签约基于流量的会话级或者业务级配额，且UPCF和对端PCEF遵循3GPP R9协议定义的FUP（Fair Usage Policy）上报模式时，则UPCF侧需要配置动作UsageReport。 |
| 规则  Rule\_Virtual\_Exhaust | * 条件：组成员虚拟配额耗尽，总配额未耗尽。 * 动作：  QoSAction：上行带宽为500 Kbit/s，下行带宽为1 Mbit/s。  ChargingAction：“RatingGroup”为1（1代表不计费）。  UsageReport：“MonitorKey”取值为1。 |  |
| 规则  Rule\_Exhaust | * 条件：总配额耗尽。 * 动作：  QoSAction：上行带宽为64 Kbit/s，下行带宽为128 Kbit/s。  ChargingAction：“RatingGroup”为1（1代表不计费）。  UsageReport：“MonitorKey”取值为1。 |  |

#### 操作流程

此特性的配置流程图如图2所示。

**图2** 业务配置流程图

#### 操作步骤

1. 配置软参。

   当UPCF需要开启组共享使用量业务的Diameter重定向功能时，修改此软参取值，否则，请跳过此步骤。

   * 在配置组共享使用量时，当UPCF为多FE组网或主备FE组网时，需要开启Diameter重定向功能。避免同一个组的用户在不同FE上处理，导致配额扣减出现错误。
   * 此配置需要对端PCEF支持Diameter重定向功能，并且对端PCEF和所有FE都有连接，才能打开。

   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD INSP**命令，配置参数VRM\_GROUPDIAREDIRECTSWITCH。

      命令举例：

      ```
      MOD INSP: INSPN=VRM_GROUPDIAREDIRECTSWITCH, INSPV=1;
      ```
2. 修改对端PCEF能力字典项。
   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其不支持R8标准的QoS。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=R8QoS, ABLITYVALUE=UnsupportedR8QoS;
      ```

      在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”需设置为“67”。实际的值可以通过如下方式查询：
      * 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。
      * 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
   3. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持基于3GPP R9标准的Usage Monitoring机制。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=UsageMonitor, ABLITYVALUE=UsageMonitor3GPPR9;	
      ```

      * 其中“ABILITYDICTID”为“能力字典ID”，请根据实际情况填写。当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
      * 当配置的FUP业务需使用3GPP R9 标准的Usage Monitoring机制时，才需配置“UsageMonitor3GPPR9”的能力，否则不需配置。
3. 登录UPCF WebUI界面。
4. 配置短信/邮件模板。

   导航入口为“通知管理 > 消息配置 > 短信/邮件模板”。

   短信/邮件模版的数据规划如表2所示，详细参数说明请参见短信/邮件模板参数值。

   **表2** 短信/邮件模板

   | 类别 | 参数 | 取值样例 |
   | --- | --- | --- |
   | 短信/邮件模板 1 | 名称 | Notification\_Template\_V |
   |  | 标题 | 虚拟配额耗尽通知 |
   |  | 类型 | 短信/邮件 |
   |  | 内容 | 尊敬的{OBJ.Subscriber.MSISDN}用户，截止{OBJ.System.DateTime}，您的虚拟配额已耗尽。 |
   | 短信/邮件模板 2 | 名称 | Notification\_Template |
   |  | 标题 | 配额耗尽通知 |
   |  | 类型 | 短信/邮件 |
   |  | 内容 | 尊敬的{OBJ.Subscriber.MSISDN}用户，截止{OBJ.System.DateTime}，您订购的业务{OBJ.Subscription.ServiceName}配额已耗尽。 |
5. 配置配额。

   导航入口为“业务管理 > 业务 > 配额”。

   * 配额（Quota）是指一个指定周期内供用户使用的流量或时长额度，也可指单个会话内供用户使用的时长额度。当业务的使用与流量、时长相关时，需要配置配额。
   * 本特性配置的配额为组的总配额。

   配额的数据规划如表3所示，详细参数说明请参见配额参数表。

   **表3** 配额

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 配额 | 基本信息 | 名称 | Share\_Quota |
   |  |  | 配额管理归属 | UPCC |
   |  |  | 配额类型 | 流量 |
   |  |  | 类型 | 会话级 |
   |  |  | 监控键值 | 1 |
   |  |  | 值(KB) | 104857600 |
   |  |  | 分片类型 | 值  说明：  建议设置为“值”。如果设置为“百分比”，存在如下问题： * 在同一个组内，设置了虚拟配额的用户和未设置虚拟配额的用户的配额分片大小不一致，影响运营商进行性能评估。 * 总配额一般较大，下发的分片值较大，从而影响配额累积的精度。 |
   |  |  | 分片(KB) | 10240 |
   |  | 复位设置 | 结帐模式 | 自然日历 |
   |  |  | 复位周期类型 | 月 |
   |  |  | 复位日 | 1 |
   |  |  | 复位时间 | 01:00:00 |
   |  |  | 剩余额处理方式 | 清零 |
6. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置三个条件组，用于判断虚拟配额及总配额是否耗尽。条件组的数据规划如表4所示，详细参数说明请参见条件组参数表。

   **表4** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_Normal |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | Condition\_Normal |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Share\_Quota  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Normal  说明：  “Normal”：表示总配额未耗尽。 |
   |  | 条件2 | 名称 | Condition\_V\_Normal |
   |  |  | 对象属性 | * 对象：Quota * 属性：VirtualQuotaStatus |
   |  |  | 对象实例 | Share\_Quota  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Normal  说明：  “Normal”：表示虚拟配额未耗尽。 |
   | 条件组2 | 基本信息 | 名称 | CG\_Virtual\_Exhaust |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | Condition\_Normal |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Share\_Quota  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Normal  说明：  “Normal”：表示总配额未耗尽。 |
   |  | 条件2 | 名称 | Condition\_V\_Exhaust |
   |  |  | 对象属性 | * 对象：Quota * 属性：VirtualQuotaStatus |
   |  |  | 对象实例 | Share\_Quota  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示虚拟配额耗尽。 |
   | 条件组3 | 基本信息 | 名称 | CG\_Exhaust |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | Condition\_Exhaust |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Share\_Quota  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示总配额耗尽。 |
7. 配置5G动作组。

   导航入口为“策略管理 > 策略 > 动作组”。

   * 若配置的规则为动态规则，则必须配置动作组。
   * 此场景配置动态规则且需要考虑调整带宽、计费动作和流量上报，则每个动作组需配置动作：CmdQoSAction、QoSAction、ChargingAction和UsageReport。相关应用场景如下：

     + CmdQoSAction：用于设置采取的会话层QoS策略。在用户签约的业务中，含有CmdQoSAction的规则激活时，QoSAction不参与会话层QoS策略的计算。
     + QoSAction：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制QoS。
     + ChargingAction：当需要做计费策略控制时，配置此动作（若对端为华为GGSN，此动作必须配置）。
     + UsageReport：当需要进行流量上报时，配置此动作。

   需要配置三个动作组，用于虚拟配额及总配额均未耗尽、虚拟配额耗尽但总配额未耗尽、总配额耗尽时动作的下发。动作组的数据规划如表5所示，详细参数说明请参见动作组参数表。

   **表5** 动作组

   | 类别 | 参数 |  |  | 取值样例 |
   | --- | --- | --- | --- | --- |
   | 动作组1 | 基本信息 | 名称 |  | AG\_Normal |
   |  | 动作1 | 动作 |  | CmdQoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(Kbit/s)：2000 |
   |  |  |  | MBRDL | * 值类型：Value * 值(Kbit/s)：10000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(Kbit/s)：2000 |
   |  |  |  | GBRDL | * 值类型：Value * 值(Kbit/s)：10000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   |  | 动作3 | 动作 |  | UsageReport |
   |  |  | 动作元素 | Monitorkey | * 值类型：Value * 1 |
   | 动作组2 | 基本信息 | 名称 |  | AG\_Virtual\_Exhaust |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(Kbit/s)：500 |
   |  |  |  | MBRDL | * 值类型：Value * 值(Kbit/s)：1000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(Kbit/s)：500 |
   |  |  |  | GBRDL | * 值类型：Value * 值(Kbit/s)：1000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   |  | 动作3 | 动作 |  | UsageReport |
   |  |  | 动作元素 | Monitorkey | * 值类型：Value * 值：1 |
   | 动作组3 | 基本信息 | 名称 |  | AG\_Exhaust |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(Kbit/s)：64 |
   |  |  |  | MBRDL | * 值类型：Value * 值(Kbit/s)：128 |
   |  |  |  | GBRUL | * 值类型：Value * 值(Kbit/s)：64 |
   |  |  |  | GBRDL | * 值类型：Value * 值(Kbit/s)：128 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   |  | 动作3 | 动作 |  | UsageReport |
   |  |  | 动作元素 | Monitorkey | * 值类型：Value * 值：1 |
8. 配置业务流。

   导航入口为“策略管理 > 策略 > 业务流”。

   当对端为华为GGSN时，所有的动态规则都必须配置业务流。

   业务流的数据规划如表6所示，详细参数说明请参见业务流参数表。

   **表6** 业务流

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务流 | 基本信息 | 名称 | Flow\_Filter |
   |  | 流过滤器1 | 名称 | up\_pass |
   |  |  | 流方向 | Up |
   |  |  | 协议 | Any IP Protocol |
   |  | 流过滤器2 | 名称 | down\_pass |
   |  |  | 流方向 | Down |
   |  |  | 协议 | Any IP Protocol |
9. 配置消息通知。

   导航入口为“策略管理 > 策略 > 消息通知”。

   “唯一键”为抑制发送消息通知的条件。例如，在配额状态不改变时，则抑制发送相同的消息通知，“唯一键”选择对象Quota下的属性QuotaStatus；在服务区不改变时，则抑制发送相同的消息通知，则“唯一键”选择对象IPSession下的属性ServiceZone。

   消息通知的数据规划如表7所示，详细参数说明请参见消息通知参数表。

   **表7** 消息通知

   | 类别 | 参数 | 取值样例 |
   | --- | --- | --- |
   | 消息通知 1 | 名称 | Notification\_V |
   |  | 短信 | Notification\_Template\_V  说明：  已在短信/邮件模板中定义。 |
   |  | 发送抑制 | Yes |
   |  | 抑制类型 | 按配额周期 |
   |  | 唯一键 | * 对象：Quota * 属性：QuotaStatus |
   |  | 对象实例 | Share\_Quota  说明：  已在配额中定义。 |
   | 消息通知 2 | 名称 | Notification |
   |  | 短信 | Notification\_Template  说明：  已在短信/邮件模板中定义。 |
   |  | 发送抑制 | Yes |
   |  | 抑制类型 | 按配额周期 |
   |  | 唯一键 | * 对象：Quota * 属性：QuotaStatus |
   |  | 对象实例 | Share\_Quota  说明：  已在配额中定义。 |
10. 配置规则。

    导航入口为“策略管理 > 策略 > 规则”。

    规则的数据规划如表8所示，详细参数说明请参见规则参数表。

    **表8** 规则

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 规则1 | 基本信息 | 名称 | Rule\_Normal |
    |  |  | 操作类型 | Change Rule |
    |  |  | 类型 | Dynamic |
    |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
    |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
    |  |  | 条件组 | CG\_Normal  说明：  已在条件组中定义。 |
    |  | 动作组 | 动作组 | AG\_Normal  说明：  已在动作组中定义。 |
    | 规则2 | 基本信息 | 名称 | Rule\_Virtual\_Exhaust |
    |  |  | 操作类型 | Change Rule |
    |  |  | 类型 | Dynamic |
    |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
    |  |  | 消息通知 | Notification\_V  说明：  已在消息通知中定义。 |
    |  |  | 通知对象 | Self  说明：  此参数有三种取值：Self、Group、Self+Group。各参数处理方式：  * Self：表示通知只下发给组成员自己。 * Group：表示通知只下发给组用户。 * Self+Group：表示通知发给组成员和组用户。 |
    |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
    |  |  | 条件组 | CG\_Virtual\_Exhaust  说明：  已在条件组中定义。 |
    |  | 动作组 | 动作组 | AG\_Virtual\_Exhaust  说明：  已在动作组中定义。 |
    | 规则3 | 基本信息 | 名称 | Rule\_Exhaust |
    |  |  | 操作类型 | Change Rule |
    |  |  | 类型 | Dynamic |
    |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
    |  |  | 消息通知 | Notification  说明：  已在消息通知中定义。 |
    |  |  | 通知对象 | Self+Group  说明：  此参数有三种取值：Self、Group、Self+Group。各参数处理方式：  * Self：表示通知只下发给组成员自己。 * Group：表示通知只下发给组用户。 * Self+Group：表示通知发给组成员和组用户。 |
    |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
    |  |  | 条件组 | CG\_Exhaust  说明：  已在条件组中定义。 |
    |  | 动作组 | 动作组 | AG\_Exhaust  说明：  已在动作组中定义。 |
11. 配置策略。

    导航入口为“策略管理 > 策略 > 策略”。

    策略的数据规划如表9所示，详细参数说明请参见策略参数表。

    **表9** 策略

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 策略 | 基本信息 | 名称 | Policy\_Group |
    |  | 触发器 | 名称 | IPCANSessionEstablish  UsageReport |
    |  | 规则 | 名称 | * Rule\_Normal * Rule\_Virtual\_Exhaust * Rule\_Exhaust 说明：  已在规则中定义。 |
12. 配置业务。

    导航入口为“业务管理 > 业务 > 业务”。

    业务的数据规划如表10所示，详细参数说明请参见业务参数表。

    **表10** 业务

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 业务 | 基本信息 | 名称 | Group\_Service |
    |  |  | 类型 | BASIC\_SERVICE |
    |  |  | 是否记入基本配额 | 是 |
    |  |  | 激活方式 | PCEF |
    |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
    |  |  | QoS模式 | 并集且优先级 |
    |  |  | 签约后才能使用 | 是 |
    |  |  | 是否组业务 | Yes  说明：  如果是给组用户签约的业务，则此参数必须设置为“是”。 |
    |  | 策略 | 名称 | Policy\_Group  说明：  已在策略中定义。 |
    |  | 配额 | 名称 | Share\_Quota  说明：  已在配额中定义。 |
13. 登录“UPCF 业务管理”窗口。
14. 执行**ADD PSUB**增加组用户。

    组用户的数据规划如表11所示。

    **表11** 组用户

    | 类别 | 参数 | 取值样例 |
    | --- | --- | --- |
    | **ADD PSUB** | 用户标识 | Share\_Group |
    |  | 移动用户MSISDN号 | 12345678901  说明：  若需发送短信通知，则必须配置此参数。 |
    |  | 用户状态 | Normal |
    |  | 付费类型 | NULL |
    |  | 用户身份 | Group  说明：  组用户的“USRSTATION（用户身份）”选择“Group”。 |
    |  | 联系方式 | SMS |

    命令举例：

    ```
    ADD PSUB: USRIDENTIFIER="Share_Group", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Group, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB, USRLANGUAGE=NULL, USRSMSRECEIVEFLAG=All, USRVERSTATUS=Normal;
    ```
15. 执行**ADD PSRV**给组用户签约业务。

    组用户签约业务后，组成员已共享组用户签约的业务，组成员不能单独签约组共享的业务。

    签约业务的数据规划如表12所示。

    **表12** 签约业务

    | 类别 | 参数 | 取值样例 |
    | --- | --- | --- |
    | **ADD PSRV** | 用户标识 | Share\_Group |
    |  | 业务 | Group\_Service |
    |  | 使用状态 | Normal |
    |  | 漫游类型 | NULL |

    命令举例：

    ```
    ADD PSRV: USRIDENTIFIER="Share_Group", SRVNAME="Group_Service", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
    ```
16. 执行**ADD PGRPMBR**增加组成员。

    组成员的数据规划如表13所示。

    **表13** 组成员

    | 类别 | 参数 | 取值样例 |
    | --- | --- | --- |
    | **ADD PGRPMBR** | 成员用户标识 | Group\_Member |
    |  | 组用户标识 | Share\_Group |
    |  | 配额名称 | Share\_Quota  说明：  * 该配额名称必须是被组用户已签约。 * 此参数不指定时，默认使用组用户所签约业务的所有配额。 |
    |  | 总量（KB） | 102400  说明：  * “102400”：表示组成员的虚拟配额为100MB。 * 如果参数配额名称被设置，此参数也必须被设置。 |

    * 若用户已开户，直接执行**ADD PGRPMBR**加入组。
    * 若用户未开户，则用户需要先执行**ADD PSUB**开户，再执行**ADD PGRPMBR**加入组。
    * 组成员加入组后，已共享组用户签约的业务。若组成员还需配置自己独有的业务，则在“业务”或“套餐”里增加相应的业务并签约。

    命令举例：

    ```
    ADD PGRPMBR: USRIDENTIFIER="Group_Member", GRPIDENTIFIER="Share_Group", GRPQUOTANAME="Share_Quota", GRPSHAREQUOTAVALUE=102400;
    ```

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
