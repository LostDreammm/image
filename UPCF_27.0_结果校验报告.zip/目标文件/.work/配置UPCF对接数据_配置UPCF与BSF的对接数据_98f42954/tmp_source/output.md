---
id: ''
name: 配置UPCF与BSF的对接数据
ne_type: UPCF
type: feature
description: UPCF需支持通过HTTP和Diameter接口与BSF（Binding Support Function）进行交互，接收并处理PCF的绑定信息注册/注销请求，绑定会话信息。  * 当UPCF通过Diameter接口与BSF对接时，BSF作为一个DRA网元功能实体，具体对接配置请参考配置UPCF与DRA的对接数据。 * 当UPCF通过HTTP接口与BSF直接对接时，BSF作为一个5G Core网元功能实体，具体对接配置请参考本章节。 * 当UPCF通过HTTP接口与BSF经SCP间接通信时，BSF作为一个5G Core网元功能实体，具体对接配置请参考配置UPCF与SCP的对接数据。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（非SDN）","配置UPCF对接数据","配置UPCF与BSF的对接数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UPCF需支持通过HTTP和Diameter接口与BSF（Binding Support Function）进行交互，接收并处理PCF的绑定信息注册/注销请求，绑定会话信息。* 当UPCF通过Diameter接口与BSF对接时，BSF作为一个DRA网元功能实体，具体对接配置请参考配置UPCF与DRA的对接数据。* 当UPCF通过HTTP接口与BSF直接对接时，BSF作为一个5G Core网元功能实体，具体对接配置请参考本章节。* 当UPCF通过HTTP接口与BSF经SCP间接通信时，BSF作为一个5G Core网元功能实体，具体对接配置请参考配置UPCF与SCP的对接数据。

## 必备事项
前提条件

* 已完成软件安装。
* UPCF侧已完成基础数据配置。
* BSF侧已完成基础数据配置。
* 已经获得运营商规划的UPCF与BSF的对接IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_hlbdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 32
          required: true
          description: '本端规划，该参数需要与VNRS的**ADD L3VPNINST**和**ADD VPNINSTAF**命令中“VPN实例名称”参数值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        HTTPSFUNC:
          name: 'HTTPS功能'
          type: string
          enum:
          - ON
          - OFF
          required: false
          description: '本端规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ON
        CERTSCENE:
          name: '证书应用场景'
          type: string
          enum:
          - UPCF_HLB_Lcert
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TLSCFGID:
          name: 'TLS配置ID'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_bsfcfg_list:
      type: items
      properties:
        ID:
          name: 'ID'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: '固定取值。'
          data_source: ''
          pattern: ''
          default: ''
        SWITCH:
          name: 'SWITCH'
          type: string
          enum:
          - Unsupport
          - Support
          required: true
          description: '本端规划，支持BSF功能。'
          data_source: ''
          pattern: ''
          default: ''
        IPV4ADDR:
          name: 'IPV4ADDR'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: '本端规划，支持IPv4终端地址。'
          data_source: ''
          pattern: ''
          default: ''
        FQDN:
          name: 'FQDN'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: '本端规划，支持N5接口功能。'
          data_source: ''
          pattern: ''
          default: ''
        FAILEDRELEASE:
          name: 'FailedRelease'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        GPSI:
          name: 'Gpsi'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPDOMAIN:
          name: 'IpDomain'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPENDPOINT:
          name: 'IpEndPoint'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6PREFIX:
          name: 'Ipv6Prefix'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MACADDR48:
          name: 'MacAddr48'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCFDIAMHOST:
          name: 'PcfDiamHost'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCFDIAMREALM:
          name: 'PcfDiamRealm'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SUPI:
          name: 'Supi'
          type: string
          enum:
          - Unsupport
          - Support
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_conditional_discovery:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '当PCF通过指定条件发现远端服务时，需要配置此命令，否则跳过。'
      data_source: ''
      pattern: ''
      default: TRUE
    add_disccondcfg_list:
      type: items
      properties:
        NFTYPE:
          name: '网元类型'
          type: string
          enum:
          - CHF
          - BSF
          - SCP
          - AMF
          - NWDAF
          - PCF
          required: true
          description: '对端网元类型，此处固定为**BSF**。'
          data_source: ''
          pattern: ''
          default: ''
        BSFPARA:
          name: 'BSF参数'
          type: string
          enum:
          - IPV4ADDR
          - IPV4DNN
          - IPV4IPDOMAIN
          - IPV6PREFIX
          - SRVNAME
          required: false
          description: '全网规划，由运营商提供，可以同时存在多个参数取值。'
          data_source: ''
          pattern: ''
          default: ''
        AMFPARA:
          name: 'AMF参数'
          type: string
          enum:
          - SETID
          - GUAMI
          - PREFERLOC
          - NFINSTANCE
          - SRVNAME
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CHFPARA:
          name: 'CHF参数'
          type: string
          enum:
          - GPSI
          - PREFERLOC
          - SRVNAME
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        NWDAFPARASW:
          name: 'NWDAF参数'
          type: string
          enum:
          - TAI
          - EVENT
          - SRVNAME
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCFPARA:
          name: 'PCF参数'
          type: string
          enum:
          - HPCFID
          - SUPI
          - GPSI
          - SRVNAME
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PREFERLOCVALUE:
          name: '优选位置值'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SCPPARA:
          name: 'SCP参数'
          type: string
          enum:
          - SERSCOPE
          - SCPDOMAIN
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: SCPDOMAIN
    is_scenario_static_discovery:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '当PCF采取静态方式发现远端服务时，需要配置此命令，否则跳过。'
      data_source: ''
      pattern: ''
      default: TRUE
    add_discnfprofile_list:
      type: items
      properties:
        NFINSNAME:
          name: '网元实例名称'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: '用于标识一个服务发现网元实例的名称，该参数全局唯一，可参考样例填写。'
          data_source: ''
          pattern: ''
          default: ''
        NFINSID:
          name: '网元实例标识'
          type: string
          minLength: 0
          maxLength: 36
          required: true
          description: '本端规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        NFTYPE:
          name: '网元类型'
          type: string
          enum:
          - UDM
          - AUSF
          - PCF
          - UDR
          - AMF
          - SMF
          - NEF
          - AF
          - SMSF
          - BSF
          - CHF
          - SCP
          - NWDAF
          - IOMF
          required: true
          description: '对端网元类型，此处固定为**BSF**。'
          data_source: ''
          pattern: ''
          default: ''
        NFPROFILE:
          name: '网元实例信息'
          type: string
          minLength: 0
          maxLength: 8000
          required: true
          description: '* ipv4Address配置为BSF的IP地址，port配置为BSF的端口。 * 存在多个对端时，需要添加多个**ADD DISCNFPROFILE**网元实例记录，并通过“priority”来标识对端优先级。'
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_hlbdevaddr_list:
    - DEVAID: 5
      VPNNAME: 'VPN_SBA'
      IPVER: IPV4
      IP: '10.100.100.181'
      HTTPSFUNC: OFF
      CERTSCENE: ''
      TLSCFGID: ''
      IPV6: ''
    set_bsfcfg_list:
    - ID: 1
      SWITCH: Support
      IPV4ADDR: Support
      FQDN: Support
      FAILEDRELEASE: ''
      GPSI: ''
      IPDOMAIN: ''
      IPENDPOINT: ''
      IPV6PREFIX: ''
      MACADDR48: ''
      PCFDIAMHOST: ''
      PCFDIAMREALM: ''
      SUPI: ''
    is_scenario_conditional_discovery: TRUE
    add_disccondcfg_list:
    - NFTYPE: BSF
      BSFPARA: IPV4ADDR-1&IPV4DNN-0&IPV4IPDOMAIN-1&IPV6PREFIX-0
      AMFPARA: ''
      CHFPARA: ''
      NWDAFPARASW: ''
      PCFPARA: ''
      PREFERLOCVALUE: ''
      SCPPARA: SCPDOMAIN
    is_scenario_static_discovery: TRUE
    add_discnfprofile_list:
    - NFINSNAME: 'bsf'
      NFINSID: '6947a69a-f61b-4bc1-b9da-47c9c5d11111'
      NFTYPE: BSF
      NFPROFILE: '{\"nfServices\":[{\"serviceInstanceId\":\"5947a69a-f61b-4bc1-b9da-47c9c8690005\",\"serviceName\":\"nbsf-management\",\"scheme\":\"http\",\"ipEndPoints\":[{\"ipv4Address\":\"192.168.100.181\",\"transport\":\"TCP\",\"port\":41005}],\"nfServiceStatus\":\"REGISTERED\",\"versions\":[{\"apiVersionInUri\":\"v1\",\"apiFullVersion\":\"1.PreR15.1.0\"}]}],\"nfInstanceId\":\"6947a69a-f61b-4bc1-b9da-47c9c5d11111\",\"nfStatus\":\"REGISTERED\",\"nfType\":\"BSF\", \"ipv4Addresses\":[\"192.168.100.181\"], \"priority\":1}'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录“UPCF MML命令”界面。

### 2 执行**LST HLBDEVADDR**命令，查询HLB服务配置的所有设备地址标识。

### 报文示例如下：

### %%LST HLBDEVADDR:;%%

### RETCODE = 0  操作成功

### 操作结果如下

### ------------

### 设备地址标识  =  2

### VPN名称  =  VPN1

### IP版本  =  IPV4

### IPV4地址  =  10.168.0.130

### IPV6地址  =  NULL

### HTTPS功能  =  ON

### 证书应用场景  =  UPCF_HLB_Lcert

### TLS配置ID  =  1

### 描述  =  HLB_IPV4

### (结果个数 = 1)

### ---    END

### 3 执行**ADD HLBDEVADDR**命令增加HLB服务用于与BSF对接的本端IP地址。

```jinja2
{%- for item in add_hlbdevaddr_list -%}
    ADD HLBDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNNAME="{{item.VPNNAME}}",
    IPVER={{item.IPVER}},
    {#- --- 可选参数 --- -#}
    {%- if item.HTTPSFUNC is not none -%}
        HTTPSFUNC={{item.HTTPSFUNC}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：HTTPSFUNC=ON 时必选 --- -#}
    {%- if item.HTTPSFUNC == 'ON' -%}
        CERTSCENE={{item.CERTSCENE}},
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    {#- --- 条件必选：HTTPSFUNC=ON 时必选 --- -#}
    {%- if item.HTTPSFUNC == 'ON' -%}
        TLSCFGID={{item.TLSCFGID}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 4 执行**SET BSFCFG**命令，配置为支持BSF功能。

```jinja2
{%- for item in set_bsfcfg_list -%}
    SET BSFCFG:
    {#- --- 必选参数 --- -#}
    ID={{item.ID}},
    SWITCH={{item.SWITCH}},
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.IPV4ADDR is not none -%}
            IPV4ADDR={{item.IPV4ADDR}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.FQDN is not none -%}
            FQDN={{item.FQDN}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.FAILEDRELEASE is not none -%}
            FAILEDRELEASE={{item.FAILEDRELEASE}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.GPSI is not none -%}
            GPSI={{item.GPSI}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.IPDOMAIN is not none -%}
            IPDOMAIN={{item.IPDOMAIN}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.IPENDPOINT is not none -%}
            IPENDPOINT={{item.IPENDPOINT}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.IPV6PREFIX is not none -%}
            IPV6PREFIX={{item.IPV6PREFIX}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.MACADDR48 is not none -%}
            MACADDR48={{item.MACADDR48}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.PCFDIAMHOST is not none -%}
            PCFDIAMHOST={{item.PCFDIAMHOST}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.PCFDIAMREALM is not none -%}
            PCFDIAMREALM={{item.PCFDIAMREALM}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SWITCH=Support 时可选 --- -#}
    {%- if item.SWITCH == 'Support' -%}
        {%- if item.SUPI is not none -%}
            SUPI={{item.SUPI}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 4.1 该命令用于设置BSF开关状态以及指定支持BSF时需要上报的属性参数，示例未列出的具体属性参数请根据实际情况规划选择是否支持。

#### 4.2 当BSF只备份语音DNN会话，请将软参VRM\_BSFONLYVOLTE设置为1；如果需要BSF同时备份数据和语音等其他DNN会话，请提前端到端确认系统容量、组网方案，并将软参VRM\_BSFONLYVOLTE设置为0。

### 5 当PCF通过指定条件发现远端服务时，需要配置此命令，否则跳过。

### 执行**ADD DISCCONDCFG**命令，增加发现BSF网元的条件信息。

```jinja2
{%- if is_scenario_conditional_discovery -%}
    {%- for item in add_disccondcfg_list -%}
        ADD DISCCONDCFG:
        {#- --- 必选参数 --- -#}
        NFTYPE={{item.NFTYPE}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：NFTYPE=BSF 时必选 --- -#}
        {%- if item.NFTYPE == 'BSF' -%}
            BSFPARA={{item.BSFPARA}},
        {%- endif -%}
        {#- --- 条件必选：NFTYPE=AMF 时必选 --- -#}
        {%- if item.NFTYPE == 'AMF' -%}
            AMFPARA={{item.AMFPARA}},
        {%- endif -%}
        {#- --- 条件必选：NFTYPE=CHF 时必选 --- -#}
        {%- if item.NFTYPE == 'CHF' -%}
            CHFPARA={{item.CHFPARA}},
        {%- endif -%}
        {#- --- 条件必选：NFTYPE=NWDAF 时必选 --- -#}
        {%- if item.NFTYPE == 'NWDAF' -%}
            NWDAFPARASW={{item.NWDAFPARASW}},
        {%- endif -%}
        {#- --- 条件必选：NFTYPE=PCF 时必选 --- -#}
        {%- if item.NFTYPE == 'PCF' -%}
            PCFPARA={{item.PCFPARA}},
        {%- endif -%}
        {#- --- 条件必选：NFTYPE=SCP 时必选 --- -#}
        {%- if item.NFTYPE == 'SCP' -%}
            SCPPARA={{item.SCPPARA}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：NFTYPE=CHF/AMF 时可选 --- -#}
        {%- if item.NFTYPE in ['CHF', 'AMF'] -%}
            {%- if item.PREFERLOCVALUE is not none -%}
                PREFERLOCVALUE="{{item.PREFERLOCVALUE}}",
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 6 当PCF采取静态方式发现远端服务时，需要配置此命令，否则跳过。

### 执行**ADD DISCNFPROFILE**命令，增加发现BSF网元的实例信息。

### 当对端配置了多个IP和端口时，需要对应配置多条**ADD DISCNFPROFILE**命令，添加对应的网元实例信息，并通过“priority”来控制对端的优先级。“priority”取值越小，对端优先级越高。例如，存在2个对端，“priority”分别取值为1和2时，对端为主备工作模式，UPCF只与“priority”为1的对端进行消息交互；“priority”取值相同时，对端为负荷分担工作模式，UPCF会轮选对端进行消息交互。

```jinja2
{%- if is_scenario_static_discovery -%}
    {%- for item in add_discnfprofile_list -%}
        ADD DISCNFPROFILE:
        {#- --- 必选参数 --- -#}
        NFINSNAME="{{item.NFINSNAME}}",
        NFINSID="{{item.NFINSID}}",
        NFTYPE={{item.NFTYPE}},
        NFPROFILE="{{item.NFPROFILE}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

