# 配置MML的SSH接入

* 操作场景
* 对系统的影响
* 必备事项
* 操作步骤

#### 操作场景

当USCDB与业务发放系统均完成硬件数据和基础数据的配置后，需要配置PGW MML的SSH接入安全策略。

传统的网络服务程序，如：FTP在网络上用明文传送口令和数据，这些口令和数据很容易被第三方非法截获并冒充真正的服务器进行收发数据。因此出于安全的考虑，需要在配置PGW MML的SSH接入安全策略。

#### 对系统的影响

无。

#### 必备事项

**前提条件**

向系统管理员获取OM Portal的帐号的密码。

**数据**

该操作无需准备数据。

#### 操作步骤

1. 登录“USCDB MML命令”界面。
2. 执行**ADD PGWSSHUSER**命令增加PGW SSH用户。

   ```
   ADD PGWSSHUSER: USERNAME=用户名, PWD=新密码, CFM=确认密码, PORT=PGW服务端口, DESCRIPTION=用户描述;
   ```

   “PGW服务端口”可以通过**LST PORT**命令查询，使用“端口类型”为“PORT\_FOR\_PROV”，“端口子类型”为“PORT\_FOR\_MML”对应的端口作为“PGW服务端口”。

   当SSH客户端完成SSH鉴权后，需要发送PGW的登录鉴权指令**LGI**鉴权成功，才能执行后续PGW命令。
3. 执行**MOD INSP**命令将软参“PGWMMLSWITCH”修改“0”，禁止客户端通过MML接入PGW。

   ```
   MOD INSP: INSPT=PGW, INSPN=PGWMMLSWITCH, INSPV=0;
   ```

版权所有 © 华为技术有限公司
