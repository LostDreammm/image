# 检查数据

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤

#### 操作场景

当完成容灾组网部署时，需要对主用UPCF和容灾UPCF的设备进行对接调测，以检查容灾相关配置是否正确。为保证主用与容灾系统能够正常使用，需要对数据进行检查。

#### 对系统的影响

该操作对系统正常运行无影响。

#### 必备事项

**前提条件**

* 已经检查主用局和容灾局的硬件运行状态、软件运行情况、数据配置等。
* 已经完成主用局和容灾局的BE和FE对接。请参考对接主用容灾局。

**数据**

执行操作前需要根据工程设计输出和运营商统一规划信息规划参数取值。

从工程设计输出中提取容灾调测需要的数据：

* 主用UPCF和容灾UPCF的OMU外部IP地址、PGW外部IP地址。
* 主用UPCF的BE数据：Location ID、Cluster ID、Cluster主备标识、节点ID、远端访问优先级、数据平面IP地址、DSG模块号。
* 主用UPCF的FE数据：Location ID、远端访问优先级、数据平面IP地址、DSG模块号。
* 容灾UPCF的BE数据：Location ID、Cluster ID、Cluster主备标识、节点ID、远端访问优先级、数据平面IP地址、DSG模块号。
* 容灾UPCF的FE数据：Location ID、远端访问优先级、数据平面IP地址、DSG模块号。
* 主用UPCF和容灾UPCF的信令点、链路等信令配置。

**工具**

该操作无需准备工具。

#### 操作流程

无缝地理容灾主备组网数据检查流程如图1所示。

**图1** 无缝地理容灾主备组网数据检查流程

#### 操作步骤

1. 分别导出主用局和容灾局的USCDB、UPCF的网元配置数据，并记录导出时间。

   假设：主用局USCDB网元ID为5，UPCF网元ID为6；容灾局USCDB网元ID为11，UPCF网元ID为12。

   1. 在主用UPCF上，登录“CSP MML命令”界面。
   2. 执行**EXP MML**命令导出网元配置命令数据。

      导出参考命令如下：

      /\*导出USCDB网元配置数据\*/

      ```
      EXP MML: MEID=5, METYPE=USCDB;
      ```

      /\*导出UPCF网元配置数据\*/

      ```
      EXP MML: MEID=6, METYPE=UPCF;
      ```

      执行过程，命令界面会有导出进度信息输出，当进度提示100%时，表示导出完成。
   3. 记录导出时间。

      导出时间与命令发送时间相同，所以记录命令发送时间即可。
   4. 在容灾UPCF上，登录“CSP MML命令”界面。
   5. 导出网元配置命令数据。

      参考步骤1.b，网元ID按照假设修改为11、12。
   6. 记录导出时间。

      * 导出时间与命令发送时间相同，所以记录命令发送时间即可。
      * 导出的数据以文本文件形式保存在OMU的“导出文件”目录中，文件的名称由系统默认生成，具体请参考**EXP MML**命令的联机帮助。
2. 分别下载主用局和容灾局的USCDB、UPCF的网元配置数据到本地。

   通过SFTP下载网元配置文件，SFTP操作方法请参考上传/下载文件。下载时，SFTP界面选择的“远程目录”是“导出文件”；SFTP界面的本地目录可以是任意目录，为了操作方便，可以在本地新建一个目录“数据配置”专门保存配置命令文件。

   如果“导出文件”目录下有多个文件，请选择与1记录的导出时间相同的文件导出，以免取得的配置与当前不符。

   1. 在本地PC新建目录“数据配置”。
   2. 登录主用局的CSP MML命令界面。方法参见登录“CSP MML命令”界面。
   3. 通过SFTP将USCDB、UPCF的数据配置文件下载到“数据配置”目录。
   4. 登录容灾局的CSP MML命令界面。方法参见登录“CSP MML命令”界面。
   5. 通过SFTP将USCDB、UPCF的数据配置文件下载到“数据配置”目录。

      下载后的文件包括主用局和容灾局的4个文本文件，按照假设的网元ID，文件名可能为：

      /\*主用USCDB网元数据配置\*/

      ME5\_20091201145529.txt

      /\*主用UPCF网元数据配置\*/

      ME6\_20091201145733.txt

      /\*容灾USCDB网元数据配置\*/

      ME11\_20091201145939.txt

      /\*容灾UPCF网元数据配置\*/

      ME12\_20091201155129.txt
   6. 用文本编辑器，比如用记事本打开主用和容灾的数据配置文件，以备后续的操作使用。
3. 检查主用USCDB和容灾USCDB的容灾参数配置是否正确。需检查的参数请见配置主用容灾局的容灾参数。

   例如检查“全局数据定时刷新周期”是否正确。

   此参数在主用局和容灾局都需要检查，主用局和容灾局均设置为20。

   1. 在主用局检查。

      在主用局的USCDB配置文件中通过关键字“MOD INSP: INSPN=GLOBALDATAREFRESHCYCLE, INSPV=”找到“全局数据定时刷新周期”配置，检查命令中的参数值“INSPV”是否为“20”。

      * 是 => 配置正确。
      * 否 => 与现场华为工程师确认是否配置错误或工程设计发生变化。

      如果需要设置“全局数据定时刷新周期”，通过执行命令**MOD INSP**修改软件参数。

      ```
      MOD INSP: INSPN=GLOBALDATAREFRESHCYCLE, INSPV=20;
      ```
   2. 在容灾局检查。

      在容灾局的USCDB配置文件中通过关键字“MOD INSP: INSPN=GLOBALDATAREFRESHCYCLE, INSPV=”找到“全局数据定时刷新周期”配置，检查命令中的参数值“INSPV”是否为“20”。

      * 是 => 配置正确。
      * 否 => 与现场华为工程师确认是否配置错误或工程设计发生变化。

      如果需要设置“全局数据定时刷新周期”，通过执行**MOD INSP**命令修改软件参数。

      ```
      MOD INSP: INSPN=GLOBALDATAREFRESHCYCLE, INSPV=20;
      ```
4. 检查主用USCDB和容灾USCDB的Cluster ID是否配置正确。

   分别在主用局和容灾局的USCDB的配置文件中通过关键字“ADD CLUSTER:”找到Cluster配置命令，比对主用和容灾配置文件中相同Cluster Type（简称CT）的Cluster ID是否与工程设计相同，且主用局Cluster ID与容灾局Cluster ID是否相同。

   * 是 => 配置正确。
   * 否 => 与现场配置操作人员确认是否配置错误或工程设计发生变化。

   本例中相同CT的Cluster ID也相同，如图2所示。

   **图2** 主用局和容灾局的Cluster ID示例
5. 检查主用USCDB和容灾USCDB的Cluster主备标识是否正确。

   检查主用USCDB配置文件中Cluster的“ROLE”参数是否是“ACTIVE”，容灾局USCDB配置文件中Cluster的“ROLE”参数是否是“REDUNDANCY”。

   * 是 => 配置正确。
   * 否 => 与现场配置操作人员确认是否配置错误或工程设计发生变化。

   本例中Cluster的ROLE参数如图3所示。

   **图3** 主用局和容灾局的Cluster主备标识正确示例
6. 检查主用USCDB和容灾USCDB的节点ID是否配置正确。

   分别在主用局和容灾局的USCDB的配置文件中通过关键字“ADD NODE:”找到节点配置命令，检查主用局和容灾局USCDB配置文件中相同CID的节点的ID是否与工程设计相同。

   * 是 => 配置正确。
   * 否 => 与现场配置操作人员确认是否配置错误或工程设计发生变化。

   本例中节点ID参数如图4所示。

   **图4** 主用局和容灾局的节点ID示例
7. 检查主用UPCF与容灾UPCF的对接数据配置。

   通过关键字找到相应的配置，然后与工程设计比对，检查是否相同，如果相同，则配置正确，否则，需要与现场配置操作人员确认是否配置错误或工程设计发生变化。下面给出各检查项对应的关键字查找方法：

   1. 通过关键字“ADD PCRF”找到UPCF的本地主机名、本地域名。
   2. 分别通过关键字“ADD PPCEFL”、“ADD PAFL”找到与PCEF（Policy and Charging Enforcement Function）、AF（Application Function）。
8. 分别检查主用局的UPCF、USCDB以及容灾局的UPCF、USCDB的远端Location和优先级配置是否正确。

   * 添加远端Location时，UPCF可以添加USCDB网元，“远端网元类型”等于“USCDB”。
   * 添加远端Location时，USCDB可以添加远端USCDB网元、UPCF网元，“远端网元类型”分别等于“USCDB”、“UPCF”。
   * 在配置命令中，“LP”取值代表优先级，对于访问级别，优先级值越小，优先级越高。

   1. 为了便于对比远端Location ID，先在USCDB主用局和容灾局的配置文件中，通过关键字“SET LOCATION:”查看主用局和容灾局的USCDB的本地Location ID。在UPCF主用局和容灾局的配置文件中，通过关键字“SET DBSLOCATION:”查看主用局和容灾局的UPCF的本地Location ID。

      假设本例中，查看结果为：

      主用UPCF的Location ID：SET DBSLOCATION:LOCID=12;

      主用USCDB的Location ID：SET LOCATION:LOCID=11;

      容灾UPCF的Location ID：SET DBSLOCATION:LOCID=22;

      容灾USCDB的Location ID：SET LOCATION:LOCID=21;
   2. 在主用UPCF的配置文件中，通过关键字“ADD DBSRLOCATION:”找到主用UPCF的远端Location配置，检查其访问方式是否为主用UPCF优先访问主用USCDB。

      在主用UPCF中，主用USCDB的优先级配置比容灾USCDB优先级高。

      假设本例中，查看结果如下，说明正确配置了远端Location ID，主用USCDB优先级为1，容灾USCDB优先级为2。

      ```
      ADD DBSRLOCATION: RLOCID=11, RMT=USCDB, LP=1;
      ```

      ```
      ADD DBSRLOCATION: RLOCID=21, RMT=USCDB, LP=2;
      ```
   3. 在主用USCDB的配置文件中，通过关键字“ADD RLOCATION：”找到主用USCDB的远端Location配置，检查其访问方式是否为USCDB优先访问本地UPCF。

      * 在主用USCDB中，主用UPCF的优先级配置比容灾UPCF优先级高。

        假设本例中，查看结果如下，说明正确配置了远端Location ID，主用UPCF优先级为1，容灾UPCF优先级为2。

        ```
        ADD RLOCATION:RLOCID=12,RMT="UPCF",LP=1,REDUNFLAG=No;
        ```

        ```
        ADD RLOCATION:RLOCID=22,RMT="UPCF",LP=2,REDUNFLAG=No;
        ```
      * 在主用USCDB中，容灾USCDB的优先级与主用USCDB的优先级相同。

        假设本例中，查看结果如下，说明正确配置了远端Location ID，容灾USCDB优先级为1。

        ```
        ADD RLOCATION:RLOCID=21,RMT="USCDB",LP=1,REDUNFLAG=Yes;
        ```
   4. 在容灾UPCF的配置文件中，通过关键字“ADD DBSRLOCATION:”找到容灾UPCF的远端Location配置，检查其访问方式是否为容灾UPCF优先访问主用USCDB。

      在容灾UPCF中，主用USCDB的优先级配置比容灾USCDB优先级高。

      假设本例中，查看结果如下，说明正确配置了远端Location ID，主用USCDB优先级为1，容灾USCDB优先级为2。

      ```
      ADD DBSRLOCATION: RLOCID=11, RMT=USCDB, LP=1;
      ```

      ```
      ADD DBSRLOCATION: RLOCID=21, RMT=USCDB, LP=2;
      ```
   5. 在容灾USCDB的配置文件中，通过关键字“ADD RLOCATION：”找到容灾USCDB的远端Location配置，检查其访问方式是否为容灾USCDB优先访问主用UPCF。

      * 在容灾USCDB中，主用UPCF的优先级配置比容灾UPCF的优先级高。

        假设本例中，查看结果如下，说明正确配置了远端Location ID，主用UPCF优先级为1，容灾UPCF优先级为2。

        ```
        ADD RLOCATION:RLOCID=12,RMT="UPCF",LP=1,REDUNFLAG=No;
        ```

        ```
        ADD RLOCATION:RLOCID=22,RMT="UPCF",LP=2,REDUNFLAG=No;
        ```
      * 在容灾USCDB中，主用USCDB的优先级配置与容灾USCDB的优先级相同。

        假设本例中，查看结果如下，说明正确配置了远端Location ID，主用USCDB优先级为1，容灾USCDB优先级为1。

        ```
        ADD RLOCATION:RLOCID=11,RMT="USCDB",LP=1,REDUNFLAG=Yes;
        ```
9. 分别检查主用局与容灾局的远端IP地址配置是否正确。

   * 在USCDB的配置文件中：
     + 通过关键字“ADD RIPADDR:”查看是否添加了远端IP地址配置。
     + 通过关键字“ADD SRVIPADDR:”查看网元本端IP地址，出于备份考虑，IP地址包括两个。
   * 在UPCF的配置文件中：
     + 通过关键字“ADD DBSRIPADDR:”查看是否添加了远端IP地址配置。
     + 通过关键字“ADD DBSIPADDR:”查看网元本端IP地址，出于备份考虑，IP地址包括两个。

   本例中各网元本地IP配置如表1所示。

   **表1** 网元本地IP配置示例

   | 网元 | IP1 | IP2 |
   | --- | --- | --- |
   | 主用USCDB（网元5） | 10.0.0.0 | 10.0.0.0 |
   | 主用UPCF（网元6） | 10.0.0.2 | 10.0.0.3 |
   | 容灾USCDB（网元11） | 10.0.0.0 | 10.0.0.1 |
   | 容灾UPCF（网元12） | 10.0.0.4 | 10.0.0.5 |

   检查远端IP与工程设计相同。本例中各网元远端IP配置如表2所示。

   **表2** 网元远端IP配置示例

   | 本地网元 | 远端网元 | 远端IP地址配置 |
   | --- | --- | --- |
   | 主用USCDB（网元5） | 主用UPCF（网元6） | IP1是10.0.0.2，IP2是10.0.0.3 |
   |  | 容灾UPCF（网元12） | IP1是10.0.0.4，IP2是10.0.0.5 |
   |  | 容灾USCDB（网元11） | IP1是10.0.0.0，IP2是10.0.0.1 |
   | 主用UPCF（网元6） | 容灾USCDB（网元11） | IP1是10.0.0.0，IP2是10.0.0.1 |
   |  | 主用USCDB（网元5） | IP1是10.0.0.0，IP2是10.0.0.0 |
   | 容灾USCDB（网元11） | 主用UPCF（网元6） | IP1是10.0.0.2，IP2是10.0.0.3 |
   |  | 容灾UPCF（网元12） | IP1是10.0.0.4，IP2是10.0.0.5 |
   |  | 主用USCDB（网元5） | IP1是10.0.0.0，IP2是10.0.0.0 |
   | 容灾UPCF（网元12） | 容灾USCDB（网元11） | IP1是10.0.0.0，IP2是10.0.0.1 |
   |  | 主用USCDB（网元5） | IP1是10.0.0.0，IP2是10.0.0.0 |
10. 分别检查主用UPCF、USCDB，以及容灾UPCF、USCDB的远端DSG（Data Service Gateway）配置是否正确。在导出的配置文件中，通过关键字“ADD RDSG:”查看是否添加了远端DSG配置，检查该配置与远端网元的DSG模块ID是否一致，且远端DSG业务类型配置是否正确。

    1. 检查主用UPCF到容灾USCDB的远端DSG配置。

       检查主用UPCF配置文件中是否包括容灾USCDB的DSG的模块，且与工程设计的容灾USCDB的DSG模块ID相对应。
    2. 检查主用USCDB到容灾USCDB的远端DSG配置。

       检查主用USCDB配置文件中是否包括容灾USCDB的DSG的模块，且与工程设计的容灾USCDB的DSG模块ID相对应，“RDSGST（远端DSG业务类型）”配置为“UPCF”。
    3. 检查主用USCDB到容灾UPCF的远端DSG配置。

       检查主用USCDB配置文件中是否包括容灾UPCF的DSG的模块，且与工程设计的容灾UPCF的DSG模块ID相对应，“RDSGST（远端DSG业务类型）”配置为“UPCF”，“RDSGTYPE（远端DSG类型）”配置为“DBS”。
    4. 检查容灾UPCF到主用USCDB的远端DSG配置。

       检查容灾UPCF配置文件中是否包括主用USCDB的DSG的模块，且与工程设计的主用USCDB的DSG模块ID相对应。
    5. 检查容灾USCDB到主用USCDB的远端DSG配置。

       检查容灾USCDB配置文件中是否包括主用USCDB的DSG的模块，且与工程设计的主用USCDB的DSG模块ID相对应，“RDSGST（远端DSG业务类型）”配置为“UPCF”。
11. 检查主用UPCF和容灾UPCF与业务发放系统对接数据配置是否正确。

    1. 在主用局和容灾局，登录USPID3/USPID3L/USPGW，使用**ping**命令检查与业务发放系统的IP连通情况，确认可以ping通。

       如果ping不通，请按如下方式排除故障，故障排除后重新进行检查。

       * 检查IP地址、网关及路由是否配置正确。
       * 检查业务发放系统与交换机之间连接是否损坏。
    2. 在业务发放系统中，使用**ping**命令检查业务发放系统与UPCF业务发放IP的连接情况，确认可以ping通。

       如果ping不通，请按如下方式排除故障，故障排除后重新进行检查。

       * 检查IP地址、网关及路由是否配置正确。
       * 检查业务发放系统与交换机之间连线是否损坏。

       UPCF业务发放IP以及配置该IP的网口可以通过登录“USCDB MML命令”界面，执行**LST SRVIPADDR**命令查看，其中“网关类型”选择“PGW”。
    3. 在业务发放系统中，通过已经配置的UPCF业务发放IP登录PGW（Provisioning Gateway）服务端，如果能正常登录，则IP地址配置成功。
12. 分别检查主用局和容灾局与网管对接数据配置是否正确。

    检查网管侧是否都已经创建主用局和容灾局的USCDB、UPCF网元。请参考配置UPCF与网管服务器的对接数据。

版权所有 © 华为技术有限公司
