---
id: ''
name: 检查数据
ne_type: UPCF
type: feature
description: 当完成容灾组网部署时，需要对主用UPCF和容灾UPCF的设备进行对接调测，以检查容灾相关配置是否正确。为保证主用与容灾系统能够正常使用，需要对数据进行检查。
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾部署","（N+1）*FE+2*BE主备地理容灾方案","安装和调测容灾系统","调测容灾系统","检查数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当完成容灾组网部署时，需要对主用UPCF和容灾UPCF的设备进行对接调测，以检查容灾相关配置是否正确。为保证主用与容灾系统能够正常使用，需要对数据进行检查。

## 必备事项
前提条件

* 已经检查主用局和容灾局的硬件运行状态、软件运行情况、数据配置等。
* 已经完成主用局和容灾局的BE和FE对接。请参考对接主用容灾局。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    exp_mml_list:
      type: items
      properties:
        MEID:
          name: 'MEID'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        METYPE:
          name: 'METYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    exp_mml_list_1:
      type: items
      properties:
        MEID:
          name: 'MEID'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        METYPE:
          name: 'METYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list:
      type: items
      properties:
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_1:
      type: items
      properties:
        INSPN:
          name: '软件参数名称'
          type: string
          enum:
          - MAXONECLIENTNUMS
          - FWDLOGINFOSWITCH
          - USCDBLOGFLAG
          - DBGLOGL0
          - DBGLOGL1
          - DBGLOGL2
          - DBGLOGL3
          - DBGLOGL4
          - RUNLOGL0
          - RUNLOGL1
          - RUNLOGL2
          - RUNLOGL3
          - RUNLOGL4
          - MSCLEARTIME
          - MSBUFREMAIN
          - SERVICEPORT
          - DRUIMDBS
          - DSUIMDBS
          - LDRSOURCE
          - TSYNCOPER
          - TQUERYOPER
          - TVERIFYOPER
          - TMULTINODEOPER
          - TREPRSPW
          - TVERIFYRSPW
          - TDSURSPW
          - TSYNCREPRSPW
          - TASYNCREPRSPW
          - TVERITYRSPW
          - FWDVFYSWT
          - REVVFYSWT
          - FWDRTVFYSWT
          - REVRTVFYSWT
          - TMFWDVFY
          - TMREVVFY
          - TMFWDRTVFY
          - TMREVRTVFY
          - PRDFWDVFY
          - PRDREVVFY
          - PRDFWDRTVFY
          - PRDREVRTVFY
          - GLOBALDATAREFRESHCYCLE
          - DRUFRWDVFYUNITNUM
          - DSUFRWDVFYUNITNUM
          - REVVFYUNITNUM
          - FWDRTVFYUNITNUM
          - REVRTVFYUNITNUM
          - HESRTBEATPERIOD
          - INNERHEARTBEATTIMEOUT
          - OUTERHEARTBEATTIMEOUT
          - CHECKPERIOD
          - THREADMONPERIOD
          - REPSPENDTIME
          - UPGRADESTATUS
          - TIMEBACKUPFLAG
          - BACKUPHOUR
          - BACKUPMINUTE
          - CBTABLESIZE
          - TIMEROFAllDRUWAIT
          - TIMEROFUSRVFY
          - TIMEROFEXCPTROUTEVFY
          - PERIODVFYONLYCHECK
          - REDUNDANCYSWITCH
          - NOCONSISTWARINGNUM
          - COUNTERLOGSWT
          - INTERREPSWITCH
          - LANGUAGE
          - PATCHSWITCH
          - SESWITCH
          - MAXWEBLMTNUMBER
          - MAXCLIENTNUMBER
          - PGWREJECTSWITCH
          - VERIFYCODEFLAG
          - BATSEQLEN
          - PGWRESERVE1
          - PGWBATSTEP
          - PGWDIRMONINTV
          - TLSMODE
          - SOAPVERSION
          - CONNWAITTIME
          - TRANSTIMEOUT
          - MAXCONNNUMPERIP
          - SOAPMAXRECVBUFFER
          - SOAPMAXSENDBUFFER
          - SESSIONTIMEOUT
          - HTTPSAUTHSWITCH
          - LDAPSWITCH
          - RLOADSWITCH
          - RLOADTIMEOUT
          - RLOADPACKETSIZE
          - RCHANNELLOADSW
          - REDUCFSWITCH
          - REDUTFSWITCH
          - REDURFSWITCH
          - REDUCFINTERVAL
          - REDURFINTERVAL
          - REDUALAINTERVAL
          - APPLICATIONTYPE
          - PGWOPLOGTYPE
          - PGWOPLOGCYC
          - USERDATAMEASUREFLAG
          - MEASUREHOUR
          - MEASUREMINUTE
          - STARTLICENSETIME
          - GRANTIPSWITCH
          - WEBLMTHTTPSSWITCH
          - PGWLOGMAXCOUNT
          - GDRUIMDBS
          - IUDMSWT
          - IUDMLSD
          - IUDMHOUR
          - IUDMMIN
          - WEBLMTTIMEOUT
          - USERTRANSSPEED
          - UIVFYSWT
          - PRDUIVFY
          - UIVFYUNITNUM
          - DMVFYSWT
          - PGWSNDDCIMSGMODE
          - LINGERTIME
          - NPSWITCH
          - MVNOSWITCH
          - PWDVERIFYSWITCH
          - CONBATMMLQUEUE
          - JRVFYPRD
          - JRVFYUNITNUM
          - REDUNAUTOTAKEOVER
          - TAKEOVERDELAY
          - LICINFODSPCTRL
          - DATANOTIFYMODE
          - DSNOTIFYTIMEOUT
          - DSNOTIFYRETRY
          - PRVBATRSTSAVEPATH
          - CMDDISCARDSWITCH
          - NOTIFYLINKSWAPSWITCH
          - VFYDATARECORDFLAG
          - NOTIFYHBTIMEWAIT
          - SESSIONIDALGSWITCH
          - RSPWITHOUTDESCSWITCH
          - SOAPENVSWITCH
          - MAXBATNUMBER
          - AUTORECOVERYFLAG
          - LENQUKVFYQUE
          - REDQUKVFYSPD
          - DYNUSERMEASURE
          - DYNMEASURESPEED
          - INNERQUKVFYSWT
          - LOCREPEVENT
          - LOGDISCARDCMDSWITCH
          - LOGORIGINALSOAPSWITCH
          - DRUINNERREPQUEUESIZE
          - DELSUBDATASWT
          - SCANSUBDATASPEED
          - SOAPPACKAGEMAXSIZE
          - STATBUFFRESULTSIZE
          - CLOUDADDSIDPOLICY
          - PROVRIGHTSWITCH
          - USERTRACEFLAG
          - PGWMMLSWITCH
          - WEBLMTFILERESTRICT
          - IMSRETINFOSWITCH
          - FORBIDCRCERR
          - PGWSERIALSWITCH
          - NOTIFYGETLOCATIONPOLICY
          - MAXCPUOVERLOADVALUE
          - SUPP_DOWNTIME_FUNC
          - DOWNTIME_THRESHOLD
          - LINKAGESWITCH
          - SERVICERIGHTSWITCH
          - EXTERNALACCESSSWITCH
          - VMSTORAGEFAULTRMSWITCH
          - MAXCMDNUMPERBAT
          - LOGTOOMU
          - EMIGRATIONPERIOD
          - SENDHBBYCLUSTER
          - NEEXPMMLANDPLA
          - LICDSPMODE
          - BYPASSDRUSWITCH
          - OUTERQUKVFYSWT
          - VFYCOVERRECORDSWT
          - PARALLELLOADNUM
          - SPLOCALEXC
          - BATSUSPENDSWITCH
          - SOCKETUNIQUE
          - FINDOPRFORHEADAUTH
          - PROVISIONBATRESULTFILESWITCH
          - AUTHWITHSRCIP
          - SPCFDIRRSTSWT
          - QUKVERIFYMODE
          - PGWLOGCOUNT
          - NOTIFYCONTROL
          - SENDHBMODE
          - SPCFOPLOGWRITEFILESWT
          - LDAPCONNTHDALMSWT
          - DRUOUTERREPQUEUESIZE
          - DSUINNERREPQUEUESIZE
          - DSUOUTERREPQUEUESIZE
          - SSHALGORITHMSWITCH
          - GDRUTHREADNUM
          - DRUTHREADNUM
          - DSUTHREADNUM
          - SAVLOGMAXCOUNT
          - PGWLOGORDER
          - ROUTEMIGMSGSIZE
          - LICCUSTOMIZEDSWITCH
          - EXPMSGQLENGTH
          - IMDBWORKMODE
          - OBJECTSERIALIZEFLAG
          - NUMBATPROCESSSWITCH
          - PGWSESSIONMAXNUM
          - PGWCONALMSWT
          - IMPORTSEQLEN
          - STATICMEASURESPEED
          - DSUUSRCNTUPDTHD
          - MCIRETURNIMMEDIATELY
          - AAMODESWITCH
          - TIMINGSUBSCRIPTIONUNITNUM
          - TIMINGSUBSCRIPTIONRESENDPERIOD
          - INCONSISTENTTHRESHOLD
          - EXPORTSPEED
          - SERVERLINGERTIME
          - GDATAEXPORTSPEED
          - RTMTNMODE
          - DELJUNKDATANUM
          - REMAINDATANUM
          - DRUDISPATCHMODE
          - DMAGLOBALREFRESHCYCLE
          - FLOWCTRLRSPSWITCH
          - MSGTIMEOUTTHRESHOLD
          - DRUREPRSPW
          - DRUSYNCREPRSPW
          - PCDRBTPWINSIZE
          - THIRDCFGCHECKSWITCH
          - RETENTION_BACKUP
          - RETENTION_LOG
          - RETENTION_EXPORT
          - Q922TASKDELAYTIME
          - CLUSTERBALANCESWITCH
          - PGWLOGTOREMOTE
          - MASTERLDRCOMPRESS
          - EMGRSTMODE
          - DELJUNKDATACYCLE
          - IGNOREPREFIXCHECK
          - BATWRITERESULTAPART
          - AUTOBATPARALLELNUM
          - BATCMDASYNCNOTIFY
          - EXCOMLQUERYSPEED
          - EXCOMLUPDATESPEED
          - CLOUDADAPTERSWITCH
          - NETWORKMODE
          - DCIFWDMODE
          - NOTIFYFLOWMSGCOUNT
          - LOCREPMULTHREADSWT
          - OBJECTCOMPRESSMODE
          - SOAPDECODESWITCH
          - SELFSPACEBACKUP
          - THIRDSPACEBACKUP
          - UPDOWNTASKNUM
          - TIMEOUTTHIRDBKLOAD
          - TIMEOUTSELFBKLOAD
          - DSULOADSHAREMODE
          - GROUTEVRFYSWT
          - BROADCASTQUERYSTEP
          - BROADCASTUPDATESTEP
          - SFTPUSERPWDVALID
          - BATCHROUTEUPDATEDELAYTIME
          - EXCEPTIONROUTEVERIFYSWITCH
          - BATCHREPLICATIONDELAYTIME
          - BATCHREPLICATIONMODE
          - TAKEOVERFORCLUSTER
          - EXPIRETIME
          - PROVBATCHDELORIFILE
          - MAPLOGTOVRP
          - FWDMMLERRCODESWT
          - PROVBATCHFOBTAINFILEMODE
          - WEBLMTSECURITYOPTIONSWITCH
          - USERTRANSBKPSWITCH
          - MAXTMOUTPROVFORWARD
          - COMMANDACCESSTYPECONTROL
          - NTFCFGOFREMOTEIDSWITCH
          - OPRPWDPBKDF2ALGSWITCH
          - SOAPERRORMSGTYPESWITCH
          - REDOARCHIVEDAYS
          - INCREDOSWITCH
          - DBPAGEVACUUMMODE
          - PSITEMSGSWITCH
          - DMAMODULECFGSWT
          - SSHKEXALGORITHMSWITCH
          - LOCATIONVERIFYMODE
          - BKPFILEVRFSWT
          - CERTALAINTERVAL
          - KVDCISYNCTOUDB
          - SFTPCLIENTSECURITYALGSW
          - RESTHTTPSAUTHSWITCH
          - BYPASSREVRTSYNSWITCH
          - LENQUKVFYQUEOFROUTE
          - HTTPPROVRIGHTSWITCH
          - PROVHTTPSAUTHSWITCH
          - USERTRANSRECOVERSPEED
          - COMFORMATOFEXPFILE
          - FILEUPLOADMODE
          - HETERJUDGESWITCH
          - USERDATAMIGEXCEPENHANCESW
          - STOPTRACECPUTHD
          - SCTPDELAYSYNFLOWCTRLSW
          - MSGPRIQUEUECOMBINESW
          - ROLLBACKSTATUS
          - GLBDATAPOLICY
          - LOCREPCHECKSWITCH
          - HLOADSWITCH
          - RPRESTORENUM
          - BROADCASTPOLICY
          - QFECTRSW
          - QBEPRESSPARA
          - KEYRESPROTECT
          - FEBEFLOWSW
          - PARTITIONFLOWSW
          - RCVUSERLISTNUM
          - RCVUSERSPEED
          - SYNFLOWPRESSPARA
          - MMLTLSAUTHSWITCH
          - LENQUKVFYQUEFORPARTITION
          - DTLSOVERSCTPSWT
          - NOTIFYMAPPING
          - MAXNODERECORDLIMIT
          - SSHSFTPSRVSEPARATION
          - ACTIVELOCELECTSWT
          - GRDSYNCMODE
          - MLOADBUFLEN
          - MLOADDELAYTIME
          - RLOADBUFLEN
          - RLOADDELAYTIME
          - FABRICPROTECTSW
          - FABRICPROTECTFLOWPRESSPARA
          - FABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPROTECTSW
          - SDRFABRICPORTFLOWCTRTHRESHOLD
          - SDRFABRICPORTFLOWCTREND
          - ALLOWENDWITHFSWITCH
          - MIGRATEWATCHPERIOD
          - HRCPMSMGR
          - MAXBROADCASTNUM
          - MAXVRYNUMINPRIKEY
          - FILEBKPENCSWT
          - ALLOWCSVTYPESWITCH
          - ALARMFORFAILEDEXP
          - MAXSFTPIPNUM
          - PGWCLEARMMLSWITCH
          - WEBLMTCONNTIMEOUT
          - SFTPCLIENTHOSTKEYSWITCH
          - SSORIGHTSWITCH
          - EXCOMLSHIELDSWITCH
          - SPCFTIMERSTSWT
          - RETENTION_EMG_BACKUP
          - VERIFYCOMPATIBILITYSWT
          - MAXINDEXBROADCASTNUM
          - BRDCSTFLOWCTLDROPSWT
          - MIGRATECTRLSWT
          - REDUNDANCYSYNFLOWCTRLSW
          - SCTPRCVQUEUETHD
          - DSGLINKCFGCHKSWT
          - NONGLOBALROUTEMODESWT
          - SPECFICDSGSCTPSRVSWT
          - PARGLBDATAVFYSPD
          - BATCHQUERYLIMIT
          - BATCHMODIFYLIMIT
          - BATCHMODIFYFAILLOGRETENTION
          - BUSINESSUSERLOCKTIMEOUT
          - BUSINESSUSERLOCKSWITCH
          - DMSRIGHTSWITCH
          - MAXONEUSERWEBLMTNUMS
          - MAXPAGEQUERYUSERDATANUM
          - UNIONEXPSPEED
          - ALMSUPPRESSIONSWT
          - ACCFILETIMEOUT
          - FTPCLIENTSENDPACKETCOUNT
          - FTPCLIENTPACKETSIZE
          - FTPCLIENTFLOWCTRLSENDTASKDELAY
          - SFTPCLIENTPACKETSIZE
          - SFTPCLIENTFLOWCTRLSENDTASKDELAY
          - EXPLOGTASKTARMODE
          - PHYDBMAXMEMORYSIZE
          - OPRCMDGMGRSWT
          - LGIFAILEDERRSWITCH
          - GDATANOCONSISTNUM
          - USERDATANOCONSISTNUM
          - SECIDXDEFVALSTORESWT
          - RESTCONNWAITTIME
          - GLOBALDATANOTIFYSWITCH
          - DCIFORWARDINGSWT
          - FABRICPLANELOADBALANCESW
          - FABRICPLANEPRISETSW
          - SOAPRSPMSGMODE
          - MAXIMPNUMBER
          - VERIFYMERGESWT
          - LICFROZENBUFFERTIME
          - PHYDBMEMREPSWITCH
          - NOTIFYTOSRCFESWT
          - PSITEHEARTBEATSWITCH
          - PARTITIONFORWARDPOLICY
          - LOCUSERDIFFNUM
          - LOCGDATADIFFNUM
          - VERIFYPAUSETIME
          - CROSSREGIONMIGRATESPEED
          - CROSSREGIONRBKSPEED
          - DYNDATARBKSWITCH
          - USERTRANSSTATUS
          - MAXILEGALBATCHQUERYNUM
          - SECONDMSGBYPASSDRU
          - PARALLELLOADCTRL
          - LICRATEDISPSWITCH
          - GDATAMAXREQNUM
          - SOAPCONBATSWITCH
          - MULTINODEBRDCSTRTNUM
          - INNERMSGSENDPATH
          - RLOADAUTOBATCHSWT
          - MAXRLOADTASKNUMPERIPU
          - UPGRADECOMPATIBILITYSWT
          - MULTIRANGECHECKSWITCH
          - SOAPRPTCTRL
          - THREADMONITORSWT
          - RCVDBEXECSW
          - EXCOMLEXECSW
          - N36NOTIFYSW
          - IMDBINSUFFICIENTTHD
          - DUALPROVLOG
          - INTERNALFILETRANSMODE
          - REPIGNORESWT
          - PHYDBCERTSWITCH
          - SCTPFAULTMMLSWT
          - DMSCONNTIMEOUT
          - MODULENOAUTOASSIGNALGORI
          - PLANEBATCHESMAXNUM
          - VERIFYHASHALGORITHM
          - CMPDBEXECSW
          - CMPDBPARALLELNUM
          - CMPDBSPEED
          - LIGHTSCHEDULSWT
          - BPTHREADDETACHSWT
          - SIMPLEDCIREPCOMPRSWT
          - WEBLMTLOGSAVEDAYS
          - PROVLOCREPMULTHREADSWT
          - ENABLEROARTINDEX
          - ROUTECONFLICTVFYMODE
          - GLOBALROUTEGENMODE
          - LOGAUDITSW
          - OBJREBUILDFRAGTHD
          - EXCOMLUSERQUERYSTEP
          - PGWCHECKRESTOPNAME
          - BATPARALLELADAPTSW
          - PHYDBBACKUPTRANSINTV
          - VERIFYCODEDISTIMES
          - USERDATASYNCVSPSW
          - VERIFYENHANCEMODE
          - MAXRLOADTASKNUMPERDSG
          - CUSIMPFAILEDNUM
          - NEWSUBALLOCMODE
          - SOAPGRANTIPMODE
          - PGWSDRFABRICPROTECTSW
          - AUTOTAKEOVERFWDMODE
          - CDB_VRSP_R_RECONSTRUCTMODE
          - BATSEQMINLEN
          - USERTRANSQRYSPEED
          - DRUUPGDPLANEACCSS
          - VFYCYCPRD
          - MANMACHINERELGISWT
          - THIRDSYSTEMSSOMODE
          - COUNTMERGESWT
          - LSTLOGRPTMAXRECNUM
          - DSUIMDBBALTHD
          - EXPFILEENCSWT
          - EXPLOGFILEENCSWT
          - MEMLOGCTRLSWT
          - STBYPDAPRTSW
          - DYNUSERMEASUREGROUP
          - LICENSEDEVIATION
          - LICENSEINTERVAL
          - USERTRANSLOCKSWT
          - ROUTEDRUREDOARCHIVEDAYS
          - GBKCODECONVERSIONSWITCH
          - PGWSNDDCIMSGPRIORITY
          - FTPPASSIVEIPVFYSWT
          - SCTPHASHALGO
          - DCIRSPCOMPRESSMODE
          - IPUPROTECTSW
          - IPUPROTECTTHD
          - IPUPROTECTENDTHD
          - IPURSPBANDWIDTH
          - DCIRSPCMPSTARTTHD
          - DCIRSPCMPCLOSETHD
          - LOCREPCOMPATIBILITYSWT
          - FVMODTSRECORDMODE
          - BATFILEVALIDPERIOD
          - RESTLINGERTIME
          - FLEXNOTIFYFLOWCBCOUNT
          - STATICMEASURESPEEDMODE
          - PGWMODPWDRTYSW
          - IPUFABRICFLWCTLFORCEENDTH
          - UPDRSPMODEONSUBABSENSCE
          - SDRTHRDRXSCHPERIOD
          - SIMPLETIMENOTIFYSW
          - SIMPLETIMENOTIFYTIME
          - BALANCALGPOLLFACTOR
          - BALANCALGSWTHD
          - MMLLGODISCONNECTSWT
          - SANDBOXCFGSWITCH
          - INTERQUKVFYQUERECMODE
          - EXITFORWARDMODE
          - USERMIGRATIONDSUIMDBTHD
          - LOCQUKVFYSENDDELAYTIME
          - SOAPLNKSWITCHTIME
          - DUALACTIVEQUKVFYMODE
          - EXPSUBPATHRETENTION
          - FEBEFLOWCTRMODE
          - USERPRDVFYSEQMODE
          - SDRFABRICPLANESPECSW
          - SDRRELIABLETRANSCTRL
          - USERTRANSSHRINKDSUIMDBTHD
          - REVGLBRTVFTUNITNUM
          - DMSBASEONDBSCHEMASWT
          - PGWRANGEBLACKLISTSWT
          - LOCATIONREPCONFQUESW
          - LOCALREPCONFQUESW
          - COFLOWQENDCOEF
          - EXPTARSPEEDLIMIT
          - CAMPEXPMATCHCOND
          - USERDATAMIGBALSTRATEGY
          - SFTPGRANTIPSWITCH
          - WEBLMTMMLBATCHSWT
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软件参数值'
          type: integer
          minimum: 0
          maximum: 4294967294
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPT:
          name: '软件参数类型'
          type: string
          enum:
          - PCDR
          - LOG
          - DBSRV
          - WDS
          - MULTIDRU
          - VERIFY
          - PGW
          - LDAP
          - STAT
          - FE
          - FUNCCFG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FETYPEN:
          name: '网元类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsrlocation_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          enum:
          - USCDB
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list_2:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsrlocation_list_2:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          enum:
          - USCDB
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list_3:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list_5:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - exp_mml_list:
    - MEID: '5'
      METYPE: USCDB
    exp_mml_list_1:
    - MEID: '6'
      METYPE: UPCF
    mod_insp_list:
    - INSPN: GLOBALDATAREFRESHCYCLE
      INSPV: 20
      INSPT: ''
      FETYPEN: ''
    mod_insp_list_1:
    - INSPN: GLOBALDATAREFRESHCYCLE
      INSPV: 20
      INSPT: ''
      FETYPEN: ''
    add_dbsrlocation_list:
    - RLOCID: 11
      RMT: USCDB
      LP: 1
    add_rlocation_list:
    - RLOCID: 12
      RMT: 'UPCF'
      LP: 1
      REDUNFLAG: No
    add_rlocation_list_2:
    - RLOCID: 21
      RMT: 'USCDB'
      LP: 1
      REDUNFLAG: Yes
    add_dbsrlocation_list_2:
    - RLOCID: 11
      RMT: USCDB
      LP: 1
    add_rlocation_list_3:
    - RLOCID: 12
      RMT: 'UPCF'
      LP: 1
      REDUNFLAG: No
    add_rlocation_list_5:
    - RLOCID: 11
      RMT: 'USCDB'
      LP: 1
      REDUNFLAG: Yes
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 分别导出主用局和容灾局的USCDB、UPCF的网元配置数据，并记录导出时间。

### 假设：主用局USCDB网元ID为5，UPCF网元ID为6；容灾局USCDB网元ID为11，UPCF网元ID为12。

#### 1.1 在主用UPCF上，登录“CSP MML命令”界面。

#### 1.2 执行**EXP MML**命令导出网元配置命令数据。

#### 导出参考命令如下：

#### /\*导出USCDB网元配置数据\*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该exp_mml_list的变量区（command: EXP MML） -#}
<!-- MISSING_MACRO: command=EXP MML list_name=exp_mml_list step_id=1.2 -->
```

#### /\*导出UPCF网元配置数据\*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该exp_mml_list_1的变量区（command: EXP MML） -#}
<!-- MISSING_MACRO: command=EXP MML list_name=exp_mml_list_1 step_id=1.2 -->
```

#### 执行过程，命令界面会有导出进度信息输出，当进度提示100%时，表示导出完成。

#### 1.3 记录导出时间。

#### 导出时间与命令发送时间相同，所以记录命令发送时间即可。

#### 1.4 在容灾UPCF上，登录“CSP MML命令”界面。

#### 1.5 导出网元配置命令数据。

#### 参考步骤1.b，网元ID按照假设修改为11、12。

#### 1.6 记录导出时间。

#### 导出时间与命令发送时间相同，所以记录命令发送时间即可。

#### 导出的数据以文本文件形式保存在OMU的“导出文件”目录中，文件的名称由系统默认生成，具体请参考**EXP MML**命令的联机帮助。

### 2 分别下载主用局和容灾局的USCDB、UPCF的网元配置数据到本地。

### 通过SFTP下载网元配置文件，SFTP操作方法请参考上传/下载文件。下载时，SFTP界面选择的“远程目录”是“导出文件”；SFTP界面的本地目录可以是任意目录，为了操作方便，可以在本地新建一个目录“数据配置”专门保存配置命令文件。

### 如果“导出文件”目录下有多个文件，请选择与1记录的导出时间相同的文件导出，以免取得的配置与当前不符。

#### 2.1 在本地PC新建目录“数据配置”。

#### 2.2 登录主用局的CSP MML命令界面。方法参见登录“CSP MML命令”界面。

#### 2.3 通过SFTP将USCDB、UPCF的数据配置文件下载到“数据配置”目录。

#### 2.4 登录容灾局的CSP MML命令界面。方法参见登录“CSP MML命令”界面。

#### 2.5 通过SFTP将USCDB、UPCF的数据配置文件下载到“数据配置”目录。

#### 下载后的文件包括主用局和容灾局的4个文本文件，按照假设的网元ID，文件名可能为：

#### /\*主用USCDB网元数据配置\*/

#### ME5\_20091201145529.txt

#### /\*主用UPCF网元数据配置\*/

#### ME6\_20091201145733.txt

#### /\*容灾USCDB网元数据配置\*/

#### ME11\_20091201145939.txt

#### /\*容灾UPCF网元数据配置\*/

#### ME12\_20091201155129.txt

#### 2.6 用文本编辑器，比如用记事本打开主用和容灾的数据配置文件，以备后续的操作使用。

### 3 检查主用USCDB和容灾USCDB的容灾参数配置是否正确。需检查的参数请见配置主用容灾局的容灾参数。

### 例如检查“全局数据定时刷新周期”是否正确。

### 此参数在主用局和容灾局都需要检查，主用局和容灾局均设置为20。

#### 3.1 在主用局检查。

#### 在主用局的USCDB配置文件中通过关键字“MOD INSP: INSPN=GLOBALDATAREFRESHCYCLE, INSPV=”找到“全局数据定时刷新周期”配置，检查命令中的参数值“INSPV”是否为“20”。

#### 是 => 配置正确。

#### 否 => 与现场华为工程师确认是否配置错误或工程设计发生变化。

#### 如果需要设置“全局数据定时刷新周期”，通过执行命令**MOD INSP**修改软件参数。

```jinja2
{%- for item in mod_insp_list -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    INSPT={{item.INSPT}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
    {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
        FETYPEN="{{item.FETYPEN}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 3.2 在容灾局检查。

#### 在容灾局的USCDB配置文件中通过关键字“MOD INSP: INSPN=GLOBALDATAREFRESHCYCLE, INSPV=”找到“全局数据定时刷新周期”配置，检查命令中的参数值“INSPV”是否为“20”。

#### 是 => 配置正确。

#### 否 => 与现场华为工程师确认是否配置错误或工程设计发生变化。

#### 如果需要设置“全局数据定时刷新周期”，通过执行**MOD INSP**命令修改软件参数。

```jinja2
{%- for item in mod_insp_list_1 -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    INSPT={{item.INSPT}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：INSPN=DRUIMDBS/DSUIMDBS/RLOADSWITCH/RCHANNELLOADSW/RLOADTIMEOUT/RLOADPACKETSIZE/LDRSOURCE/REVVFYSWT/FWDRTVFYSWT/REVRTVFYSWT/FWDVFYSWT/PRDFWDVFY/PRDREVVFY/PRDFWDRTVFY/PRDREVRTVFY/DRUFRWDVFYUNITNUM/DSUFRWDVFYUNITNUM/REVVFYUNITNUM/FWDRTVFYUNITNUM/PERIODVFYONLYCHECK/REDUNDANCYSWITCH/NOCONSISTWARINGNUM/UPGRADESTATUS/TIMEBACKUPFLAG/BACKUPHOUR/BACKUPMINUTE/GDRUIMDBS/IUDMSWT/RESTHTTPSAUTHSWITCH/HTTPPROVRIGHTSWITCH/PROVHTTPSAUTHSWITCH/HTTPSAUTHSWITCH/TLSMODE/USERTRANSSPEED/UIVFYSWT/PRDUIVFY/UIVFYUNITNUM/DMVFYSWT/LDAPSWITCH/REVRTVFYUNITNUM/REDUNAUTOTAKEOVER/TAKEOVERDELAY/JRVFYPRD/JRVFYUNITNUM/LICINFODSPCTRL/DATANOTIFYMODE/VFYDATARECORDFLAG/AUTORECOVERYFLAG/LENQUKVFYQUE/REDQUKVFYSPD/DYNUSERMEASURE/DYNMEASURESPEED/INNERQUKVFYSWT/LOCREPEVENT/DRUINNERREPQUEUESIZE/DELSUBDATASWT/SCANSUBDATASPEED/STATBUFFRESULTSIZE/PROVRIGHTSWITCH/RSPWITHOUTDESCSWITCH/SOAPENVSWITCH/NOTIFYGETLOCATIONPOLICY/LINKAGESWITCH/SERVICERIGHTSWITCH/VMSTORAGEFAULTRMSWITCH/BYPASSDRUSWITCH/OUTERQUKVFYSWT/VFYCOVERRECORDSWT/EMIGRATIONPERIOD/SPCFDIRRSTSWT/QUKVERIFYMODE/SPCFOPLOGWRITEFILESWT/DRUOUTERREPQUEUESIZE/DSUINNERREPQUEUESIZE/DSUOUTERREPQUEUESIZE/GDRUTHREADNUM/DRUTHREADNUM/DSUTHREADNUM/ROUTEMIGMSGSIZE/LICCUSTOMIZEDSWITCH/EXPMSGQLENGTH/IMDBWORKMODE/OBJECTSERIALIZEFLAG/STATICMEASURESPEED/DSUUSRCNTUPDTHD/AAMODESWITCH/TIMINGSUBSCRIPTIONUNITNUM/TIMINGSUBSCRIPTIONRESENDPERIOD/INCONSISTENTTHRESHOLD/EXPORTSPEED/GDATAEXPORTSPEED/RTMTNMODE/DELJUNKDATANUM/REMAINDATANUM/DRUDISPATCHMODE/DRUREPRSPW/DRUSYNCREPRSPW/Q922TASKDELAYTIME/DMAGLOBALREFRESHCYCLE/FLOWCTRLRSPSWITCH/MSGTIMEOUTTHRESHOLD/CLUSTERBALANCESWITCH/MASTERLDRCOMPRESS/EMGRSTMODE/DELJUNKDATACYCLE/IGNOREPREFIXCHECK/EXCOMLQUERYSPEED/EXCOMLUPDATESPEED/NETWORKMODE/DCIFWDMODE/OBJECTCOMPRESSMODE/ALLOWENDWITHFSWITCH/SELFSPACEBACKUP/THIRDSPACEBACKUP/UPDOWNTASKNUM/TIMEOUTTHIRDBKLOAD/TIMEOUTSELFBKLOAD/GROUTEVRFYSWT/THIRDCFGCHECKSWITCH/BROADCASTQUERYSTEP/BROADCASTUPDATESTEP/DSULOADSHAREMODE/BATCHROUTEUPDATEDELAYTIME/EXCEPTIONROUTEVERIFYSWITCH/BATCHREPLICATIONDELAYTIME/BATCHREPLICATIONMODE/TAKEOVERFORCLUSTER/EXPIRETIME/CLOUDADDSIDPOLICY/MCIRETURNIMMEDIATELY/FWDMMLERRCODESWT/USERTRANSBKPSWITCH/REDOARCHIVEDAYS/INCREDOSWITCH/DBPAGEVACUUMMODE/PSITEMSGSWITCH/LOCATIONVERIFYMODE/BKPFILEVRFSWT/KVDCISYNCTOUDB/BYPASSREVRTSYNSWITCH/LENQUKVFYQUEOFROUTE/GLBDATAPOLICY/LOCREPCHECKSWITCH/HLOADSWITCH/RPRESTORENUM/BROADCASTPOLICY/QFECTRSW/QBEPRESSPARA/KEYRESPROTECT/FEBEFLOWSW/PARTITIONFLOWSW/RCVUSERLISTNUM/RCVUSERSPEED/SYNFLOWPRESSPARA/MMLTLSAUTHSWITCH/LENQUKVFYQUEFORPARTITION/DTLSOVERSCTPSWT/NOTIFYMAPPING/MAXNODERECORDLIMIT/ACTIVELOCELECTSWT/MLOADBUFLEN/MLOADDELAYTIME/RLOADBUFLEN/RLOADDELAYTIME/GRDSYNCMODE/USERTRANSRECOVERSPEED/FABRICPROTECTSW/FABRICPROTECTFLOWPRESSPARA/FABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPROTECTSW/SDRFABRICPORTFLOWCTRTHRESHOLD/SDRFABRICPORTFLOWCTREND/MIGRATEWATCHPERIOD/MAXBROADCASTNUM/MAXVRYNUMINPRIKEY/BRDCSTFLOWCTLDROPSWT/MAXINDEXBROADCASTNUM/SCTPRCVQUEUETHD/REDUNDANCYSYNFLOWCTRLSW/VERIFYCOMPATIBILITYSWT/FILEBKPENCSWT/COMFORMATOFEXPFILE/FILEUPLOADMODE/HETERJUDGESWITCH/MIGRATECTRLSWT/USERDATAMIGEXCEPENHANCESW/SCTPDELAYSYNFLOWCTRLSW/MSGPRIQUEUECOMBINESW/DSGLINKCFGCHKSWT/NONGLOBALROUTEMODESWT/SPECFICDSGSCTPSRVSWT/PARGLBDATAVFYSPD/BATCHQUERYLIMIT/BATCHMODIFYLIMIT/BUSINESSUSERLOCKTIMEOUT/BUSINESSUSERLOCKSWITCH/EXCOMLSHIELDSWITCH/SPCFTIMERSTSWT/MAXPAGEQUERYUSERDATANUM/UNIONEXPSPEED/ALMSUPPRESSIONSWT/ACCFILETIMEOUT/GDATANOCONSISTNUM/USERDATANOCONSISTNUM/SECIDXDEFVALSTORESWT/GLOBALDATANOTIFYSWITCH/DCIFORWARDINGSWT/FABRICPLANELOADBALANCESW/FABRICPLANEPRISETSW/VERIFYMERGESWT/LICFROZENBUFFERTIME/PSITEHEARTBEATSWITCH/PARTITIONFORWARDPOLICY/LOCUSERDIFFNUM/LOCGDATADIFFNUM/VERIFYPAUSETIME/CROSSREGIONMIGRATESPEED/CROSSREGIONRBKSPEED/DYNDATARBKSWITCH/USERTRANSSTATUS/SECONDMSGBYPASSDRU/LICRATEDISPSWITCH/GDATAMAXREQNUM/SOAPCONBATSWITCH/MULTINODEBRDCSTRTNUM/RLOADAUTOBATCHSWT/MAXRLOADTASKNUMPERIPU/UPGRADECOMPATIBILITYSWT/MULTIRANGECHECKSWITCH/N36NOTIFYSW/IMDBINSUFFICIENTTHD/REPIGNORESWT/VERIFYHASHALGORITHM/CMPDBSPEED/LIGHTSCHEDULSWT/BPTHREADDETACHSWT/SIMPLEDCIREPCOMPRSWT/PROVLOCREPMULTHREADSWT/ENABLEROARTINDEX/ROUTECONFLICTVFYMODE/GLOBALROUTEGENMODE/OBJREBUILDFRAGTHD/EXCOMLUSERQUERYSTEP/USERDATASYNCVSPSW/AUTOTAKEOVERFWDMODE/CDB_VRSP_R_RECONSTRUCTMODE/USERTRANSQRYSPEED/VERIFYENHANCEMODE/DRUUPGDPLANEACCSS/MAXRLOADTASKNUMPERDSG/VFYCYCPRD/DSUIMDBBALTHD/COUNTMERGESWT/STBYPDAPRTSW/DYNUSERMEASUREGROUP/LICENSEDEVIATION/ROUTEDRUREDOARCHIVEDAYS/USERTRANSLOCKSWT/PGWSNDDCIMSGPRIORITY/SCTPHASHALGO/DCIRSPCOMPRESSMODE/IPUPROTECTSW/IPUPROTECTTHD/IPUPROTECTENDTHD/IPURSPBANDWIDTH/DCIRSPCMPSTARTTHD/DCIRSPCMPCLOSETHD/LOCREPCOMPATIBILITYSWT/FVMODTSRECORDMODE/STATICMEASURESPEEDMODE/IPUFABRICFLWCTLFORCEENDTH/UPDRSPMODEONSUBABSENSCE/SIMPLETIMENOTIFYSW/SIMPLETIMENOTIFYTIME/BALANCALGPOLLFACTOR/BALANCALGSWTHD/INTERQUKVFYQUERECMODE/USERMIGRATIONDSUIMDBTHD/LOCQUKVFYSENDDELAYTIME/DUALACTIVEQUKVFYMODE/USERPRDVFYSEQMODE/SDRFABRICPLANESPECSW/FEBEFLOWCTRMODE/USERTRANSSHRINKDSUIMDBTHD/REVGLBRTVFTUNITNUM/PGWRANGEBLACKLISTSWT/LOCATIONREPCONFQUESW/LOCALREPCONFQUESW/COFLOWQENDCOEF/CAMPEXPMATCHCOND/USERDATAMIGBALSTRATEGY 时必选 --- -#}
    {%- if item.INSPN in ['DRUIMDBS', 'DSUIMDBS', 'RLOADSWITCH', 'RCHANNELLOADSW', 'RLOADTIMEOUT', 'RLOADPACKETSIZE', 'LDRSOURCE', 'REVVFYSWT', 'FWDRTVFYSWT', 'REVRTVFYSWT', 'FWDVFYSWT', 'PRDFWDVFY', 'PRDREVVFY', 'PRDFWDRTVFY', 'PRDREVRTVFY', 'DRUFRWDVFYUNITNUM', 'DSUFRWDVFYUNITNUM', 'REVVFYUNITNUM', 'FWDRTVFYUNITNUM', 'PERIODVFYONLYCHECK', 'REDUNDANCYSWITCH', 'NOCONSISTWARINGNUM', 'UPGRADESTATUS', 'TIMEBACKUPFLAG', 'BACKUPHOUR', 'BACKUPMINUTE', 'GDRUIMDBS', 'IUDMSWT', 'RESTHTTPSAUTHSWITCH', 'HTTPPROVRIGHTSWITCH', 'PROVHTTPSAUTHSWITCH', 'HTTPSAUTHSWITCH', 'TLSMODE', 'USERTRANSSPEED', 'UIVFYSWT', 'PRDUIVFY', 'UIVFYUNITNUM', 'DMVFYSWT', 'LDAPSWITCH', 'REVRTVFYUNITNUM', 'REDUNAUTOTAKEOVER', 'TAKEOVERDELAY', 'JRVFYPRD', 'JRVFYUNITNUM', 'LICINFODSPCTRL', 'DATANOTIFYMODE', 'VFYDATARECORDFLAG', 'AUTORECOVERYFLAG', 'LENQUKVFYQUE', 'REDQUKVFYSPD', 'DYNUSERMEASURE', 'DYNMEASURESPEED', 'INNERQUKVFYSWT', 'LOCREPEVENT', 'DRUINNERREPQUEUESIZE', 'DELSUBDATASWT', 'SCANSUBDATASPEED', 'STATBUFFRESULTSIZE', 'PROVRIGHTSWITCH', 'RSPWITHOUTDESCSWITCH', 'SOAPENVSWITCH', 'NOTIFYGETLOCATIONPOLICY', 'LINKAGESWITCH', 'SERVICERIGHTSWITCH', 'VMSTORAGEFAULTRMSWITCH', 'BYPASSDRUSWITCH', 'OUTERQUKVFYSWT', 'VFYCOVERRECORDSWT', 'EMIGRATIONPERIOD', 'SPCFDIRRSTSWT', 'QUKVERIFYMODE', 'SPCFOPLOGWRITEFILESWT', 'DRUOUTERREPQUEUESIZE', 'DSUINNERREPQUEUESIZE', 'DSUOUTERREPQUEUESIZE', 'GDRUTHREADNUM', 'DRUTHREADNUM', 'DSUTHREADNUM', 'ROUTEMIGMSGSIZE', 'LICCUSTOMIZEDSWITCH', 'EXPMSGQLENGTH', 'IMDBWORKMODE', 'OBJECTSERIALIZEFLAG', 'STATICMEASURESPEED', 'DSUUSRCNTUPDTHD', 'AAMODESWITCH', 'TIMINGSUBSCRIPTIONUNITNUM', 'TIMINGSUBSCRIPTIONRESENDPERIOD', 'INCONSISTENTTHRESHOLD', 'EXPORTSPEED', 'GDATAEXPORTSPEED', 'RTMTNMODE', 'DELJUNKDATANUM', 'REMAINDATANUM', 'DRUDISPATCHMODE', 'DRUREPRSPW', 'DRUSYNCREPRSPW', 'Q922TASKDELAYTIME', 'DMAGLOBALREFRESHCYCLE', 'FLOWCTRLRSPSWITCH', 'MSGTIMEOUTTHRESHOLD', 'CLUSTERBALANCESWITCH', 'MASTERLDRCOMPRESS', 'EMGRSTMODE', 'DELJUNKDATACYCLE', 'IGNOREPREFIXCHECK', 'EXCOMLQUERYSPEED', 'EXCOMLUPDATESPEED', 'NETWORKMODE', 'DCIFWDMODE', 'OBJECTCOMPRESSMODE', 'ALLOWENDWITHFSWITCH', 'SELFSPACEBACKUP', 'THIRDSPACEBACKUP', 'UPDOWNTASKNUM', 'TIMEOUTTHIRDBKLOAD', 'TIMEOUTSELFBKLOAD', 'GROUTEVRFYSWT', 'THIRDCFGCHECKSWITCH', 'BROADCASTQUERYSTEP', 'BROADCASTUPDATESTEP', 'DSULOADSHAREMODE', 'BATCHROUTEUPDATEDELAYTIME', 'EXCEPTIONROUTEVERIFYSWITCH', 'BATCHREPLICATIONDELAYTIME', 'BATCHREPLICATIONMODE', 'TAKEOVERFORCLUSTER', 'EXPIRETIME', 'CLOUDADDSIDPOLICY', 'MCIRETURNIMMEDIATELY', 'FWDMMLERRCODESWT', 'USERTRANSBKPSWITCH', 'REDOARCHIVEDAYS', 'INCREDOSWITCH', 'DBPAGEVACUUMMODE', 'PSITEMSGSWITCH', 'LOCATIONVERIFYMODE', 'BKPFILEVRFSWT', 'KVDCISYNCTOUDB', 'BYPASSREVRTSYNSWITCH', 'LENQUKVFYQUEOFROUTE', 'GLBDATAPOLICY', 'LOCREPCHECKSWITCH', 'HLOADSWITCH', 'RPRESTORENUM', 'BROADCASTPOLICY', 'QFECTRSW', 'QBEPRESSPARA', 'KEYRESPROTECT', 'FEBEFLOWSW', 'PARTITIONFLOWSW', 'RCVUSERLISTNUM', 'RCVUSERSPEED', 'SYNFLOWPRESSPARA', 'MMLTLSAUTHSWITCH', 'LENQUKVFYQUEFORPARTITION', 'DTLSOVERSCTPSWT', 'NOTIFYMAPPING', 'MAXNODERECORDLIMIT', 'ACTIVELOCELECTSWT', 'MLOADBUFLEN', 'MLOADDELAYTIME', 'RLOADBUFLEN', 'RLOADDELAYTIME', 'GRDSYNCMODE', 'USERTRANSRECOVERSPEED', 'FABRICPROTECTSW', 'FABRICPROTECTFLOWPRESSPARA', 'FABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPROTECTSW', 'SDRFABRICPORTFLOWCTRTHRESHOLD', 'SDRFABRICPORTFLOWCTREND', 'MIGRATEWATCHPERIOD', 'MAXBROADCASTNUM', 'MAXVRYNUMINPRIKEY', 'BRDCSTFLOWCTLDROPSWT', 'MAXINDEXBROADCASTNUM', 'SCTPRCVQUEUETHD', 'REDUNDANCYSYNFLOWCTRLSW', 'VERIFYCOMPATIBILITYSWT', 'FILEBKPENCSWT', 'COMFORMATOFEXPFILE', 'FILEUPLOADMODE', 'HETERJUDGESWITCH', 'MIGRATECTRLSWT', 'USERDATAMIGEXCEPENHANCESW', 'SCTPDELAYSYNFLOWCTRLSW', 'MSGPRIQUEUECOMBINESW', 'DSGLINKCFGCHKSWT', 'NONGLOBALROUTEMODESWT', 'SPECFICDSGSCTPSRVSWT', 'PARGLBDATAVFYSPD', 'BATCHQUERYLIMIT', 'BATCHMODIFYLIMIT', 'BUSINESSUSERLOCKTIMEOUT', 'BUSINESSUSERLOCKSWITCH', 'EXCOMLSHIELDSWITCH', 'SPCFTIMERSTSWT', 'MAXPAGEQUERYUSERDATANUM', 'UNIONEXPSPEED', 'ALMSUPPRESSIONSWT', 'ACCFILETIMEOUT', 'GDATANOCONSISTNUM', 'USERDATANOCONSISTNUM', 'SECIDXDEFVALSTORESWT', 'GLOBALDATANOTIFYSWITCH', 'DCIFORWARDINGSWT', 'FABRICPLANELOADBALANCESW', 'FABRICPLANEPRISETSW', 'VERIFYMERGESWT', 'LICFROZENBUFFERTIME', 'PSITEHEARTBEATSWITCH', 'PARTITIONFORWARDPOLICY', 'LOCUSERDIFFNUM', 'LOCGDATADIFFNUM', 'VERIFYPAUSETIME', 'CROSSREGIONMIGRATESPEED', 'CROSSREGIONRBKSPEED', 'DYNDATARBKSWITCH', 'USERTRANSSTATUS', 'SECONDMSGBYPASSDRU', 'LICRATEDISPSWITCH', 'GDATAMAXREQNUM', 'SOAPCONBATSWITCH', 'MULTINODEBRDCSTRTNUM', 'RLOADAUTOBATCHSWT', 'MAXRLOADTASKNUMPERIPU', 'UPGRADECOMPATIBILITYSWT', 'MULTIRANGECHECKSWITCH', 'N36NOTIFYSW', 'IMDBINSUFFICIENTTHD', 'REPIGNORESWT', 'VERIFYHASHALGORITHM', 'CMPDBSPEED', 'LIGHTSCHEDULSWT', 'BPTHREADDETACHSWT', 'SIMPLEDCIREPCOMPRSWT', 'PROVLOCREPMULTHREADSWT', 'ENABLEROARTINDEX', 'ROUTECONFLICTVFYMODE', 'GLOBALROUTEGENMODE', 'OBJREBUILDFRAGTHD', 'EXCOMLUSERQUERYSTEP', 'USERDATASYNCVSPSW', 'AUTOTAKEOVERFWDMODE', 'CDB_VRSP_R_RECONSTRUCTMODE', 'USERTRANSQRYSPEED', 'VERIFYENHANCEMODE', 'DRUUPGDPLANEACCSS', 'MAXRLOADTASKNUMPERDSG', 'VFYCYCPRD', 'DSUIMDBBALTHD', 'COUNTMERGESWT', 'STBYPDAPRTSW', 'DYNUSERMEASUREGROUP', 'LICENSEDEVIATION', 'ROUTEDRUREDOARCHIVEDAYS', 'USERTRANSLOCKSWT', 'PGWSNDDCIMSGPRIORITY', 'SCTPHASHALGO', 'DCIRSPCOMPRESSMODE', 'IPUPROTECTSW', 'IPUPROTECTTHD', 'IPUPROTECTENDTHD', 'IPURSPBANDWIDTH', 'DCIRSPCMPSTARTTHD', 'DCIRSPCMPCLOSETHD', 'LOCREPCOMPATIBILITYSWT', 'FVMODTSRECORDMODE', 'STATICMEASURESPEEDMODE', 'IPUFABRICFLWCTLFORCEENDTH', 'UPDRSPMODEONSUBABSENSCE', 'SIMPLETIMENOTIFYSW', 'SIMPLETIMENOTIFYTIME', 'BALANCALGPOLLFACTOR', 'BALANCALGSWTHD', 'INTERQUKVFYQUERECMODE', 'USERMIGRATIONDSUIMDBTHD', 'LOCQUKVFYSENDDELAYTIME', 'DUALACTIVEQUKVFYMODE', 'USERPRDVFYSEQMODE', 'SDRFABRICPLANESPECSW', 'FEBEFLOWCTRMODE', 'USERTRANSSHRINKDSUIMDBTHD', 'REVGLBRTVFTUNITNUM', 'PGWRANGEBLACKLISTSWT', 'LOCATIONREPCONFQUESW', 'LOCALREPCONFQUESW', 'COFLOWQENDCOEF', 'CAMPEXPMATCHCOND', 'USERDATAMIGBALSTRATEGY'] -%}
        FETYPEN="{{item.FETYPEN}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 4 检查主用USCDB和容灾USCDB的Cluster ID是否配置正确。

### 分别在主用局和容灾局的USCDB的配置文件中通过关键字“ADD CLUSTER:”找到Cluster配置命令，比对主用和容灾配置文件中相同Cluster Type（简称CT）的Cluster ID是否与工程设计相同，且主用局Cluster ID与容灾局Cluster ID是否相同。

### 是 => 配置正确。

### 否 => 与现场配置操作人员确认是否配置错误或工程设计发生变化。

### 本例中相同CT的Cluster ID也相同，如图2所示。

### **图2** 主用局和容灾局的Cluster ID示例

### 5 检查主用USCDB和容灾USCDB的Cluster主备标识是否正确。

### 检查主用USCDB配置文件中Cluster的“ROLE”参数是否是“ACTIVE”，容灾局USCDB配置文件中Cluster的“ROLE”参数是否是“REDUNDANCY”。

### 是 => 配置正确。

### 否 => 与现场配置操作人员确认是否配置错误或工程设计发生变化。

### 本例中Cluster的ROLE参数如图3所示。

### **图3** 主用局和容灾局的Cluster主备标识正确示例

### 6 检查主用USCDB和容灾USCDB的节点ID是否配置正确。

### 分别在主用局和容灾局的USCDB的配置文件中通过关键字“ADD NODE:”找到节点配置命令，检查主用局和容灾局USCDB配置文件中相同CID的节点的ID是否与工程设计相同。

### 是 => 配置正确。

### 否 => 与现场配置操作人员确认是否配置错误或工程设计发生变化。

### 本例中节点ID参数如图4所示。

### **图4** 主用局和容灾局的节点ID示例

### 7 检查主用UPCF与容灾UPCF的对接数据配置。

### 通过关键字找到相应的配置，然后与工程设计比对，检查是否相同，如果相同，则配置正确，否则，需要与现场配置操作人员确认是否配置错误或工程设计发生变化。下面给出各检查项对应的关键字查找方法：

#### 7.1 通过关键字“ADD PCRF”找到UPCF的本地主机名、本地域名。

#### 7.2 分别通过关键字“ADD PPCEFL”、“ADD PAFL”找到与PCEF（Policy and Charging Enforcement Function）、AF（Application Function）。

### 8 分别检查主用局的UPCF、USCDB以及容灾局的UPCF、USCDB的远端Location和优先级配置是否正确。

### 添加远端Location时，UPCF可以添加USCDB网元，“远端网元类型”等于“USCDB”。

### 添加远端Location时，USCDB可以添加远端USCDB网元、UPCF网元，“远端网元类型”分别等于“USCDB”、“UPCF”。

### 在配置命令中，“LP”取值代表优先级，对于访问级别，优先级值越小，优先级越高。

#### 8.1 为了便于对比远端Location ID，先在USCDB主用局和容灾局的配置文件中，通过关键字“SET LOCATION:”查看主用局和容灾局的USCDB的本地Location ID。在UPCF主用局和容灾局的配置文件中，通过关键字“SET DBSLOCATION:”查看主用局和容灾局的UPCF的本地Location ID。

#### 假设本例中，查看结果为：

#### 主用UPCF的Location ID：SET DBSLOCATION:LOCID=12;

#### 主用USCDB的Location ID：SET LOCATION:LOCID=11;

#### 容灾UPCF的Location ID：SET DBSLOCATION:LOCID=22;

#### 容灾USCDB的Location ID：SET LOCATION:LOCID=21;

#### 8.2 在主用UPCF的配置文件中，通过关键字“ADD DBSRLOCATION:”找到主用UPCF的远端Location配置，检查其访问方式是否为主用UPCF优先访问主用USCDB。

#### 在主用UPCF中，主用USCDB的优先级配置比容灾USCDB优先级高。

#### 假设本例中，查看结果如下，说明正确配置了远端Location ID，主用USCDB优先级为1，容灾USCDB优先级为2。

```jinja2
{%- for item in add_dbsrlocation_list -%}
    ADD DBSRLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT={{item.RMT}},
    LP={{item.LP}},
    ;
{%- endfor -%}
```

#### 8.3 在主用USCDB的配置文件中，通过关键字“ADD RLOCATION：”找到主用USCDB的远端Location配置，检查其访问方式是否为USCDB优先访问本地UPCF。

#### 在主用USCDB中，主用UPCF的优先级配置比容灾UPCF优先级高。

#### 假设本例中，查看结果如下，说明正确配置了远端Location ID，主用UPCF优先级为1，容灾UPCF优先级为2。

```jinja2
{%- for item in add_rlocation_list -%}
    ADD RLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT="{{item.RMT}}",
    LP={{item.LP}},
    REDUNFLAG={{item.REDUNFLAG}},
    ;
{%- endfor -%}
```

#### 在主用USCDB中，容灾USCDB的优先级与主用USCDB的优先级相同。

#### 假设本例中，查看结果如下，说明正确配置了远端Location ID，容灾USCDB优先级为1。

```jinja2
{%- for item in add_rlocation_list_2 -%}
    ADD RLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT="{{item.RMT}}",
    LP={{item.LP}},
    REDUNFLAG={{item.REDUNFLAG}},
    ;
{%- endfor -%}
```

#### 8.4 在容灾UPCF的配置文件中，通过关键字“ADD DBSRLOCATION:”找到容灾UPCF的远端Location配置，检查其访问方式是否为容灾UPCF优先访问主用USCDB。

#### 在容灾UPCF中，主用USCDB的优先级配置比容灾USCDB优先级高。

#### 假设本例中，查看结果如下，说明正确配置了远端Location ID，主用USCDB优先级为1，容灾USCDB优先级为2。

```jinja2
{%- for item in add_dbsrlocation_list_2 -%}
    ADD DBSRLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT={{item.RMT}},
    LP={{item.LP}},
    ;
{%- endfor -%}
```

#### 8.5 在容灾USCDB的配置文件中，通过关键字“ADD RLOCATION：”找到容灾USCDB的远端Location配置，检查其访问方式是否为容灾USCDB优先访问主用UPCF。

#### 在容灾USCDB中，主用UPCF的优先级配置比容灾UPCF的优先级高。

#### 假设本例中，查看结果如下，说明正确配置了远端Location ID，主用UPCF优先级为1，容灾UPCF优先级为2。

```jinja2
{%- for item in add_rlocation_list_3 -%}
    ADD RLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT="{{item.RMT}}",
    LP={{item.LP}},
    REDUNFLAG={{item.REDUNFLAG}},
    ;
{%- endfor -%}
```

#### 在容灾USCDB中，主用USCDB的优先级配置与容灾USCDB的优先级相同。

#### 假设本例中，查看结果如下，说明正确配置了远端Location ID，主用USCDB优先级为1，容灾USCDB优先级为1。

```jinja2
{%- for item in add_rlocation_list_5 -%}
    ADD RLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT="{{item.RMT}}",
    LP={{item.LP}},
    REDUNFLAG={{item.REDUNFLAG}},
    ;
{%- endfor -%}
```

### 9 分别检查主用局与容灾局的远端IP地址配置是否正确。

#### 9.1 在USCDB的配置文件中：

##### 9.1.1 通过关键字“ADD RIPADDR:”查看是否添加了远端IP地址配置。

##### 9.1.2 通过关键字“ADD SRVIPADDR:”查看网元本端IP地址，出于备份考虑，IP地址包括两个。

#### 9.2 在UPCF的配置文件中：

##### 9.2.1 通过关键字“ADD DBSRIPADDR:”查看是否添加了远端IP地址配置。

##### 9.2.2 通过关键字“ADD DBSIPADDR:”查看网元本端IP地址，出于备份考虑，IP地址包括两个。

### 本例中各网元本地IP配置如表1所示。

### **表1** 网元本地IP配置示例

### | 网元 | IP1 | IP2 |

### | --- | --- | --- |

### | 主用USCDB（网元5） | 10.0.0.0 | 10.0.0.0 |

### | 主用UPCF（网元6） | 10.0.0.2 | 10.0.0.3 |

### | 容灾USCDB（网元11） | 10.0.0.0 | 10.0.0.1 |

### | 容灾UPCF（网元12） | 10.0.0.4 | 10.0.0.5 |

### 检查远端IP与工程设计相同。本例中各网元远端IP配置如表2所示。

### **表2** 网元远端IP配置示例

### | 本地网元 | 远端网元 | 远端IP地址配置 |

### | --- | --- | --- |

### | 主用USCDB（网元5） | 主用UPCF（网元6） | IP1是10.0.0.2，IP2是10.0.0.3 |

### |  | 容灾UPCF（网元12） | IP1是10.0.0.4，IP2是10.0.0.5 |

### |  | 容灾USCDB（网元11） | IP1是10.0.0.0，IP2是10.0.0.1 |

### | 主用UPCF（网元6） | 容灾USCDB（网元11） | IP1是10.0.0.0，IP2是10.0.0.1 |

### |  | 主用USCDB（网元5） | IP1是10.0.0.0，IP2是10.0.0.0 |

### | 容灾USCDB（网元11） | 主用UPCF（网元6） | IP1是10.0.0.2，IP2是10.0.0.3 |

### | 容灾UPCF（网元12） | 容灾USCDB（网元11） | IP1是10.0.0.0，IP2是10.0.0.1 |

### 10 分别检查主用UPCF、USCDB，以及容灾UPCF、USCDB的远端DSG（Data Service Gateway）配置是否正确。在导出的配置文件中，通过关键字“ADD RDSG:”查看是否添加了远端DSG配置，检查该配置与远端网元的DSG模块ID是否一致，且远端DSG业务类型配置是否正确。

#### 10.1 检查主用UPCF到容灾USCDB的远端DSG配置。

#### 检查主用UPCF配置文件中是否包括容灾USCDB的DSG的模块，且与工程设计的容灾USCDB的DSG模块ID相对应。

#### 10.2 检查主用USCDB到容灾USCDB的远端DSG配置。

#### 检查主用USCDB配置文件中是否包括容灾USCDB的DSG的模块，且与工程设计的容灾USCDB的DSG模块ID相对应，“RDSGST（远端DSG业务类型）”配置为“UPCF”。

#### 10.3 检查主用USCDB到容灾UPCF的远端DSG配置。

#### 检查主用USCDB配置文件中是否包括容灾UPCF的DSG的模块，且与工程设计的容灾UPCF的DSG模块ID相对应，“RDSGST（远端DSG业务类型）”配置为“UPCF”，“RDSGTYPE（远端DSG类型）”配置为“DBS”。

#### 10.4 检查容灾UPCF到主用USCDB的远端DSG配置。

#### 检查容灾UPCF配置文件中是否包括主用USCDB的DSG的模块，且与工程设计的主用USCDB的DSG模块ID相对应。

#### 10.5 检查容灾USCDB到主用USCDB的远端DSG配置。

#### 检查容灾USCDB配置文件中是否包括主用USCDB的DSG的模块，且与工程设计的主用USCDB的DSG模块ID相对应，“RDSGST（远端DSG业务类型）”配置为“UPCF”。

### 11 检查主用UPCF和容灾UPCF与业务发放系统对接数据配置是否正确。

#### 11.1 在主用局和容灾局，登录USPID3/USPID3L/USPGW，使用**ping**命令检查与业务发放系统的IP连通情况，确认可以ping通。

#### 如果ping不通，请按如下方式排除故障，故障排除后重新进行检查。

#### 检查IP地址、网关及路由是否配置正确。

#### 检查业务发放系统与交换机之间连接是否损坏。

#### 11.2 在业务发放系统中，使用**ping**命令检查业务发放系统与UPCF业务发放IP的连接情况，确认可以ping通。

#### 如果ping不通，请按如下方式排除故障，故障排除后重新进行检查。

#### 检查IP地址、网关及路由是否配置正确。

#### 检查业务发放系统与交换机之间连线是否损坏。

#### UPCF业务发放IP以及配置该IP的网口可以通过登录“USCDB MML命令”界面，执行**LST SRVIPADDR**命令查看，其中“网关类型”选择“PGW”。

#### 11.3 在业务发放系统中，通过已经配置的UPCF业务发放IP登录PGW（Provisioning Gateway）服务端，如果能正常登录，则IP地址配置成功。

### 12 分别检查主用局和容灾局与网管对接数据配置是否正确。

### 检查网管侧是否都已经创建主用局和容灾局的USCDB、UPCF网元。请参考配置UPCF与网管服务器的对接数据。

