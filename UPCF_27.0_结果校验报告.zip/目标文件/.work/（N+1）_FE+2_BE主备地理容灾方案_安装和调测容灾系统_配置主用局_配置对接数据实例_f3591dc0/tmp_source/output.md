---
id: ''
name: 配置对接数据实例
ne_type: UPCF
type: feature
description: 该任务指导工程师在UPCF开局时，通过OM portal完成对接数据的配置。  本实例的配置场景如下：  * 支持4\*300万并发会话-5400万静态用户。 * 实现UPCF主用局的容灾组网对接。
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾部署","（N+1）*FE+2*BE主备地理容灾方案","安装和调测容灾系统","配置主用局","配置对接数据实例"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
该任务指导工程师在UPCF开局时，通过OM portal完成对接数据的配置。本实例的配置场景如下：* 支持4\*300万并发会话-5400万静态用户。* 实现UPCF主用局的容灾组网对接。

## 必备事项
前提条件

* 已完成网元安装。
* 已完成基础数据配置。
* UPCF需对接的对端设备已完成基础数据配置。
* UPCF主备容灾局的数据层网络已互通。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    use_me_list:
      type: items
      properties:
        MEID:
          name: 'MEID'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list_1:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rdsg_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGMID:
          name: '远端DSG模块号'
          type: integer
          minimum: 1
          maximum: 2047
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGTYPE:
          name: '远端DSG类型'
          type: string
          enum:
          - DSG
          - DBS
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: DSG
    add_rdsg_list_9:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGMID:
          name: '远端DSG模块号'
          type: integer
          minimum: 1
          maximum: 2047
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDSGTYPE:
          name: '远端DSG类型'
          type: string
          enum:
          - DSG
          - DBS
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: DSG
    add_ripaddr_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ID:
          name: '远端DPU模块号/远端业务IP索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '远端Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '远端Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDPUST:
          name: '远端IP地址业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '远端Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '远端Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ripaddr_list_6:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ID:
          name: '远端DPU模块号/远端业务IP索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '远端Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '远端Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RDPUST:
          name: '远端IP地址业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '远端Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '远端Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_notifycfg_list:
      type: items
      properties:
        FETYPE:
          name: '订阅通知的FE类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        REMOTEID:
          name: '订阅通知对端的ID'
          type: integer
          minimum: 1
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FEID:
          name: 'FE标识'
          type: integer
          minimum: 1
          maximum: 100
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INFTYPE:
          name: '订阅通知的接口类型'
          type: string
          enum:
          - MCI
          - SOAP
          - FILE
          - THIRDPARTY
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SYNCHROSWITCH:
          name: '同步开关'
          type: string
          enum:
          - ASYNC
          - SYNC
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        WAITTIMEOUT:
          name: '超时时长'
          type: integer
          minimum: 1
          maximum: 60
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LOCATIONID:
          name: '订阅通知发送的Location标识'
          type: integer
          minimum: 0
          maximum: 512
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PID:
          name: 'Partition标识'
          type: integer
          minimum: 0
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        NOTIFYDEST:
          name: '通知目标'
          type: integer
          minimum: 0
          maximum: 2
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PERIOD:
          name: '文件生成周期'
          type: integer
          minimum: 5
          maximum: 86400
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RBKLOCATIONID:
          name: '回退时订阅通知发送的Location标识'
          type: integer
          minimum: 0
          maximum: 512
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SAVEPATH:
          name: '文件保存路径'
          type: string
          maxLength: 20
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SAVEPERIOD:
          name: '文件保存周期'
          type: integer
          minimum: 1
          maximum: 30
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SUBERGRPID:
          name: '订阅组'
          type: integer
          minimum: 1
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    act_ipdisp_list:
      type: items
      properties: {}
    add_dbsrlocation_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          enum:
          - USCDB
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsrdsg_list:
      type: items
      properties:
        RDSGMID:
          name: '远端DSG模块号'
          type: integer
          minimum: 1
          maximum: 2047
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsripaddr_list:
      type: items
      properties:
        ID:
          name: '远端业务IP的索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '远端Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '远端Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '远端Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '远端Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    act_dbsipdisp_list:
      type: items
      properties: {}
  examples:
  - use_me_list:
    - MEID: '81'
    add_rlocation_list:
    - RLOCID: 82
      RMT: 'USCDB'
      LP: 2
      REDUNFLAG: Yes
    add_rlocation_list_1:
    - RLOCID: 232
      RMT: 'UPCF'
      LP: 2
      REDUNFLAG: No
    add_rdsg_list:
    - RLOCID: 82
      RDSGMID: 1
      RDSGST: 'UPCF'
      RDSGTYPE: DSG
    add_rdsg_list_9:
    - RLOCID: 232
      RDSGMID: 171
      RDSGST: 'UPCF'
      RDSGTYPE: DBS
    add_ripaddr_list:
    - RLOCID: 82
      ID: 81
      IPVER: IPV4
      IPV4IP1: '192.168.201.30'
      IPV4IP2: '192.168.201.31'
      RDPUST: 'UPCF'
      IPV6IP1: ''
      IPV6IP2: ''
    add_ripaddr_list_6:
    - RLOCID: 232
      ID: 91
      IPVER: IPV4
      IPV4IP1: '192.168.201.44'
      IPV4IP2: '192.168.201.45'
      RDPUST: 'UPCF'
      IPV6IP1: ''
      IPV6IP2: ''
    add_notifycfg_list:
    - FETYPE: 'UPCF'
      REMOTEID: 1
      FEID: 1
      INFTYPE: MCI
      SYNCHROSWITCH: ASYNC
      WAITTIMEOUT: 25
      LOCATIONID: 232
      PID: 0
      IPVER: ''
      NOTIFYDEST: ''
      PERIOD: ''
      RBKLOCATIONID: ''
      SAVEPATH: ''
      SAVEPERIOD: ''
      SUBERGRPID: ''
    act_ipdisp_list:
    - {}
    add_dbsrlocation_list:
    - RLOCID: 82
      RMT: USCDB
      LP: 2
    add_dbsrdsg_list:
    - RDSGMID: 1
      RLOCID: 82
    add_dbsripaddr_list:
    - ID: 81
      IPV4IP1: '192.168.201.30'
      IPV4IP2: '192.168.201.31'
      IPVER: IPV4
      RLOCID: 82
      IPV6IP1: ''
      IPV6IP2: ''
    act_dbsipdisp_list:
    - {}
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 **任务描述**

### 完成UPCF对接数据的配置，使UPCF与其他网元互通正常。

### **脚本**

### 配置主用局USCDB的容灾数据

#### 1.1 /*登录到主用局USCDB MML命令界面*/

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该use_me_list的变量区（command: USE ME） -#}
<!-- MISSING_MACRO: command=USE ME list_name=use_me_list step_id=1.1 -->
```

#### 1.2 /*配置远端容灾局USCDB的Location信息数据*/

```jinja2
{%- for item in add_rlocation_list -%}
    ADD RLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT="{{item.RMT}}",
    LP={{item.LP}},
    REDUNFLAG={{item.REDUNFLAG}},
    ;
{%- endfor -%}
```

#### 1.3 /*配置远端容灾局UPCF的Location信息数据*/

```jinja2
{%- for item in add_rlocation_list_1 -%}
    ADD RLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT="{{item.RMT}}",
    LP={{item.LP}},
    REDUNFLAG={{item.REDUNFLAG}},
    ;
{%- endfor -%}
```

#### 1.4 /*配置远端容灾局USCDB的DSG数据*/

```jinja2
{%- for item in add_rdsg_list -%}
    ADD RDSG:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RDSGMID={{item.RDSGMID}},
    RDSGST="{{item.RDSGST}}",
    {#- --- 可选参数 --- -#}
    {%- if item.RDSGTYPE is not none -%}
        RDSGTYPE={{item.RDSGTYPE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 1.5 /*配置远端容灾局UPCF的DSG数据*/

```jinja2
{%- for item in add_rdsg_list_9 -%}
    ADD RDSG:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RDSGMID={{item.RDSGMID}},
    RDSGST="{{item.RDSGST}}",
    {#- --- 可选参数 --- -#}
    {%- if item.RDSGTYPE is not none -%}
        RDSGTYPE={{item.RDSGTYPE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 1.6 /*配置远端容灾局USCDB的网元IP数据*/

```jinja2
{%- for item in add_ripaddr_list -%}
    ADD RIPADDR:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    ID={{item.ID}},
    IPVER={{item.IPVER}},
    RDPUST="{{item.RDPUST}}",
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4IP1="{{item.IPV4IP1}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6IP1="{{item.IPV6IP1}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4IP2 is not none -%}
            IPV4IP2="{{item.IPV4IP2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6IP2 is not none -%}
            IPV6IP2="{{item.IPV6IP2}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 1.7 /*配置远端容灾局UPCF的网元IP数据*/

```jinja2
{%- for item in add_ripaddr_list_6 -%}
    ADD RIPADDR:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    ID={{item.ID}},
    IPVER={{item.IPVER}},
    RDPUST="{{item.RDPUST}}",
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4IP1="{{item.IPV4IP1}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6IP1="{{item.IPV6IP1}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4IP2 is not none -%}
            IPV4IP2="{{item.IPV4IP2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6IP2 is not none -%}
            IPV6IP2="{{item.IPV6IP2}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 1.8 /*增加订阅通知*/

```jinja2
{%- for item in add_notifycfg_list -%}
    ADD NOTIFYCFG:
    {#- --- 必选参数 --- -#}
    FETYPE="{{item.FETYPE}}",
    FEID={{item.FEID}},
    INFTYPE={{item.INFTYPE}},
    {#- --- 可选参数 --- -#}
    {%- if item.REMOTEID is not none -%}
        REMOTEID={{item.REMOTEID}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：INFTYPE=SOAP 时必选 --- -#}
    {%- if item.INFTYPE == 'SOAP' -%}
        IPVER={{item.IPVER}},
    {%- endif -%}
    {#- --- 条件必选：INFTYPE=THIRDPARTY 时必选 --- -#}
    {%- if item.INFTYPE == 'THIRDPARTY' -%}
        SUBERGRPID={{item.SUBERGRPID}},
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
    {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
        {%- if item.SYNCHROSWITCH is not none -%}
            SYNCHROSWITCH={{item.SYNCHROSWITCH}},
        {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI/THIRDPARTY 时可选 --- -#}
    {%- elif item.INFTYPE in ['MCI', 'THIRDPARTY'] -%}
        {%- if item.SYNCHROSWITCH is not none -%}
            SYNCHROSWITCH={{item.SYNCHROSWITCH}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
    {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
        {%- if item.WAITTIMEOUT is not none -%}
            WAITTIMEOUT={{item.WAITTIMEOUT}},
        {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- elif item.INFTYPE == 'MCI' -%}
        {%- if item.WAITTIMEOUT is not none -%}
            WAITTIMEOUT={{item.WAITTIMEOUT}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- if item.INFTYPE == 'MCI' -%}
        {%- if item.LOCATIONID is not none -%}
            LOCATIONID={{item.LOCATIONID}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- if item.INFTYPE == 'MCI' -%}
        {%- if item.PID is not none -%}
            PID={{item.PID}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- if item.INFTYPE == 'MCI' -%}
        {%- if item.NOTIFYDEST is not none -%}
            NOTIFYDEST={{item.NOTIFYDEST}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
    {%- if item.INFTYPE == 'FILE' -%}
        {%- if item.PERIOD is not none -%}
            PERIOD={{item.PERIOD}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- if item.INFTYPE == 'MCI' -%}
        {%- if item.RBKLOCATIONID is not none -%}
            RBKLOCATIONID={{item.RBKLOCATIONID}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
    {%- if item.INFTYPE == 'FILE' -%}
        {%- if item.SAVEPATH is not none -%}
            SAVEPATH="{{item.SAVEPATH}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
    {%- if item.INFTYPE == 'FILE' -%}
        {%- if item.SAVEPERIOD is not none -%}
            SAVEPERIOD={{item.SAVEPERIOD}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 1.9 /*激活链路*/

```jinja2
ACT IPDISP:
;
```

### 2 配置主用局UPCF的容灾数据

#### 2.1 /*登录到主用局UPCF1的UPCF MML命令界面*/

#### 2.2 /*配置远端容灾局USCDB的Location信息数据*/

```jinja2
{%- for item in add_dbsrlocation_list -%}
    ADD DBSRLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT={{item.RMT}},
    LP={{item.LP}},
    ;
{%- endfor -%}
```

#### 2.3 /*配置远端容灾局USCDB的DSG数据*/

```jinja2
{%- for item in add_dbsrdsg_list -%}
    ADD DBSRDSG:
    {#- --- 必选参数 --- -#}
    RDSGMID={{item.RDSGMID}},
    RLOCID={{item.RLOCID}},
    ;
{%- endfor -%}
```

#### 2.4 /*配置远端容灾局USCDB的网元IP数据*/

```jinja2
{%- for item in add_dbsripaddr_list -%}
    ADD DBSRIPADDR:
    {#- --- 必选参数 --- -#}
    ID={{item.ID}},
    IPVER={{item.IPVER}},
    RLOCID={{item.RLOCID}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4IP1="{{item.IPV4IP1}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6IP1="{{item.IPV6IP1}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4IP2 is not none -%}
            IPV4IP2="{{item.IPV4IP2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6IP2 is not none -%}
            IPV6IP2="{{item.IPV6IP2}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 2.5 /*激活链路*/

```jinja2
ACT DBSIPDISP:
;
```

### 3 配置主用局UPCF1-UPCF4对接数据

### 参考配置UPCF对接数据,根据网设规划和现网实际网元部署情况，完成主用局与各网元对接即可。(主用容灾UPCF与其他网元对接时，配置相互独立，即可看做单局点与网元对接即可。)

#### 3.1 /*配置UPCF与网管服务器的对接数据*/

#### 具体步骤请参见配置UPCF与网管服务器的对接数据。

