---
id: ''
name: 验证基于使用量的动态策略控制（调整资费）（5G）
ne_type: UPCF
type: feature
description: 用于验证5G网络中用户在一个周期内（如日、周、月）的使用量达到某个阈值时，运营商可以调整用户的费率计算。  以典型的上网流量包月业务，UPCF对接华为UNC为例：  * 配额为20GB。 * 每月1号的01:00:00进行配额复位，剩余配额采用清零方式。 * 资费控制：   + 当配额消耗小于20GB时，上行带宽为50 Mbit/s，下行带宽为20 Mbit/s，使用免费。   + 当配额消耗大于等于20GB时，上下行带宽不变，但按一定费率计费。 * UPCF进行配额累积。 * 不配置消息通知。 * 配置动态规则。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611001 基于使用量的动态策略控制","WHFD-611001 基于使用量的动态策略控制特性调测","验证基于使用量的动态策略控制（调整资费）（5G）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
用于验证5G网络中用户在一个周期内（如日、周、月）的使用量达到某个阈值时，运营商可以调整用户的费率计算。以典型的上网流量包月业务，UPCF对接华为UNC为例：* 配额为20GB。* 每月1号的01:00:00进行配额复位，剩余配额采用清零方式。* 资费控制：  + 当配额消耗小于20GB时，上行带宽为50 Mbit/s，下行带宽为20 Mbit/s，使用免费。  + 当配额消耗大于等于20GB时，上下行带宽不变，但按一定费率计费。* UPCF进行配额累积。* 不配置消息通知。* 配置动态规则。

## 必备事项
前提条件

* 已完成基于使用量的动态策略控制（调整资费）（5G）的业务配置，业务名称为“FUP\_Service\_5G”。具体的配置方法参见基于使用量的动态策略控制（调整资费）（5G）。
* 已增加用户并签约“FUP\_Service\_5G”业务。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 在OM Portal界面上创建“用户消息跟踪”任务。

#### 1.1 选择“监控分析 > 消息跟踪 > 任务管理 > upcf\_XXXX\_N”。

#### “upcf\_XXXX\_N”选项中“N”表示网元的ID，“XXXX”表示网元的名称。

#### 1.2 单击“用户消息跟踪”，在“用户消息跟踪”任务对话框点击“创建跟踪任务”。

#### 1.3 填写“任务名称”、“跟踪时长”和用户的“用户标识”，并选中“N7”接口。其中，“用户标识”为开户时“USRIDENTIFIER”参数的值。

#### 1.4 单击“确认”。

### 2 用户A接入5G网络，进行网页浏览或者文件下载，在用户使用量达到20GB之前，通过OM Portal消息跟踪结果查看用户使用网络的带宽和计费信息。如表1所示。

### **表1** 使用量达到20GB之前验证结果

### | 消息名称 | 验证信息 | 预期结果 |

### | --- | --- | --- |

### | Npcf\_SMPolicyControl\_Create响应 | 上下行带宽 | * qosDecs下“maxbrUl”取值为“20000000 bps”，表示上行带宽为20 Mbit/s。 * qosDecs下“maxbrDl”取值为“50000000 bps”，表示下行带宽为50 Mbit/s。 |

### |  | 计费信息 | PccRule中属性refChgData下信元：  * “chgId”取值为“fup1\_5G”。 * “ratingGroup”取值为“1”。 |

### |  | 触发器 | “policyCtrlReqTriggers”取值为“US\_RE”。 |

### |  | 分片与监控键值 | * “umId”取值为“101”，表示监控键值。 * “volumeThreshold”取值为“2097152000”，表示分片大小。 |

### 3 在用户使用量达到20GB之后，查看用户使用计费信息以及配额剩余量信息。如表2所示。

### **表2** 使用量达到20GB之后验证结果

### | 消息名称 | 验证信息 | 预期结果 |

### | --- | --- | --- |

### | Npcf\_SMPolicyControl\_Update请求 | 触发器 | “repPolicyCtrlReqTriggers”取值为“US\_RE”。 |

### |  | 监控键值 | “umId”取值为“101”，表示监控键值。 |

### | Npcf\_SMPolicyControl\_Update响应 | 计费信息 | PccRule中属性refChgData下信元：  * “chgId”取值为“fup2\_5G”。 * “ratingGroup”取值为“2”。 |

### | - | 配额剩余量 | 在**LST PQUOTA**命令输出结果中，“Balance”的取值为“0”，表示配额已耗尽。 |

### 4 验证用户下线时，UPCF发起终止N7会话请求。

### 用户接口消息跟踪结果中存在Npcf\_SMPolicyControl\_Delete消息，并且Npcf\_SMPolicyControl\_Delete响应消息结果为“204 No Content”。

