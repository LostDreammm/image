---
id: ''
name: 基于用户等级的小区拥塞控制（2G/3G）
ne_type: UPCF
type: feature
description: 在特定的热点小区，如机场、大型商业中心或体育馆等，大量用户同时使用无线接入时；或者少量的用户使用大量无收益且具有较强的带宽抢占能力的业务（如P2P业务）时，会导致无法保障VIP用户的业务体验，同时也影响大多数用户正常使用业务。 华为UPCF通过与PCEF（Policy and Charging Enforcement Function）配合实现拥塞小区的用户体验提升。UPCF可以对拥塞小区内不同价值的用户进行差异化控制，以保障VIP用户的业务体验。 华为UPCF支持根据小区拥塞状态变化和用户等级进行拥塞控制，确保高优先级客户优先使用网络。此时每个条件组中需要配置两个条件，条件1配置为对象AccessNode下的LoadStatus，条件2配置为对象Subscriber下的Category。以UPCF对接华为GGSN为例，配置场景如下： 带宽控制： * 当用户在小区上线时，上下行带宽均为2 Mbit/s。 * 当小区拥塞时，普通用户上下行最大带宽降为1 Mbit/s，金牌用户上下行带宽仍为2 Mbit/s。 * 当小区拥塞状态解除时，金牌用户和普通用户上下行带宽均为2 Mbit/s。 * 当用户在小区上线时，UPCF给用户下发非拥塞状态下的业务规则。 * PCEF定时检测配置的小区是否发生拥塞，如果发生拥塞或拥塞解除，PCEF对该小区内所有用户分别上报拥塞事件到UPCF，UPCF进行策略调整。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611028 小区拥塞控制","WHFD-611028 小区拥塞控制特性配置","基于用户等级的小区拥塞控制（2G/3G）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
在特定的热点小区，如机场、大型商业中心或体育馆等，大量用户同时使用无线接入时；或者少量的用户使用大量无收益且具有较强的带宽抢占能力的业务（如P2P业务）时，会导致无法保障VIP用户的业务体验，同时也影响大多数用户正常使用业务。华为UPCF通过与PCEF（Policy and Charging Enforcement Function）配合实现拥塞小区的用户体验提升。UPCF可以对拥塞小区内不同价值的用户进行差异化控制，以保障VIP用户的业务体验。华为UPCF支持根据小区拥塞状态变化和用户等级进行拥塞控制，确保高优先级客户优先使用网络。此时每个条件组中需要配置两个条件，条件1配置为对象AccessNode下的LoadStatus，条件2配置为对象Subscriber下的Category。以UPCF对接华为GGSN为例，配置场景如下：带宽控制：* 当用户在小区上线时，上下行带宽均为2 Mbit/s。* 当小区拥塞时，普通用户上下行最大带宽降为1 Mbit/s，金牌用户上下行带宽仍为2 Mbit/s。* 当小区拥塞状态解除时，金牌用户和普通用户上下行带宽均为2 Mbit/s。* 当用户在小区上线时，UPCF给用户下发非拥塞状态下的业务规则。* PCEF定时检测配置的小区是否发生拥塞，如果发生拥塞或拥塞解除，PCEF对该小区内所有用户分别上报拥塞事件到UPCF，UPCF进行策略调整。

## 必备事项
前提条件

操作员已了解WHFD-611028 小区拥塞控制特性概述。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    mod_insp_list:
      type: items
      properties:
        INSPN:
          name: '参数名'
          type: string
          enum:
          - VRM_MAXIPCANSESNUMPERSPU
          - VRM_MAXAFSESNUMPERSPU
          - VRM_MAXSUBNUMPERSPU
          - VRM_UPGRADE
          - VRM_MAXRATBEARIDPERSES
          - VRM_SRVNUMPERUSR
          - VRM_MAXPAFNUM
          - VRM_MAXPCEFNUM
          - VRM_MAXRADIUSSRVNUM
          - VRM_MAXCONNECTIONPERPAF
          - VRM_MAXCONNECTIONPERPCEF
          - VRM_MAXLINKRADIUSSRV
          - VRM_SUBSRCIPTIONIDTYPE
          - VRM_GLBREFLASHINTERVAL
          - VRM_NOTIFYMSGMAXRECORDPERSUB
          - VRM_NOTIFYMSGMAXDAYPERSUB
          - VRM_REVALIDATIONTIMEMETHOD
          - VRM_NOSUBSCRIPTIONERRORCODE
          - VRM_NOTIFYMSGMAXWAITEDRECORDS
          - VRM_PRINTLOCALLOG
          - VRM_USRREVALIHRANGE
          - VRM_ONLINECHECK
          - VRM_TIMEZONEENHANCE
          - VRM_GXIMEIFORMAT
          - VRM_NOTIFYMSGMAXRECORDPERDSU
          - VRM_CLEARALLDYNCREATEDUSER
          - VRM_PEELDOMAINSWITCH
          - VRM_NOTIFYRCVER
          - VRM_FIRSTDAYOFWEEK
          - VRM_UPDATESPRSUBACTIVE
          - VRM_SUBCTRLRESULT
          - VRM_SPRSUBMAXOFFLINEDAYS
          - VRM_CHECKSUBSCRIBEDSERVICE
          - VRM_SUBACTCTRL
          - VRM_SESSIONCHECKINTERVAL
          - VRM_CHKSUBSRVSYTYPE
          - VRM_RARSENDSPEED
          - VRM_DIAREDIRECTSWITCH
          - VRM_PERIODVALUE
          - VRM_PROTECTTIMER
          - VRM_SENDUSERNUM
          - VRM_POLICYCASESENSITIVE
          - VRM_SESSIONRESTORATION
          - VRM_RXRPMAPRELATION
          - VRM_NOTIFYUSAGEUNITCONVERT
          - VRM_TIMEACCUMODE
          - VRM_SYSWITCH
          - VRM_PLMNMATCHPRIORITY
          - VRM_RESETNOTIFYRPT
          - VRM_REPORTINGLEVEL
          - VRM_RATINGGROUP
          - VRM_SERVICEIDENTIFIER
          - VRM_DFTCHARGINGPARA
          - VRM_LOGPRINTPERIOD
          - VRM_MAXBBERFNUM
          - VRM_MAXCONNECTIONPERBBERF
          - VRM_SPNOTIFYDOMAIN
          - VRM_EXSPRNOTIFICATION
          - VRM_SESSIONBACKUPSWITCH
          - VRM_DIAMHBINTERVAL
          - VRM_DIAMHBTIMES
          - VRM_EDRACCESSFORMATE
          - VRM_IPCANTERMSWITCH
          - VRM_DELBEAROPTION
          - VRM_LDAPREVBUFFERSIZE
          - VRM_NOTIFYOPTIMIZE
          - VRM_RESULTCODESWITCH
          - VRM_FMTIPADDR
          - VRM_GROUPDIAREDIRECTSWITCH
          - VRM_RMVSUBWITHOUTRAR
          - VRM_GRPMBRUSAGECACHE1
          - VRM_GRPMBRUSAGECACHE2
          - VRM_DYNRULEFORMAT
          - VRM_IPV6HASHLENGTH
          - VRM_DURATIONMKMATCH
          - VRM_SNRRECSPEED
          - VRM_DIAMTIMETHRD
          - VRM_LDAPTIMETHRD
          - VRM_RELGXBYRAATIMEOUT
          - VRM_SETHOMESRVZONE
          - VRM_MAXTDFNUM
          - VRM_TDFCCRUSPD
          - VRM_TDFCCRTSPD
          - VRM_PROCHEARTBEATTIMEOUT
          - VRM_MAXAUXILIARYAREA
          - VRM_AADIAREDIRECTSWITCH
          - VRM_DIAMFAILOVERSWITCH
          - VRM_DYNSMSMSISDN
          - VRM_SUBGRPCREATESUB
          - VRM_QUOTACROSSSERVICE
          - VRM_SYSUBIDTYPE
          - VRM_DEACTIVESERVICETIMER
          - VRM_QUOTALOGSWITCH
          - VRM_SIMPLEPOLICYSTATISTIC
          - VRM_GXTRIGGERCMP
          - VRM_QOSNEGOTIATIONSWITCH
          - VRM_IPFLOWANYCVT
          - VRM_SUBLISTNORULE
          - VRM_NTFOVERDUEMODE
          - VRM_DESTPEERMODE
          - VRM_SYNDATASWITCH
          - VRM_SYNDATAINTERVAL
          - VRM_TAIECGIMATCHMODE
          - VRM_SYCARRYSUBID
          - VRM_SYRESENDTIMES
          - VRM_DYNQUOTATIMEZONE
          - VRM_FIRSTGXSESSIONATTR
          - VRM_SESSIONIDHASHMODE
          - VRM_PEERFCDURATION
          - VRM_AFPOLICYRECALCULATE
          - VRM_SGWRESTORETIME
          - VRM_QUOTAUSEPRIORITY
          - VRM_SESSIONIDSWITCH
          - VRM_REPORTUSAGE
          - VRM_IMEIQUERYSERVICE
          - VRM_MCITRIGGERUDR
          - VRM_RXMAXUL
          - VRM_RXMAXDL
          - VRM_SYSESSIONCONTROLATTRIBUTE
          - VRM_SYSESSIONCONTROLVALUE
          - VRM_AUTORECUSRLOC
          - VRM_LINKDSPMODE
          - VRM_RXSTAINCAUTHAPPID
          - VRM_MAXAREANUM
          - VRM_GXSESSIONONLYVOLTE
          - VRM_LDAPDBTIMEOUT
          - VRM_OFFSETTIME
          - VRM_APNSENSITIVE
          - VRM_DYNGROUPNUMBERPERUSER
          - VRM_SYSESSIONBACKUP
          - VRM_NOTIFYATTRRESTRICTION
          - VRM_UNKNOWNRULEPROC
          - VRM_FORCEUPGRADEQOS
          - VRM_RMVGRPMEMBERACT
          - VRM_SYNUSRDATASPEED
          - VRM_SYCHARGINGCHARSWITCH
          - VRM_LICDSPMODE
          - VRM_GRPMBRPARENTSTATUSFLAG
          - VRM_TERMSESSNOTIFICATIONFLAG
          - VRM_DCIPRIORITY
          - VRM_SERVICEINFOSTATUSMODE
          - VRM_RXARPMAPPINGMODE
          - VRM_NOTIFYATTRENUMVALUEMODE
          - VRM_GLBSESDATAREFRESH
          - VRM_MAXPOCSCPNUM
          - VRM_SPUAUTOSWITCHOVER
          - VRM_PRAIDCODECMODE
          - VRM_DFTROAMINGSTATUS
          - VRM_MCIPROCMODE
          - VRM_VMSTORAGEFAULTRMSWITCH
          - VRM_PREBINDFORSESSIONBACKUP
          - VRM_SHARESYQUOTAMODE
          - VRM_MEMCHECKALARMSWITCH
          - VRM_QUOTASTATUSSTATISTIC
          - VRM_SUBIDCHOOSESWITCH
          - VRM_MCCMNCROAMREGION
          - VRM_TERMFIRSTSESSIONSWITCH
          - VRM_RECORDMEMSWITCH
          - VRM_Q922ERRMSGSWITCH
          - VRM_MEMFREERECORDSTKSWITCH
          - VRM_MEMFREERECORDSTKPOLICY
          - VRM_MSGFREERECORDSTKSWITCH
          - VRM_MSGFREERECORDSTKPOLICY
          - VRM_MEMALLOCFAILEDHOOKSWITCH
          - VRM_LOADINGALLAREADATA
          - VRM_MAXMSGTEMPLATENUM
          - VRM_PCEFHOSTTOGROUP
          - VRM_LINKBASEAPN
          - VRM_CBOVERRUNALMTH
          - VRM_CBRECOVERYALMTH
          - VRM_VOLTESESSINDEPENDENT
          - VRM_MEWORKROLE
          - VRM_RESETFORALLOCMEMFAILED
          - VRM_RESETFORALLOCMSGFAILED
          - VRM_ENABLEVOLTEAPNGXFLOWCTRL
          - VRM_CBWATCHTIME
          - VRM_DIAMMSGRELAYSWITCH
          - VRM_SYNTIMER
          - VRM_DEVAUDITACCELERATION
          - VRM_PENDINGTRANSACTIONNUM
          - VRM_VOLTEQRYSPR
          - VRM_TRIGGERRESTRICTTYPE
          - BLC_UPMUSERREQ
          - BLC_BEARUPDATE
          - BLC_WAITBEARTERM
          - BLC_ZONETYPE
          - BLC_SECPDPQOSCONTROL
          - RM_RATINGVOLRNDUNIT
          - RM_USGVOLRNDUNIT
          - RM_USGVOLRNDTHRESH
          - RM_RUSGVOLRNDUNIT
          - RM_RUSGVOLRNDTHRESH
          - RM_PLMNANDSGSNALM
          - RM_ALMCLRPERIOD
          - BLC_NOTIFYSENDINTERVAL
          - VRM_OCSCHARGEFLAGFORPRE
          - VRM_OCSCHARGEFLAGFORPOS
          - VRM_OCSCHARGEFLAGFOROTHER
          - BLC_DELSSINVALIDINTERVAL
          - BLC_DELSSINTERVAL
          - BLC_DELSSNUM
          - VRM_CHECKAPNIP
          - VRM_QCIUPGRADE
          - VRM_UNDERCONTROLTHRESHOLD
          - VRM_NORMALVALUE
          - UPM_SUBCTRL
          - UPM_ACCRARTIMEOUT
          - UPM_TIMERPLYCNTREQ
          - VRM_KPIMONITORINGSWITCH
          - VRM_TDFPOLICYMODE
          - VRM_RXBEARWITH5002
          - LIC_PREALMTH
          - VRM_QRYSPRPRIORITY
          - VRM_SDUROUTECONFILICTRAR
          - VRM_DBTIMERVALIDPERIOD
          - VRM_FORCERECOVERYSESSION
          - ALC_WAITAFTERM
          - VRM_RARWITHTRIGGER
          - VRM_RELEASERXTRIGGER
          - VRM_MAXIPCANNUMPERUSR
          - VRM_RETENTION_NOTIFYLOG
          - VRM_RETENTION_MNTLOG
          - VRM_RETENTION_EXPORT
          - VRM_MAXSESSBACKUPNUMPERSUB
          - VRM_SAVESYORGSTATUS
          - VRM_SNRSUPPORTSUBID
          - VRM_AUDITFAILEDCODE
          - VRM_ADJUSTSERVICEMODE
          - VRM_SYORIGINSTATEID
          - VRM_NOTRARWITHSAMEINSTALLRULE
          - VRM_CALCPRIBYSRVNAME
          - VRM_PENDINGTIME2LOCALTIME
          - VRM_MAXPCEFRADIUSNUM
          - VRM_RTPDRNOFLOW
          - VRM_SYDRASLRITIMEOUTSTRCTRL
          - VRM_GXREDIRECTACTION
          - VRM_GXRULEDEDUP
          - VRM_MCITOPGWSPEED
          - VRM_NRIPV6HASHLENGTH
          - VRM_SDCHARGINGCHARSWITCH
          - VRM_OFFLINESRVSWITCH
          - VRM_OFFLINEREDOLOG
          - VRM_VOLTESESSIONNOTUPDATE
          - VRM_BSFONLYVOLTE
          - VRM_BSFRESENDTIMES
          - VRM_BSFTIMEOUT
          - VRM_CHRGIDFMT
          - VRM_LONGTERMNTYRECORDPERSUB
          - VRM_GXQRYCHARINGSYSMODE
          - VRM_RECREATERULENOTIFICATION
          - VRM_PACKETFILTER
          - VRM_SNRWITHOUTHOSTMODE
          - VRM_SYCOUNTERTRANSMODE
          - VRM_MAXCONDITIONNUM
          - VRM_MAXQUOTANUM
          - VRM_RMVSYSRVBYRESULTCODE
          - VRM_VIRTUALSUBIDSWITCH
          - VRM_VOLTEPDPQRYSY
          - VRM_PACKETERRRATETYPE
          - VRM_IPDOMAINSENSITIVE
          - VRM_NRCOMBINEPRIORITYMODE
          - VRM_N15COMPATIBILITYSWITCH
          - VRM_HASHAUDITSWITCH
          - VRM_RECUSRLOCBASERAT
          - VRM_MULTIPCEFQRYDB
          - VRM_DEVAUDITSTARTTIME
          - VRM_MCIDELOLDSES
          - VRM_MCIDELOLDSESSPEED
          - VRM_CHECKSUBSRV
          - VRM_MASTERSLAVENOTIFYENHANCE
          - VRM_NEPEERSTATUS
          - VRM_NONOVERLOADERRORCODESW
          - VRM_AMFRESELECTSWITCH
          - VRM_REDIRECTSWITCH
          - VRM_POLICYASSOCIATESWITCH
          - VRM_DIAMDIRECTPATH
          - VRM_SMFALMWITHIPPORT
          - VRM_REGWITHINSTANCENAME
          - VRM_VIRTUALQUOTAREPORTUSAGE
          - VRM_SPONSORDYNRULEFORMAT
          - VRM_SRVTOKENNUM
          - VRM_UPDSMFSTA
          - VRM_N7CHGNORULESWITCH
          - VRM_QUOTAOBJNOTEXISTCALCMODE
          - VRM_SDRRELIABTRANSSWITCH
          - VRM_CALCULBYNR
          - VRM_GXSESSIONCHARGE
          - VRM_RARSPEEDDOWNCPU
          - VRM_RARSPEEDUPCPU
          - VRM_SUBSCRIBERGROUPMATCHMODE
          - VRM_SCANSTARTTIME
          - VRM_DISTRIQUERYMAXRECORD
          - VRM_GLBPARTITIONLOADINGSWITCH
          - VRM_COMPARECCRIUQOS
          - VRM_AUTORECUSRLOCEX
          - VRM_AVGCHILDPERPARENT
          - VRM_AVGPARENTPERCHILD
          - VRM_SELECTNTSMETHOD
          - VRM_QUOTADEDUCTMODE
          - VRM_MAXBEARNUMPERIPCAN
          - VRM_SDSESSIONBACKUP
          - VRM_SERVICEZONEAREAMATCHTYPE
          - VRM_USRLOCATION_VALUE
          - VRM_RULESUFFIXLENAPPMODE
          - VRM_TAIMATCHINGMODE
          - VRM_N7PCCNOCHGANINFOSW
          - VRM_N5SESSIONBACKUP
          - VRM_PROFILEUPDATEBASERULEPRI
          - VRM_AFSELBINDCFG
          - VRM_ROUTEQUERYRETRYTIMES
          - VRM_ROUTEQUERYRETRYINTERVAL
          - VRM_NOTIFYBEFOREEXPIRE
          - VRM_N36INTERFACESW
          - VRM_N36SUBSCRIPTIONSW
          - VRM_PCFLIPSELECTMODE
          - VRM_PESSRVDISCTIMER
          - VRM_EXATTR1DEFAULTVALUE
          - VRM_HTTPCLIENTREDIRECTTIMES
          - VRM_N23SWITCH
          - VRM_DIAMGETAPPID
          - VRM_N23SESSIONBACKUP
          - VRM_GLBDATAIDMAPSWITCH
          - VRM_PEERNFDEFAULTPRIORITY
          - VRM_N23SESADTMSGSPEED
          - VRM_IPDOMAINSRCFORGX
          - VRM_N15VIRTUALSUBIDSWITCH
          - VRM_SESSIONCOMPRESSTYPE
          - VRM_UPDAMFSTA
          - VRM_N23TIMEOUT
          - VRM_MAXAMSAUNUMPERSPU
          - VRM_N24AMSWITCH
          - VRM_N24AMTIMEOUT
          - VRM_CALLRXFIRSTSW
          - VRM_BACKFILLSESRULE
          - VRM_N7NWDAFLINKDOWNSW
          - VRM_N7POLICYCHGN23SW
          - VRM_RSTSYQUOTASW
          - VRM_HTTPLOCFILLMODE
          - VRM_DRALINKSTAMPUPTMODE
          - VRM_TRACECACHECHKSW
          - VRM_N15AREACODESW
          - VRM_USELASTPLMNIFNOTMATCHED
          - VRM_AUTORESETSWITCH4FSM
          - VRM_N23HDPCFIDMODE
          - VRM_CALCREDPRIBYNAME
          - VRM_STATEXTERNALRESTORATION
          - VRM_BSFBINDINGUPDATESW
          - VRM_SBICALLBACKVALUE
          - VRM_NGPOLICYCASESENSITIVE
          - VRM_N15QRYCHARINGSYSMODE
          - VRM_AFUPDATEUMMODE
          - VRM_HSRCTRLSW
          - VRM_CALCMEDRULEPRIBYNAME
          - VRM_DATAVIRTUALSUBIDSWITCH
          - VRM_INTRANETSESSEFFMODE
          - VRM_N28PENDINGTIME2LOCAL
          - VRM_MIDNIGHTGLBREFRESHSWITCH
          - VRM_SCANFROZENUSER
          - VRM_N1NOTIFYTIMER
          - VRM_MAXNWDAFSESNUMPERSPU
          - VRM_PCEFPARAMATCHMODE
          - VRM_N5VIRTUALMEDIA
          - VRM_SYQTAINSTMODE
          - VRM_N7UPDATECAFCRXMODE
          - VRM_N7ACTN23POLICYMODE
          - VRM_N23BAKCOMPATIBILITYSW
          - VRM_N7MAXDYNRULENUM
          - VRM_N7FAILRCPROCMETHOD
          - VRM_DELAYSTATAUTOENABLEDSW
          - VRM_AUTHSRVENCODEMODE
          - VRM_SUBLOCNUM
          - VRM_HPCFDELIVERLOCCHSW
          - VRM_N15RMVSPCMCCFROMGPSI
          - VRM_MODULERSTPROTECTTIME
          - VRM_N15DYNMATCHMODE
          - VRM_NESTATUSREFRESHCYCLE
          - VRM_SYCCFROMN7SWITCH
          - VRM_MAXSESSRESTOREDELAYTIME
          - VRM_SESSIONNUMCOUNTMODE
          - VRM_UEINITRESOURCEBYSMFSWITCH
          - VRM_SATT2TVOICESW
          - VRM_ROLLBACKN7LINKDOWN
          - VRM_DEVAUDITAUTO
          - VRM_N24NFSETRESENTTIMES
          - VRM_UNKNOWNLOCPROC
          - VRM_N15SUBCTRL
          - VRM_UPMUSERREQTIMERLEN
          - VRM_SYSLRIDATIME
          - VRM_MAXNXSESNUMPERSPU
          - VRM_NXNASTIMEOUT
          - VRM_NXNASRETRYTIMES
          - VRM_NZTIMEOUT
          - VRM_NZRETRYTIMES
          - VRM_NXPENDINGRETRYTIMES
          - VRM_NXNWDAFDICMODE
          - VRM_NXNZSESSIONBACKUP
          - VRM_SLRURESENDTIMES
          - VRM_CHECKNTSLINKSTATUS
          - VRM_ABSVALPRDSRVAUTOSW
          - VRM_N23USETAIDISCMODE
          - VRM_SYTOGXRCMODE
          - VRM_VONRLICSTATMODE
          - VRM_PROFILEUPTTIMELEN
          - VRM_SYNASSOCDATAINTERVAL
          - VRM_N7NWDAFLINKDOWNCYCLE
          - VRM_N7NWDAFLINKDOWNMAXTIMES
          - VRM_RXIPV6PCEFGROUPID
          - VRM_DLBPRQTIMERLEN
          - VRM_CLIENTPORTVERIFY
          - VRM_RECHARGENOTIFIRESTRAIN
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '参数值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list_1:
      type: items
      properties:
        INSPN:
          name: '参数名'
          type: string
          enum:
          - VRM_MAXIPCANSESNUMPERSPU
          - VRM_MAXAFSESNUMPERSPU
          - VRM_MAXSUBNUMPERSPU
          - VRM_UPGRADE
          - VRM_MAXRATBEARIDPERSES
          - VRM_SRVNUMPERUSR
          - VRM_MAXPAFNUM
          - VRM_MAXPCEFNUM
          - VRM_MAXRADIUSSRVNUM
          - VRM_MAXCONNECTIONPERPAF
          - VRM_MAXCONNECTIONPERPCEF
          - VRM_MAXLINKRADIUSSRV
          - VRM_SUBSRCIPTIONIDTYPE
          - VRM_GLBREFLASHINTERVAL
          - VRM_NOTIFYMSGMAXRECORDPERSUB
          - VRM_NOTIFYMSGMAXDAYPERSUB
          - VRM_REVALIDATIONTIMEMETHOD
          - VRM_NOSUBSCRIPTIONERRORCODE
          - VRM_NOTIFYMSGMAXWAITEDRECORDS
          - VRM_PRINTLOCALLOG
          - VRM_USRREVALIHRANGE
          - VRM_ONLINECHECK
          - VRM_TIMEZONEENHANCE
          - VRM_GXIMEIFORMAT
          - VRM_NOTIFYMSGMAXRECORDPERDSU
          - VRM_CLEARALLDYNCREATEDUSER
          - VRM_PEELDOMAINSWITCH
          - VRM_NOTIFYRCVER
          - VRM_FIRSTDAYOFWEEK
          - VRM_UPDATESPRSUBACTIVE
          - VRM_SUBCTRLRESULT
          - VRM_SPRSUBMAXOFFLINEDAYS
          - VRM_CHECKSUBSCRIBEDSERVICE
          - VRM_SUBACTCTRL
          - VRM_SESSIONCHECKINTERVAL
          - VRM_CHKSUBSRVSYTYPE
          - VRM_RARSENDSPEED
          - VRM_DIAREDIRECTSWITCH
          - VRM_PERIODVALUE
          - VRM_PROTECTTIMER
          - VRM_SENDUSERNUM
          - VRM_POLICYCASESENSITIVE
          - VRM_SESSIONRESTORATION
          - VRM_RXRPMAPRELATION
          - VRM_NOTIFYUSAGEUNITCONVERT
          - VRM_TIMEACCUMODE
          - VRM_SYSWITCH
          - VRM_PLMNMATCHPRIORITY
          - VRM_RESETNOTIFYRPT
          - VRM_REPORTINGLEVEL
          - VRM_RATINGGROUP
          - VRM_SERVICEIDENTIFIER
          - VRM_DFTCHARGINGPARA
          - VRM_LOGPRINTPERIOD
          - VRM_MAXBBERFNUM
          - VRM_MAXCONNECTIONPERBBERF
          - VRM_SPNOTIFYDOMAIN
          - VRM_EXSPRNOTIFICATION
          - VRM_SESSIONBACKUPSWITCH
          - VRM_DIAMHBINTERVAL
          - VRM_DIAMHBTIMES
          - VRM_EDRACCESSFORMATE
          - VRM_IPCANTERMSWITCH
          - VRM_DELBEAROPTION
          - VRM_LDAPREVBUFFERSIZE
          - VRM_NOTIFYOPTIMIZE
          - VRM_RESULTCODESWITCH
          - VRM_FMTIPADDR
          - VRM_GROUPDIAREDIRECTSWITCH
          - VRM_RMVSUBWITHOUTRAR
          - VRM_GRPMBRUSAGECACHE1
          - VRM_GRPMBRUSAGECACHE2
          - VRM_DYNRULEFORMAT
          - VRM_IPV6HASHLENGTH
          - VRM_DURATIONMKMATCH
          - VRM_SNRRECSPEED
          - VRM_DIAMTIMETHRD
          - VRM_LDAPTIMETHRD
          - VRM_RELGXBYRAATIMEOUT
          - VRM_SETHOMESRVZONE
          - VRM_MAXTDFNUM
          - VRM_TDFCCRUSPD
          - VRM_TDFCCRTSPD
          - VRM_PROCHEARTBEATTIMEOUT
          - VRM_MAXAUXILIARYAREA
          - VRM_AADIAREDIRECTSWITCH
          - VRM_DIAMFAILOVERSWITCH
          - VRM_DYNSMSMSISDN
          - VRM_SUBGRPCREATESUB
          - VRM_QUOTACROSSSERVICE
          - VRM_SYSUBIDTYPE
          - VRM_DEACTIVESERVICETIMER
          - VRM_QUOTALOGSWITCH
          - VRM_SIMPLEPOLICYSTATISTIC
          - VRM_GXTRIGGERCMP
          - VRM_QOSNEGOTIATIONSWITCH
          - VRM_IPFLOWANYCVT
          - VRM_SUBLISTNORULE
          - VRM_NTFOVERDUEMODE
          - VRM_DESTPEERMODE
          - VRM_SYNDATASWITCH
          - VRM_SYNDATAINTERVAL
          - VRM_TAIECGIMATCHMODE
          - VRM_SYCARRYSUBID
          - VRM_SYRESENDTIMES
          - VRM_DYNQUOTATIMEZONE
          - VRM_FIRSTGXSESSIONATTR
          - VRM_SESSIONIDHASHMODE
          - VRM_PEERFCDURATION
          - VRM_AFPOLICYRECALCULATE
          - VRM_SGWRESTORETIME
          - VRM_QUOTAUSEPRIORITY
          - VRM_SESSIONIDSWITCH
          - VRM_REPORTUSAGE
          - VRM_IMEIQUERYSERVICE
          - VRM_MCITRIGGERUDR
          - VRM_RXMAXUL
          - VRM_RXMAXDL
          - VRM_SYSESSIONCONTROLATTRIBUTE
          - VRM_SYSESSIONCONTROLVALUE
          - VRM_AUTORECUSRLOC
          - VRM_LINKDSPMODE
          - VRM_RXSTAINCAUTHAPPID
          - VRM_MAXAREANUM
          - VRM_GXSESSIONONLYVOLTE
          - VRM_LDAPDBTIMEOUT
          - VRM_OFFSETTIME
          - VRM_APNSENSITIVE
          - VRM_DYNGROUPNUMBERPERUSER
          - VRM_SYSESSIONBACKUP
          - VRM_NOTIFYATTRRESTRICTION
          - VRM_UNKNOWNRULEPROC
          - VRM_FORCEUPGRADEQOS
          - VRM_RMVGRPMEMBERACT
          - VRM_SYNUSRDATASPEED
          - VRM_SYCHARGINGCHARSWITCH
          - VRM_LICDSPMODE
          - VRM_GRPMBRPARENTSTATUSFLAG
          - VRM_TERMSESSNOTIFICATIONFLAG
          - VRM_DCIPRIORITY
          - VRM_SERVICEINFOSTATUSMODE
          - VRM_RXARPMAPPINGMODE
          - VRM_NOTIFYATTRENUMVALUEMODE
          - VRM_GLBSESDATAREFRESH
          - VRM_MAXPOCSCPNUM
          - VRM_SPUAUTOSWITCHOVER
          - VRM_PRAIDCODECMODE
          - VRM_DFTROAMINGSTATUS
          - VRM_MCIPROCMODE
          - VRM_VMSTORAGEFAULTRMSWITCH
          - VRM_PREBINDFORSESSIONBACKUP
          - VRM_SHARESYQUOTAMODE
          - VRM_MEMCHECKALARMSWITCH
          - VRM_QUOTASTATUSSTATISTIC
          - VRM_SUBIDCHOOSESWITCH
          - VRM_MCCMNCROAMREGION
          - VRM_TERMFIRSTSESSIONSWITCH
          - VRM_RECORDMEMSWITCH
          - VRM_Q922ERRMSGSWITCH
          - VRM_MEMFREERECORDSTKSWITCH
          - VRM_MEMFREERECORDSTKPOLICY
          - VRM_MSGFREERECORDSTKSWITCH
          - VRM_MSGFREERECORDSTKPOLICY
          - VRM_MEMALLOCFAILEDHOOKSWITCH
          - VRM_LOADINGALLAREADATA
          - VRM_MAXMSGTEMPLATENUM
          - VRM_PCEFHOSTTOGROUP
          - VRM_LINKBASEAPN
          - VRM_CBOVERRUNALMTH
          - VRM_CBRECOVERYALMTH
          - VRM_VOLTESESSINDEPENDENT
          - VRM_MEWORKROLE
          - VRM_RESETFORALLOCMEMFAILED
          - VRM_RESETFORALLOCMSGFAILED
          - VRM_ENABLEVOLTEAPNGXFLOWCTRL
          - VRM_CBWATCHTIME
          - VRM_DIAMMSGRELAYSWITCH
          - VRM_SYNTIMER
          - VRM_DEVAUDITACCELERATION
          - VRM_PENDINGTRANSACTIONNUM
          - VRM_VOLTEQRYSPR
          - VRM_TRIGGERRESTRICTTYPE
          - BLC_UPMUSERREQ
          - BLC_BEARUPDATE
          - BLC_WAITBEARTERM
          - BLC_ZONETYPE
          - BLC_SECPDPQOSCONTROL
          - RM_RATINGVOLRNDUNIT
          - RM_USGVOLRNDUNIT
          - RM_USGVOLRNDTHRESH
          - RM_RUSGVOLRNDUNIT
          - RM_RUSGVOLRNDTHRESH
          - RM_PLMNANDSGSNALM
          - RM_ALMCLRPERIOD
          - BLC_NOTIFYSENDINTERVAL
          - VRM_OCSCHARGEFLAGFORPRE
          - VRM_OCSCHARGEFLAGFORPOS
          - VRM_OCSCHARGEFLAGFOROTHER
          - BLC_DELSSINVALIDINTERVAL
          - BLC_DELSSINTERVAL
          - BLC_DELSSNUM
          - VRM_CHECKAPNIP
          - VRM_QCIUPGRADE
          - VRM_UNDERCONTROLTHRESHOLD
          - VRM_NORMALVALUE
          - UPM_SUBCTRL
          - UPM_ACCRARTIMEOUT
          - UPM_TIMERPLYCNTREQ
          - VRM_KPIMONITORINGSWITCH
          - VRM_TDFPOLICYMODE
          - VRM_RXBEARWITH5002
          - LIC_PREALMTH
          - VRM_QRYSPRPRIORITY
          - VRM_SDUROUTECONFILICTRAR
          - VRM_DBTIMERVALIDPERIOD
          - VRM_FORCERECOVERYSESSION
          - ALC_WAITAFTERM
          - VRM_RARWITHTRIGGER
          - VRM_RELEASERXTRIGGER
          - VRM_MAXIPCANNUMPERUSR
          - VRM_RETENTION_NOTIFYLOG
          - VRM_RETENTION_MNTLOG
          - VRM_RETENTION_EXPORT
          - VRM_MAXSESSBACKUPNUMPERSUB
          - VRM_SAVESYORGSTATUS
          - VRM_SNRSUPPORTSUBID
          - VRM_AUDITFAILEDCODE
          - VRM_ADJUSTSERVICEMODE
          - VRM_SYORIGINSTATEID
          - VRM_NOTRARWITHSAMEINSTALLRULE
          - VRM_CALCPRIBYSRVNAME
          - VRM_PENDINGTIME2LOCALTIME
          - VRM_MAXPCEFRADIUSNUM
          - VRM_RTPDRNOFLOW
          - VRM_SYDRASLRITIMEOUTSTRCTRL
          - VRM_GXREDIRECTACTION
          - VRM_GXRULEDEDUP
          - VRM_MCITOPGWSPEED
          - VRM_NRIPV6HASHLENGTH
          - VRM_SDCHARGINGCHARSWITCH
          - VRM_OFFLINESRVSWITCH
          - VRM_OFFLINEREDOLOG
          - VRM_VOLTESESSIONNOTUPDATE
          - VRM_BSFONLYVOLTE
          - VRM_BSFRESENDTIMES
          - VRM_BSFTIMEOUT
          - VRM_CHRGIDFMT
          - VRM_LONGTERMNTYRECORDPERSUB
          - VRM_GXQRYCHARINGSYSMODE
          - VRM_RECREATERULENOTIFICATION
          - VRM_PACKETFILTER
          - VRM_SNRWITHOUTHOSTMODE
          - VRM_SYCOUNTERTRANSMODE
          - VRM_MAXCONDITIONNUM
          - VRM_MAXQUOTANUM
          - VRM_RMVSYSRVBYRESULTCODE
          - VRM_VIRTUALSUBIDSWITCH
          - VRM_VOLTEPDPQRYSY
          - VRM_PACKETERRRATETYPE
          - VRM_IPDOMAINSENSITIVE
          - VRM_NRCOMBINEPRIORITYMODE
          - VRM_N15COMPATIBILITYSWITCH
          - VRM_HASHAUDITSWITCH
          - VRM_RECUSRLOCBASERAT
          - VRM_MULTIPCEFQRYDB
          - VRM_DEVAUDITSTARTTIME
          - VRM_MCIDELOLDSES
          - VRM_MCIDELOLDSESSPEED
          - VRM_CHECKSUBSRV
          - VRM_MASTERSLAVENOTIFYENHANCE
          - VRM_NEPEERSTATUS
          - VRM_NONOVERLOADERRORCODESW
          - VRM_AMFRESELECTSWITCH
          - VRM_REDIRECTSWITCH
          - VRM_POLICYASSOCIATESWITCH
          - VRM_DIAMDIRECTPATH
          - VRM_SMFALMWITHIPPORT
          - VRM_REGWITHINSTANCENAME
          - VRM_VIRTUALQUOTAREPORTUSAGE
          - VRM_SPONSORDYNRULEFORMAT
          - VRM_SRVTOKENNUM
          - VRM_UPDSMFSTA
          - VRM_N7CHGNORULESWITCH
          - VRM_QUOTAOBJNOTEXISTCALCMODE
          - VRM_SDRRELIABTRANSSWITCH
          - VRM_CALCULBYNR
          - VRM_GXSESSIONCHARGE
          - VRM_RARSPEEDDOWNCPU
          - VRM_RARSPEEDUPCPU
          - VRM_SUBSCRIBERGROUPMATCHMODE
          - VRM_SCANSTARTTIME
          - VRM_DISTRIQUERYMAXRECORD
          - VRM_GLBPARTITIONLOADINGSWITCH
          - VRM_COMPARECCRIUQOS
          - VRM_AUTORECUSRLOCEX
          - VRM_AVGCHILDPERPARENT
          - VRM_AVGPARENTPERCHILD
          - VRM_SELECTNTSMETHOD
          - VRM_QUOTADEDUCTMODE
          - VRM_MAXBEARNUMPERIPCAN
          - VRM_SDSESSIONBACKUP
          - VRM_SERVICEZONEAREAMATCHTYPE
          - VRM_USRLOCATION_VALUE
          - VRM_RULESUFFIXLENAPPMODE
          - VRM_TAIMATCHINGMODE
          - VRM_N7PCCNOCHGANINFOSW
          - VRM_N5SESSIONBACKUP
          - VRM_PROFILEUPDATEBASERULEPRI
          - VRM_AFSELBINDCFG
          - VRM_ROUTEQUERYRETRYTIMES
          - VRM_ROUTEQUERYRETRYINTERVAL
          - VRM_NOTIFYBEFOREEXPIRE
          - VRM_N36INTERFACESW
          - VRM_N36SUBSCRIPTIONSW
          - VRM_PCFLIPSELECTMODE
          - VRM_PESSRVDISCTIMER
          - VRM_EXATTR1DEFAULTVALUE
          - VRM_HTTPCLIENTREDIRECTTIMES
          - VRM_N23SWITCH
          - VRM_DIAMGETAPPID
          - VRM_N23SESSIONBACKUP
          - VRM_GLBDATAIDMAPSWITCH
          - VRM_PEERNFDEFAULTPRIORITY
          - VRM_N23SESADTMSGSPEED
          - VRM_IPDOMAINSRCFORGX
          - VRM_N15VIRTUALSUBIDSWITCH
          - VRM_SESSIONCOMPRESSTYPE
          - VRM_UPDAMFSTA
          - VRM_N23TIMEOUT
          - VRM_MAXAMSAUNUMPERSPU
          - VRM_N24AMSWITCH
          - VRM_N24AMTIMEOUT
          - VRM_CALLRXFIRSTSW
          - VRM_BACKFILLSESRULE
          - VRM_N7NWDAFLINKDOWNSW
          - VRM_N7POLICYCHGN23SW
          - VRM_RSTSYQUOTASW
          - VRM_HTTPLOCFILLMODE
          - VRM_DRALINKSTAMPUPTMODE
          - VRM_TRACECACHECHKSW
          - VRM_N15AREACODESW
          - VRM_USELASTPLMNIFNOTMATCHED
          - VRM_AUTORESETSWITCH4FSM
          - VRM_N23HDPCFIDMODE
          - VRM_CALCREDPRIBYNAME
          - VRM_STATEXTERNALRESTORATION
          - VRM_BSFBINDINGUPDATESW
          - VRM_SBICALLBACKVALUE
          - VRM_NGPOLICYCASESENSITIVE
          - VRM_N15QRYCHARINGSYSMODE
          - VRM_AFUPDATEUMMODE
          - VRM_HSRCTRLSW
          - VRM_CALCMEDRULEPRIBYNAME
          - VRM_DATAVIRTUALSUBIDSWITCH
          - VRM_INTRANETSESSEFFMODE
          - VRM_N28PENDINGTIME2LOCAL
          - VRM_MIDNIGHTGLBREFRESHSWITCH
          - VRM_SCANFROZENUSER
          - VRM_N1NOTIFYTIMER
          - VRM_MAXNWDAFSESNUMPERSPU
          - VRM_PCEFPARAMATCHMODE
          - VRM_N5VIRTUALMEDIA
          - VRM_SYQTAINSTMODE
          - VRM_N7UPDATECAFCRXMODE
          - VRM_N7ACTN23POLICYMODE
          - VRM_N23BAKCOMPATIBILITYSW
          - VRM_N7MAXDYNRULENUM
          - VRM_N7FAILRCPROCMETHOD
          - VRM_DELAYSTATAUTOENABLEDSW
          - VRM_AUTHSRVENCODEMODE
          - VRM_SUBLOCNUM
          - VRM_HPCFDELIVERLOCCHSW
          - VRM_N15RMVSPCMCCFROMGPSI
          - VRM_MODULERSTPROTECTTIME
          - VRM_N15DYNMATCHMODE
          - VRM_NESTATUSREFRESHCYCLE
          - VRM_SYCCFROMN7SWITCH
          - VRM_MAXSESSRESTOREDELAYTIME
          - VRM_SESSIONNUMCOUNTMODE
          - VRM_UEINITRESOURCEBYSMFSWITCH
          - VRM_SATT2TVOICESW
          - VRM_ROLLBACKN7LINKDOWN
          - VRM_DEVAUDITAUTO
          - VRM_N24NFSETRESENTTIMES
          - VRM_UNKNOWNLOCPROC
          - VRM_N15SUBCTRL
          - VRM_UPMUSERREQTIMERLEN
          - VRM_SYSLRIDATIME
          - VRM_MAXNXSESNUMPERSPU
          - VRM_NXNASTIMEOUT
          - VRM_NXNASRETRYTIMES
          - VRM_NZTIMEOUT
          - VRM_NZRETRYTIMES
          - VRM_NXPENDINGRETRYTIMES
          - VRM_NXNWDAFDICMODE
          - VRM_NXNZSESSIONBACKUP
          - VRM_SLRURESENDTIMES
          - VRM_CHECKNTSLINKSTATUS
          - VRM_ABSVALPRDSRVAUTOSW
          - VRM_N23USETAIDISCMODE
          - VRM_SYTOGXRCMODE
          - VRM_VONRLICSTATMODE
          - VRM_PROFILEUPTTIMELEN
          - VRM_SYNASSOCDATAINTERVAL
          - VRM_N7NWDAFLINKDOWNCYCLE
          - VRM_N7NWDAFLINKDOWNMAXTIMES
          - VRM_RXIPV6PCEFGROUPID
          - VRM_DLBPRQTIMERLEN
          - VRM_CLIENTPORTVERIFY
          - VRM_RECHARGENOTIFIRESTRAIN
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '参数值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pcefabiitem_list:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pcefabiitem_list_1:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCATEGORY:
          name: 'USRCATEGORY'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - mod_insp_list:
    - INSPN: VRM_NORMALVALUE
      INSPV: 1
    mod_insp_list_1:
    - INSPN: VRM_UNDERCONTROLTHRESHOLD
      INSPV: 0
    mod_pcefabiitem_list:
    - ABILITYDICTID: 67
      ABILITYITEMID: R8QoS
      ABLITYVALUE: UnsupportedR8QoS
    mod_pcefabiitem_list_1:
    - ABILITYDICTID: 67
      ABILITYITEMID: AccessNode
      ABLITYVALUE: SupportedAccessNode
    add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: '12345678901'
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRCATEGORY: Gold
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: MBB
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: Service_CELL
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 配置软参。

#### 1.1 登录“UPCF MML命令”界面。

#### 1.2 执行**MOD INSP**命令，配置参数VRM\_NORMALVALUE（拥塞空闲取值）。

#### 当需要修改处于拥塞控制状态下用户恢复的拥塞状态值时，执行此步骤，否则，请跳过此步骤。

#### 命令举例：

```jinja2
{%- for item in mod_insp_list -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    ;
{%- endfor -%}
```

#### 1.3 执行**MOD INSP**命令，配置参数VRM\_UNDERCONTROLTHRESHOLD（受控状态阈值）。

#### 当需要修改小区拥塞时用户是否受控的起始阈值时，执行此步骤，否则，请跳过此步骤。

#### 命令举例：

```jinja2
{%- for item in mod_insp_list_1 -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    ;
{%- endfor -%}
```

### 2 修改对端PCEF（Policy and Charging Enforcement Function）能力字典项。

#### 2.1 登录“UPCF MML命令”界面。

#### 2.2 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其不支持R8标准的QoS。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”默认设置为“67”。实际的值可以通过如下方式查询：

#### 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。

#### 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。

#### 2.3 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持小区拥塞功能。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list_1 -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 3 登录UPCF Web UI界面。

### 4 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 需要配置两个条件组，用于判断普通用户和金牌用户的小区拥塞状态。条件组的数据规划如表2所示，详细参数说明请参见条件组参数表。

### **表2** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | CG\_normal |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | C\_normal |

### |  |  | 对象属性 | * 对象：AccessNode * 属性：LoadStatus |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Level1  说明：  GGSN上报值为Normal=1，在UPCF中枚举值“1”对应的条件为Level1，则为Level1配置Normal的规则进行下发。 |

### |  | 条件2 | 名称 | C\_common1 |

### |  |  | 对象属性 | * 对象：Subscriber * 属性：Category |

### |  |  | 操作符 | Not Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Gold |

### | 条件组2 | 基本信息 | 名称 | CG\_congestion |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | C\_clear |

### |  |  | 对象属性 | * 对象：AccessNode * 属性：LoadStatus |

### |  |  | 操作符 | Not Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Level1 |

### |  | 条件2 | 名称 | C\_common2 |

### |  |  | 对象属性 | * 对象：Subscriber * 属性：Category |

### |  |  | 操作符 | Not Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Gold |

### 5 配置动作组。

### 导航入口为“策略管理 > 策略 > 动作组”。

### 若配置的规则为动态规则，则必须配置动作组。

### 此场景配置动态规则且仅考虑调整带宽，则每个动作组需配置动作：QoSAction和ChargingAction。相关应用场景如下：

### QoSAction：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制QoS。

### ChargingAction：当需要做计费策略控制时，配置此动作（若对端为华为GGSN，此动作必须配置）。

### 需要配置两个动作组，用于普通用户和金牌用户在小区未拥塞和小区拥塞时动作的下发。动作组的数据规划如表3所示，详细参数说明请参见动作组参数表。

### **表3** 动作组

### | 类别 | 参数 |  |  | 取值样例 |

### | --- | --- | --- | --- | --- |

### | 动作组1 | 基本信息 | 名称 |  | AG\_normal |

### |  | 动作1 | 动作 |  | QoSAction |

### |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |

### |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：2000 |

### |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：2000 |

### |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：2000 |

### |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：2000 |

### |  |  |  | ARPLevel | * 值类型：Value * 值：1 |

### |  | 动作2 | 动作 |  | ChargingAction  说明：  * 当PCEF对端为华为GGSN时，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。 * 计费参数取值需要和计费系统、GGSN上相关参数取值保持一致。 |

### |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |

### |  |  |  | RatingGroup | * 值类型：Value * 值：1 |

### |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |

### | 动作组2 | 基本信息 | 名称 |  | AG\_congestion |

### |  | 动作1 | 动作 |  | QoSAction |

### |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |

### |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：1000 |

### |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：1000 |

### |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：1000 |

### |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：1000 |

### |  |  |  | ARPLevel | * 值类型：Value * 值：1 |

### |  | 动作2 | 动作 |  | ChargingAction  说明：  * 当PCEF对端为华为GGSN时，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。 * 计费参数取值需要和计费系统、GGSN上相关参数取值保持一致。 |

### |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |

### |  |  |  | RatingGroup | * 值类型：Value * 值：1 |

### |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |

### 6 配置业务流。

### 导航入口为“策略管理 > 策略 > 业务流”。

### 当对端为华为GGSN时，所有的动态规则都必须配置业务流。

### 业务流的数据规划如表4所示，详细参数说明请参见业务流参数表。

### **表4** 业务流

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务流 | 基本信息 | 名称 | Flow\_Filter |

### |  | 流过滤器1 | 名称 | up\_pass |

### |  |  | 流方向 | Up |

### |  |  | 协议 | Any IP Protocol |

### |  | 流过滤器2 | 名称 | down\_pass |

### |  |  | 流方向 | Down |

### |  |  | 协议 | Any IP Protocol |

### 7 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 规则的数据规划如表5所示，详细参数说明请参见规则参数表。

### **表5** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | Rule\_normal |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Dynamic |

### |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |

### |  |  | EDR | OFF |

### |  | 动作组 | 动作组 | AG\_normal  说明：  已在动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | Rule\_congestion |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Dynamic |

### |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_congestion  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_congestion  说明：  已在动作组中定义。 |

### | 规则3 | 基本信息 | 名称 | Rule\_clear |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Dynamic |

### |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_normal  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_normal  说明：  已在动作组中定义。 |

### 8 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表6所示，详细参数说明请参见策略参数表。

### **表6** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略1 | 基本信息 | 名称 | Policy\_CELL\_1 |

### |  | 触发器 | 名称 | IPCANSessionEstablish |

### |  | 规则 | 名称 | Rule\_normal  说明：  已在规则中定义。 |

### | 策略2 | 基本信息 | 名称 | Policy\_CELL\_2 |

### |  | 触发器 | 名称 | CellCongested |

### |  | 规则 | 名称 | * Rule\_congestion * Rule\_clear 说明：  已在规则中定义。 |

### 9 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

### 业务的数据规划如表7所示，详细参数说明请参见业务参数表。

### **表7** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | Service\_CELL |

### |  |  | 类型 | VALUE\_ADDED\_SERVICE |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | * Policy\_CELL\_1 * Policy\_CELL\_2 说明：  已在策略中定义。 |

### 10 登录“UPCF 业务管理”窗口。

### 11 发放业务。

#### 11.1 执行**ADD PSUB**增加一个用户。

#### 开户时，需要配置用户的“USRCATEGORY（用户类别）”为“Gold”或者“Common”（非金牌用户）。

#### “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=11.1 -->
```

#### 11.2 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=11.2 -->
```

