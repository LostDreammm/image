# 基于用户等级的小区拥塞控制（2G/3G）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

在特定的热点小区，如机场、大型商业中心或体育馆等，大量用户同时使用无线接入时；或者少量的用户使用大量无收益且具有较强的带宽抢占能力的业务（如P2P业务）时，会导致无法保障VIP用户的业务体验，同时也影响大多数用户正常使用业务。

华为UPCF通过与PCEF（Policy and Charging Enforcement Function）配合实现拥塞小区的用户体验提升。UPCF可以对拥塞小区内不同价值的用户进行差异化控制，以保障VIP用户的业务体验。

华为UPCF支持根据小区拥塞状态变化和用户等级进行拥塞控制，确保高优先级客户优先使用网络。此时每个条件组中需要配置两个条件，条件1配置为对象AccessNode下的LoadStatus，条件2配置为对象Subscriber下的Category。以UPCF对接华为GGSN为例，配置场景如下：

带宽控制：

* 当用户在小区上线时，上下行带宽均为2 Mbit/s。
* 当小区拥塞时，普通用户上下行最大带宽降为1 Mbit/s，金牌用户上下行带宽仍为2 Mbit/s。
* 当小区拥塞状态解除时，金牌用户和普通用户上下行带宽均为2 Mbit/s。

* 当用户在小区上线时，UPCF给用户下发非拥塞状态下的业务规则。
* PCEF定时检测配置的小区是否发生拥塞，如果发生拥塞或拥塞解除，PCEF对该小区内所有用户分别上报拥塞事件到UPCF，UPCF进行策略调整。

#### 对系统的影响

当小区拥塞时小区内大量用户或者多个小区同时发生拥塞或者拥塞解除时，对端上报的消息量超过UPCF的处理能力，此时UPCF会启动流控丢弃部分上报消息。

#### 必备事项

**前提条件**

操作员已了解WHFD-611028 小区拥塞控制特性概述。

**数据**

根据应用场景，参考业务拆解总体原则，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 业务Service\_CELL | 此包月业务即为一个独立的业务（Service）。 | - |
| 策略Policy\_CELL\_1 | 此策略在用户上线时被调用，触发器为“IPCANSessionEstablish”，包含规则：Rule\_normal。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配并下发策略给PCEF。 |
| 策略Policy\_CELL\_2 | 此策略在小区拥塞和小区拥塞解除时被调用，触发器为“CellCongested”，包含规则：Rule\_congestion和Rule\_clear。 |  |
| 规则Rule\_normal | 动作：  * QoSAction：上下行带宽为2 Mbit/s。 * ChargingAction：“RatingGroup”为1（1代表不计费）。 | * 当使用小区拥塞状态做条件控制时，条件“对象属性”选用对象AccessNode下的LoadStatus属性。 * 若对端为华为GGSN，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。“RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。 * 业务流：若不区分各业务的数据流，统一只根据会话流量控制带宽，则规则中上下行业务流均取默认值“Any IP Protocol”。 |
| 规则Rule\_congestion | * 条件：小区处于拥塞状态且用户类型不是金牌用户。 * 动作：    + QoSAction：上下行带宽为1 Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 |  |
| 规则Rule\_clear | * 条件：小区拥塞状态解除。 * 动作：    + QoSAction：上下行带宽为2 Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 |  |

#### 操作流程

此特性的配置流程图如图2所示。

**图2** 业务配置流程图

#### 操作步骤

1. 配置软参。
   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD INSP**命令，配置参数VRM\_NORMALVALUE（拥塞空闲取值）。

      当需要修改处于拥塞控制状态下用户恢复的拥塞状态值时，执行此步骤，否则，请跳过此步骤。

      命令举例：

      ```
      MOD INSP: INSPN=VRM_NORMALVALUE, INSPV=1;
      ```
   3. 执行**MOD INSP**命令，配置参数VRM\_UNDERCONTROLTHRESHOLD（受控状态阈值）。

      当需要修改小区拥塞时用户是否受控的起始阈值时，执行此步骤，否则，请跳过此步骤。

      命令举例：

      ```
      MOD INSP: INSPN=VRM_UNDERCONTROLTHRESHOLD, INSPV=0;
      ```
2. 修改对端PCEF（Policy and Charging Enforcement Function）能力字典项。
   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其不支持R8标准的QoS。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=R8QoS, ABLITYVALUE=UnsupportedR8QoS;
      ```

      在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”默认设置为“67”。实际的值可以通过如下方式查询：
      * 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。
      * 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
   3. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持小区拥塞功能。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=AccessNode, ABLITYVALUE=SupportedAccessNode;
      ```
3. 登录UPCF Web UI界面。
4. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置两个条件组，用于判断普通用户和金牌用户的小区拥塞状态。条件组的数据规划如表2所示，详细参数说明请参见条件组参数表。

   **表2** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_normal |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | C\_normal |
   |  |  | 对象属性 | * 对象：AccessNode * 属性：LoadStatus |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Level1  说明：  GGSN上报值为Normal=1，在UPCF中枚举值“1”对应的条件为Level1，则为Level1配置Normal的规则进行下发。 |
   |  | 条件2 | 名称 | C\_common1 |
   |  |  | 对象属性 | * 对象：Subscriber * 属性：Category |
   |  |  | 操作符 | Not Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Gold |
   | 条件组2 | 基本信息 | 名称 | CG\_congestion |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | C\_clear |
   |  |  | 对象属性 | * 对象：AccessNode * 属性：LoadStatus |
   |  |  | 操作符 | Not Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Level1 |
   |  | 条件2 | 名称 | C\_common2 |
   |  |  | 对象属性 | * 对象：Subscriber * 属性：Category |
   |  |  | 操作符 | Not Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Gold |
5. 配置动作组。

   导航入口为“策略管理 > 策略 > 动作组”。

   * 若配置的规则为动态规则，则必须配置动作组。
   * 此场景配置动态规则且仅考虑调整带宽，则每个动作组需配置动作：QoSAction和ChargingAction。相关应用场景如下：

     + QoSAction：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制QoS。
     + ChargingAction：当需要做计费策略控制时，配置此动作（若对端为华为GGSN，此动作必须配置）。

   需要配置两个动作组，用于普通用户和金牌用户在小区未拥塞和小区拥塞时动作的下发。动作组的数据规划如表3所示，详细参数说明请参见动作组参数表。

   **表3** 动作组

   | 类别 | 参数 |  |  | 取值样例 |
   | --- | --- | --- | --- | --- |
   | 动作组1 | 基本信息 | 名称 |  | AG\_normal |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction  说明：  * 当PCEF对端为华为GGSN时，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。 * 计费参数取值需要和计费系统、GGSN上相关参数取值保持一致。 |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   | 动作组2 | 基本信息 | 名称 |  | AG\_congestion |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction  说明：  * 当PCEF对端为华为GGSN时，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。 * 计费参数取值需要和计费系统、GGSN上相关参数取值保持一致。 |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
6. 配置业务流。

   导航入口为“策略管理 > 策略 > 业务流”。

   当对端为华为GGSN时，所有的动态规则都必须配置业务流。

   业务流的数据规划如表4所示，详细参数说明请参见业务流参数表。

   **表4** 业务流

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务流 | 基本信息 | 名称 | Flow\_Filter |
   |  | 流过滤器1 | 名称 | up\_pass |
   |  |  | 流方向 | Up |
   |  |  | 协议 | Any IP Protocol |
   |  | 流过滤器2 | 名称 | down\_pass |
   |  |  | 流方向 | Down |
   |  |  | 协议 | Any IP Protocol |
7. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   规则的数据规划如表5所示，详细参数说明请参见规则参数表。

   **表5** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | Rule\_normal |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
   |  |  | EDR | OFF |
   |  | 动作组 | 动作组 | AG\_normal  说明：  已在动作组中定义。 |
   | 规则2 | 基本信息 | 名称 | Rule\_congestion |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_congestion  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_congestion  说明：  已在动作组中定义。 |
   | 规则3 | 基本信息 | 名称 | Rule\_clear |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_normal  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_normal  说明：  已在动作组中定义。 |
8. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   策略的数据规划如表6所示，详细参数说明请参见策略参数表。

   **表6** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略1 | 基本信息 | 名称 | Policy\_CELL\_1 |
   |  | 触发器 | 名称 | IPCANSessionEstablish |
   |  | 规则 | 名称 | Rule\_normal  说明：  已在规则中定义。 |
   | 策略2 | 基本信息 | 名称 | Policy\_CELL\_2 |
   |  | 触发器 | 名称 | CellCongested |
   |  | 规则 | 名称 | * Rule\_congestion * Rule\_clear 说明：  已在规则中定义。 |
9. 配置业务。

   导航入口为“业务管理 > 业务 > 业务”。

   完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

   业务的数据规划如表7所示，详细参数说明请参见业务参数表。

   **表7** 业务

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务 | 基本信息 | 名称 | Service\_CELL |
   |  |  | 类型 | VALUE\_ADDED\_SERVICE |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | * Policy\_CELL\_1 * Policy\_CELL\_2 说明：  已在策略中定义。 |
10. 登录“UPCF 业务管理”窗口。
11. 发放业务。
    1. 执行**ADD PSUB**增加一个用户。

       * 开户时，需要配置用户的“USRCATEGORY（用户类别）”为“Gold”或者“Common”（非金牌用户）。
       * “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

       ```
       ADD PSUB: USRIDENTIFIER="46010381012****", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRCATEGORY="Gold", USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB;
       ```
    2. 执行**ADD PSRV**给用户签约业务。

       ```
       ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="Service_CELL", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
       ```

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
