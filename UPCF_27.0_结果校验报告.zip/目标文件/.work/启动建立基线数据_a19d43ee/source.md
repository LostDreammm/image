# 启动建立基线数据

* 操作场景
* 必备事项
* 操作步骤
* 参考信息

#### 操作场景

如果容灾UPCF建立时，主用UPCF已经运行了一段时间，导致主用UPCF中已有用户数据，而容灾UPCF中没有用户数据，此时需要建立基线数据。

本节主要介绍以采用远端加载的方式进行基线建立的操作。

#### 必备事项

**前提条件**

建立基线数据，需要具备以下条件:

* 检查系统状态已完成。
* 主用UPCF和容灾UPCF的所有告警已经恢复。

**数据**

该操作无需准备数据。

#### 操作步骤

1. 停止主用局业务发放系统侧业务。

   该操作由客户工程师完成。
2. 在容灾局打开“从远端局点加载数据开关”。

   在容灾局的“USCDB MML命令”界面，执行如下命令：

   ```
   MOD INSP: INSPT=FE, INSPN=LDRSOURCE, INSPV=0, FETYPEN="UPCF";
   MOD INSP: INSPT=FE, INSPN=LDRSOURCE, INSPV=0, FETYPEN="USCDB";
   MOD INSP: INSPT=FE, INSPN=LDRSOURCE, INSPV=0, FETYPEN="UPCF-SESSION";

   SET RLOADCFG: SERVICETYPE="USCDB", RLOCID=[主用BE LocationID], RLOADSWT=ON;
   SET RLOADCFG: SERVICETYPE="UPCF", RLOCID=[主用BE LocationID], RLOADSWT=ON;
   SET RLOADCFG: SERVICETYPE="UPCF-SESSION", RLOCID=[主用BE LocationID], RLOADSWT=ON;
   ```

   如果修改前已经是现有配置，会上报“参数未修改，请至少指定一个待修改参数”，无须关注。
3. 在容灾局的“CSP MML命令”界面，执行**RST ME**命令重启USCDB网元。
4. 等待容灾UPCF的DSU（Data Service Unit）、DRU（Data Routing Unit）节点从主用UPCF加载数据完成。

   在主用UPCF和容灾UPCF的“USCDB MML命令”界面 ，分别执行**DSP NODE**命令。如果节点状态为“Slave”或“Master”，表明加载完成。
5. 恢复主用局业务发放系统侧业务。

   该操作由客户工程师完成。
6. 在容灾局关闭“从远端局点加载数据开关”。

   在容灾局的“USCDB MML命令”界面，执行如下命令：

   ```
   SET RLOADCFG: SERVICETYPE="USCDB", RLOCID=[主用BE LocationID], RLOADSWT=OFF;
   SET RLOADCFG: SERVICETYPE="UPCF", RLOCID=[主用BE LocationID], RLOADSWT=OFF;
   SET RLOADCFG: SERVICETYPE="UPCF-SESSION", RLOCID=[主用BE LocationID], RLOADSWT=OFF;
   ```

#### 参考信息

**自动建立基线数据**

容灾UPCF的DSU和DRU节点加载完后，会自动进行一致性校验，保证容灾UPCF数据与主用UPCF数据一致。一致性校验需要一定时间。请在容灾UPCF节点加载3天内不要进行容灾接管。

如果启动了Gx会话和Sd会话备份功能，可通过UPCF与USCDB间的审计来校验Gx会话数据和Sd会话数据。如果USCDB不存在Gx会话和Sd会话，则UPCF往USCDB中插入Gx会话数据和Sd会话数据。

自动基线数据建立的流程如图1所示。

* 由于建立基线数据是由BE完成的，所以图1中没有体现FE。
* 图1中上半部分表示DRU的基线数据建立流程，下半部分表示DSU的基线数据建立流程。
* 如果启动了Gx会话和Sd会话备份功能，主用BE和容灾BE通过部署UPCF-SESSION业务类型的DSG模块建立SCTP（Stream Control Transmission Protocol）连接，作为数据同步通道。Gx会话数据和Sd会话数据使用独立的DRU、DSU和DSG模块，不和用户数据共用DRU、DSU和DSG模块。

**图1** 基线数据建立的流程

1. 主用UPCF的DRU\DSU Master节点发起周期性校验，将校验消息发送给DSG（Data Service Gateway）。
2. 主用UPCF的DSG将消息转发给容灾UPCF的DSG。
3. 容灾UPCF的DSG根据消息中DRU\DSU的Cluster ID，将消息转给容灾UPCF相同Cluster ID的DRU\DSU Master节点。
4. 容灾UPCF的DRU\DSU Master节点将数据更新成功后，将数据复制给Slave节点。
5. 容灾UPCF的DRU\DSU Slave节点数据更新成功后，将响应消息返回给Master节点。
6. 容灾UPCF的DRU\DSU Master节点将响应消息返回给容灾UPCF的DSG。
7. 容灾UPCF的DSG将响应消息返回给主用UPCF的DSG。
8. 主用DSG将响应消息返回给主用UPCF的DRU\DSU Master节点。
9. 容灾UPCF的DSU Master节点更新成功后，生成路由消息发送至对应的DRU Master节点。
10. 容灾UPCF的DRU Master节点通过校验将路由数据更新成功后，将路由数据复制给Slave节点。
11. 容灾UPCF的DRU Slave节点路由数据更新成功后，将响应消息返回给Master节点。
12. 容灾UPCF的DRU Master节点将响应消息返回给对应的DSU Master节点。

从图1可知，DRU节点与DSU节点基线数据建立时数据信息及数据流方向一致，因此统一描述不分开说明。

版权所有 © 华为技术有限公司
