# 实例化CSP网元

* 操作场景
* 必备事项
* 操作步骤

## 操作场景

实例化网元是根据现网的网络具体情况，将前期上传的VNFD文件、镜像和业务软件包安装配置成网元的过程，网元完成实例化后，才可以正常工作。

部署UPCF网元时，需要先部署CSP子网元，待CSP部署完成后，继续部署USCDB和UPCF。

## 必备事项

前提条件

* 已上传VNFD文件和软件包。
* 当网元通过一键式部署功能配置VNF实例化时，CSP应为CSP 24.0.0及以上版本，PaaS应为NFV\_FusionStage 24.0.0及以上版本，LCM应为MAE-CN VNF-LCM V100R023C10SPC220及以上版本。

数据

在进行各子网元部署时，需要根据LLD的规划，在NFVO界面输入对应参数，如表1所示。

VNFD入参即根据LLD规划，主要包含了网元部署的区域（云服务、主机组等）、规划部署的VM、网络互通使用的逻辑网络等关键信息。

* 参数样例标注为“**黑色**”时，表示参数固定配置为样例取值，通常无需修改。
* 参数样例标注为“**红色**”时，表示参数配置源自运营商规划（多为外部网络地址、部署模式等）。
* 参数样例标注为“**蓝色**”时，表示参数配置依赖产品设计规划和LLD 网络设计（多为逻辑网络、内部私网地址段等），可以结合网设数据，进一步了解入参取值原则。

**表1** CSP输入参数

| 参数名 | 含义 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| Language | 安装版本的语言类型。 | **chinese** | 根据需要填写，可选择“chinese/english”。 |
| Cloud service:service VPC | * “Cloud service”为MANO上添加的部署CSP虚拟机所在FusionSphere OpenStack云服务的名称。 * “service VPC”为部署CSP虚拟机所使用的业务VPC的名称。 * “:”为云服务名称和业务VPC名称之间的分隔符。 | **dc1\_FS01\_Srv:Srv\_VPC\_CC** | * “Cloud service”参见：“NFV LLD” > **云管理设计** > “MAE-VNF LCM与FusionSphere对接数据规划”表 > 部署UPCF的域名所对应的“云服务名称”。 * “service VPC”参见： “NFV LLD” > **计算资源设计** > “VNF规划”表 > VPC名称。 |
| Region id | 隔离域ID。  非SDN场景可以不填写。 | **az1.dc1** | 在MAE-VNF LCM界面，选择“NFVI资源 > 云资源 > 网络”，查看云资源对接云服务的“区域”。 |
| VNF name | 物理网元名称。  说明：  该参数为长度不超过64位的字符串，仅支持包含ａ-z，A-Z，0-9，下划线(\_)，中划线(-)和点(.)，仅能以ａ-z和A-Z开头，不能以点(.)结尾，且不允许包含连续两个及以上的点(.)。 | **dc1imsomu** | 参见“NFV LLD” > **计算资源设计** > “PaaS Lite资源设计 ”表 > 在“VNF名称”列获取规划的CSP VNF名称。 |
| HA name | 网元虚拟机所在的主机组名称。 | **Service\_HA01** | 参见“NFV LLD” > **计算资源设计** > “DC配置规划”表 > Host Aggregate名称。  说明：  * 仅NFV\_FusionSphere 24.1.0.SPH35及之后版本ARM场景支持跨HA扩容扩展域虚拟机，或3节点跨HA扩容5节点场景。 * 扩容时此参数表示新增的虚拟机所在的主机组名称。 |
| Compute availability zone | 部署虚拟机对应的计算可用分区（计算AZ名称）。 | **az1.dc1** | 参见“NFV LLD” > **计算资源设计** > “DC配置规划”表 > 计算AZ名称。 |
| Storage availability zone | 部署虚拟机对应的存储可用分区（存储AZ名称）。 | **az1.dc1** | 参见“NFV LLD” > **存储资源设计** > 获取存储资源设计中的“存储AZ名称”。 |
| Disk type 1 | 部署网元虚拟机对应的磁盘类型。 | **VolumeService01**  **(仅填写一种磁盘类型)** | 参见“NFV LLD” > **存储资源设计** > “磁阵侧规划”表 > 根据“备注”列选择部署UPCF所对应的“磁盘类型”。  说明：  Disk type未规划时，禁止填写“\*”，请联系运营商进行规划或复用已规划的磁盘类型。 |
| Disk type 2 | 部署网元虚拟机对应的磁盘类型。 | **VolumeService02**  **(仅填写一种磁盘类型)** |  |
| Disk type 3 | 部署网元虚拟机对应的磁盘类型。 | **VolumeService03**  **(仅填写一种磁盘类型)** |  |
| Disk type 4,5 | 部署网元虚拟机对应的磁盘类型。  （该参数仅在部署5节点时显示。） | **VolumeService04,VolumeService05**  **(两种磁盘类型以','分隔轮询使用)** |  |
| PaaS Mng | PaaS Mng虚拟网络平面的逻辑网络名称。 | **app\_om\_plane** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“app\_om\_plane”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| OM | OM虚拟网络平面的逻辑网络名称。 | **S\_OM\_Network\_VM\_CSP01** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| Enable Update OM Virtual Ip | 用于控制是否强制修改OM浮动IP。 | **false**  说明：  该参数设置为“true”会导致用户配置数据丢失，且执行**SET OMIP**和**MOD VIRTUALIP**命令会返回失败，无法对系统OM IP进行修改。 | 本端规划，此处配置建议使用默认值。 |
| vBase | vBase虚拟网络平面的逻辑网络名称。 | **Inner\_Plane1\_Base01****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane1\_Base01”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| vFabric1 | vFabric1虚拟网络平面的逻辑网络名称。 | **Inner\_Plane2\_Fabric01****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane2\_Fabric01”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| vFabric2 | vFabric2虚拟网络平面的逻辑网络名称。 | **Inner\_Plane2\_Fabric02****\_CSP01** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“Inner\_Plane2\_Fabric02”的网络名称。  非SDN组网下，部署前需要提前在FusionSphere OpenStack OM前台上创建的网络，提供给网元使用。 |
| Network subnet enable dhcp | 用于控制OM虚拟网络平面的逻辑网络子网是否开启DHCP。 | **true** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > 根据“地址获取方式”列确认OM网络平面是否开启DHCP。 |
| PaaS Internal floating IP | PaaS虚拟机内部网络浮动IP地址。  说明：  PaaS Internal floating IP需要填写为PaaS的App\_Manage\_Plane网络平面浮动IP。 | * **IPV4样例：172.18.1.5** * **IPV6样例：fc00:0db8::2** | 参见“NFV LLD” > **I层IP对接设计** > “CloudOS IP设计 ”表 > >PaaS的App\_Manage\_Plane网络平面内部互通的浮动IP。 |
| SWR Registry address | 获取软件仓库镜像的域名或地址。   * IPV4场景为PaaS虚拟机内部网络浮动IP地址，与PaaS Internal floating IP参数取值相同。 * IPV6场景为FusionStage镜像仓库域名，可以从镜像仓库中查看某个镜像拉取地址获取，该参数填写为拉取地址中端口号前的域名信息。 例如，查看某个镜像的拉取地址为“registry.fusionstage.local:20202/csp/cspupgradetool:20.3.0”，则该参数填写为端口号20202前的域名“registry.fusionstage.local”。 | * **IPV4样例：172.18.1.5** * **IPV6样例：registry.fusionstage.local** | 参见FusionStage的“软件中心 > 软件仓库 > 镜像仓库”页签，单击“镜像名称”，在“拉取地址”获取。 |
| OM gateway IPV4 | OM网段IPV4地址的网关。  OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **192.168.1.254** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称对应“网关”及“IP地址段掩码”。 |
| CSP subnet mask IPV4 | OM网段IPV4地址的子网掩码。  OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **255.255.255.0** |  |
| CSP floating IPV4 | CSP虚拟机外部浮动IPV4地址。  OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **192.168.1.8** | 参见“NFV LLD” > **5G Core业务IP对接设计** > “逻辑网络”列中包含关键字“S\_OM\_Network”，“IP类型”为“Floating IP”的IP地址。 |
| CSP floating IPV6 | CSP虚拟机外部浮动IPV6地址。  OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写为NULL。 | **fc00:0db8::22** |  |
| OM gateway IPV6 | OM网络的IPV6地址的网关。  OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写为NULL。 | **fc00:0db8::23** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络名称对应“网关”及“IP地址段掩码”。 |
| CSP prefix length IPV6 | OM网络的IPV6地址的前缀长度。  OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写为NULL。 | **64** |  |
| Registering to CAAS user name | PAAS虚拟机镜像登录名。 | **paas** | 参见“NFV LLD” > **账号管理设计** > “NFVI账户管理”表获取PaaS登录类型为“PuTTY”所对应的“账户”与“密码”。  EulerOS的初始帐号密码。 |
| Registering to CAAS password | PAAS虚拟机镜像登录密码。 | **QAZ2wsx@123!** |  |
| CAAS ID | 对接的PAAS名，与同步的云服务名称保持一致。 | **FusionStage2.3** | 在MAE-VNF LCM“NFVI资源 > 云服务”查看对接的FusionStage名称。  或参见“NFV LLD” > **云管理设计** > “VNFM/MAE-CN与FusionStage告警对接数据规划”表 > 云服务名称。 |
| Tenant password | PAAS租户的密码。 | **Changeme\_123** | 参见“NFV LLD” > **云管理设计** > “VNFM/MAE-CN与FusionStage对接数据规划”表 > 获取“密码”。 |
| Project name | paas的项目名称。  说明：  Project name参数名称不能超过50个字符，只能包含ａ-z，0-9，中划线(-)。 | **csp** | 参见“NFV LLD” > 计算资源设计 > “PaaS Lite资源设计”表 > Project/Namespace名称。 |
| Node Max Num | paas项目的节点资源配额。  说明：  取值范围为：1-2000。 | **2000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“节点总数配额”。 |
| Pod Max Num | paas项目的Pod资源配额。  说明：  取值范围为：1-20000。 | **20000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“实例总数配额”。 |
| Node CPU Max Num(cores) | paas项目的CPU资源配额。  说明：  取值范围为：1-100000。 | **100000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 > 获取“动态节点CPU总量配额(核)”。 |
| Node Memory Max Num(GB) | paas项目的内存资源配额。  说明：  取值范围为：1-700000。 | **700000** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 >获取“动态节点内存总量配额(GB)”。 |
| Caas Region Name | 分权分域的区域名称。  说明：  此处指FusionStage的分权分域。 | **QWE** | 参见“NFV LLD” > **计算资源设计** > “Project设计”表 >获取“PaaS区域名称”。 |
| Network For Node | 对节点业务通信网段进行配置。  说明：  部署时需填写所有需要的网段，最多支持填写10个网段，多个网段填写格式为“网段1,网段2,网段3”。 | **fc00:0db9::/24,127.0.0.1/16** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 >获取“逻辑网络”列中包含关键字“app\_om\_plane01”的网络名称对应的“网络地址”和“子网掩码”，将网络地址和掩码长度进行拼接。 |
| Cert Private Key Password | Pod间通信证书私钥解密使用的密码。 | **Huawei12#$**  须知：  * 请谨慎填写确保密码填写正确。 * 安装阶段，若此密码填写错误，会导致安装任务运行失败，安装任务整体耗时50分钟左右；安装失败后需要先执行回退操作，然后填写正确的密码，重新创建部署任务。 | * 密码内容来源于“inner-comm-cert.yaml”文件中“privKeyPwd”对应的值。获取路径为：从软件包UPCF\_2\*.\*\*\*.\*\*\*.\*\*\*\_VNFD\_X86/ARM.zip中获取Secret文件（即inner-comm-cert.yaml文件）。 * 密码首次部署后不可更新。 |
| CSP pod PaaS Mng subnet | CSP PaaS Mng容器网络平面子网。  说明：  部署多套网元时，对于不同的Project name可以填写相同的CSP pod PaaS Mng subnet。 | * **IPV4样例：172.25.0.0/16** * **IPV6样例：fc00:0db8::113:1/88-123** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_Paas\_MNG”的网络名称所对应的IP网段。 |
| CSP pod vbase subnet | CSP vbase pod容器网络平面子网。  说明：  部署多套网元时，对于不同的Project name可以填写相同的CSP pod vbase subnet。 | * **IPV4样例：172.30.0.0/16** * **IPV6样例：fc00:0db8::113:5/88** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_vBase\_Plane1”的网络名称所对应的IP网段。 |
| CSP pod PaaS Mng subnet Extend | 容器网络扩容场景CSP PaaS Mng容器网络平面子网。 | - | * 该参数仅适用于容器网络扩容场景，初始部署场景必须保持默认值，即空值。 * 该参数配置的IP网段不能与该网元其他网络平面的IP网段互相包含或者重叠。 * 如果没有足够的剩余IP地址可规划，且FusionStage的版本为23.0.RC1及以上，则“CSP pod vbase subnet Extend”参数可复用其他VNF的Base容器网络地址空间。 |
| CSP pod vbase subnet Extend | 容器网络扩容场景CSP vbase pod容器网络平面子网。 | - |  |
| IP Version of pod | CSP vbase容器网络平面的IP版本。 | * **IPV4样例：4** * **IPV6样例：6** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_vBase\_Plane1”的网络名称所对应的IP Version。 |
| PaaS IP Version of pod | Paas管理面容器网络IP类型。 | * **IPV4样例：4** * **IPV6样例：6** | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“C\_Paas\_MNG”的网络名称所对应的IP Version。 |
| Feature type | 表示是否部署扩展域协议。 | **NULL** | 部署CSP时，如果部署扩展域，需要填写为“LI”，否则保持默认值。 |
| OM\_EX | 扩展域OM虚拟网络平面的逻辑网络名称。 | **S\_OM\_Network\_GL001** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”和“GL”的网络名称。 |
| OM gateway IPV4 Ex | 扩展域OM网段IPV4地址的网关。  扩展域OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **192.168.2.254** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的扩展域网络名称对应“网关”及“IP地址段掩码”。 |
| CSP subnet mask IPV4 Ex | 扩展域OM网段IPV4地址的子网掩码。  扩展域OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **255.255.255.0** |  |
| CSP floating IPV4 Ex | 扩展域OM浮动IPV4地址。  扩展域OM双栈或者OM IPV4单栈时填写。OM IPV6单栈时填写NULL。 | **192.168.2.8** | 参考“NFV LLD” > **5G Core业务IP对接设计** > “逻辑网络”列包含“S\_OM\_Network”，“IP类型”为“Floating IP”的扩展域IP地址。 |
| CSP floating IPV6 Ex | 扩展域OM浮动IPV6地址。  扩展域OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写NULL。 | **fc00:0db8::22** |  |
| OM gateway IPV6 Ex | 扩展域OM网络的IPV6网关。  扩展域OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写NULL。 | **fc00:0da8::23** | 参考“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的扩展域网络名称对应“网关”及“IP地址段掩码”。 |
| CSP prefix length IPV6 Ex | 扩展域OM网络的IPV6地址的前缀长度。  扩展域OM双栈或者OM IPV6单栈时填写。OM IPV4单栈时填写NULL。 | **64** |  |
| Initialize CSP OM\_ex Stack | 是否初始创建扩展堆栈。   * true：初始创建扩展堆栈 * false：初始不创建扩展堆栈。 | **false** | 本端规划。 |
| Initialize CSP OM\_ex VM Group | 是否初始创建扩展虚拟机组。   * 0：初始部署时不创建扩展虚拟机组 * 1：初始部署时创建扩展虚拟机组 | **0** | 本端规划。 |
| Storage Bypass Mode | 软件安装支持的存储Bypass模式。建议保持默认值（MemoryDiskMode ）。   * LocalDiskMode (本地磁盘存储Bypass模式) * MemoryDiskMode (内存存储Bypass模式) * None (非存储Bypass模式) | **MemoryDiskMode** | 本端规划。  其中“LocalDiskMode”枚举值为预留字段暂不支持。 |
| Resource Naming Rule | 用于标明网元的资源命名规则。 | **None** | 预留参数，根据需要填写，若无则建议保持空值。 |
| Resource Naming Prefix | 用于标明网元的资源命名的前缀。 | **None** | 预留参数，根据需要填写，若无则建议保持空值。 |
| Resource Category And Supplier | 用于标明网元的资源用途和所属厂商。 | **None** | 预留参数，根据需要填写，若无则建议保持空值。 |
| 4A Network | OM虚拟网络平面的逻辑网络名称，用于4A安全扫描。 | **OM\_Plane**  说明：  此项必填，且必须与OM参数保持一致，不能填写为NULL。 | 参见“NFV LLD” > **逻辑网络设计** > “UPCF逻辑网络设计 ”表 > “逻辑网络”列中包含关键字“S\_OM\_Network”的网络所对应的“逻辑网络”、“网络地址”、“子网掩码”、“IP起始”与“IP结束”。  当需要进行4A安全扫描时，  * OM单栈IPV4场景，需要输入“4A Network”、“CSP 4A Subnet IPV4 Cidr”、“CSP 4A subnet IPV4 Pools Start”和“CSP 4A subnet IPV4 Pools End”。且子网模式为DHCP时，地址池起始范围不能和浮动IP地址“CSP floating IPV4”冲突。 * OM单栈IPV6场景，需要输入“4A Network”、“CSP 4A subnet IPV6 Cidr”。 * OM双栈场景，参数均需要输入。 |
| CSP 4A Subnet IPV4 Cidr | OM网络IPV4地址的子网/掩码位，用于4A安全扫描。其中“掩码位”需要和“CSP subnet mask IPV4”对应。 | **192.168.1.0/24** |  |
| CSP 4A subnet IPV4 Pools Start | OM网络IPV4地址池的开始范围，用于4A安全扫描。 | **192.168.1.20** |  |
| CSP 4A subnet IPV4 Pools End | OM网络IPV4地址池的终止范围，用于4A安全扫描。 | **192.168.1.240** |  |
| CSP 4A subnet IPV6 Cidr | OM网络IPV6地址的子网/前缀长度，用于4A安全扫描。其中“前缀长度”需要和“CSP prefix length IPV6”对应。  OM IPV4单栈时填写NULL。 | **NULL** |  |
| Security Boot Enable | Guest OS启动校验开关。   * false：启动Guest OS前，不校验操作系统。 * true：启动Guest OS前，校验操作系统，避免被篡改。 | **false** | 本端规划。  开启该参数对系统性能有一定影响，具体影响程度需要根据话务模型和实施的业务特性进行评估。 |
| Optimal\_Deployment\_Switch | 最优化部署总开关。   * false：关闭。 * true：开启。 | **true** | 本端规划。  说明：  仅在轻量化核心网场景下显示该参数。 |
| Optimal Expansion | 是否允许最优部署VM和非最优部署的VM部署在同一个刀片。   * false：否。 * true：是。 | **true** |  |
| Disable\_4A\_Network | 用于控制是否禁用4A网络。 | **false** | 本端规划。 |
| EXTOM\_GW | 4A口网关的IP地址，双栈场景IPv4和IPv6通过逗号分隔。 | * **IPV4样例：172.18.1.5** * **IPV6样例：fc00:0db8::2** * **双栈样例：****172.18.1.6****,****fc00:0db8::6** | 参见“NFV LLD”文档 > **逻辑网络设计** > “UPCF逻辑网络设计 ”表。 |
| EXTOM\_NETMASK | 4A口子网掩码/前缀，双栈场景IPv4和IPv6通过逗号分隔。 | * **IPV4样例：255.255.255.0** * **IPV6样例：64** * **双栈样例：255.255.255.0,64** |  |
| VDU\_CPU\_NUM | 用于表示普通域虚机CPU核数。 | * **非x86\_7285CPU：8** * **x86\_7285CPU：16** | 本端规划。  说明：  仅x86模板显示该部分参数，部署后不支持修改。 |
| VDU\_CPU\_NUM\_EX | 用于表示扩展域虚机CPU核数。 | * **非x86\_7285CPU：4** * **x86\_7285CPU：8** |  |
| Deploy Mode | 用于表示部署模式。 | * **X86部署模式：**   + **同构场景：X86**   + **异构场景：X86-ARM** * **ARM部署模式：**   + **同构****场景****：ARM**   + **异构：X86-ARM** | 本端规划。  说明：  同构场景，使用iMaster MAE-CN V100R022C10SPC220+CP2202+HP2203之前的版本部署需要同时上传X86及ARM的软件包。 |
| Measured\_Boot\_Support | 用于表示是否创建支持度量启动的虚拟机。 | **false** | 本端规划。  开启度量启动对系统启动性能有一定影响。 |
| service pmscalc expand label | 控制话统指标计算能力的标签。 | **NA** | 请根据实际使用场景填写，若话统指标量较大，需部署4个PMSCalc服务实例，该参数填写“OM”；若话统指标量较小，可部署2个PMSCalc服务实例，该参数为默认值“NA”。如无法判断，请联系华为技术支持。  说明：  仅5节点模板显示该参数。 |
| service pmscalc instance num | 话统指标计算的实例数量。 | **2** | 请根据实际使用场景填写，若话统指标量较大，需部署4个PMSCalc服务实例，该参数填写4；若话统指标量较小，可部署2个PMSCalc服务实例，该参数为默认值2。如无法判断，请联系华为技术支持。  说明：  仅5节点模板显示该参数。 |

## 操作步骤

1. 在浏览器地址栏中输入地址“https://NFVO运维面的IP地址:31943”，登录NFVO客户端。

   登录用户为组织管理员或VNF运维人员或具有查询NFV Catalog和VNF管理操作权限的用户。
2. 在MAE主界面的“应用”区域，单击“Orchestrator”，进入“Orchestrator”界面。在主菜单中选择“NFVO > VNF管理 ”。
3. 在左侧导航栏中单击“VNF实例”。
4. 在“VNF实例”页面，点击“部署”，进入“创建VNF”页面。如图1所示。

   **图1** 部署页面入口
5. 根据模板规范选择部署方式。
   1. 当使用华为标准包部署时，请执行步骤6。
   2. 当使用中国区规范包部署时，请执行步骤7。
6. 华为标准包部署。
   1. 进入“创建VNF”页面后，自定义“任务名称”，选择“模板规范”为“华为”。
   2. 在“VNF设置”区域，单击“新增”，弹出“VNFD列表”对话框。勾选需要部署的VNFD，单击“确定”。
   3. 设置VNFD相关参数，可以通过选择“拷贝参数”复制该VNFD历史参数设置。

      **表2** 基本参数

      | 参数名称 | 参数说明 |
      | --- | --- |
      | VNF 名称 | 自定义VNF名称。 |
      | VPC | 选择已创建的VPC。 |
      | VNF 规划 | 部署Plan，可选择VNF包中已上线的部署Plan。 |
   4. 根据表1结合实际网络规划设置“扩展参数”。如图2所示

      也可以通过：单击“导入VNF扩展参数”，根据界面提示导入网设数据中获取的定制.yaml格式的VNF部署参数plan文件，导入VNF部署参数，导入成功后，覆盖界面已有参数。

      **图2** 华为规范部署场景参数
   5. 单击“下一步”，页面显示设置好的参数。
   6. 单击“确定”，开始创建VNF。系统跳转到“部署任务”页面，可以查看任务状态与日志。
7. 中国区规范包部署。
   1. 进入“创建VNF”页面后，自定义“任务名称”，选择“模板规范”为“中国区”。
   2. 在“VNF设置”区域，单击“新增”，弹出“VNFD列表”对话框。勾选需要部署的VNFD，单击“确定”。
   3. 设置VNFD相关参数，可以通过选择“拷贝参数”复制该VNFD历史参数设置。

      **表3** 基本参数

      | 参数名称 | 参数说明 |
      | --- | --- |
      | VNF 名称 | 自定义VNF名称。 |
      | VPC | 选择已创建的VPC。  当VPC关联VNFM实例的版本信息为v1时，请执行7-d。  当VPC关联VNFM实例的版本信息为v2/v3/v4时，请执行7-e。  说明：  * 在MAE主界面的“应用”区域，单击“Orchestrator”，进入“Orchestrator”界面。在主菜单中选择“系统 > 接入管理”，在“系统类型”页面，选择 C6 VNFM系统类型查看对接的“版本信息”。 * NFVO版本为V100R022C10SPC200之前版本界面与当前描述存在差异：“模板规范”为“中国区（V1）和中国区（V2/V3）”两种情况。   + “模板规范”为“中国区（V1）”时，请执行7-d。   + “模板规范”为“中国区（V2/V3）”时，请执行7-e。 |
      | VNF 规划 | 部署Plan，可选择VNF包中已上线的部署Plan。 |
   4. 当VPC关联VNFM实例的版本信息为v1时，同华为标准包部署场景步骤6-d-6-f。
   5. 当VPC关联VNFM实例的版本信息为v2/v3/v4时，单击“创建VNFR”，如图3所示。页面生成一条VNFR信息。在生成的VNFR信息行，在“操作”列的下拉菜单中选择“VNFR实例化”，对该VNFR进行实例化操作。

      **图3** 中国区部署场景参数  

      如果部署失败，进入“VNF管理”页面，单击展开“状态信息变更列表”，单击操作列的，查看日志信息。若日志信息为“查询FusionStage云服务project异常，请检查FusionStage租户是否正确”，说明项目不存在且不支持一键式部署。请手动创建项目，或升级CSP版本为CSP 24.0.0及以上；PaaS版本为NFV\_FusionStage 24.0.0及以上；LCM版本为MAE-CN VNF-LCM V100R023C10SPC220及以上来支持一键式部署功能。
8. 在左侧导航栏中点击“任务>部署任务”，查询部署任务的“进度”和“状态”，若“状态”为“成功”，则部署完成，如图4所示。

   **图4** 部署完成

版权所有 © 华为技术有限公司
