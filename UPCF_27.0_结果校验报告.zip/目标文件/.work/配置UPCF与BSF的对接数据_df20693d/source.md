# 配置UPCF与BSF的对接数据

* 操作场景
* 必备事项
* 操作步骤
* 验证方法

## 操作场景

UPCF需支持通过HTTP和Diameter接口与BSF（Binding Support Function）进行交互，接收并处理PCF的绑定信息注册/注销请求，绑定会话信息。

* 当UPCF通过Diameter接口与BSF对接时，BSF作为一个DRA网元功能实体，具体对接配置请参考配置UPCF与DRA的对接数据。
* 当UPCF通过HTTP接口与BSF直接对接时，BSF作为一个5G Core网元功能实体，具体对接配置请参考本章节。
* 当UPCF通过HTTP接口与BSF经SCP间接通信时，BSF作为一个5G Core网元功能实体，具体对接配置请参考配置UPCF与SCP的对接数据。

## 必备事项

前提条件

* 已完成软件安装。
* UPCF侧已完成基础数据配置。
* BSF侧已完成基础数据配置。
* 已经获得运营商规划的UPCF与BSF的对接IP地址。

数据

配置前规划的对接数据如表1所示。

**表1** 对接数据规划

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **ADD HLBDEVADDR** | DEVAID （设备地址标识） | 5 | 本端规划，取值范围内不允许重复。 |
|  | VPNNAME（VPN名称） | VPN\_SBA | 本端规划，该参数需要与VNRS的**ADD L3VPNINST**和**ADD VPNINSTAF**命令中“VPN实例名称”参数值保持一致。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，由运营商提供。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | IP （IPV4地址） | 10.100.100.181 | 全网规划，由运营商提供。 |
|  | HTTPSFUNC（HTTPS功能） | OFF | 本端规划，由运营商提供。 |
| **SET BSFCFG** | ID（ID） | 1 | 固定取值。 |
|  | SWITCH（Switch） | Support | 本端规划，支持BSF功能。 |
|  | IPV4ADDR（Ipv4Addr） | Support | 本端规划，支持IPv4终端地址。 |
|  | FQDN（Fqdn） | Support | 本端规划，支持N5接口功能。 |
| **ADD DISCCONDCFG** | NFTYPE（网元类型） | BSF | 对端网元类型，此处固定为**BSF**。 |
|  | BSFPARA（BSF参数） | IPV4ADDR-1&IPV4DNN-0&IPV4IPDOMAIN-1&IPV6PREFIX-0 | 全网规划，由运营商提供，可以同时存在多个参数取值。 |
| **ADD DISCNFPROFILE** | NFINSNAME（网元实例名称） | * bsf * bsf01 | 用于标识一个服务发现网元实例的名称，该参数全局唯一，可参考样例填写。 |
|  | NFINSID（网元实例标识） | * 6947a69a-f61b-4bc1-b9da-47c9c5d11111 * 6947a69a-f61b-4bc1-b9da-47c9c5d11112 | 本端规划，由运营商提供。 |
|  | NFTYPE（网元类型） | BSF | 对端网元类型，此处固定为**BSF**。 |
|  | NFPROFILE（网元实例信息） | * {\"nfServices\":[{\"serviceInstanceId\":\"5947a69a-f61b-4bc1-b9da-47c9c8690005\",\"serviceName\":\"nbsf-management\",\"scheme\":\"http\",\"ipEndPoints\":[{\"ipv4Address\":\"192.168.100.181\",\"transport\":\"TCP\",\"port\":41005}],\"nfServiceStatus\":\"REGISTERED\",\"versions\":[{\"apiVersionInUri\":\"v1\",\"apiFullVersion\":\"1.PreR15.1.0\"}]}],\"nfInstanceId\":\"6947a69a-f61b-4bc1-b9da-47c9c5d11111\",\"nfStatus\":\"REGISTERED\",\"nfType\":\"BSF\", \"ipv4Addresses\":[\"192.168.100.181\"], \"priority\":1} * {\"nfServices\":[{\"serviceInstanceId\":\"5947a69a-f61b-4bc1-b9da-47c9c8690006\",\"serviceName\":\"nbsf-management\",\"scheme\":\"http\",\"ipEndPoints\":[{\"ipv4Address\":\"192.168.100.182\",\"transport\":\"TCP\",\"port\":41006}],\"nfServiceStatus\":\"REGISTERED\",\"versions\":[{\"apiVersionInUri\":\"v1\",\"apiFullVersion\":\"1.PreR15.1.0\"}]}],\"nfInstanceId\":\"6947a69a-f61b-4bc1-b9da-47c9c5d11112\",\"nfStatus\":\"REGISTERED\",\"nfType\":\"BSF\", \"ipv4Addresses\":[\"192.168.100.182\"], \"priority\":2} | * ipv4Address配置为BSF的IP地址，port配置为BSF的端口。 * 存在多个对端时，需要添加多个**ADD DISCNFPROFILE**网元实例记录，并通过“priority”来标识对端优先级。 |

## 操作步骤

1. 登录“UPCF MML命令”界面。
2. 执行**LST HLBDEVADDR**命令，查询HLB服务配置的所有设备地址标识。

   ```
   LST HLBDEVADDR:;
   ```

   报文示例如下：

   ```
   %%LST HLBDEVADDR:;%%
   RETCODE = 0  操作成功

   操作结果如下
   ------------
   设备地址标识  =  2
        VPN名称  =  VPN1
         IP版本  =  IPV4
       IPV4地址  =  10.168.0.130
       IPV6地址  =  NULL
      HTTPS功能  =  ON
   证书应用场景  =  UPCF_HLB_Lcert
      TLS配置ID  =  1
           描述  =  HLB_IPV4
   (结果个数 = 1)

   ---    END
   ```
3. 执行**ADD HLBDEVADDR**命令增加HLB服务用于与BSF对接的本端IP地址。

   ```
   ADD HLBDEVADDR: DEVAID=5, VPNNAME="VPN_SBA", IPVER=IPV4, IP="10.100.100.181", HTTPSFUNC=OFF;
   ```
4. 执行**SET BSFCFG**命令，配置为支持BSF功能。

   ```
   SET BSFCFG: ID=1, SWITCH=Support, IPV4ADDR=Support, FQDN=Support;
   ```

   1. 该命令用于设置BSF开关状态以及指定支持BSF时需要上报的属性参数，示例未列出的具体属性参数请根据实际情况规划选择是否支持。
   2. 当BSF只备份语音DNN会话，请将软参VRM\_BSFONLYVOLTE设置为1；如果需要BSF同时备份数据和语音等其他DNN会话，请提前端到端确认系统容量、组网方案，并将软参VRM\_BSFONLYVOLTE设置为0。
5. 当PCF通过指定条件发现远端服务时，需要配置此命令，否则跳过。

   执行**ADD DISCCONDCFG**命令，增加发现BSF网元的条件信息。

   ```
   ADD DISCCONDCFG: NFTYPE=BSF, BSFPARA=IPV4ADDR-1&IPV4DNN-0&IPV4IPDOMAIN-1&IPV6PREFIX-0;
   ```
6. 当PCF采取静态方式发现远端服务时，需要配置此命令，否则跳过。

   执行**ADD DISCNFPROFILE**命令，增加发现BSF网元的实例信息。

   当对端配置了多个IP和端口时，需要对应配置多条**ADD DISCNFPROFILE**命令，添加对应的网元实例信息，并通过“priority”来控制对端的优先级。“priority”取值越小，对端优先级越高。例如，存在2个对端，“priority”分别取值为1和2时，对端为主备工作模式，UPCF只与“priority”为1的对端进行消息交互；“priority”取值相同时，对端为负荷分担工作模式，UPCF会轮选对端进行消息交互。

   ```
   ADD DISCNFPROFILE: NFINSNAME="bsf", NFINSID="6947a69a-f61b-4bc1-b9da-47c9c5d11111", NFTYPE=BSF, NFPROFILE="{\"nfServices\":[{\"serviceInstanceId\":\"5947a69a-f61b-4bc1-b9da-47c9c8690005\",\"serviceName\":\"nbsf-management\",\"scheme\":\"http\",\"ipEndPoints\":[{\"ipv4Address\":\"192.168.100.181\",\"transport\":\"TCP\",\"port\":41005}],\"nfServiceStatus\":\"REGISTERED\",\"versions\":[{\"apiVersionInUri\":\"v1\",\"apiFullVersion\":\"1.PreR15.1.0\"}]}],\"nfInstanceId\":\"6947a69a-f61b-4bc1-b9da-47c9c5d11111\",\"nfStatus\":\"REGISTERED\",\"nfType\":\"BSF\", \"ipv4Addresses\":[\"192.168.100.181\"], \"priority\":1}";

   ADD DISCNFPROFILE: NFINSNAME="bsf01", NFINSID="6947a69a-f61b-4bc1-b9da-47c9c5d11112", NFTYPE=BSF, NFPROFILE="{\"nfServices\":[{\"serviceInstanceId\":\"5947a69a-f61b-4bc1-b9da-47c9c8690006\",\"serviceName\":\"nbsf-management\",\"scheme\":\"http\",\"ipEndPoints\":[{\"ipv4Address\":\"192.168.100.182\",\"transport\":\"TCP\",\"port\":41006}],\"nfServiceStatus\":\"REGISTERED\",\"versions\":[{\"apiVersionInUri\":\"v1\",\"apiFullVersion\":\"1.PreR15.1.0\"}]}],\"nfInstanceId\":\"6947a69a-f61b-4bc1-b9da-47c9c5d11112\",\"nfStatus\":\"REGISTERED\",\"nfType\":\"BSF\", \"ipv4Addresses\":[\"192.168.100.182\"], \"priority\":2}";
   ```

## 验证方法

检查UPCF-BSF链路。

1. 对接配置完成后，触发UPCF-BSF之间业务流程。
2. 登录“UPCF MML命令”界面。
3. 执行**DSP HLBHTTPCLINK**命令，“NF类型”参数为“BSF”，“对端标识”输入正确的取值，检查“状态”参数项的返回结果。

   * 在线 => UPCF-BSF链路正常，UPCF-BSF设备对接调测结束。
   * 离线 => 4
4. 登录OM Portal界面，选择“监控分析 > 告警管理”，查看系统是否有上报“34163 PCF与NF之间的HTTP链路故障”告警。
   * 是 => 根据告警帮助进行处理。
   * 否 => 5
5. 请联系华为技术支持处理。

版权所有 © 华为技术有限公司
