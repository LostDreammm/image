---
id: ''
name: WHFD-940040 多业务APN特性配置
ne_type: UPCF
type: feature
description: 多业务APN特性需要PCEF（Policy and Charging Enforcement Function）、UPCF和Provisioning System配合完成。为用户开通多业务APN业务，需要在UPCF上配置该业务，并为用户订购此业务。  场景举例：  * 用户通过一个APN1既能访问因特网，又能访问企业网。 * 用户通过Provisioning System切换业务。 * 因特网业务和企业网业务对应的预定义规则不同。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-940040 多业务APN","WHFD-940040 多业务APN特性配置"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
多业务APN特性需要PCEF（Policy and Charging Enforcement Function）、UPCF和Provisioning System配合完成。为用户开通多业务APN业务，需要在UPCF上配置该业务，并为用户订购此业务。场景举例：* 用户通过一个APN1既能访问因特网，又能访问企业网。* 用户通过Provisioning System切换业务。* 因特网业务和企业网业务对应的预定义规则不同。

## 必备事项
前提条件

* PCEF网元支持多业务APN功能。
* UPCF网元与PCEF、Provisioning System间的链路正常。
* 操作员已了解WHFD-940040 多业务APN特性描述。
* 操作员已登录UPCF WebUI界面。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    mod_pcefabiitem_list:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pcefabiitem_list_1:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - mod_pcefabiitem_list:
    - ABILITYDICTID: 67
      ABILITYITEMID: R8QoS
      ABLITYVALUE: UnsupportedR8QoS
    mod_pcefabiitem_list_1:
    - ABILITYDICTID: 67
      ABILITYITEMID: MultipleServiceAPN
      ABLITYVALUE: SupportedMultipleServiceAPN
    add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: '12345678901'
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: MBB
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: SP1
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 修改对端PCEF能力字典项。

#### 1.1 登录“UPCF MML命令”界面。

#### 1.2 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其不支持R8标准的QoS。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”需设置为“67”。实际的值可以通过如下方式查询：

#### 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。

#### 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。

#### 1.3 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持多业务APN特性。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list_1 -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 2 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 需要配置一个条件组，用于保证用户仅接入一个APN地址。条件组的数据规划如表2所示，详细参数说明请参见条件组参数表。

### **表2** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组 | 基本信息 | 名称 | CG\_1 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_APN1 |

### |  |  | 对象属性 | * 对象：IPSession * 属性：CalledStationID |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | APN1 |

### 3 配置动作组。

### 导航入口为“策略管理 > 策略 > 动作组”。

### 多业务APN业务，必须配置动作“IndicateServiceName”。

### 需要配置两个动作组，用于在用户访问因特网或企业网时动作的下发。动作组的数据规划如表3所示，详细参数说明请参见动作组参数表。

### **表3** 动作组

### | 类别 | 参数 |  |  | 取值样例 |

### | --- | --- | --- | --- | --- |

### | 动作组1 | 基本信息 | 名称 |  | AG\_1 |

### |  | 动作 | 动作 |  | IndicateServiceName |

### |  |  | 动作元素 | ServiceName | Internet01  说明：  此参数需和PCEF协商一致。 |

### | 动作组2 | 基本信息 | 名称 |  | AG\_2 |

### |  | 动作 | 动作 |  | IndicateServiceName |

### |  |  | 动作元素 | ServiceName | Intranet02  说明：  此参数需和PCEF协商一致。 |

### 4 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 规则的数据规划如表4所示，详细参数说明请参见规则参数表。

### **表4** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | Rule\_1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined |

### |  |  | 预定义名 | MULTI\_SERVICE\_APN\_SP1  说明：  已在PCEF侧定义。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_1  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_1  说明：  已在动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | Rule\_2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined |

### |  |  | 预定义名 | MULTI\_SERVICE\_APN\_SP2  说明：  已在PCEF侧定义。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_1  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_2  说明：  已在动作组中定义。 |

### 5 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表5所示，详细参数说明请参见策略参数表。

### **表5** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略1 | 基本信息 | 名称 | SP1\_Establish |

### |  | 触发器 | 名称 | IPCANSessionEstablish |

### |  | 规则 | 名称 | Rule\_1  说明：  已在规则中定义。 |

### | 策略2 | 基本信息 | 名称 | SP2\_Establish |

### |  | 触发器 | 名称 | IPCANSessionEstablish |

### |  | 规则 | 名称 | Rule\_2  说明：  已在规则中定义。 |

### 6 配置“多业务APN”的业务：因特网业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 因特网业务的数据规划如表6所示，详细参数说明请参见业务参数表。

### **表6** 业务1

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | SP1 |

### |  |  | 类型 | MULTI\_SERVICE\_APN |

### |  |  | 显示名称 | Internet\_Control |

### |  |  | 默认激活 | 是 |

### |  |  | 是否允许PA调整 | 是 |

### |  |  | 服务链接 | http://example1.com |

### |  |  | 是否鉴权 | 否 |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  | 策略 | 名称 | SP1\_Establish  说明：  已在策略中定义。 |

### 7 配置“多业务APN”的业务：企业网业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 企业网业务的数据规划如表7所示，详细参数说明请参见业务参数表。

### **表7** 业务2

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | SP2 |

### |  |  | 类型 | MULTI\_SERVICE\_APN |

### |  |  | 显示名称 | Intranet\_Control |

### |  |  | 默认激活 | 否 |

### |  |  | 是否允许PA调整 | 是 |

### |  |  | 服务链接 | http://example2.com |

### |  |  | 是否鉴权 | 否 |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  | 策略 | 名称 | SP2\_Establish  说明：  已在策略中定义。 |

### 8 登录“UPCF 业务管理”窗口。

### 9 发放业务。

#### 9.1 执行**ADD PSUB**增加一个用户。

#### “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=9.1 -->
```

#### 9.2 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=9.2 -->
```

