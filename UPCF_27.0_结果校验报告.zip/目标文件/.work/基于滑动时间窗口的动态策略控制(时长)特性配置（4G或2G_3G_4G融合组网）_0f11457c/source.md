# 基于滑动时间窗口的动态策略控制(时长)特性配置（4G或2G/3G/4G融合组网）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

移动宽带业务日益丰富，部分业务会占有大量网络资源，用户长时间使用这类业务对网络影响较大。运营商可根据过去一段时间使用某业务的时长，及时调整策略，以减少对网络的冲击。

以一个签约2 Mbit/s数据业务的用户为例，且此场景UPCF对接华为UGW9811：

* 如果在过去的连续3天内，每天使用网络资源超过9小时，则带宽降低为64 kbit/s；否则带宽保持2 Mbit/s不变。
* 带宽降低为64 kbit/s之后，后续如果连续3天内，每天使用网络资源都低于6小时，则带宽恢复为2 Mbit/s。
* 配置动态规则。

#### 对系统的影响

窗口类型为周期型时，系统需要记录用户历史周期的使用时长，系统存储容量会下降。平均每用户多存储一条历史记录，系统存储容量下降1.5%。

#### 必备事项

**前提条件**

操作员已了解WHFD-611021 基于滑动时间窗口的动态策略控制(时长)特性概述。

**数据**

根据应用场景，参考业务拆解总体原则，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 用户业务Service | 此用户业务包括：一个业务（Accum\_Service）和一个累计项（Accum\_Accumulation）。 | - |
| 业务Accum\_Service | 此业务包括：策略Policy\_Using和配额Accum\_Quota。 | * 策略Policy\_Using：用户上线和在流量消耗的过程中使用，触发器分别为IPCANSessionEstablish和UsageReport。涉及累计项的相关策略只能使用触发器UsageReport，而不能使用触发器UsageStatusChange和AccountStatusChange。 * 配额Accum\_Quota:由于累计项进行累计的触发点是配额上报，有配额分片的下发才会进行配额上报，因此使用累计项的业务必须配置Quota，且它必须被累计项关联。 |
| 累计项Accum\_Accumulation | 配置累计项的基本信息、检测信息和关联配额。   * 基本信息   + 累计类别：时长   + 累计类型：周期累计   + 复位周期类型：天 * 检测信息   + 窗口长度：3   + 滑动步长：1   + 检测类型：周期使用量   + 检测周期长度：3   + 高耗额门限使用量（秒）：32400   + 恢复门限使用量（秒）：21600 * 关联配额：配额类型必须为“时长”。 | 如图1和图3所示：   * 此场景累计每天用户消耗的时长，所以“累计类型”为“周期累计”，“复位周期类型”为“天”。 * 此场景以连续3天为一个单位进行策略调整，所以“窗口长度”为“3”。 * 相邻窗口之间的周期个数即“滑动步长”。 * 此场景只检查“每天的使用量”是否超过高耗额或低于恢复额，表示“检测类型”为“周期使用量”。要求每天的使用量都高于高耗额，且窗口长度是3，表示“检测周期长度”也是“3”。 * 关联配额的“配额类型”必须与累计项的“累计类别”一致。 * 1个累计项最多关联6个配额。 * 对应相同“监控键值”的配额，只能选择关联一个；针对没有配置“监控键值”的配额，认为是相同的。 |
| 配额Accum\_Quota | 配置用户的配额类型、配额值、复位时间及阈值等。 | - |
| 策略Policy\_Using | 此策略在用户上线和时长消耗的过程中被调用，触发器分别为IPCANSessionEstablish和UsageReport，包含所有规则。 | * 不论是上线还是时长消耗，涉及的条件有2个：   + 连续3天内，每天使用网络资源超过9小时。即CG\_Change。   + 连续3天内，每天使用网络资源都低于6小时。即CG\_Restore。 因此，条件组一共有2个。 * 根据业务规划，条件组和动作组进行组合，产生2个规则：   + 连续3天内，每天使用网络资源超过9小时，则带宽降低为64 kbit/s。即Rule\_Change。   + 连续3天内，每天使用网络资源都低于6小时，则带宽恢复为2 Mbit/s。即Rule\_Restore。 |
| 规则Rule1\_Change1 | * 条件：累计项状态为HeavyLevel。 * 动作：DefaultBearerQoS（QCI=8，ARP=1）。 | 建立默认承载时，必须配置动作DefaultBearerQoS，从而下发QoS。 |
| 规则Rule1\_Restore1 | * 条件：累计项状态为LightLevel。 * 动作：DefaultBearerQoS（QCI=8，ARP=1）。 |  |
| 规则Rule2\_Change2 | * 条件：累计项状态为HeavyLevel。 * 动作QoSAction：QCI为8，ARP为1，上下行带宽为64 kbit/s。  ChargingAction：“RatingGroup”为1（1代表不计费）。  UsageReport：“MonitorKey”与配额中的“监控键值”相等。 | * 当连续3天内，每天使用网络资源超过9小时，该累计项的状态变为HeavyLevel。 * 当连续3天内，每天使用网络资源都低于6小时，该累计项的状态变为LightLevel。 * “RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。 * 当配额类型为“会话级”或“业务级”，且UPCF和对端PCEF遵循3GPP R9协议定义的FUP上报模式时，UPCF侧需要配置UsageReport动作。 * 业务流：本场景不区分各业务的数据流，统一只根据会话时长控制带宽，所以对规则中上下行业务流均取默认值“Any IP Protocol”。 |
| 规则Rule2\_Restore2 | * 条件：累计项状态为LightLevel。 * 动作QoSAction：QCI为8，ARP为1，上下行带宽为2 Mbit/s。  ChargingAction：“RatingGroup”为1（1代表不计费）。  UsageReport：“MonitorKey”与配额中的“监控键值”相等。 |  |

#### 操作流程

此特性的配置流程图如图2所示：

**图2** 累计项业务配置流程图

#### 操作步骤

1. 配置软参。
   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD INSP**命令，修改软参UPM\_ACCRARTIMEOUT的取值。

      当需要配置的用户累计项的“累计类型”为“会话累计”，且需要修改UPCF等待PCEF上报当前使用量的时长（默认值：10秒）时，执行此步骤，否则，请跳过此步骤。

      命令举例：

      ```
      MOD INSP: INSPN=UPM_ACCRARTIMEOUT, INSPV=30;
      ```
2. 修改对端PCEF能力字典项。
   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持R8标准的QoS。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=68, ABILITYITEMID=R8QoS, ABLITYVALUE=SupportedR8QoS;
      ```

      在4G或2G/3G/4G融合组网中，UPCF与华为UGW9811对接时，“ABILITYDICTID”需设置为“68”。实际的值可以通过如下方式查询：
      * 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。
      * 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
   3. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持基于3GPP R9标准的Usage Monitoring机制。

      当配置的FUP业务需使用3GPP R9标准的Usage Monitoring机制时，才需配置“UsageMonitor3GPPR9”的能力，否则，略过此步骤。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=68, ABILITYITEMID=UsageMonitor, ABLITYVALUE=UsageMonitor3GPPR9;	
      ```
   4. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，设置Monitor Key以哪种字节长度处理。

      Monitor Key的长度处理方式有如下三种：
      * FourBytesHex：MonitorKey按照十六进制4字节处理。
      * MaxFourBytesHex：MonitorKey按照十六进制最大4字节处理。
      * ASCIIMode：MonitorKey按照ASCII码处理。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=68, ABILITYITEMID=MonitorKeyCodecModeForR9, ABLITYVALUE=ASCIIMode;	
      ```
3. 登录UPCF Web UI界面。
4. 配置配额。

   导航入口为“业务管理 > 业务 > 配额”。

   配额的“配额类型”必须与其被关联的累计项的“累计类别”一致。

   配额的数据规划如表2所示，详细参数说明请参见配额参数表。

   **表2** 配额

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 配额 | 基本信息 | 名称 | Accum\_Quota |
   |  |  | 配额管理归属 | UPCC |
   |  |  | 配额类型 | 时长 |
   |  |  | 类型 | 会话级 |
   |  |  | 监控键值 | 101 |
   |  |  | 值(秒) | 216000 |
   |  |  | 分片类型 | 百分比 |
   |  |  | 分片(%) | 10 |
   |  | 复位设置 | 结帐模式 | 自然日历 |
   |  |  | 复位周期类型 | 月 |
   |  |  | 复位日期 | 1 |
   |  |  | 复位时间 | 01:00:00 |
   |  |  | 剩余额处理方式 | 清零 |
5. 配置累计项。

   导航入口为“业务管理 > 业务 > 累计项”。

   * 累计项是指一段时间内用户消耗累计的流量配额或时间配额。
   * UPCF可以通过定时检测历史累计项，来不断调整用户累计状态，从而根据累计状态的改变情况动态调整策略的下发。
     + 当连续3天内，每天使用网络资源超过9小时，该累计项的状态变为HeavyLevel。
     + 当连续3天内，每天使用网络资源都低于6小时，该累计项的状态变为LightLevel。
   * 在配置滑动窗口业务时，必须配置累计项。
   * “检测周期长度”只对累计状态从LightLevel变为HeavyLevel的过程有效。

   累计项的数据规划如表3所示，详细参数说明请参见累计项参数表。

   **表3** 累计项

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 累计项 | 基本信息 | 名称 | Accum\_Accumulation |
   |  |  | 累计类别 | 时长 |
   |  |  | 累计类型 | 周期累计 |
   |  | 累计周期 | 周期模式 | 自然日历 |
   |  |  | 复位周期类型 | 天 |
   |  |  | 复位时间 | 01:00:00 |
   |  | 检测信息 | 窗口长度 | 3 |
   |  |  | 滑动步长 | 1 |
   |  |  | 检测类型 | 周期使用量 |
   |  | 高耗额门限 | 检测周期长度 | 3 |
   |  |  | 使用量（秒） | 32400 |
   |  | 恢复门限 | 使用量（秒） | 21600 |
   |  | 配额 | 名称 | Accum\_Quota  说明：  已在配额中定义。 |
6. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置两个条件组，用于判断累计项状态为HeavyLevel或LightLevel。条件组的数据规划如表4所示，详细参数说明请参见条件组参数表。

   **表4** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_Change |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | Condition\_Change |
   |  |  | 对象属性 | * 对象：Accumulation * 属性：AccumulationStatus |
   |  |  | 对象实例 | Accum\_Accumulation  说明：  已在累计项中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | HeavyLevel  说明：  “HeavyLevel”：表示累计项检测使用量达到高耗额门限值。 |
   | 条件组2 | 基本信息 | 名称 | CG\_Restore |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | Condition\_Restore |
   |  |  | 对象属性 | * 对象：Accumulation * 属性：AccumulationStatus |
   |  |  | 对象实例 | Accum\_Accumulation  说明：  已在累计项中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | LightLevel  说明：  “LightLevel”：表示累计项检测使用量低于恢复门限值。 |
7. 配置动作组。

   导航入口为“策略管理 > 策略 > 动作组”。

   * 若配置的规则为动态规则，则必须配置动作组。
   * 此场景配置动态规则且需要考虑默认承载的QoS、调整带宽、计费动作和流量上报，则每个动作组需配置动作：DefaultBearerQoS、QoSAction、ChargingAction和UsageReport。相关应用场景如下：

     + DefaultBearerQoS：当需要建立默认承载时必须配置此动作。
     + QoSAction：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制QoS。
     + ChargingAction：当需要做计费策略控制时，配置此动作（若对端为华为UGW9811，此动作必须配置）。其中属性“RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。
     + UsageReport：当需要进行流量上报时，配置此动作。

   需要配置四个动作组，用于在累计项状态为HeavyLevel或LightLevel动作的下发。动作组的数据规划如表5所示，详细参数说明请参见动作组参数表。

   **表5** 动作组

   | 类别 | 参数 |  |  | 取值样例 |
   | --- | --- | --- | --- | --- |
   | 动作组1 | 基本信息 | 名称 |  | AG1\_Change1 |
   |  | 动作 | 动作 |  | DefaultBearerQoS |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  |  |  | PreemptionCapability | * 值类型：Value * 值：Disabled |
   |  |  |  | PreemptionVulnerability | * 值类型：Value * 值：Enabled |
   |  |  |  | AMBRDL | * 值类型：Value * 值(kbit/s)：64 |
   |  |  |  | AMBRUL | * 值类型：Value * 值(kbit/s)：64 |
   | 动作组2 | 基本信息 | 名称 |  | AG1\_Restore1 |
   |  | 动作 | 动作 |  | DefaultBearerQoS |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  |  |  | PreemptionCapability | * 值类型：Value * 值：Disabled |
   |  |  |  | PreemptionVulnerability | * 值类型：Value * 值：Enabled |
   |  |  |  | AMBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | AMBRUL | * 值类型：Value * 值(kbit/s)：2000 |
   | 动作组3 | 基本信息 | 名称 |  | AG2\_Change2 |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：64 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：64 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：64 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：64 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Duration |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示按月计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   |  | 动作3 | 动作 |  | UsageReport |
   |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |
   | 动作组4 | 基本信息 | 名称 |  | AG2\_Restore2 |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Duration |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示按月计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   |  | 动作3 | 动作 |  | UsageReport |
   |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |
8. 配置业务流。

   导航入口为“策略管理 > 策略 > 业务流”。

   当对端为华为UGW9811时，所有的动态规则都必须配置业务流。

   业务流的数据规划如表6所示，详细参数说明请参见业务流参数表。

   **表6** 业务流

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务流 | 基本信息 | 名称 | Flow\_Filter |
   |  | 流过滤器1 | 名称 | up\_pass |
   |  |  | 流方向 | Up |
   |  |  | 协议 | Any IP Protocol |
   |  | 流过滤器2 | 名称 | down\_pass |
   |  |  | 流方向 | Down |
   |  |  | 协议 | Any IP Protocol |
9. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   规则的数据规划如表7所示，详细参数说明请参见规则参数表。

   **表7** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | Rule1\_Change1 |
   |  |  | 类型 | Default Bearer QoS  说明：  默认承载QoS场景，规则类型必须为“Default Bearer QoS”。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Change  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG1\_Change1  说明：  已在动作组中定义。 |
   | 规则2 | 基本信息 | 名称 | Rule1\_Restore1 |
   |  |  | 类型 | Default Bearer QoS  说明：  默认承载QoS场景，规则类型必须为“Default Bearer QoS”。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Restore  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG1\_Restore1  说明：  已在动作组中定义。 |
   | 规则3 | 基本信息 | 名称 | Rule2\_Change2 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Change  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG2\_Change2  说明：  已在动作组中定义。 |
   | 规则4 | 基本信息 | 名称 | Rule2\_Restore2 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Restore  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG2\_Restore2  说明：  已在动作组中定义。 |
10. 配置策略。

    导航入口为“策略管理 > 策略 > 策略”。

    策略的数据规划如表8所示，详细参数说明请参见策略参数表。

    **表8** 策略

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 策略 | 基本信息 | 名称 | Policy\_Using |
    |  | 触发器 | 名称 | IPCANSessionEstablish  UsageReport |
    |  | 规则 | 名称 | * Rule1\_Change1 * Rule1\_Restore1 * Rule2\_Change2 * Rule2\_Restore2 说明：  已在规则中定义。 |
11. 配置业务。

    导航入口为“业务管理 > 业务 > 业务”。

    业务的数据规划如表9所示，详细参数说明请参见业务参数表。

    **表9** 业务

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 业务 | 基本信息 | 名称 | Accum\_Service |
    |  |  | 类型 | BASIC\_SERVICE |
    |  |  | 是否记入基本配额 | 是 |
    |  |  | 激活方式 | PCEF |
    |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
    |  |  | QoS模式 | 替换 |
    |  |  | 签约后才能使用 | 是 |
    |  | 策略 | 名称 | Policy\_Using  说明：  已在策略中定义。 |
    |  | 配额 | 名称 | Accum\_Quota  说明：  已在配额中定义。 |
12. 登录“UPCF 业务管理”窗口。
13. 发放业务。
    1. 执行**ADD PSUB**增加一个用户。

       “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

       ```
       ADD PSUB:USRIDENTIFIER="46010381012****", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB;
       ```
    2. 执行**ADD PSRV**给用户签约业务。

       ```
       ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="Accum_Service", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
       ```
14. 执行**ADD PACCUM**签约累计项。

    ```
    ADD PACCUM: USRIDENTIFIER="46010381012****", ACCNAME="Accum_Accumulation";
    ```

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
