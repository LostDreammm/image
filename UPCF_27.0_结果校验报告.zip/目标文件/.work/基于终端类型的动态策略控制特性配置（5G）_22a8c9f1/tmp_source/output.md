---
id: ''
name: 基于终端类型的动态策略控制特性配置（5G）
ne_type: UPCF
type: feature
description: 运营商可以在UPCF中定义不同的终端类型，通过终端类型来区分用户，根据不同终端类型下发不同的策略。基于终端类型的动态策略控制主要包含如下应用场景：\n\n* 智能机和非智能机：分配不同的网络带宽。\n* 不同操作系统的手机，如操作系统1和操作系统2：分配不同的网络带宽。\n* 手机、上网卡、POS机等不同类型终端：定义不同的通知方式，比如流量耗尽时，给手机用户发短信通知，给上网卡用户发email通知，给POS机用户的手机发送短信通知。\n* 区分特殊身份的手机，比如运营商合约机：给合约机以高带宽保障，限制合约机使用某类业务。\n\n这几种应用场景的主要配置差异是定义不同的名称和IMEI值，所以本节以第一种场景，运营商向使用UE1终端用户提供高QoS带宽服务，向UE2终端用户提供普通QoS带宽，且UPCF对接华为UNC为例来介绍配置过程。\n\n* UE1终端，最大上、下行带宽为100 Mbps。\n* UE2终端，最大上、下行带宽为20 Mbps。\n* 配置动态规则。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611005 基于终端类型的动态策略控制","WHFD-611005 基于终端类型的动态策略控制特性配置","基于终端类型的动态策略控制特性配置（5G）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
运营商可以在UPCF中定义不同的终端类型，通过终端类型来区分用户，根据不同终端类型下发不同的策略。基于终端类型的动态策略控制主要包含如下应用场景：\n\n* 智能机和非智能机：分配不同的网络带宽。\n* 不同操作系统的手机，如操作系统1和操作系统2：分配不同的网络带宽。\n* 手机、上网卡、POS机等不同类型终端：定义不同的通知方式，比如流量耗尽时，给手机用户发短信通知，给上网卡用户发email通知，给POS机用户的手机发送短信通知。\n* 区分特殊身份的手机，比如运营商合约机：给合约机以高带宽保障，限制合约机使用某类业务。\n\n这几种应用场景的主要配置差异是定义不同的名称和IMEI值，所以本节以第一种场景，运营商向使用UE1终端用户提供高QoS带宽服务，向UE2终端用户提供普通QoS带宽，且UPCF对接华为UNC为例来介绍配置过程。\n\n* UE1终端，最大上、下行带宽为100 Mbps。\n* UE2终端，最大上、下行带宽为20 Mbps。\n* 配置动态规则。

## 必备事项
前提条件

操作员已了解WHFD-611005 基于终端类型的动态策略控制特性概述，且通过4G/5G业务配置差异介绍已经了解5G规则配置原理。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: 1234567****
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: eMBB-SA
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: 5GTerminal_Service
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录UPCF WebUI界面。

### 2 配置终端类型。

### 导航入口为“系统配置管理 > 终端类型 > 终端类型”。

#### 2.1 一个终端类型可以添加一个或多个IMEI前缀或IMEI区间。

#### 2.2 当条件的“对象属性”选用对象“SmfSession”下的“Pei”属性时，可以不用配置终端类型，直接通过IMEI前缀找到对应的终端。只是这种方法需要配置多个条件，从而对单个的IMEI终端进行策略控制。

#### 2.3 当需要增量导入或批量修改终端类型数据时，可通过配置UPCF与FTP/SFTP服务器的对接数据（批量导入）进行批量导入。

#### 2.4 支持IMEI标识的区间匹配。

### 终端类型数据规划如表2所示，详细参数说明请参见终端类型参数表。

### **表2** 终端类型

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 终端类型 | 基本信息 | 类型名称 | UE1 |

### |  | 终端 | IMEI前缀 | 35503701  说明：  实际终端的IMEI前缀。 |

### |  |  | 终端名称 | UE5G |

### 3 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

#### 3.1 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

#### 3.2 根据用户上线时使用的终端类型做策略控制：条件选择对象SmfSession下的属性TerminalType。

### 配置条件组1和条件组2用于判断终端类型为UE1或UE2。条件组的数据规划如表3所示，详细参数说明请参见条件组参数表。

### **表3** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | CG\_UE1 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | Condition\_UE1 |

### |  |  | 对象属性 | * 对象：SmfSession * 属性：TerminalType |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | UE1 |

### | 条件组2 | 基本信息 | 名称 | CG\_UE2 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | Condition\_UE2 |

### |  |  | 对象属性 | * 对象：SmfSession * 属性：TerminalType |

### |  |  | 操作符 | Not Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | UE1 |

### 4 配置5G动作组。

### 导航入口为“策略管理 > 策略 > 5G动作组”。

#### 4.1 若配置的规则为动态规则，则必须配置动作组。

#### 4.2 此场景配置动态规则且需要考虑缺省QoS Flow和调整带宽，则需配置动作：Arp、Ambr、DefaultQosInformation、SessionRuleAction、FlowDescription、FlowInformation、QoSData、DynamicPccRule。相关应用场景如下：

##### 4.2.1 SessionRuleAction：当需要建立缺省QoS Flow时可以配置此动作。

##### 4.2.2 QoSData：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制QoS。

### 请增加如下动作组和动作：

#### 4.3 动作组AG\_Session\_01：动作Arp、Ambr、DefaultQosInformation、SessionRuleAction

#### 4.4 动作组AG\_Session\_02：动作Arp、Ambr、DefaultQosInformation、SessionRuleAction

#### 4.5 动作组AG\_Dynamic\_01：动作Arp、FlowDescription、FlowInformation、QoSData、DynamicPccRule

#### 4.6 动作组AG\_Dynamic\_02：动作Arp、FlowDescription、FlowInformation、QoSData、DynamicPccRule

### 配置动作组用于终端类型为UE1或UE2动作的下发。动作组的数据规划如表4所示，详细参数说明请参见5G动作参数表。

### **表4** 5G动作组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 5G动作组1 | 基本信息 | 名称 | AG\_Arp |

### |  |  | 类型 | Arp |

### |  | 属性 | priorityLevel | * 类型：Value * 值：1 |

### |  |  | preemptCap | * 类型：Value * 值：NOT\_PREEMPT |

### |  |  | preemptVuln | * 类型：Value * 值：NOT\_PREEMPTABLE |

### | 5G动作组2 | 基本信息 | 名称 | AG\_Ambr\_01 |

### |  |  | 类型 | Ambr |

### |  | 属性 | uplink | * 类型：Value * 值：100000000 bps |

### |  |  | downlink | * 类型：Value * 值：100000000 bps |

### | 5G动作组3 | 基本信息 | 名称 | AG\_Ambr\_02 |

### |  |  | 类型 | Ambr |

### |  | 属性 | uplink | * 类型：Value * 值：20000000 bps |

### |  |  | downlink | * 类型：Value * 值：20000000 bps |

### | 5G动作组4 | 基本信息 | 名称 | AG\_DefQoSInfo |

### |  |  | 类型 | DefaultQosInformation |

### |  | 属性 | 5qi | * 类型：Value * 值：9 |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_Arp  说明：  已在5G动作组中定义。 |

### | 5G动作组5 | 基本信息 | 名称 | AG\_Session\_01 |

### |  |  | 类型 | SessionRuleAction |

### |  | 属性 | sessRuleId | * 类型：Value * 值：AG\_Session\_01 |

### |  |  | authSessAmbr | * 类型：Reference ActionGroup * 值：AG\_Ambr\_01 说明：  已在5G动作组中定义。 |

### |  |  | authDefQos | * 类型：Reference ActionGroup * 值：AG\_DefQoSInfo 说明：  已在5G动作组中定义。 |

### | 5G动作组6 | 基本信息 | 名称 | AG\_Session\_02 |

### |  |  | 类型 | SessionRuleAction |

### |  | 属性 | sessRuleId | * 类型：Value * 值：AG\_Session\_02 |

### |  |  | authSessAmbr | * 类型：Reference ActionGroup * 值：AG\_Ambr\_02 说明：  已在5G动作组中定义。 |

### |  |  | authDefQos | * 类型：Reference ActionGroup * 值：AG\_DefQoSInfo 说明：  已在5G动作组中定义。 |

### | 5G动作组7 | 基本信息 | 名称 | AG\_FloDes |

### |  |  | 类型 | FlowDescription |

### |  | 属性 | action | * 类型：Value * 值：PERMIT |

### |  |  | direction | * 类型：Value * 值：OUT |

### |  |  | protocol | * 类型：Value * 值：ANY |

### |  |  | sourceIP | * 类型：Value * 值：any |

### |  |  | destinationIP | * 类型：Value * 值：any |

### | 5G动作组8 | 基本信息 | 名称 | AG\_FloInfo |

### |  |  | 类型 | FlowInformation |

### |  | 属性 | flowDirection | * 类型：Value * 值：BIDIRECTIONAL |

### |  |  | flowDescription | * 类型：Reference ActionGroup * 值：AG\_FloDes 说明：  已在5G动作组中定义。 |

### | 5G动作组9 | 基本信息 | 名称 | AG\_TraCon |

### |  |  | 类型 | TrafficControlData |

### |  | 属性 | tcId | * 类型：Value * 值：AG\_TraCon |

### |  |  | flowStatus | * 类型：Value * 值：ENABLED |

### | 5G动作组10 | 基本信息 | 名称 | AG\_QoSData\_01 |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：AG\_Default\_01 |

### |  |  | 5qi | * 类型：Value * 值：9 |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_Arp 说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：100 Mbps |

### |  |  | maxbrDl | * 类型：Value * 值：100 Mbps |

### | 5G动作组11 | 基本信息 | 名称 | AG\_QoSData\_02 |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：AG\_Default\_02 |

### |  |  | 5qi | * 类型：Value * 值：9 |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_Arp 说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：20 Mbps |

### |  |  | maxbrDl | * 类型：Value * 值：20 Mbps |

### | 5G动作组12 | 基本信息 | 名称 | AG\_Dynamic\_01 |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：AG\_Dynamic\_01 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_TraCon 说明：  已在5G动作组中定义。 |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG\_FloInfo 说明：  已在5G动作组中定义。 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_QoSData\_01 说明：  已在5G动作组中定义。 |

### | 5G动作组13 | 基本信息 | 名称 | AG\_Dynamic\_02 |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：AG\_Dynamic\_02 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_TraCon 说明：  已在5G动作组中定义。 |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG\_FloInfo 说明：  已在5G动作组中定义。 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_QoSData\_02 说明：  已在5G动作组中定义。 |

### 5 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 规则的数据规划如表5所示，详细参数说明请参见规则参数表。

### **表5** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | Rule1\_UE1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Session Rule |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_UE1  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_Session\_01  说明：  已在5G动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | Rule1\_UE2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Session Rule |

### |  | 条件组 | 关系 | AND |

### |  |  | 条件组 | CG\_UE2  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_Session\_02  说明：  已在5G动作组中定义。 |

### | 规则3 | 基本信息 | 名称 | Rule2\_UE1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  | 条件组 | 关系 | AND |

### |  |  | 条件组 | CG\_UE1  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_Dynamic\_01  说明：  已在5G动作组中定义。 |

### | 规则4 | 基本信息 | 名称 | Rule2\_UE2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  | 条件组 | 关系 | AND |

### |  |  | 条件组 | CG\_UE2  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_Dynamic\_02  说明：  已在5G动作组中定义。 |

### 6 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表6所示，详细参数说明请参见策略参数表。

### **表6** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略 | 基本信息 | 名称 | 5GTerminal\_Policy |

### |  |  | 策略类型 | N7 Policy |

### |  | 触发器 | 名称 | IPCAN\_EST |

### |  | 规则 | 名称 | * Rule1\_UE1 * Rule1\_UE2 * Rule2\_UE1 * Rule2\_UE2 说明：  已在规则中定义。 |

### 7 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 业务的数据规划如表7所示，详细参数说明请参见业务参数表。

### 完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

### **表7** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | 5GTerminal\_Service |

### |  |  | 类型 | BASIC\_SERVICE |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | 5GTerminal\_Policy  说明：  已在策略中定义。 |

### 8 登录“UPCF 业务管理”窗口。

### 9 发放业务。

#### 9.1 执行**ADD PSUB**增加一个用户。

#### “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=9.1 -->
```

#### 9.2 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=9.2 -->
```

