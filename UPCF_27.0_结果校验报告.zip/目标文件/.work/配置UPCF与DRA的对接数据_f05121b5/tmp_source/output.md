---
id: ''
name: 配置UPCF与DRA的对接数据
ne_type: UPCF
type: feature
description: UPCF与PCEF/AF/OCS/TDF之间通过DRA准直连组网时，需要配置UPCF与DRA的对接数据，其组网示意图如图1所示。  **图1** 准直连组网示意图
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（SDN）","配置UPCF对接数据","配置UPCF与DRA的对接数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UPCF与PCEF/AF/OCS/TDF之间通过DRA准直连组网时，需要配置UPCF与DRA的对接数据，其组网示意图如图1所示。**图1** 准直连组网示意图

## 必备事项
前提条件

* 已完成软件安装。
* UPCF侧已完成基础数据配置。
* DRA侧已完成基础数据配置。
* 已经获得运营商规划的UPCF与DRA的对接IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录OM Portal，打开“MML命令行 - UPCF”窗口。

### 2 执行**ADD DLBVPN**命令，关联配置FE CSLB基础数据时添加的Diameter信令平面的VPN。

### 3 执行**ADD DLBDEVADDR**命令增加UPCF与DRA对接的本端IP地址。

### 4 配置对端PCEF数据。

### 如果UPCF与PCEF直连，则跳过此步骤。

### | 操作步骤 | 关键参数说明 |

### | --- | --- |

### | 执行**ADD PPCEFCAT**命令增加PCEF类别。 | 说明：  在多PCEF场景或TDF组网场景时，需要配置PCEF类别，实现多个Gx会话间或Gx会话和Sd会话间统一的策略控制。否则不需要执行此步骤。  * 对端PCEF类别：该参数会在配置PCEF主机数据时引用。 * 会话超时后的处理方式：   + “ReleaseSingleSession”表示释放自身会话。   + “ReleaseAllSession”表示释放所有绑定会话。 * CCR\_T会话释放处理方式：   + “ReleaseSingleSession”表示释放该PCEF对应的会话的同时，会按照配置释放其他会话。 说明：  当“TERMINALPROCESS”取值为“ReleaseSingleSession”，如果要释放绑定的某个会话，则用户签约业务下需要包含关联了“IPCANSessionTermination”触发器和操作类型为“Term IP-CAN Session”的规则，且此规则中配置“目的PEER”为需要释放的会话的对端类别。   + “ReleaseAllSession”表示释放所有绑定会话。 |

### | 执行**ADD PCEFABIDICT**命令增加PCEF能力字典。 | 说明：  默认PCEF能力字典：64（HUAWEIGGSN）、65（HUAWEISYMASIG）、66（ALLOTPCEF）、67（HUAWEIGGSNR9）和68（HUAWEIPDNGW）。当以上PCEF能力字典不能满足局点需求时，需要配置新的PCEF能力字典。否则不需要执行此步骤。  能力字典ID： * 由于63～127是系统预置字典，因此建议该参数取值为0～62。 * 该参数会在配置PCEF主机数据时引用。 |

### | 执行**MOD PCEFABIITEM**命令修改新增的PCEF能力字典的字典项。 | 说明：  新增PCEF能力字典后，需要根据PCEF的实际能力，修改新增的PCEF能力字典的字典项。否则不需要执行此步骤。  能力字典项默认取值请参考**MOD PCEFABIITEM**，取值说明请参考PCRF对端PCEF能力字典项管理。 |

### | 执行**ADD PDHOSTCFG**命令增加PCEF主机数据。 | * 应用类型：   + PCEF：当网络中PCEF的能力都不同时，应用类型配置为“PCEF”，此时必须要输入目的主机名。   + DynamicPCEF：当网络中具有相同主机名字符子串的PCEF具有相同的能力时，应用类型配置为“DynamicPCEF”，此时目的主机名只需要输入实际主机名的字符子串，进行模糊匹配。   + DefaultPCEF：当网络中PCEF的能力都是相同的，应用类型配置为“DefaultPCEF”，此时不需要配置目的主机名。只能配置1条“DefaultPCEF”应用类型的目的主机。 说明：  + 对于Gx接口，使用CCR消息中的Origin-Host AVP优先匹配“应用类型”为“PCEF”的配置记录。   + 如果匹配“PCEF”类型失败，继续匹配“应用类型”为“DynamicPCEF”的配置记录，多条记录时按“目的主机名”的长度由大到小排序，如果长度相同，优先匹配“目的主机ID”的值小的。   + 如果匹配“DynamicPCEF”类型失败，则判定PCEF为“DefaultPCEF”应用类型。如果没有配置DefaultPCEF，则返回失败CCA消息，携带错误码“3010 DIAMETER\_UNKNOWN\_PEER”。 * 目的主机名：   + 当“应用类型”为“DefaultPCEF”时，不能配置该参数。   + 当“应用类型”为“DynamicPCEF”时，可以配置为实际主机名的子字符串，支持模糊匹配。   + 当“应用类型”为“PCEF”时，必须配置为完整的主机名。 * 能力字典ID：根据PCEF的实际能力，配置该参数。该参数已通过**ADD PCEFABIDICT**命令配置，或使用默认配置。 * 对端PCEF类别：在多PCEF场景和TDF组网场景下需要配置该参数。该参数已通过**ADD PPCEFCAT**命令配置。 * 对端PCEF组：用于IP地址冲突检测。当网络中在不同PCEF上线的不同终端的IP地址可能相同时，需要配置该参数。当“应用类型”为“DefaultPCEF”时，不能配置该参数。 |

### 5 配置对端AF数据。

### 如果组网中无AF或UPCF与AF直连，则跳过此步骤。

### | 操作步骤 | 关键参数说明 |

### | --- | --- |

### | 执行**ADD AFABIDICT**命令增加AF能力字典。 | 说明：  默认AF能力字典：0为华为AF，1为RESTFULAF（即PEF）。当以上AF能力字典不能满足局点需求时，需要配置新的AF能力字典。否则不需要执行此步骤。  能力字典ID： * 由于0～31是系统预置字典，因此建议该参数取值为32～127。 * 该参数会在配置AF主机数据时引用。 |

### | 执行**MOD AFABIITEM**命令修改新增的AF能力字典的字典项。 | 说明：  新增AF能力字典后，需要根据AF的实际能力，修改新增的AF能力字典的字典项。否则不需要执行此步骤。  能力字典项的默认取值和取值说明请参考**MOD AFABIITEM**的“参数说明”。 |

### | 执行**ADD PDHOSTCFG**命令增加AF主机数据。 | * 应用类型：   + AF：当网络中AF的能力都不同时，应用类型配置为“AF”，此时必须要输入目的主机名。   + DynamicAF：当网络中具有相同主机名字符子串的AF具有相同的能力时，应用类型配置为“DynamicAF”，此时目的主机名只需要输入实际主机名的字符子串，进行模糊匹配。   + DefaultAF：当网络中AF的能力都是相同的，应用类型配置为“DefaultAF”，此时不需要配置目的主机名。只能配置1条“DefaultAF”应用类型的目的主机。 说明：  + 对于Rx接口，使用AAR消息中的Origin-Host AVP优先匹配“应用类型”为“AF”的配置记录。   + 如果匹配“AF”类型失败，继续匹配“应用类型”为“DynamicAF”的配置记录，多条记录时按“目的主机名”的长度由大到小排序，如果长度相同，优先匹配“目的主机ID”小的值。   + 如果匹配“DynamicAF”类型失败，则判定AF为“DefaultAF”应用类型。如果没有配置DefaultAF，则以AF的“能力字典ID”为“0”处理。 * 目的主机名：   + 当“应用类型”为“DefaultAF”时，不能配置该参数。   + 当“应用类型”为“DynamicAF”时，可以配置为实际主机名的子字符串，支持模糊匹配。   + 当“应用类型”为“AF”时，必须配置为完整的主机名。 * 能力字典ID：根据AF的实际能力，配置该参数。该参数已通过**ADD AFABIDICT**命令配置，或使用默认配置。 |

### 6 配置对端OCS数据。

### | 操作步骤 | 关键参数说明 |

### | --- | --- |

### | 执行**MOD OCSABIITEM**命令修改OCS能力字典的字典项。 | 说明：  * 需要根据OCS的实际能力，修改OCS能力字典的字典项。 * OCS能力字典项支持与UPCF直连的OCS配置，当UPCF通过DRA与OCS连接时，仅支持关联“能力字典ID”为“0”的能力字典项。  能力字典项的默认取值和取值说明请参考**MOD OCSABIITEM**的“参数说明”。 |

### 7 配置对端TDF数据。

### 如果组网中无TDF或UPCF与TDF为直连，则跳过此步骤。

### | 操作步骤 | 关键参数说明 |

### | --- | --- |

### | 执行**ADD PPCEFCAT**命令增加TDF类别。 | * “对端PCEF类别”：该参数会在配置TDF域数据时引用。 * “CCR\_T会话释放处理方式”： “ReleaseSingleSession（释放自身单个会话）”表示释放该PCEF对应的会话的同时，会按照配置释放其他会话。 说明：  当“CCR\_T会话释放处理方式”取值为“ReleaseSingleSession（释放自身单个会话）”，如果要释放绑定的某个会话，则用户签约业务下需要包含关联了“IPCANSessionTermination”触发器和操作类型为“Term IP-CAN Session”的规则，且此规则中配置“目的PEER”为需要释放的会话的对端类别。 * TSA返回失败后处理方式：   + “ReleaseSingleSession（释放自身单个会话）”表示当UPCF向TDF发送TSR消息请求建立Sd会话，TDF返回失败或超时导致Sd会话无法正常建立时，UPCF只释放当前Sd会话。   + “ReleaseAllSession（释放所有绑定会话）”表示当UPCF向TDF发送TSR消息请求建立Sd会话，TDF返回失败或超时导致Sd会话无法正常建立时，既释放当前Sd会话，也释放绑定的Gx会话。 |

### | 执行**ADD PCEFABIDICT**命令增加TDF能力字典。 | 须知：  默认TDF能力字典：63（TDF）。当以上TDF能力字典不能满足局点需求时，需要配置新的TDF能力字典。否则不需要执行此步骤。  能力字典ID： * 由于63～127是系统预置字典，因此建议该参数取值为0～62。 * 该参数会在配置TDF域数据时引用。 |

### | 执行**MOD PCEFABIITEM**命令修改新增的TDF能力字典的字典项。 | 须知：  新增TDF能力字典后，需要根据TDF的实际能力，修改新增的TDF能力字典的字典项。否则不需要执行此步骤。  能力字典项默认取值请参考**MOD PCEFABIITEM**，取值说明请参考PCRF对端PCEF能力字典项管理。 |

### | 执行**ADD PDREALMCFG**命令增加TDF域数据。 | * 目的域应用类型：   + TDF（TDF）：TDF能力不同时，应用类型配置为“TDF”，此时必须要配置“目的域名”，并且不同能力的TDF的域名必须不相同。   + DefaultTDF（DefaultTDF）：TDF能力相同时，应用类型可以配置为“DefaultTDF”，不用配置“目的域名”。 * 目的域名：   + 当“目的域应用类型”为“DefaultTDF”时，不能配置该参数。   + 当“目的域应用类型”为“TDF”时，必须配置为完整的TDF域名。 * 能力字典ID：根据TDF的实际能力，配置该参数。该参数已通过**ADD AFABIDICT**命令配置，或使用默认配置。 * 对端PCEF类别：在TDF组网场景下，需要配置该参数。该参数已通过**ADD PPCEFCAT**命令配置。 |

### | 执行**ADD TDFROUTE**命令增加TDF对端路由数据。 | 须知：  当Gx接口消息不携带TDF-Information AVP时，必须配置TDF对端路由数据，以建立PCEF和TDF的映射关系。否则不需要执行此步骤。  * 路由类型：准直连场景下，该参数取值必须为“PcefRealmName（PCEF域名）”。 说明：  该参数取值为“PcefRealmName（PCEF域名）”时，不支持配置“对端标识”参数。 * TDF域名：根据运营商的PCEF与TDF的域名映射规划配置该参数与“路由键”。 说明：  + 当配置了“DefaultTDF”类型的TDF域数据时，如果TDF的能力字典和对端PCEF类别与“DefaultTDF”类型的TDF域数据一致，则该参数可以不用通过**ADD PDREALMCFG**命令配置。   + 当TDF的能力字典和对端PCEF类别与“DefaultTDF”类型的TDF域数据不一致，或未配置“DefaultTDF”类型的TDF域数据时，该参数必须通过**ADD PDREALMCFG**命令配置。 * 路由键：映射到该TDF域名的PCEF域名。 |

### 8 配置对端DRA数据和UPCF与DRA的链路。

### | 操作步骤 | 关键参数说明 |

### | --- | --- |

### | 执行**ADD PEER**命令增加DRA对端数据。 | * 对端类型：准直连组网场景下，固定取值为“DRA”。 * 对端标识：对端类型选择DRA时，对端标识的取值范围是0～15。该参数会在通过**ADD PEERL**命令增加对接链路和设置路由和对端关联关系时被引用。 * 对端域名：该参数取值为DRA的域名。 * 对端主机名：该参数取值为DRA的主机名。 * 业务保活时长（s）：当UPCF与DRA链路故障时，在业务保活时长内，UPCF不会释放故障链路上的会话。 * 审计开关：用于设置是否定时审计UPCF和DRA之间的会话，清理无效会话。 * 设备间审计时长（m）：用于设置审计UPCF和DRA之间的会话的时间间隔。 * 本端工作模式：需要与DRA协商一致。   + Server：UPCF作为服务端启动TCP侦听，处理DRA的建链请求。   + Client：UPCF作为客户端主动向DRA发起建链请求。 * 对端链路选择方式：   + ROUND\_ROBIN（轮询模式）：主备UPCF轮流选择链路发送请求消息。   + MASTER\_SLAVE（主备模式）：主备UPCF优先选择主用链路发送，主用链路故障时，选择一条备用链路发送。 说明：  该参数建议配置为轮询模式。 |

### | 执行**ADD PEERL**命令增加与DRA对接链路。  说明：  需要多次执行该命令以增加多条准直连链路。 | * 对端类型：准直连组网场景下，固定取值为“DRA”。 * 对端标识：DRA的对端标识，该参数已通过**ADD PEER**命令配置。 * 对端链路标识：配置多个对端链路时，从0开始顺序配置。 * 分发模式：准直连组网下，如果选择使用SCTP传输协议，则该参数不支持配置为知名端口分发。   + SpecialQuintuple（固定五元组转发）   + WellKnownPort（知名端口分发） * 传输协议类型：该参数需要与DRA协商一致。   + TCP(传输控制协议)   + SCTP(流量控制传输协议) * 双归属开关：“传输协议类型”取值为“SCTP”时，才可以配置该参数。 说明：  该参数取值为“ON”时，表示启动链路的双归属功能，才能够配置“双归属本端IPV4地址”或“双归属本端IPV6地址”、“双归属对端IPV4地址”或“双归属对端IPV6地址”。 * 交叉路径：当“双归属开关”为“ON”时，需要设置此参数。当DRA不支持SCTP交叉路径功能时，需要设置该参数为“OFF”。 * 本地端口：当“分发模式”选择“固定五元组转发”时，才设置该参数。该参数需要与UPCF协商一致。   + “本端工作模式”为Client时，本端端口范围0～65534。   + “本端工作模式”为Server时，本端端口范围1～65534。 * 对端端口：该参数需要与DRA协商一致。   + “本端工作模式”为Client时，本端端口范围1～65534。   + “本端工作模式”为Server时，本端端口范围0～65534。 * 本地端口模式：当“分发模式”为“固定五元组转发”时，才可设置该参数。UPCF参数也受“本端工作模式”的限制。该参数建议设置为“MultiplePorts(本地多端口模式)”。   + WellKnownPort：本地知名UPCF对外呈现的端口为“本地端口”参数指定的端口。   + MultiplePorts：本地多UPCF对外呈现的端口为“本地端口”参数指定的端口。 * 容灾PCRF标识：该参数只在开启Rx会话备份功能时才需要配置，其他场景不需要配置。 |

### 9 配置域路由数据。

### | 操作步骤 | 关键参数说明 |

### | --- | --- |

### | 执行**ADD PREALMRT**命令增加域路由数据。 | * 路由标识：配置多个对端域路由时，该参数从0开始顺序配置。 * 是否是默认路由：UPCF支持每种接口类型最多配置1条默认路由。 * 域名：PCEF/AF/OCS/TDF的域名。当“是否是默认路由”选择“YES(是)”时，不配置该参数。 * 接口类型：用于指示路由对应的接口类型。 * 对端选择方式：   + MASTER\_SLAVE(主备模式)：UPCF优先选择发送消息到主用DRA，当主用DRA故障时，发送消息到备用DRA。   + ROUND\_ROBIN(轮询模式)：UPCF轮流选择DRA发送消息。   + USER\_CTL(用户模式)：UPCF优先选择发送消息到原发送CCR消息的DRA，当原DRA故障时，再轮流选择其他正常DRA。 说明：  * 当PCEF/AF/TDF具有相同的域名，且通过相同的DRA实现准直连组网时，配置一条路由数据，或直接配置一条默认路由数据。 * 当PCEF/AF/TDF具有不同的域名，且通过相同的DRA实现准直连组网时，分别配置路由数据，或直接配置一条默认路由数据。 * 当PCEF/AF/TDF通过不同的DRA实现准直连组网时，必须分别配置路由数据。 * UPCF与OCS准直连组网时，必须单独配置路由数据。UPCF只支持配置一条Sy接口路由数据，或直接配置一条默认路由数据。 |

### 10 配置路由与DRA关联关系

### | 操作步骤 | 关键参数说明 |

### | --- | --- |

### | 执行**ADD PREALMPEERREL**命令增加路由与DRA关联关系。 | * 路由标识：用于标识域路由。该参数必须先由****ADD PREALMRT****命令定义，然后才能在此处索引。 * 对端标识：用于标识Diameter对端实体。该参数必须先由**ADD PEER**命令定义，然后才能在此处索引。 * 是否为Master对端：用于设置是否为Master对端。   + True（True）：是Master对端   + False（False）：不是Master对端 |

