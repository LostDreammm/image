# 检查容灾参数配置

* 操作场景
* 对系统的影响
* 必备事项
* 操作步骤

#### 操作场景

在容灾系统搭建完成后，指导操作人员检查无缝地理容灾组网的关键参数配置。该操作仅需在容灾系统搭建完成后执行一次，后续例行维护过程中不需要再执行此操作。

如果配置有误，容灾倒换后会出现业务异常。

#### 对系统的影响

该操作对系统正常运行无影响。

#### 必备事项

**前提条件**

容灾系统已完成搭建。

**数据**

该操作无需准备数据。

#### 操作步骤

检查主用UPCF的容灾参数配置

1. 在主用UPCF上，登录“USCDB MML命令”界面。
2. 执行**LST INSP**命令查询参数“REDUNDANCYSWITCH”的取值：

   ```
   LST INSP: INSPN=REDUNDANCYSWITCH;
   ```

   如果“REDUNDANCYSWITCH”的值不为“0”，则将其改为“0”：

   ```
   MOD INSP: INSPN=REDUNDANCYSWITCH, INSPV=0, FETYPEN="UPCF";
   ```
3. 执行**LST INSP**命令查询参数“GLOBALDATAREFRESHCYCLE”的取值：

   ```
   LST INSP: INSPN=GLOBALDATAREFRESHCYCLE;
   ```

   如果“GLOBALDATAREFRESHCYCLE”的值不为“20”，则将其改为“20”：

   ```
   MOD INSP: INSPN=GLOBALDATAREFRESHCYCLE, INSPV=20;
   ```
4. 执行**LST INSP**命令查询参数“PGWSNDDCIMSGMODE”的取值：

   ```
   LST INSP: INSPN=PGWSNDDCIMSGMODE;
   ```

   如果“PGWSNDDCIMSGMODE”的值不为“1”，则将其改为“1”：

   ```
   MOD INSP: INSPN=PGWSNDDCIMSGMODE, INSPV=1;
   ```
5. 在主用UPCF上，登录“UPCF MML命令”界面。
6. 执行**LST INSP**命令查询参数“VRM\_SESSIONBACKUPSWITCH”的取值：

   该软参用于Session备份功能，如果未启用Session备份功能，则跳过此步骤。

   ```
   LST INSP: INSPN=VRM_SESSIONBACKUPSWITCH;
   ```

   根据需要开启的会话备份功能确认“VRM\_SESSIONBACKUPSWITCH”的值是否正确，如果“VRM\_SESSIONBACKUPSWITCH”的值不正确，则将其改为对应的值。以软参的取值需改为“3”为例：

   ```
   MOD INSP: INSPN=VRM_SESSIONBACKUPSWITCH, INSPV=3;
   ```
7. 执行**LST INSP**命令查询参数“VRM\_OFFLINESRVSWITCH”的取值：

   ```
   LST INSP: INSPN=VRM_OFFLINESRVSWITCH;
   ```

   如果“VRM\_OFFLINESRVSWITCH”的值不为“1”，则将其改为“1”：

   ```
   MOD INSP: INSPN=VRM_OFFLINESRVSWITCH, INSPV=1;
   ```

检查容灾UPCF的容灾参数配置

8. 在容灾UPCF1和容灾UPCF2上，登录“USCDB MML命令”界面。
9. 执行**LST INSP**命令查询参数“REDUNDANCYSWITCH”的取值：

   ```
   LST INSP: INSPN=REDUNDANCYSWITCH;
   ```

   如果“REDUNDANCYSWITCH”的值不为“0”，则将其改为“0”：

   ```
   MOD INSP: INSPN=REDUNDANCYSWITCH, INSPV=0, FETYPEN="UPCF";
   ```
10. 执行**LST INSP**命令查询参数“GLOBALDATAREFRESHCYCLE”的取值：

    ```
    LST INSP: INSPN=GLOBALDATAREFRESHCYCLE;
    ```

    如果“GLOBALDATAREFRESHCYCLE”的值不为“20”，则将其改为“20”：

    ```
    MOD INSP: INSPN=GLOBALDATAREFRESHCYCLE, INSPV=20;
    ```
11. 执行**LST INSP**命令查询参数“PGWSNDDCIMSGMODE”的取值：

    ```
    LST INSP: INSPN=PGWSNDDCIMSGMODE;
    ```

    如果“PGWSNDDCIMSGMODE”的值不为“1”，则将其改为“1”：

    ```
    MOD INSP: INSPN=PGWSNDDCIMSGMODE, INSPV=1;
    ```
12. 在容灾UPCF1和容灾UPCF2上，登录“UPCF MML命令”界面。
13. 执行**LST INSP**命令查询参数“VRM\_SESSIONBACKUPSWITCH”的取值：

    该软参用于Session备份功能，如果未启用Session备份功能，则跳过此步骤。

    ```
    LST INSP: INSPN=VRM_SESSIONBACKUPSWITCH;
    ```

    根据需要开启的会话备份功能确认“VRM\_SESSIONBACKUPSWITCH”的值是否正确，如果“VRM\_SESSIONBACKUPSWITCH”的值不正确，则将其改为对应的值。以软参的取值需改为“3”为例：

    ```
    MOD INSP: INSPN=VRM_SESSIONBACKUPSWITCH, INSPV=3;
    ```
14. 执行**LST INSP**命令查询参数“VRM\_OFFLINESRVSWITCH”的取值：

    ```
    LST INSP: INSPN=VRM_OFFLINESRVSWITCH;
    ```

    如果“VRM\_OFFLINESRVSWITCH”的值不为“1”，则将其改为“1”：

    ```
    MOD INSP: INSPN=VRM_OFFLINESRVSWITCH, INSPV=1;
    ```

版权所有 © 华为技术有限公司
