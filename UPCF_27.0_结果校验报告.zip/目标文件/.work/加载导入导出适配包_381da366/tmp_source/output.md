---
id: ''
name: 加载导入导出适配包
ne_type: UPCF
type: feature
description: 完成基础数据配置后，UPCF支持加载导入导出适配包，配合对应的导入导出模板，实现相关数据导入导出及备份。  * 本产品在提供用户数据导出功能时，将不可避免的使用用户的个人数据，如：IMSI等，因此您需遵循所适用国家的法律或贵公司的用户隐私政策并采取足够的措施，以确保用户的个人数据受到充分的保护。 * 导入导出适配包存放在UPCF\_\*\*\*\_PLUG.zip文件夹下，分别对应Import\_ADPPKG\_\*\*\*.tar和Export\_ADPPKG\_\*\*\*.tar，其中\*\*\*为对应版本的版本号。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（SDN）","加载导入导出适配包"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
完成基础数据配置后，UPCF支持加载导入导出适配包，配合对应的导入导出模板，实现相关数据导入导出及备份。* 本产品在提供用户数据导出功能时，将不可避免的使用用户的个人数据，如：IMSI等，因此您需遵循所适用国家的法律或贵公司的用户隐私政策并采取足够的措施，以确保用户的个人数据受到充分的保护。* 导入导出适配包存放在UPCF\_\*\*\*\_PLUG.zip文件夹下，分别对应Import\_ADPPKG\_\*\*\*.tar和Export\_ADPPKG\_\*\*\*.tar，其中\*\*\*为对应版本的版本号。

## 必备事项
前提条件

* OM Portal已经安装完成。
* 已配置BE的数据库双机。
* USCDB网元下的各模块状态正常。

  执行**LOD ADPPKG**命令之前务必要保证PGW模块状态正常，否则无法加载成功。
* FE插件包已安装。
* 导入导出适配包已下载到本地，详细信息请参见“软件安装 > 基于NFVO/LCM安装UPCF（SDN/非SDN） > 安装前准备 > 获取软件包”。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    lod_pkg_list:
      type: items
      properties:
        FNM:
          name: '文件名称'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    lod_adppkg_list:
      type: items
      properties:
        ADPPKGNAME:
          name: '适配包名称'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PKGTYPE:
          name: '适配包加载类型'
          type: string
          enum:
          - EXPORT
          - IMPORT
          - MIGRATE
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICETYPE:
          name: '服务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - lod_pkg_list:
    - FNM: 'Import_ADPPKG_***.tar'
    lod_adppkg_list:
    - ADPPKGNAME: 'Import_ADPPKG_***.tar'
      PKGTYPE: IMPORT
      SERVICETYPE: 'UPCF'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录CSP Portal，选择 “系统 > 文件传输”，进入指定目录“CGPLite文件 > 软件包”。点击添加文件，将Import\_ADPPKG\_\*\*\*.tar和Export\_ADPPKG\_\*\*\*.tar适配包上传到该路径下。

### 2 上传成功后，在“CSP MML命令”界面，执行**LOD PKG**命令，将导入导出适配插件包加载到系统中。其中，文件名称即为刚上传的适配包。

```jinja2
{%- for item in lod_pkg_list -%}
    LOD PKG:
    {#- --- 必选参数 --- -#}
    FNM="{{item.FNM}}",
    ;
{%- endfor -%}
```

### 3 登录OM Portal界面，“选择系统” > “文件传输”，在“CGPLite > 网元文件”路径下，创建“ADAPTER”文件夹。若文件夹已存在，则无需创建。

### 4 登录OM Portal界面，在“应用管理 > MML”中选择“USCDB”网元，执行**LOD ADPPKG**命令，加载导入导出适配包。

```jinja2
{%- for item in lod_adppkg_list -%}
    LOD ADPPKG:
    {#- --- 必选参数 --- -#}
    ADPPKGNAME="{{item.ADPPKGNAME}}",
    PKGTYPE={{item.PKGTYPE}},
    SERVICETYPE="{{item.SERVICETYPE}}",
    ;
{%- endfor -%}
```

### 5 执行**RST MODULE**命令，重启所有PGW模块。

### 6 执行**DSP ADPPKG**命令，查询适配包加载状态。

### 查看输出报文，确保适配包加载成功。

### 7 如需更新适配包，请重新加载适配包。

#### 7.1 联系华为技术支持，在华为技术支持的指导下执行**CLR ADPPKG**命令，清除之前的加载记录。

#### 7.2 执行**RST MODULE**命令，重启所有PGW模块。

#### 7.3 执行**LOD ADPPKG**命令，重新加载适配插件包。

