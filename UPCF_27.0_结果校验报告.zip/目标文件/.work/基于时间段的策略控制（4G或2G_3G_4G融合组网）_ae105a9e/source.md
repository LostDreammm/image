# 基于时间段的策略控制（4G或2G/3G/4G融合组网）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

运营商为了提升网络资源使用效率，满足大多数用户的体验，需要引导用户均衡使用网络。例如根据4G或2G/3G/4G融合组网用户的使用习惯，18:00～23:00为网络流量的高峰期，大量P2P、下载类业务的使用影响了其他数据业务的正常使用，运营商可以设置在这个时间段内降低P2P、下载类业务的带宽，防止网络拥塞。

以如下应用场景，UPCF对接华为UGW9811为例：

* 忙时18:00～23:00，上行带宽为500 kbit/s，下行带宽为1 Mbit/s，使用免费。
* 闲时23:00～18:00，上行带宽为1 Mbit/s，下行带宽为2 Mbit/s，使用免费。
* 由UPCF启动定时器，统计业务有效时间。
* 不配置消息通知。
* 配置动态规则。

#### 对系统的影响

当大量用户同时在线，并且用户所使用业务的策略触发时间段都相同，会导致在同一时刻触发大量定时器消息，产生大量的定时消息包。UPCF下发策略时CPU负荷略有上升，每个用户的策略下发略有延迟。

可以通过配置RuleTimeRange动作提前下发规则激活时间和去激活时间，避免在同一时刻触发大量定时器消息。

#### 必备事项

**前提条件**

操作员已了解WHFD-611003 基于时间段的动态策略控制特性概述。

**数据**

根据应用场景，参考业务拆解总体原则，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 业务Service\_1 | 此时间段策略控制业务即为一个独立的业务（service）。 | - |
| 策略Policy\_Using | 此策略在用户上线和UPCF系统时间到达指定范围时被调用，触发器分别为IPCANSessionEstablish和TimeRangeChange，包含所有规则。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配并下发策略给PCEF（Policy and Charging Enforcement Function）。  时间段业务中，若由UPCF启动定时器，则触发器选择TimeRangeChange；若由PCEF启动定时器，则触发器选择RevalidationTimeout。 |
| 规则Rule1\_Change1 | * 条件：忙时18:00～23:00。 * 动作：DefaultBearerQoS（QCI=8，ARP=1）。 | 建立默认承载时，必须配置动作DefaultBearerQoS，从而下发QoS。 |
| 规则Rule1\_Change2 | * 条件：闲时23:00～18:00。 * 动作：DefaultBearerQoS（QCI=8，ARP=1）。 |  |
| 规则Rule2\_Change1 | * 条件：忙时18:00～23:00。 * 动作：    + QoSAction：QCI为8，ARP为1，上行带宽为500 kbit/s，下行带宽为1 Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 | * 基于时间段的策略控制，条件要选用系统的当前时间，即“对象属性”选用对象System下的Datetime属性。 * 若对端为华为UGW9811，不管用户需求是否需要改变计费策略均需配置动作ChargingAction。“RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。 * 业务流：若不区分各业务的数据流，统一只根据会话流量控制带宽，则规则中上下行业务流均取默认值“Any IP Protocol”。 |
| 规则Rule2\_Change2 | * 条件：闲时23:00～18:00。 * 动作：    + QoSAction：QCI为8，ARP为1，上行带宽为1 Mbit/s，下行带宽为2 Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 |  |

#### 操作流程

业务的配置流程图如图2所示。

**图2** 业务配置流程图

#### 操作步骤

1. 配置软参。
   1. 登录“UPCF MML命令”界面。
   2. 执行命令**MOD INSP**，修改软参“VRM\_REVALIDATIONTIMEMETHOD”的取值。

      根据运营商需求，当需要由PCEF启动定时器时，执行此步骤，否则，请跳过此步骤。

      * 软参“VRM\_REVALIDATIONTIMEMETHOD”的值为0，表示由UPCF启动定时器。当UPCF启动的定时器达到设定时间时，UPCF直接向PCEF下发RAR消息，更改策略。
      * 软参“VRM\_REVALIDATIONTIMEMETHOD”的值为1，表示由PCEF启动定时器。当PCEF的定时器达到设定时间时，PCEF向UPCF发送CCR-update消息，请求更改策略。
      * 软参“VRM\_REVALIDATIONTIMEMETHOD”的默认值为0。

      命令举例：

      ```
      MOD INSP: INSPN=VRM_REVALIDATIONTIMEMETHOD, INSPV=1;
      ```
   3. 执行命令**MOD INSP**，修改软参“VRM\_USRREVALIHRANGE”的取值。

      当由UPCF启动定时器且需要修改定时器的散列时间范围值（默认值：300秒）时，执行此步骤，否则，请跳过此步骤。

      命令举例：

      ```
      MOD INSP: INSPN=VRM_USRREVALIHRANGE, INSPV=600;
      ```
2. 修改对端PCEF能力字典项。
   1. 登录“UPCF MML命令”界面。
   1. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持R8标准的QoS。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=68, ABILITYITEMID=R8QoS, ABLITYVALUE=SupportedR8QoS;
      ```

      在4G或2G/3G/4G融合组网中，UPCF与华为UGW9811对接时，“ABILITYDICTID”需设置为“68”。实际的值可以通过如下方式查询：
      * 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。
      * 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
   2. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持IP-CAN Session Revalidation机制。

      根据运营商需求，当需要由PCEF启动定时器时，执行此步骤，否则，请跳过此步骤。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=68, ABILITYITEMID=IPSessRevalidation, ABLITYVALUE=SupportedRevalidation;
      ```
3. 登录UPCF WebUI界面。
4. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置两个条件组，用于判断忙时（18:00～23:00）或闲时（23:00～18:00）。条件组的数据规划如表2所示，详细参数说明请参见条件组参数表。

   **表2** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_Change1 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | Condition1 |
   |  |  | 对象属性 | * 对象：System * 属性：Datetime |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | 相对时间段  * 月：全选 * 日：全选 * 星期：全选 * 开始时间：18:00:00 * 持续时间：5 说明：  时间条件中，时间间隔必须大于软参VRM\_USRREVALIHRANGE（散列时间范围）的值，否则匹配上该时间条件的规则无法被触发。 |
   | 条件组2 | 基本信息 | 名称 | CG\_Change2 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | Condition2 |
   |  |  | 对象属性 | * 对象：System * 属性：Datetime |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | 相对时间段  * 月：全选 * 日：全选 * 星期：全选 * 开始时间：23:00:00 * 持续时间：19 说明：  时间条件中，时间间隔必须大于软参VRM\_USRREVALIHRANGE（散列时间范围）的值，否则匹配上该时间条件的规则无法被触发。 |
5. 配置动作组。

   导航入口为“策略管理 > 策略 > 动作组”。

   * 若配置的规则为动态规则，则必须配置动作组。
   * 此场景配置动态规则且需要考虑默认承载的QoS、调整带宽和计费动作，则需配置动作：DefaultBearerQoS、QoSAction和ChargingAction。相关应用场景如下：

     + DefaultBearerQoS：当需要建立默认承载时必须配置此动作。
     + QoSAction：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制QoS。
     + ChargingAction：当需要做计费策略控制时，配置此动作（若对端为华为UGW9811，此动作必须配置）。

   需要配置四个动作组，用于在忙时（18:00～23:00）或闲时（23:00～18:00）动作的下发。动作组的数据规划如表3所示，详细参数说明请参见动作组参数表。

   **表3** 动作组

   | 类别 | 参数 |  |  | 取值样例 |
   | --- | --- | --- | --- | --- |
   | 动作组1 | 基本信息 | 名称 |  | AG1\_Change1 |
   |  | 动作 | 动作 |  | DefaultBearerQoS |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  |  |  | PreemptionCapability | * 值类型：Value * 值：Disabled |
   |  |  |  | PreemptionVulnerability | * 值类型：Value * 值：Enabled |
   |  |  |  | AMBRDL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | AMBRUL | * 值类型：Value * 值(kbit/s)：500 |
   | 动作组2 | 基本信息 | 名称 |  | AG1\_Change2 |
   |  | 动作 | 动作 |  | DefaultBearerQoS |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  |  |  | PreemptionCapability | * 值类型：Value * 值：Disabled |
   |  |  |  | PreemptionVulnerability | * 值类型：Value * 值：Enabled |
   |  |  |  | AMBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | AMBRUL | * 值类型：Value * 值(kbit/s)：1000 |
   | 动作组3 | 基本信息 | 名称 |  | AG2\_Change1 |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：500 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：500 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示按月计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   | 动作组4 | 基本信息 | 名称 |  | AG2\_Change2 |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：1000 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示按月计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
6. 配置业务流。

   导航入口为“策略管理 > 策略 > 业务流”。

   当对端为华为UGW9811时，所有的动态规则都必须配置业务流。

   业务流的数据规划如表4所示，详细参数说明请参见业务流参数表。

   **表4** 业务流

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务流 | 基本信息 | 名称 | Flow\_Filter |
   |  | 流过滤器1 | 名称 | up\_pass |
   |  |  | 流方向 | Up |
   |  |  | 协议 | Any IP Protocol |
   |  | 流过滤器2 | 名称 | down\_pass |
   |  |  | 流方向 | Down |
   |  |  | 协议 | Any IP Protocol |
7. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   规则的数据规划如表5所示，详细参数说明请参见规则参数表。

   **表5** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | Rule1\_Change1 |
   |  |  | 类型 | Default Bearer QoS 说明：  默认承载QoS场景，规则类型必须为“Default Bearer QoS”。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Change1  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG1\_Change1  说明：  已在动作组中定义。 |
   | 规则2 | 基本信息 | 名称 | Rule1\_Change2 |
   |  |  | 类型 | Default Bearer QoS 说明：  默认承载QoS场景，规则类型必须为“Default Bearer QoS”。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Change2  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG1\_Change2  说明：  已在动作组中定义。 |
   | 规则3 | 基本信息 | 名称 | Rule2\_Change1 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Change1  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG2\_Change1  说明：  已在动作组中定义。 |
   | 规则4 | 基本信息 | 名称 | Rule2\_Change2 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Change2  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG2\_Change2  说明：  已在动作组中定义。 |
8. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   策略的数据规划如表6所示，详细参数说明请参见策略参数表。

   **表6** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略 | 基本信息 | 名称 | Policy\_Using |
   |  | 触发器 | 名称 | IPCANSessionEstablish  TimeRangeChange  说明：  时间段业务中，若由UPCF启动定时器，则触发器选择TimeRangeChange；若由PCEF启动定时器，则触发器选择RevalidationTimeout。此场景由UPCF启动定时器。 |
   |  | 规则 | 名称 | * Rule1\_Change1 * Rule1\_Change2 * Rule2\_Change1 * Rule2\_Change2 说明：  已在规则中定义。 |
9. 配置业务。

   导航入口为“业务管理 > 业务 > 业务”。

   完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

   业务的数据规划如表7所示，详细参数说明请参见业务参数表。

   **表7** 业务

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务 | 基本信息 | 名称 | Service\_1 |
   |  |  | 类型 | BASIC\_SERVICE |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | Policy\_Using  说明：  已在策略中定义。 |
10. 登录“UPCF 业务管理”窗口。
11. 发放业务。
    1. 执行**ADD PSUB**增加一个用户。

       “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

       ```
       ADD PSUB:USRIDENTIFIER="46010381012****", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB;
       ```
    2. 执行**ADD PSRV**给用户签约业务。

       ```
       ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="Service_1", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
       ```

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
