# Gx增强的ADC基本功能（带宽控制）（2G/3G）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

ADC（Application Detection and Control）为无线承载网提供基于Gx接口的应用流检测和控制功能，PCEF支持ADC功能，即PCEF和TDF（Traffic Detection Function）可以合设部署。UPCF与合设的PCEF配套使用可以通过Gx接口进行消息交互，实现对用户的应用进行流量累计、应用流QoS控制、应用流Gate控制、重定向等功能。当运营商需要基于用户的应用进行策略控制时，需要部署此特性。

以签约包月业务的用户又签约某特定视频优惠应用，并且使用某特定视频应用时，系统为用户提供高带宽的QoS保障的场景为例，UPCF对接华为GGSN：

* 当用户开始使用某特定视频应用时，最大上、下行带宽分别为2 Mbit/s、4 Mbit/s。
* 当用户初始上线或停止使用某特定视频应用时，不进行带宽控制。
* PCEF检测到业务流应用后，上报事件给UPCF。
* 配置动态规则。

#### 对系统的影响

该操作对系统正常运行无影响。

#### 必备事项

**前提条件**

操作员已了解WHFD-611060 Gx增强的ADC基本功能特性描述。

已完成配置UPCF与PCEF的对接数据。

**数据**

根据应用场景，参考业务拆解总体原则，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系图

**表1** 配置关系解释

| 名称 | 需求分解项 | 基本原则 |
| --- | --- | --- |
| 业务Service\_01 | 此包月业务包含两个业务：  * 业务PCEF\_ADC\_Establish * 业务PCEF\_ADC\_Service | 根据用户需求，此业务场景需要3种触发器：  * IPCANSessionEstablish：上线时使用。 * ApplicationStart和ApplicationStop：应用事件上报过程中使用。 |
| 业务PCEF\_ADC\_Establish | 此业务包括一个策略：Policy\_ADC\_Establish，在用户上线过程中被调用。 | - |
| 业务PCEF\_ADC\_Service | 此业务包括两个策略：Policy\_ADC\_Start和Policy\_ADC\_Stop，在用户使用某特定视频应用时被调用。 | - |
| 策略Policy\_ADC\_Establish | 此策略在用户上线过程中被调用，触发器为IPCANSessionEstablish，包含规则Rule\_ADC\_Establish。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配并下发策略给PCEF。  说明：  关联ApplicationStop触发器的策略，仅支持关联“操作类型”为“Remove Rule”或“类型”为“Non-PCC”的规则。 |
| 策略Policy\_ADC\_Start | 此策略在ApplicationStart应用事件上报过程中被调用，触发器ApplicationStart，包含规则Rule\_ADC\_4M。 |  |
| 策略Policy\_ADC\_Stop | 此策略在ApplicationStop应用事件上报过程中被调用，触发器ApplicationStop，包含规则Rule\_ADC\_Stop。 |  |
| 规则Rule\_ADC\_Establish | 用户上线时，UPCF会订阅相关应用事件，不进行带宽控制，下发此规则。  * 条件：无。 * 动作：   + TDFApplicationIdentifier：“TDFApplicationIdentifier”为“ABC”。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 | * 条件中“对象属性”选用对象IPSession下的TDFApplicationIdentifier属性。 * 需配置动作TDFApplicationIdentifier，用于对用户使用的应用流进行订阅标识。“TDFApplicationIdentifier”的取值需与对端PCEF协商一致。 * 若对端为华为GGSN，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。“RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。 |
| 规则Rule\_ADC\_4M | 如果检测到用户开始使用某特定视频应用，UPCF进行带宽控制，提供高带宽的QoS保障，则下发此规则。  * 条件：IPSession：TDFApplicationIdentifier为“ABC”。 * 动作：   + QoSAction：上行带宽为2Mbit/s，下行带宽为4Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 |  |
| 规则Rule\_ADC\_Stop | 如果检测到用户开始停止某特定视频应用，UPCF不进行带宽控制，则下发此规则。  规则类型：Non-PCC | 规则类型配置为“Non-PCC”。因为用户停止使用某特定视频应用，不需要提供高带宽的QoS保障，并且UPCF不进行带宽控制，则删除PCEF\_ADC\_Service业务下的原有规则。 |

#### 操作流程

此特性的配置流程图如图2所示。

**图2** 业务配置流程图

#### 操作步骤

1. 修改对端PCEF能力字典项。
   1. 登录“UPCF MML命令”界面。
   2. 执行**LST PCEFABIITEM**，查询对端PCEF能力字典AppDetectionAbility，是否支持应用检测触发器的下发。

      如果查询的“AppDetectionAbility”取值不为默认值“SupportedAppDetection”，则需执行1.c，否则，略过1.c。
   3. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持应用检测触发器的下发。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=AppDetectionAbility, ABLITYVALUE=SupportedAppDetection;
      ```

      在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”默认设置为“67”。实际的值可以通过如下方式查询：
      * 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。
      * 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
   4. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其不支持R8标准的QoS。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=R8QoS, ABLITYVALUE=UnsupportedR8QoS;
      ```
2. 登录UPCF Web UI界面。
3. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   条件组的数据规划如表2所示，详细参数说明请参见条件组参数表。

   **表2** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组 | 基本信息 | 名称 | CG\_ADC\_Start |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_ADC\_Start |
   |  |  | 对象属性 | * 对象：IPSession * 属性：TDFApplicationIdentifier |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | ABC  说明：  “ABC”：表示用户使用的为某特定视频应用。 |
4. 配置动作组。

   导航入口为“策略管理 > 策略 > 动作组”。

   动作组的数据规划如表3所示，详细参数说明请参见动作组参数表。

   **表3** 动作组

   | 类别 | 参数 |  |  | 取值样例 |
   | --- | --- | --- | --- | --- |
   | 动作组1 | 基本信息 | 名称 |  | AG\_ADC1 |
   |  | 动作1 | 动作 |  | TDFApplicationIdentifier |
   |  |  | 动作元素 | TDFApplicationIdentifier | * 值类型：Value * 值：ABC 说明：  TDFApplicationIdentifier取值需与对端协商一致。 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示不计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
   | 动作组2 | 基本信息 | 名称 |  | AG\_ADC2 |
   |  | 动作1 | 动作 |  | QoSAction |
   |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |
   |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：4000 |
   |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：2000 |
   |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：4000 |
   |  |  |  | ARPLevel | * 值类型：Value * 值：1 |
   |  | 动作2 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示不计费。 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
5. 配置业务流。

   导航入口为“策略管理 > 策略 > 业务流”。

   当动态规则下需要配置包含“TDFApplicationIdentifier”动作的动作组时，动态规则不可以配置业务流。

   业务流的数据规划如表4所示，详细参数说明请参见业务流参数表。

   **表4** 业务流

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务流 | 基本信息 | 名称 | Flow\_Filter |
   |  | 流过滤器1 | 名称 | up\_pass |
   |  |  | 流方向 | Up |
   |  |  | 协议 | Any IP Protocol |
   |  | 流过滤器2 | 名称 | down\_pass |
   |  |  | 流方向 | Down |
   |  |  | 协议 | Any IP Protocol |
6. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   规则的数据规划如表5所示，详细参数说明请参见规则参数表。

   **表5** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | Rule\_ADC\_Establish |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 目的PEER | PCEF |
   |  |  | EDR | OFF |
   |  | 动作组 | 动作组 | AG\_ADC1  说明：  已在动作组中定义。 |
   | 规则2 | 基本信息 | 名称 | Rule\_ADC\_4M |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter |
   |  |  | 目的PEER | PCEF |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_ADC\_Start  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_ADC2  说明：  已在动作组中定义。 |
   | 规则3 | 基本信息 | 名称 | Rule\_ADC\_Stop |
   |  |  | 类型 | Non-PCC |
   |  |  | EDR | OFF |
7. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   策略的数据规划如表6所示，详细参数说明请参见策略参数表。

   **表6** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略1 | 基本信息 | 名称 | Policy\_ADC\_Establish |
   |  | 触发器 | 名称 | IPCANSessionEstablish |
   |  | 规则 | 名称 | Rule\_ADC\_Establish  说明：  已在规则中定义。 |
   | 策略2 | 基本信息 | 名称 | Policy\_ADC\_Start |
   |  | 触发器 | 名称 | ApplicationStart |
   |  | 规则 | 名称 | Rule\_ADC\_4M  说明：  已在规则中定义。 |
   | 策略3 | 基本信息 | 名称 | Policy\_ADC\_Stop |
   |  | 触发器 | 名称 | ApplicationStop |
   |  | 规则 | 名称 | Rule\_ADC\_Stop  说明：  已在规则中定义。 |
8. 配置业务。

   导航入口为“业务管理 > 业务 > 业务”。

   完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

   业务的数据规划如表7所示，详细参数说明请参见业务参数表。

   **表7** 业务

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务1 | 基本信息 | 名称 | PCEF\_ADC\_Establish |
   |  |  | 类型 | BASIC\_SERVICE |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | Policy\_ADC\_Establish  说明：  已在策略中定义。 |
   | 业务2 | 基本信息 | 名称 | PCEF\_ADC\_Service |
   |  |  | 类型 | BASIC\_SERVICE |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | Policy\_ADC\_Start  Policy\_ADC\_Stop  说明：  已在策略中定义。 |
9. 发放业务。

   发放业务有两种方式：一、执行命令逐条增加；二、批处理。

   如下以执行命令逐条增加为例，批处理的详细操作请参考**BAT**。

   1. 登录“UPCF 业务管理”窗口。
   2. 执行**ADD PSUB**增加一个用户。

      “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认值为“IMSI”。

      ```
      ADD PSUB: USRIDENTIFIER="46010381012****", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB;
      ```
   3. 执行**ADD PSRV**给用户签约业务。

      ```
      ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="PCEF_ADC_Establish", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
      ```

      ```
      ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="PCEF_ADC_Service", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
      ```

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
