---
id: ''
name: 检查信令软参数据一致性
ne_type: UPCF
type: feature
description: 在对容灾系统例行维护的过程中，指导操作人员检查主用UPCF和容灾UPCF之间的信令软参数据一致性。  信令软参数据不一致，容灾倒换后会出现业务异常。
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾维护","2*（FE+BE）主备地理容灾方案","容灾日常维护","检查数据一致性","检查信令软参数据一致性"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
在对容灾系统例行维护的过程中，指导操作人员检查主用UPCF和容灾UPCF之间的信令软参数据一致性。信令软参数据不一致，容灾倒换后会出现业务异常。

## 必备事项
前提条件

* 容灾系统已完成搭建。
* 主用UPCF和容灾UPCF的版本一致。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 在主用UPCF上，登录“UPCF MML命令”界面。

### 2 执行**LST INSP**，查询信令软参配置。

### 3 在容灾UPCF上，登录“UPCF MML命令”界面。

### 4 执行**LST INSP**，查询信令软参配置。

### 5 比较主用UPCF和容灾UPCF的信令软参查询结果是否完全一致。

#### 5.1 是 => 查询结束。

#### 5.2 否 => 执行**MOD INSP**命令修改不一致的数据。

