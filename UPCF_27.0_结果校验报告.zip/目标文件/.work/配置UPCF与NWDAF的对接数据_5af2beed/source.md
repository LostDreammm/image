# 配置UPCF与NWDAF的对接数据

* 操作场景
* 必备事项
* 操作步骤
* 验证方法

## 操作场景

当UPCF触发业务时，UPCF可以向NRF发送服务发现请求，或者配置静态方式发现NWDAF服务，进而实现通过N23接口向NWDAF下发订阅用户体验分析数据。

本页面用于指导配置UPCF与NWDAF之间N23接口的对接数据。

* 当UPCF与NWDAF直接对接时，具体对接配置请参考本章节。
* 当UPCF与NWDAF通过SCP间接通信时，具体对接配置请参考配置UPCF与SCP的对接数据。

## 必备事项

前提条件

* 已完成配置UPCF与NRF的对接数据（包含N5接口的服务配置）。具体请参见：UPCF产品文档 > 网络部署 > 初始配置 > UPCF初始配置与调测 > 初始配置与调测 > 配置UPCF对接数据 > 配置UPCF与NRF的对接数据。

  多FE组网下，若开启UPCF多逻辑实例功能（即“VRM\_MULTIPCFLOGICINSTSW”软参为“1”），则需要保证所有UPCF逻辑实例向NRF注册时，每个UPCF逻辑实例均需要配置相同的nfServices/nfServicesList。
* 已经获得运营商规划的UPCF与NWDAF的对接IP地址。

数据

配置前规划的对接数据如表1所示。

**表1** 对接数据规划

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **ADD HLBDEVADDR** | DEVAID （设备地址标识） | 5 | 本端规划，取值范围内不允许重复。 |
|  | VPNNAME（VPN名称） | VPN\_SBIChinaMobile\_SG | 本端规划，该参数需要与VNRS的****ADD L3VPNINST****和****ADD VPNINSTAF****命令中“VPN实例名称”参数值保持一致。 |
|  | IPVER（IP版本） | * IPV4 * IPV6 | 全网规划。 |
|  | IP （IPV4地址） | 10.100.100.156 | 全网规划。  当“IPVER”为“IPV4”时，此处规划的参数应为IPv4地址。 |
|  | HTTPSFUNC（HTTPS功能） | OFF | 本端规划，由运营商提供。 |
| **MOD INSP** | INSPN（参数名） | VRM\_SESSIONBACKUPSWITCH | 固定取值。 |
|  | INSPV（参数值） | 3 | 本端规划，开启会话备份功能。 |
|  | INSPN（参数名） | VRM\_N5SESSIONBACKUP | 固定取值。 |
|  | INSPV（参数值） | 1 | 本端规划，开启N5会话备份开关。 |
|  | INSPN（参数名） | VRM\_N23SWITCH | 固定取值。 |
|  | INSPV（参数值） | 1 | 本端规划，开启N23接口功能。 |
|  | INSPN（参数名） | VRM\_N23SESSIONBACKUP | 固定取值。 |
|  | INSPV（参数值） | 1 | 本端规划，开启N23会话备份开关。 |
|  | INSPN（参数名） | VRM\_N23BAKCOMPATIBILITYSW | 固定取值。 |
|  | INSPV（参数值） | 1 | 本端规划，开启N23独立会话备份开关。  说明：  * 新建局点：需要手动将该软参取值修改为“1”。 * 升级局点：当从低版本升级到UPCF 20.16.0及以上版本时，在FE主备局和BE主备局都升级完成后，需要手动将该软参取值修改为“1”。 |
|  | INSPN（参数名） | VRM\_N5VIRTUALMEDIA | 固定取值。 |
|  | INSPV（参数值） | 1 | 本端规划，用于控制N5会话是否支持只携带媒体部件medComponents，不携带媒体子部件medSubComps的N5会话自动申请虚拟媒体子部件。  说明：  重点业务保障中，当需要基于APP进行应用级下行保障时，要求N5会话携带媒体部件medComponents来触发专用承载时，可将本软参设置为“1”。 |
| **MOD INSP** | INSPN（参数名） | VRM\_N23HDPCFIDMODE | 固定取值。 |
|  | INSPV（参数值） | 1 | 本端规划，开启N23头域中填充subsPcfId开关。  说明：  * 若需要实施N23+N5的重点业务保障方案，引入华为PCF以触发N23订阅QoS\_ANALYSIS事件，NWDAF需与大网签约PCF（其他厂商PCF）通过N5接口进行重点业务保障交互，将该软件参数设置为“1”。 * 若不需要NWDAF与大网签约PCF（其他厂商PCF）通过N5接口进行重点业务保障交互，将该软件参数设置为“0”。 |
| **SET SBIDEVAUDIT** | SBITYPE（SBI接口类型） | N23 | 固定取值。 |
|  | PERIODICDATIME（ 周期性审计时长（m）） | 30 | 本端规划，设置N23接口的会话审计时长。  说明：  该值应小于NWDAF的N23会话老化时长。 |
| **MOD INSP** | INSPN（参数名） | VRM\_SYNTIMER | 固定取值。 |
|  | INSPV（参数值） | 1 | 本端规划，开启用户定时器持久化开关。 |
| **SET EDRREPORT** | ID（ID） | 1 | 固定取值。 |
|  | SWITCH（EDR上报特性列表） | N23SignalingEDR | 固定取值。 |
| **ADD DISCCONDCFG** | NFTYPE（网元类型） | NWDAF | 对端网元类型，此处固定为**NWDAF**。 |
|  | NWDAFPARASW（NWDAF参数） | TAI-1&EVENT-1  说明：  在海外异厂商PCF/PCRF场景下，智能PCF与NWDAF之间的服务发现条件不携带TAI，只需要勾选EVENT(EVENT)。 | 当前开启N23接口功能后，服务发现参数必须勾选EVENT(EVENT)，其余参数值由运营商根据实际需要勾选。 |
| **SET DISCNFTYPECFG** | NFTYPE（网元类型） | NWDAF | 固定取值。 |
|  | SWITCH（开关） | ON | 配置通过NWDAF网元类型进行服务发现。 |
| **SET NFDISCCFG** | SERVICETYPE（服务类型） | PES-NCS | 固定取值。 |
|  | NRFDISCSW（向NRF发起服务发现开关） | NWDAFDISC | 配置控制当本地缓存匹配NWDAF失败后，可以向NRF请求发现NWDAF服务。 |
| **ADD DISCNFPROFILE** | NFINSNAME（网元实例名称） | nwdaf01 | 用于标识一个服务发现网元实例的名称，该参数全局唯一，可参考样例填写。 |
|  | NFINSID（网元实例标识） | 6947a69a-f61b-4bc1-b9da-47c9c5d14b07 | 本端规划，由运营商提供。 |
|  | NFTYPE（网元类型） | NWDAF | 对端网元类型，此处固定为**NWDAF**。 |
|  | NFPROFILE（网元实例信息） | {\"nfServices\":[{\"versions\":[{\"apiVersionInUri\":\"v1\",\"apiFullVersion\":\"1.R15.0.0\"}],\"serviceInstanceId\":\"5947a69a-f61b-4bc1-b9da-47c9c5d01160\",\"serviceName\":\"***nnwdaf-eventssubscription***\",\"scheme\":\"http\",\"nfServiceStatus\":\"***REGISTERED***\",\"ipEndPoints\":[{\"ipv4Address\":\"***10.100.100.155***\",\"transport\":\"TCP\",\"port\":8080}],\"recoveryTime\":\"2019-07-26T12:33:24Z\",***\******"priority\":1***,\"capacity\":100}],\"nfInstanceId\":\"4947a69a-f61b-4bc1-b9da-47c9c5d01160\",\"nfType\":\"NWDAF\",\"nfStatus\":\"REGISTERED\",\"ipv4Addresses\":[\"***10.100.100.155***\"],\"recoveryTime\":\"2019-07-26T12:33:24Z\",\"nwdafInfo\":{\"nwdafEvents\":[\"QOS\_ANALYSIS\",\"QOS\_EXP\_ANALYSIS\"],\"taiList\":[{\"plmnId\":{\"mcc\":\"460\",\"mnc\":\"0000\"},\"tac\":\"372E7F\"}],\"taiRangeList\":[{\"plmnId\":{\"mcc\":\"460\",\"mnc\":\"0000\"},\"tacRangeList\":[{\"start\":\"372E80\",\"end\":\"372E85\"}]},{\"plmnId\":{\"mcc\":\"460\",\"mnc\":\"0000\"},\"tacRangeList\":[{\"start\":\"1200\",\"end\":\"12ff\"}]}]}} | * “网元类型”为“NWDAF”时，ipv4Address配置为NWDAF的IP地址，port配置为NWDAF的端口。 * 存在多个对端时，需要添加多个**ADD DISCNFPROFILE**网元实例记录，并通过“priority”来标识对端优先级。   说明：  * 若当前UPCF低于20.13.0版本，此时nwdafInfo需要配置nwdafEvents、taiList、taiRangeList。 * 若当前UPCF为20.13.0及以上版本，且该省份仅存在一个NWDAF设备商，且该设备商的NWDAF对所有的event和tai区域都能提供服务，此时建议所有的NWDAF不配置nwdafInfo；若该省份有两个不同厂商的NWDAF设备商，此时需要根据NWDAF的区域配置taiList和taiRangeList。 * “NFPROFILE（网元实例信息）”参数只需设置nwdafInfo，无需设置nwdafInfoList，同时需配置4G（4位16进制字符串）和5G（6位16进制字符串）的tac信息，且不能省略前导字符“0”，tac需合并到最少配置，不能直接配置为0000-ffff或000000-ffffff范围。 |
| **SET NFDISCCFG** | SERVICETYPE（服务类型） | PES-NCS | 固定取值。 |
|  | NRFDISCSW（向NRF发起服务发现开关） | 全部灰化 | 采取静态方式发现NWDAF服务时，固定取值。 |
| **ADD NFSERVICE** | GRPNAME（组名称） | SERVICE-PCF | 本端规划。 |
|  | SERVICEID（服务标识） | npcf-policyauthorization-1 | 本端规划，该参数全局唯一，不能重复。 |
|  | SERVICEINSTID（服务实例标识） | 6666a69a-f61b-4bc1-b9da-47c9c5d14b77 | 本端规划，该参数值需要使用UUID生成工具生成，工具需要联系华为技术支持获取。 |
|  | SERVICENAME（服务名称） | npcf-policyauthorization | 本端规划。  说明：  N5接口的“服务名称”固定配置为“npcf-policyauthorization”。 |
|  | NFSRVVERGRP（服务版本组名称） | SERVICE-PCF | 本端规划，该参数必须先由**ADD NFSRVVER**命令中的参数“组名称”定义，然后才能在此处引用。 |
|  | SCHEME（方案） | http | 本端规划，建议配置为http协议进行对接。 |
|  | STATUS（状态） | REGISTERED | 固定配置，标识UPCF正常注册到NRF。 |
|  | NFCOMINFOID（网元公共信息标识） | COMINFO-1 | 本端规划，参数由**ADD NFCOMINFO**命令定义，然后在此处引用。 |
| **MOD NFCOMINFO** | NFCOMINFOID（公共信息标识） | COMINFO-1 | 本端规划，参数由**LST NFCOMINFO**命令查询，然后在此处引用。 |
|  | CHECKIPADDR（IP地址校验开关） | YES | 本端规划。 |
|  | ALLOWEDNFTYPES（允许的网元类型） | 空格 | 本端规划，此参数填写为空格，表示UPCF与所有成功注册到对应NRF的网元均可对接。 |

## 操作步骤

1. 登录OM Portal界面，单击“应用管理 > MML”，在左上角的“网元/应用”下拉列表处，选择UPCF网元，进入“UPCF MML命令”界面。
2. 执行**ADD HLBDEVADDR**命令增加HLB服务用于与NWDAF对接的本端IP地址。

   ```
   ADD HLBDEVADDR: DEVAID=5, VPNNAME="VPN_SBIChinaMobile_SG", IPVER=IPV4, IP="10.100.100.156", HTTPSFUNC=OFF;
   ```

   UPCF配置用于与NWDAF对接的HLB设备地址对应的“设备地址标识”配置值需大于**LST HLBDEVADDR**中查询的所有值。若**LST HLBDEVADDR**中查询的“设备地址标识”值为“2”，则该步骤中的“DEVAID”值需大于“2”。
3. 执行**MOD INSP**命令，开启会话备份功能。

   ```
   /*开启会话备份功能*/
   MOD INSP:INSPN=VRM_SESSIONBACKUPSWITCH, INSPV=3;
   ```
4. 当配置重点业务保障的QoS加速策略时，需要执行如下命令，开启N5接口会话备份功能，否则跳过。

   体验感知场景下无需配置N5接口会话备份。

   ```
   /*开启N5会话备份开关*/
   MOD INSP:INSPN=VRM_N5SESSIONBACKUP, INSPV=1;
   ```
5. 执行以下命令，开启N23接口功能、会话备份开关、设备间的会话审计功能，并启动用户定时器持久化设置以及N23信令事件数据记录（EDR）功能。

   ```
   /*开启N23接口功能*/
   MOD INSP: INSPN=VRM_N23SWITCH, INSPV=1;
   /*开启N23会话备份开关*/
   MOD INSP:INSPN=VRM_N23SESSIONBACKUP, INSPV=1;
   /*开启N23会话独立备份开关*/
   MOD INSP:INSPN=VRM_N23BAKCOMPATIBILITYSW, INSPV=1;
   /*开启设备间N23会话审计*/
   SET SBIDEVAUDIT: SBITYPE=N23, PERIODICDATIME=30;
   /*开启用户定时器持久化开关*/
   MOD INSP: INSPN=VRM_SYNTIMER, INSPV=1;
   /*开启N23信令EDR*/
   SET EDRREPORT: ID=1, SWITCH=N23SignalingEDR-1;
   ```
6. 配置UPCF通过指定条件发现NWDAF服务。

   此处提供多种指定条件发现NWDAF服务，实际使用时，根据需求选择其中一种进行配置即可。

   * 配置通过TAI和EVENT发现NWDAF服务，请执行如下命令：

     ```
     ADD DISCCONDCFG: NFTYPE=NWDAF, NWDAFPARASW=TAI-1&EVENT-1;
     ```

     **确认NRF是否支持通过高铁事件类型发现NWDAF（如果NRF是华为NRF，则要求NRF版本不能低于USC 23.2.2.28）。**
     + **是，则无需执行额外步骤。**
     + **否，则****需要登录CSP OM Portal，在“UPCF MML”下执行如下命令。**

       ```
       MOD DISCCONDCFG: NFTYPE=NWDAF, NWDAFPARASW=EVENT-0;
       ```
   * 配置通过NWDAF网元类型进行服务发现，请执行如下命令：

     ```
     SET DISCNFTYPECFG: NFTYPE=NWDAF, SWITCH=ON;
     ```
7. 当UPCF需要向NRF发起服务发现时，执行SET NFDISCCFG命令，否则跳过。UPCF需要执行如下命令，向NRF发起服务发现。

   ```
   //当前配置控制当本地缓存匹配NWDAF失败后，可以向NRF请求发现NWDAF服务。
   SET NFDISCCFG: SERVICETYPE=PES-NCS, NRFDISCSW=NWDAFDISC-1;
   ```
8. 当UPCF仅采取静态方式发现NWDAF服务时，需要配置此命令，否则跳过。

   * 执行**ADD DISCNFPROFILE**命令，增加发现NWDAF网元的实例信息。

     + 当对端配置了多个IP和端口时，需要对应配置多条**ADD DISCNFPROFILE**命令，添加对应的网元实例信息，并通过“priority”来控制对端的优先级。“priority”取值越小，对端优先级越高。例如，“priority”取值相同时，对端为负荷分担工作模式，UPCF会轮选对端进行消息交互。
     + 若当前UPCF高于20.15.0版本，则支持配置NWDAF向NRF注册时携带的NwdafInfoList信元信息，用于匹配对接的NWDAF。
     + 在NRF/SCP二融合前，NRF不具备NWDAF对端处理能力，此时采用静态方式发现NWDAF服务。待后续NRF完成融合改造后，UPCF可参考步骤6向NRF发送服务发现请求，寻找NWDAF服务。

     ```
     //IPv4
     ADD DISCNFPROFILE: NFINSNAME="pcf_nwdaf", NFINSID="4947a69a-f61b-4bc1-b9da-47c9c5d01160", NFTYPE=NWDAF, NFPROFILE="{\"nfServices\":[{\"versions\":[{\"apiVersionInUri\":\"v1\",\"apiFullVersion\":\"1.R15.0.0\"}],\"serviceInstanceId\":\"5947a69a-f61b-4bc1-b9da-47c9c5d01160\",\"serviceName\":\"nnwdaf-eventssubscription\",\"scheme\":\"http\",\"nfServiceStatus\":\"REGISTERED\",\"ipEndPoints\":[{\"ipv4Address\":\"10.100.100.155\",\"transport\":\"TCP\",\"port\":8080}],\"recoveryTime\":\"2019-07-26T12:33:24Z\",\"priority\":1,\"capacity\":100}],\"nfInstanceId\":\"4947a69a-f61b-4bc1-b9da-47c9c5d01160\",\"nfType\":\"NWDAF\",\"nfStatus\":\"REGISTERED\",\"ipv4Addresses\":[\"10.100.100.155\"],\"recoveryTime\":\"2019-07-26T12:33:24Z\",\"nwdafInfo\":{\"nwdafEvents\":[\"QOS_ANALYSIS\",\"QOS_EXP_ANALYSIS\"],\"taiList\":[{\"plmnId\":{\"mcc\":\"139\",\"mnc\":\"08\"},\"tac\":\"ffffff\"}],\"taiRangeList\":[{\"plmnId\":{\"mcc\":\"460\",\"mnc\":\"00\"},\"tacRangeList\":[{\"start\":\"372E80\",\"end\":\"372E85\"}]},{\"plmnId\":{\"mcc\":\"460\",\"mnc\":\"0000\"},\"tacRangeList\":[{\"start\":\"1200\",\"end\":\"12ff\"}]}]}}";

     //IPv6
     ADD DISCNFPROFILE: NFINSNAME="pcf_nwdaf", NFINSID="4947a69a-f61b-4bc1-b9da-47c9c5d01160", NFTYPE=NWDAF, NFPROFILE="{\"nfServices\":[{\"versions\":[{\"apiVersionInUri\":\"v1\",\"apiFullVersion\":\"1.R15.0.0\"}],\"serviceInstanceId\":\"5947a69a-f61b-4bc1-b9da-47c9c5d01160\",\"serviceName\":\"nnwdaf-eventssubscription\",\"scheme\":\"http\",\"nfServiceStatus\":\"REGISTERED\",\"ipEndPoints\":[{\"ipv6Address\":\"FC00::10:1:20:1\",\"transport\":\"TCP\",\"port\":8080}],\"recoveryTime\":\"2019-07-26T12:33:24Z\",\"priority\":1,\"capacity\":100}],\"nfInstanceId\":\"4947a69a-f61b-4bc1-b9da-47c9c5d01160\",\"nfType\":\"NWDAF\",\"nfStatus\":\"REGISTERED\",\"ipv6Addresses\":[\"FC00::10:1:20:1\"],\"recoveryTime\":\"2019-07-26T12:33:24Z\",\"nwdafInfo\":{\"nwdafEvents\":[\"QOS_ANALYSIS\",\"QOS_EXP_ANALYSIS\"],\"taiList\":[{\"plmnId\":{\"mcc\":\"139\",\"mnc\":\"08\"},\"tac\":\"ffffff\"}],\"taiRangeList\":[{\"plmnId\":{\"mcc\":\"460\",\"mnc\":\"00\"},\"tacRangeList\":[{\"start\":\"372E80\",\"end\":\"372E85\"}]},{\"plmnId\":{\"mcc\":\"460\",\"mnc\":\"0000\"},\"tacRangeList\":[{\"start\":\"1200\",\"end\":\"12ff\"}]}]}}";
     ```

     当对接的NWDAF网元由华为提供时，可参考表2 网元实例信息参数与华为NWDAF网元配置命令对应关系表中的对应关系，查询实际的NWDAF网元实例信息并根据情况对样例进行修改。

     “NFPROFILE（网元实例信息）”参数只需设置nwdafInfo，无需设置nwdafInfoList，同时需配置4G（4位16进制字符串）和5G（6位16进制字符串）的tac信息，且不能省略前导字符“0”，tac需合并到最少配置，不能直接配置为0000-ffff或000000-ffffff范围。

     **表2** 网元实例信息参数与华为NWDAF网元配置命令对应关系表

     | 网元实例信息参数 | 对应的NWDAF网元命令 | 对应的NWDAF网元命令参数 | 配置说明 |
     | --- | --- | --- | --- |
     | nfInstanceId | 查询NF UUID信息（LST NFUUID） | NF实例标识 | - |
     | nfType | 查询NF UUID信息（LST NFUUID） | NF类型 | 配置为固定值“NWDAF”。 |
     | nfStatus | 查询NF实例概述信息（LST NFPROFILE） | NF状态 | - |
     | ipv4Addresses | 查询HTTP本端实体（LST HTTPLE） | IPv4地址 | 配置为查询结果中服务端的IPv4地址。 |
     | ipv6Addresses | 查询HTTP本端实体（LST HTTPLE） | IPv6地址 | 配置为查询结果中服务端的IPv6地址。 |
     | capacity | 查询NF实例概述信息（LST NFPROFILE） | 容量 | - |
     | nfServices |  |  |  |
     | >serviceInstanceId | 查询NF服务版本信息（LST NFSERVICE） | 服务实例标识 | - |
     | >serviceName | - | - | 配置为固定值“nnwdaf-eventssubscription”，该值与协议中的定义保持一致。 |
     | >versions |  |  |  |
     | >>apiVersionInUri | - | - | 配置为固定值“v1”。 |
     | >>apiFullVersion | 查询NF服务版本信息（LST NFSERVICEVER） | API版本信息 | - |
     | >scheme | 查询NF服务实例（LST NFSERVICE） | Scheme | 配置为固定值“http”。 |
     | >nfServiceStatus | 查询NF服务实例（LST NFSERVICE） | 服务实例状态 | - |
     | >ipEndPoints |  |  |  |
     | >>ipv4Address | 查询HTTP本端实体（LST HTTPLE） | IPv4地址 | 配置为查询结果中服务端的IPv4地址。 |
     | >>ipv6Address | 查询HTTP本端实体（LST HTTPLE） | IPv6地址 | 配置为查询结果中服务端的IPv6地址。 |
     | >>transport | - | - | 配置为固定值“TCP”。 |
     | >>port | 查询HTTP本端实体（LST HTTPLE） | 端口号 | - |
     | >priority | 查询NF服务实例（LST NFSERVICE） | 优先级 | - |
     | >capacity | 查询NF服务实例（LST NFSERVICE） | 容量 | - |
     | >recoveryTime | - | - | 配置为小于当前的时间即可，参考样例：2024-09-13T15:29:12+08:00。 |
     | >load | 查询NF服务实例（LST NFSERVICE） | 负载 | - |
     | nwdafInfo |  |  |  |
     | >nwdafEvents | 查询NWDAF信息（LST NWDAFINFO） | NWDAF数据分析事件 | 查询出来的参数值填写网元实例时，需要进行如下转换：  + “QOS分析”转化为“QOS\_ANALYSIS”。 + “体验感知信息分析”转化为“QOS\_EXP\_ANALYSIS”。 如遇到多个NWDAF数据分析事件需要参考如下样例填写：\"QOS\_ANALYSIS\",\"QOS\_EXP\_ANALYSIS\" |
     | >taiList |  |  |  |
     | >>plmnId |  |  |  |
     | >>>mcc | 查询NF TAI信息（LST NFTAI） | 移动国家代码 | - |
     | >>>mnc | 查询NF TAI信息（LST NFTAI） | 移动网号 | - |
     | >>tac | 查询NF TAI信息（LST NFTAI） | 跟踪区域码 | - |
     | >taiRangeList |  |  |  |
     | >>plmnId |  |  |  |
     | >>>mcc | 查询NF TAI区域信息（LST TAIRANGELIST） | 移动国家代码 | - |
     | >>>mnc | 查询NF TAI区域信息（LST TAIRANGELIST） | 移动网号 | - |
     | >tacRangeList |  |  |  |
     | >>>start | 查询NF TAC区域信息（LST TACRANGE） | TAC区域起点值 | - |
     | >>>end | 查询NF TAC区域信息（LST TACRANGE） | TAC区域结束值 | - |
     | priority | 查询NF实例概述信息（LST NFPROFILE） | 优先级 | - |
     | load | 查询NF实例概述信息（LST NFPROFILE） | 负载 | - |

   * 执行**SET NFDISCCFG**命令，确保当本地缓存匹配NWDAF失败后，也不向NRF发起动态服务发现。

     ```
     SET NFDISCCFG: SERVICETYPE=PES-NCS, NRFDISCSW=NWDAFDISC-0;
     ```
9. 当配置重点业务保障的QoS加速策略时，需要执行如下命令，UPCF向NRF注册N5接口服务名。

   ```
   ADD NFSRVVER: GRPNAME="SERVICE-PCF", INDEX=2, APIVERSIONINURI="v1", APIFULLVERSION="1.0.0";
   ADD NFSERVICE: GRPNAME="SERVICE-PCF", SERVICEID="npcf-policyauthorization-1", SERVICEINSTID="6666a69a-f61b-4bc1-b9da-47c9c5d14b77", SERVICENAME=npcf-policyauthorization, NFSRVVERGRP="SERVICE-PCF", SCHEME=http, STATUS=REGISTERED, NFCOMINFOID="COMINFO-1";
   ```
10. 执行**LST NFCOMINFO**命令，查询“允许的网元类型”的值是否为“NULL”。

    ```
    LST NFCOMINFO:;
    ```

    * 是 =>结束。
    * 否 =>执行**MOD NFCOMINFO**命令修改“允许的网元类型”的值为空格。

      ```
      MOD NFCOMINFO: NFCOMINFOID="COMINFO-1", CHECKIPADDR=YES, ALLOWEDNFTYPES=" ";
      ```

## 验证方法

1. 进入“MML命令行-UPCF”窗口，进行N23接口的调测。
2. 执行**NGPING**命令，查看UPCF与NWDAF之间的逻辑接口IP能否互通。

   ```
   //IPv4
   NGPING: IPTYPE=IPv4, VPNNAME="VPN_SBIChinaMobile_SG", SRCIPV4ADDR="UPCF的N23接口IP", DSTIPV4ADDR="NWDAF的Nnwdaf接口IP";
   ```

   ```
   //IPv6
   NGPING: IPTYPE=IPv6, VPNNAME="VPN_SBIChinaMobile_SG", SRCIPV6ADDR="UPCF的N23接口IP", DSTIPV6ADDR="NWDAF的Nnwdaf接口IP";
   ```

   * **预期结果**：如果收到NWDAF的响应且响应报文中有成功收发包的个数，表明N23接口连接正常，执行6。
   * **异常结果**：如果连续出现timeout，表明连接异常，请执行3。
3. 执行**PING**命令，查看UPCF与NWDAF的外联口IP能否互通。

   ```
   //IPv4
   PING:IPVERSION=IPv4,VPNNAME="VPN_SBIChinaMobile_SG",SOURCEIPV4ADDRESS="UPCF Nnwdaf对应的外联口IP",DESTIPV4ADDRESS="NWDAF Nnwdaf逻辑接口对应的外联口IP";
   ```

   ```
   //IPv6
   PING: IPVERSION=IPv6, VPNNAME="VPN_SBIChinaMobile_SG", SOURCEIPV6ADDRESS="UPCF Nnwdaf对应的外联口IP", DESTIPV6ADDRESS="NWDAF Nnwdaf逻辑接口对应的外联口IP";
   ```

   * 如果收到NWDAF的响应且响应报文中有成功收发包的个数，请执行4。
   * 如果连续出现timeout，表明连接异常，请执行5。
4. 检查直连路由器上是否存在到UPCF（Nnwdaf接口IP）的路由，下一跳是外联口IP。
   * 是，请执行5。
   * 否，请联系路由器工程师，增加相关路由后执行5。
5. 请参考UPCF 产品文档> 初始配置与调测 > 配置基础数据进行调测，修正配置后请重新从2开始执行。
   * 如果收到NWDAF的响应且响应报文中有成功收发包的个数，表明N23接口连接正常，执行6。
   * 如果连续出现timeout，请执行11。
6. 进入“MML命令行-UPCF”窗口，进行N5接口的调测。
7. 执行**NGPING**命令，查看UPCF与NWDAF之间的逻辑接口IP能否互通。

   ```
   //IPv4
   NGPING: IPTYPE=IPv4, VPNNAME="VPN_SBIChinaMobile_SG", SRCIPV4ADDR="UPCF的N5接口IP", DSTIPV4ADDR="NWDAF的Npcf接口IP";
   ```

   ```
   //IPv6
   NGPING: IPTYPE=IPv6, VPNNAME="VPN_SBIChinaMobile_SG", SRCIPV6ADDR="UPCF的N5接口IP", DSTIPV6ADDR="NWDAF的Npcf接口IP";
   ```

   * **预期结果**：如果收到NWDAF的响应且响应报文中有成功收发包的个数，表明连接正常，调测结束。
   * **异常结果**：如果连续出现timeout，表明连接异常，请执行8。
8. 执行**PING**命令，查看UPCF与NWDAF的外联口IP能否互通。

   ```
   //IPv4
   PING:IPVERSION=IPv4,VPNNAME="VPN_SBIChinaMobile_SG",SOURCEIPV4ADDRESS="UPCF Npcf对应的外联口IP",DESTIPV4ADDRESS="NWDAF Npcf逻辑接口对应的外联口IP";
   ```

   ```
   //IPv6
   PING: IPVERSION=IPv6, VPNNAME="VPN_SBIChinaMobile_SG", SOURCEIPV6ADDRESS="UPCF Npcf对应的外联口IP", DESTIPV6ADDRESS="NWDAF Npcf逻辑接口对应的外联口IP";
   ```

   * 如果收到NWDAF的响应且响应报文中有成功收发包的个数，请执行9。
   * 如果连续出现timeout，表明连接异常，请执行10。
9. 检查直连路由器上是否存在到UPCF（Npcf接口IP）的路由，下一跳是外联口IP。
   * 是，请执行10。
   * 否，请联系路由器工程师，增加相关路由后执行10。
10. 请参考UPCF 产品文档> 初始配置与调测 > 配置基础数据进行调测，修正配置后请重新从7开始执行。
    * 如果收到NWDAF的响应且响应报文中有成功收发包的个数，表明连接正常，调测结束。
    * 如果连续出现timeout，请执行11。
11. 收集信息并寻求技术支持。
    1. 在“MML命令行-CSP”窗口上执行**EXP MML**命令将当前配置数据导出为MML脚本文件并保存。
    2. 收集并保存上述所有查询信息。
    3. 查看并收集对端设备配置及接口状态信息。
    4. 收集归纳所有信息并联系华为技术支持解决。

版权所有 © 华为技术有限公司
