---
id: ''
name: 基于使用量的动态策略控制（调整带宽）（5G）
ne_type: UPCF
type: feature
description: 当5G用户在一个周期内（如日、周、月）的使用量达到某个阈值时，运营商可调整用户的访问带宽。  以典型的上网流量包月业务，UPCF对接华为UNC为例：  * 配额为200GB。 * 每月1号01:00:00进行配额复位，剩余配额采用清零方式。 * 带宽控制：   + 当配额消耗小于60%时，上行带宽为100 Mbit/s，下行带宽为200 Mbit/s。   + 当配额消耗大于等于60%但小于100%时，上行带宽降为40 Mbit/s，下行带宽降为80 Mbit/s。   + 当配额消耗大于等于100%时，上行带宽降为10 Mbit/s，下行带宽降为20 Mbit/s。 * UPCF进行配额累积。 * 不配置消息通知。 * 配置动态规则。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611001 基于使用量的动态策略控制","WHFD-611001 基于使用量的动态策略控制特性配置","基于使用量的动态策略控制（调整带宽）（5G）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当5G用户在一个周期内（如日、周、月）的使用量达到某个阈值时，运营商可调整用户的访问带宽。以典型的上网流量包月业务，UPCF对接华为UNC为例：* 配额为200GB。* 每月1号01:00:00进行配额复位，剩余配额采用清零方式。* 带宽控制：  + 当配额消耗小于60%时，上行带宽为100 Mbit/s，下行带宽为200 Mbit/s。  + 当配额消耗大于等于60%但小于100%时，上行带宽降为40 Mbit/s，下行带宽降为80 Mbit/s。  + 当配额消耗大于等于100%时，上行带宽降为10 Mbit/s，下行带宽降为20 Mbit/s。* UPCF进行配额累积。* 不配置消息通知。* 配置动态规则。

## 必备事项
前提条件

操作员已了解WHFD-611001 基于使用量的动态策略控制特性概述，且通过4G/5G业务配置差异介绍已经了解5G规则配置原理。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: '12345678901'
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: eMBB-SA
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: 5GFUP_Service
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录UPCF Web UI界面。

### 2 配置配额。

### 导航入口为“业务管理 > 业务 > 配额”。

### 配额（Quota）是指一个指定周期内供用户使用的流量或时长额度，也可指单个会话内供用户使用的时长额度。当业务的使用与流量、时长相关时，需要配置配额。

### 配额的数据规划如表2所示，详细参数说明请参见配额参数表。

### **表2** 配额

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 配额 | 基本信息 | 名称 | 5GFUP\_Quota |

### |  |  | 配额管理归属 | UPCC |

### |  |  | 配额类型 | 流量 |

### |  |  | 类型 | 会话级 |

### |  |  | 监控键值 | 101 |

### |  |  | 值(KB) | 209,715,200 |

### |  |  | 分片类型 | 百分比 |

### |  |  | 分片(%) | 10 |

### |  | 复位设置 | 结帐模式 | 自然日历 |

### |  |  | 复位周期类型 | 月 |

### |  |  | 复位日 | 1 |

### |  |  | 复位时间 | 01:00:00 |

### |  |  | 剩余额处理方式 | 清零 |

### |  | 阈值设置 | Level1(%) | 60 |

### 3 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 需要配置三个条件组，用于判断配额消耗小于60%，大于等于60%但未耗尽或配额耗尽。条件组的数据规划如表3所示，详细参数说明请参见条件组参数表。

### **表3** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | 5G\_CG\_Basic |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | 5G\_CG |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | 5GFUP\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Normal  说明：  “Normal”：表示配额消耗小于Level1。 |

### | 条件组2 | 基本信息 | 名称 | 5G\_CG\_Change1 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | 5G\_CG1 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | 5GFUP\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Level1  说明：  “Level1”：表示配额消耗大于等于Level1、但未耗尽。 |

### | 条件组3 | 基本信息 | 名称 | 5G\_CG\_Change2 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | 5G\_CG2 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | 5GFUP\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示配额耗尽。 |

### 4 配置5G动作组。

### 导航入口为“策略管理 > 策略 > 5G动作组”。

### 此场景配置5G动作组需要考虑流信息、业务流开关、流量上报和带宽调整，则需配置动作：FlowInformation、TrafficControlData、UsageMonitoringData和QoSData。相关应用场景如下：

### FlowInformation：当需要下发流信息时需配置此动作。

### TrafficControlData：当需要做门限控制时，配置此动作。在下发流描述时，如果不配默认为放通该流，当需要限制流时，此动作必须配置。

### UsageMonitoringData：当需要进行流量上报时，配置此动作。

### QoSData：当需要进行带宽控制时，配置此动作。

### 需要配置三个“DynamicPccRule”类型的5G动作组，分别用于在配额消耗小于60%，大于等于60%但未耗尽或配额耗尽时动作的下发。动作组的数据规划如表4所示，详细参数说明请参见动作组参数表。

### **表4** 5G动作组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 5G动作组1 | 基本信息 | 名称 | AG1\_FlowDesc |

### |  |  | 类型 | FlowDescription |

### |  | 属性 | action | * 类型：Value * 值：PERMIT |

### |  |  | direction | * 类型：Value * 值：OUT |

### |  |  | protocol | * 类型：Value * 值：ANY |

### |  |  | sourceIP | * 类型：Value * 值：any |

### |  |  | destinationIP | * 类型：Value * 值：any |

### | 5G动作组2 | 基本信息 | 名称 | AG2\_FlowInfo |

### |  |  | 类型 | FlowInformation |

### |  | 属性 | flowDescription | * 类型：Reference ActionGroup * 值：AG1\_FlowDesc  说明：  已在5G动作组中定义。 |

### |  |  | flowDirection | * 类型：Value * 值：BIDIRECTIONAL |

### | 5G动作组3 | 基本信息 | 名称 | AG3\_arp |

### |  |  | 类型 | Arp |

### |  | 属性 | priorityLevel | * 类型：Object Attribute * 值：SmfSession.SubsDefQosPriorityLevel |

### |  |  | preemptCap | * 类型：Value * 值：NOT\_PREEMPT |

### |  |  | preemptVuln | * 类型：Value * 值：NOT\_PREEMPTABLE |

### | 5G动作组4 | 基本信息 | 名称 | AG4\_usg |

### |  |  | 类型 | UsageMonitoringData |

### |  | 属性 | umId | * 类型：Value * 值：101  说明：  已在配额中定义。 |

### |  |  | volumeThreshold | * 类型：Value * 值：20480000 |

### | 5G动作组5 | 基本信息 | 名称 | AG5\_TraCtrl |

### |  |  | 类型 | TrafficControlData |

### |  | 属性 | tcId | * 类型：Value * 值：AG5\_TraCtrl |

### |  |  | flowStatus | * 类型：Value * 值：ENABLED |

### | 5G动作组6 | 基本信息 | 名称 | 5G\_AG\_Basic |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：5G\_AG\_Basic |

### |  |  | 5qi | * 类型：Object Attribute * 值：SmfSession.SubsDefQos5qi |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG3\_arp  说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：100 Mbps |

### |  |  | maxbrDl | * 类型：Value * 值：200 Mbps |

### | 5G动作组7 | 基本信息 | 名称 | 5G\_AG\_Change1 |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：5G\_AG\_Change1 |

### |  |  | 5qi | * 类型：Object Attribute * 值：SmfSession.SubsDefQos5qi |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG3\_arp  说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：40 Mbps |

### |  |  | maxbrDl | * 类型：Value * 值：80 Mbps |

### | 5G动作组8 | 基本信息 | 名称 | 5G\_AG\_Change2 |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：5G\_AG\_Change2 |

### |  |  | 5qi | * 类型：Object Attribute * 值：SmfSession.SubsDefQos5qi |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG3\_arp  说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：10 Mbps |

### |  |  | maxbrDl | * 类型：Value * 值：20 Mbps |

### | 5G动作组9 | 基本信息 | 名称 | AG\_pccRule1 |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：AG\_pccRule1 |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG2\_FlowInfo 说明：  已在5G动作组中定义。 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Basic 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG5\_TraCtrl 说明：  已在5G动作组中定义。 |

### |  |  | refUmData | * 类型：Reference ActionGroup * 值：AG4\_usg 说明：  已在5G动作组中定义。 |

### | 5G动作组10 | 基本信息 | 名称 | AG\_pccRule2 |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：AG\_pccRule2 |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG2\_FlowInfo 说明：  已在5G动作组中定义。 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Change1 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG5\_TraCtrl 说明：  已在5G动作组中定义。 |

### |  |  | refUmData | * 类型：Reference ActionGroup * 值：AG4\_usg 说明：  已在5G动作组中定义。 |

### | 5G动作组11 | 基本信息 | 名称 | AG\_pccRule3 |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：AG\_pccRule3 |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG2\_FlowInfo 说明：  已在5G动作组中定义。 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Change2 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG5\_TraCtrl 说明：  已在5G动作组中定义。 |

### |  |  | refUmData | * 类型：Reference ActionGroup * 值：AG4\_usg 说明：  已在5G动作组中定义。 |

### 5 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 规则的数据规划如表5所示，详细参数说明请参见规则参数表。

### **表5** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | 5GRule\_Basic |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | 5G\_CG\_Basic  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_pccRule1  说明：  已在5G动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | 5GRule\_Change1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | 5G\_CG\_Change1  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_pccRule2  说明：  已在5G动作组中定义。 |

### | 规则3 | 基本信息 | 名称 | 5GRule\_Change2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | 5G\_CG\_Change2  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_pccRule3  说明：  已在5G动作组中定义。 |

### 6 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表6所示，详细参数说明请参见策略参数表。

### **表6** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略 | 基本信息 | 名称 | 5GPolicy\_usage |

### |  |  | 策略类型 | N7 Policy |

### |  | 触发器 | 名称 | * IPCAN\_EST * US\_RE |

### |  | 规则 | 名称 | * 5GRule\_Basic * 5GRule\_Change1 * 5GRule\_Change2 说明：  已在规则中定义。 |

### 7 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

### 业务的数据规划如表7所示，详细参数说明请参见业务参数表。

### **表7** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | 5GFUP\_Service |

### |  |  | 类型 | BASIC\_SERVICE |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | 5GPolicy\_usage  说明：  已在策略中定义。 |

### |  | 配额 | 名称 | 5GFUP\_Quota  说明：  已在配额中定义。 |

### 8 登录“UPCF 业务管理”窗口。

### 9 发放业务。

#### 9.1 执行**ADD PSUB**增加一个用户。

#### “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=9.1 -->
```

#### 9.2 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=9.2 -->
```

