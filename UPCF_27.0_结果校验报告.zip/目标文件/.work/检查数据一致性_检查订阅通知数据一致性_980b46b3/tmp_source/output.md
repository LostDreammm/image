---
id: ''
name: 检查订阅通知数据一致性
ne_type: UPCF
type: feature
description: 在对容灾系统例行维护的过程中，指导操作人员检查主用UPCF和容灾UPCF之间的订阅通知数据一致性。  订阅通知数据不一致，将导致容灾倒换后业务发放系统指令触发的插入用户数据操作异常。
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾维护","2*（FE+BE）主备地理容灾方案","容灾日常维护","检查数据一致性","检查订阅通知数据一致性"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
在对容灾系统例行维护的过程中，指导操作人员检查主用UPCF和容灾UPCF之间的订阅通知数据一致性。订阅通知数据不一致，将导致容灾倒换后业务发放系统指令触发的插入用户数据操作异常。

## 必备事项
前提条件

容灾系统已完成搭建。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 在主用UPCF上，登录“USCDB MML命令”界面。

### 2 执行**LST NOTIFYCFG**命令查询订阅通知数据配置。

### 3 在容灾UPCF上，登录“USCDB MML命令”界面。

### 4 执行**LST NOTIFYCFG**命令查询订阅通知数据配置。

### 5 比较主用UPCF和容灾UPCF的订阅通知数据查询结果是否完全一致。

#### 5.1 是 => 查询结束。

#### 5.2 否 => 手工修正不一致的数据。

### 手工修正不一致的数据分为如下两种情况：

#### 5.3 订阅通知数据配置错误：需要在容灾UPCF先执行**RMV NOTIFYCFG**命令删除配置错误的订阅通知数据，再执行**ADD NOTIFYCFG**命令重新配置。

#### 5.4 订阅通知数据漏配：在容灾UPCF执行**ADD NOTIFYCFG**命令添加漏配的数据。

