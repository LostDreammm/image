# 配置UPCF基础数据

* 操作场景
* 必备事项
* 操作流程
* 操作步骤

## 操作场景

开局的情况下，配置UPCF基础数据。

## 必备事项

前提条件

执行操作前准备工作如下：

* 已完成软件安装。
* 已获取网元的模块配置信息。
* 已经获取运营商规划的IP地址。

数据

执行操作前规划的数据如表1所示。

**表1** 基础数据

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **SET FESN** | SN（FE序号） | 0 | * 单FE组网下FE序号设置为0。 * 多FE合一组网下FE序号由工程设计输出。 |
| **ADD PCRF** | PCRFID（PCRF标识） | 1 | 固定取值为“1”。 |
|  | DN（本地域名） | huawei.com | 全网规划，由运营商提供。 |
|  | HN（本地主机名） | upcf01.huawei.com | 全网规划，由运营商提供。 |
| **SET DBSLOCATION** | LOCID（Location标识） | 241 | 自定义。Location标识在以下网元中需要配置：主用局FE、主用局USCDB、容灾局FE、容灾局USCDB。 |
| **ADD DBSIPADDR** | DBSIPINDEX（Dbbroker IP索引） | 1 | 由运营商统一规划。 |
|  | IPVER（IP类型） | IPV4 | 由运营商统一规划。  当“IPVER”为“IPV4”时，才会规划：   * 本地Location IPV4地址1 * 本地Location IPV4网关1 * 本地Location IPV4子网掩码1   当“IPVER”为“IPV6”时，才会规划：   * 本地Location IPV6地址1 * 本地Location IPV6网关1 * 本地Location IPV6前缀长度1 |
|  | IP1VPNNAME（IP地址1的VPN名称） | VRF\_CC\_DATA | 仅当本命令中的“IP类型”参数取值有效时该参数有效。用于指定“本地Location IPV4地址1”或“本地Location IPV6地址1”的VPN名称，必须由**ADD L3VPNINST**、**ADD VPNINSTAF**和**ADD AUTOSCALINGSERVICE**命令定义后才能在此处引用。 |
|  | IPV4IP1（本地Location IPV4地址1） | 10.0.27.98 | 仅当本命令中的“IP类型”参数取值为“IPV4”时该参数有效。用于指定IPV4类型的本地IP地址。 |
|  | IPV4IP2（本地Location IPV4地址2） | 10.0.27.99 |  |
|  | IPV4MASK1（本地Location IPV4子网掩码1） | 255.255.255.255 | 仅当本命令中的“IP类型”参数取值为“IPV4”时该参数有效。用于指定本地IP地址的子网掩码。 |
|  | IPV4MASK2（本地Location IPV4子网掩码2） | 255.255.255.255 |  |
| **ADD HLBDEVADDR** | DEVAID（设备地址标识） | 1 | 本端规划，取值范围内不允许重复。 |
|  | VPNNAME（VPN名称） | VRF\_SIG | 由运营商统一规划。 |
|  | IPVER（IP版本） | IPV4 | 由运营商统一规划。  当“IPVER”为“IPV4”时，才会规划IPV4地址。  当“IPVER”为“IPV6”时，才会规划IPV6地址。 |
|  | IP（IPV4地址） | 10.30.14.150 | 由运营商统一规划。 |
|  | HTTPSFUNC（HTTPS功能） | OFF | 本端规划，由运营商提供。 |
|  | TOEDGE（对接边缘） | NO | 本端规划，由运营商提供。 |
| **ADD PMSVPN** | VPNINDEX（VPN索引） | 1 | 由运营商统一规划。 |
|  | VPNNAME（VPN名称） | VRF\_OM | 由运营商统一规划。 |
| **ADD PMSDEVADDR** | DEVAID（设备地址标识） | 3 | 本端规划，取值范围内不允许重复。 |
|  | VPNINDEX（VPN索引） | 3 | 由运营商统一规划。 |
|  | IPVER（IP版本） | IPV4 | 由运营商统一规划。  当“IPVER”为“IPV4”时，才会规划IPV4地址。  当“IPVER”为“IPV6”时，才会规划IPV6地址。 |
|  | IP（IPV4地址） | 10.208.106.90 | 由运营商统一规划。 |
| **ADD DLBVPN** | VPNINDEX（VPN索引） | 4 | 由运营商统一规划。 |
|  | VPNNAME（VPN名称） | VRF\_SIG | 由运营商统一规划。 |
| **ADD DLBDEVADDR** | DEVAID（设备地址标识） | 4 | 本端规划，取值范围内不允许重复。 |
|  | VPNINDEX（VPN索引） | 4 | 由运营商统一规划。 |
|  | IPVER（IP版本） | IPV4 | 由运营商统一规划。  当“IPVER”为“IPV4”时，才会规划IPV4地址。  当“IPVER”为“IPV6”时，才会规划IPV6地址。 |
|  | IP（IPV4地址） | 10.208.106.91 | 由运营商统一规划。 |
| **SET SDRTRANS** | FLATTYPE（通信平面类型） | FABRIC | 指定对应的网络平面，此处固定配置为FABRIC。 |
|  | TRANSABILITY（传输能力类型） | RELIABILITY | 标识SDR的传输能力类型，此处固定配置为RELIABILITY。 |
|  | OPT（选项开关） | NOTSET | 标识SDR传输能力的选项开关，此处固定配置为NOTSET。 |
| **MOD INSP** | INSPN（软参名） | VRM\_N15COMPATIBILITYSWITCH | 当新建局点时，需要手动将该软参取值修改为“1”。 |
|  | INSPV（软参值） | 1 |  |
|  | INSPN（软参名） | VRM\_SRVTOKENNUM | 当新建局点时，需要手动将该软参取值修改为“32768”。 |
|  | INSPV（软参值） | 32768 |  |
| **MOD COMPATSWITCH** | SWNAME（参数名） | LockSwitch | 当新建局点时，需要手动将该软参取值修改为“0”。 |
|  | SWVALUE（参数值） | 0 |  |

## 操作流程

配置UPCF的基础数据的流程如图1所示。

**图1** 配置基础数据流程图

## 操作步骤

1. 登录OM Portal Web MML界面，在“应用管理>MML”中选择“UPCF”网元。
2. 执行**SET FESN**命令，设置FE序号。

   ```
   SET FESN: SN=0;
   ```
3. 执行**ADD PCRF**命令增加PCRF实体。

   ```
   ADD PCRF: PCRFID=1, DN="huawei.com", HN="upcf01.huawei.com";
   ```

   网元安装完成后，未进行**ADD PCRF**初始配置时：
   * 产生“ALM-100595 进程状态未就绪”告警，告警参数中的“进程名称”为“CELL\_PcfOtes”或者“CELL\_PcfOtcs”，是正常现象，添加**ADD PCRF**配置后OTES或者OTCS服务正常。
   * 登录OM Portal，选择“应用管理 > MML”，进入MML命令界面。选择UPCF网元，执行如下命令，查看OTES或者OTCS服务“进程状态”为非“Ready（就绪状态）”是正常现象，添加**ADD PCRF**配置后OTES或者OTCS服务正常。

     ```
     DSP MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_PcfOtes";
     DSP MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_PcfOtcs";
     ```
4. 执行**ADD PCRF**命令后，需要重启HLB、DLB、PES和DUS服务。

   1. 登录“OM Portal”，在CSP网元下，执行**DSP POD**命令，查询pcf中的所有Pod类型。

      命令示例如下：

      ```
      DSP POD: TYPE=byType, PODTYPE="pcf";
      ```
   2. 执行**RST POD**命令，重启HLB、DLB、PES和DUS服务对应的Pod。

      重启虚拟机Pod命令示例如下：

      ```
      /*重启HLB、DLB、DUS服务，如果没有部署SRV-L虚拟机，则无需复位pcf-srvl1-pod231和pcf-srvl2-pod231*/
      RST POD: TYPE=byType, PODTYPE="pcf-srvl1-pod231", FORCEFLAG=true, MEID="20";
      RST POD: TYPE=byType, PODTYPE="pcf-srvl2-pod231", FORCEFLAG=true, MEID="20";
      RST POD: TYPE=byType, PODTYPE="pcf-srvr1-pod231", FORCEFLAG=true, MEID="20";
      RST POD: TYPE=byType, PODTYPE="pcf-srvra-pod231", FORCEFLAG=true, MEID="20";
      RST POD: TYPE=byType, PODTYPE="pcf-srvrb-pod231", FORCEFLAG=true, MEID="20";
      /*重启PES服务*/
      RST POD: TYPE=byType, PODTYPE="pcf-srvs-pod231", FORCEFLAG=true, MEID="20";
      ```

      重启裸机Pod命令示例如下：

      ```
      /*重启HLB、DLB、DUS、PES服务*/
      RST POD: TYPE=byType, PODTYPE="dus-pod231", FORCEFLAG=true, MEID="20";
      RST POD: TYPE=byType, PODTYPE="pcf-link-pod231", FORCEFLAG=true, MEID="20";
      RST POD: TYPE=byType, PODTYPE="pcf-srvs-pod231", FORCEFLAG=true, MEID="20";
      ```
   3. 执行**DSP POD**命令查询Pod是否已经恢复：

      ```
      DSP POD: TYPE=byType, PODTYPE="pcf";
      ```
   4. 在USCDB网元下，执行**CLR CLUSTER**命令，清除Session备份数据。

      命令示例如下：

      ```
      CLR CLUSTER: SERVICETYPE="UPCF-SESSION";
      ```
5. 执行如下命令配置dbbroker信息，用于微服务和USCDB对接。

   ```
   SET DBSLOCATION: LOCID=241;
   RST MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_UdrDbbroker";
   DSP MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_UdrDbbroker";
   ADD DBSIPADDR:DBSIPINDEX=1, IP1VPNNAME="VRF_CC_DATA", IP2VPNNAME="VRF_CC_DATA", IPV4IP1="10.0.27.98", IPV4IP2="10.0.27.99", IPV4MASK1="255.255.255.255", IPV4MASK2="255.255.255.255", IPVER=IPV4;
   ```
6. 执行**ADD HLBDEVADDR**命令配置HLB IP，用于和SMF网元通信。

   * DEVAID自定义，IP地址参考LLD设计文档 ->业务IP对接设计页签 -> 业务接口IP，选择HTTP信令平面规划的IP地址。
   * VPNNAME为5G信令面VPN，对应CSLB配置信令面的VPN名称。
   * 如果需要配置HLB数字证书，请在完成基础数据配置后，参考配置HLB数字证书章节进行操作。

   ```
   ADD HLBDEVADDR: DEVAID=1, VPNNAME="VRF_SIG", IPVER=IPV4, IP="10.30.14.150", HTTPSFUNC=OFF, TOEDGE=NO;
   ```
7. 执行如下命令配置PMS IP，用于配置策略数据。

   DEVAID和VPNINDEX自定义，**ADD PMSVPN**与**ADD PMSDEVADDR**中的VPNINDEX取值需要一致。IP地址参考LLD设计文档 ->业务IP对接设计页签 -> 业务接口IP，选择PMS维护平面的IP地址。

   ```
   ADD PMSVPN: VPNINDEX=1, VPNNAME="VRF_OM";
   ADD PMSDEVADDR: DEVAID=3, VPNINDEX=3, IPVER=IPV4, IP="10.208.106.90";
   ```
8. 执行**ADD PMSDEVADDR后需执行RST MSPROCESS**命令重启PMS服务，并通过**DSP MSPROCESS**查看服务是否恢复。

   ```
   RST MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_PcfPms";
   DSP MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_PcfPms";
   ```

   完成PMS IP配置后，需要安装PMS证书，请参考替换系统初始数字证书进行操作。完成操作后，需要进一步参考UPCF的PMS WebUI客户端登录失败进行浏览器和安全配置。至此，PMS相关配置均已完成，待按顺序完成UPCF与USCDB对接数据后，PMS Web UI功能可以正常使用。
9. 执行如下命令配置DLB IP，用于配置4G Diameter信令平面的业务地址。

   DEVAID和VPNINDEX自定义，IP地址参考LLD设计文档 ->业务IP对接设计页签 -> 业务接口IP，选择Diameter信令平面规划的IP地址。

   VPNNAME为4G信令面VPN，对应CSLB配置的信令面VPN名称。

   ```
   ADD DLBVPN: VPNINDEX=4, VPNNAME="VRF_SIG";
   ADD DLBDEVADDR: DEVAID=4, VPNINDEX=4, IPVER=IPV4, IP="10.208.106.91";
   ```
10. 执行**SET SDRTRANS**命令配置SDR的可靠性传输功能。

    ```
    SET SDRTRANS: FLATTYPE=FABRIC, TRANSABILITY=RELIABILITY, OPT=NOTSET;
    ```
11. 执行**MOD INSP**命令修改软参，开启N15接口兼容开关和修改业务token数量。

    ```
    MOD INSP: INSPN=VRM_N15COMPATIBILITYSWITCH, INSPV=1;
    MOD INSP: INSPN=VRM_SRVTOKENNUM, INSPV=32768;
    ```
12. 执行**MOD COMPATSWITCH**命令修改软参，营帐消息通知开启抢锁机制。

    ```
    MOD COMPATSWITCH: SWNAME=LockSwitch, SWVALUE=0;
    ```
13. 手动添加UPCF的营帐用户账号。

    手动添加营帐用户帐号的详细操作请参见增加PGW和DMS用户。

版权所有 © 华为技术有限公司
