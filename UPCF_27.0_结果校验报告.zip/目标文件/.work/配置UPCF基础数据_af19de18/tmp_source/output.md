---
id: ''
name: 配置UPCF基础数据
ne_type: UPCF
type: feature
description: 开局的情况下，配置UPCF基础数据。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（非SDN）","配置基础数据","配置UPCF基础数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
开局的情况下，配置UPCF基础数据。

## 必备事项
前提条件

执行操作前准备工作如下：

* 已完成软件安装。
* 已获取网元的模块配置信息。
* 已经获取运营商规划的IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    set_fesn_list:
      type: items
      properties:
        SN:
          name: 'FE序号'
          type: integer
          minimum:
          - 0
          - 255
          maximum:
          - 20
          - 255
          required: true
          description: '* 单FE组网下FE序号设置为0。 * 多FE合一组网下FE序号由工程设计输出。'
          data_source: ''
          pattern: ''
          default: ''
    add_pcrf_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: '固定取值为“1”。'
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '本地域名'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '本地主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    rst_pod_list:
      type: items
      properties:
        TYPE:
          name: 'Pod复位类型'
          type: string
          enum:
          - byId
          - byType
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PODTYPE:
          name: 'Pod类型'
          type: string
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FORCEFLAG:
          name: '强制复位'
          type: string
          enum:
          - false
          - true
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MEID:
          name: '网元ID'
          type: string
          maxLength: 40
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PODNAME:
          name: 'Pod名称'
          type: string
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    rst_pod_list_5:
      type: items
      properties:
        TYPE:
          name: 'Pod复位类型'
          type: string
          enum:
          - byId
          - byType
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PODTYPE:
          name: 'Pod类型'
          type: string
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FORCEFLAG:
          name: '强制复位'
          type: string
          enum:
          - false
          - true
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MEID:
          name: '网元ID'
          type: string
          maxLength: 40
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PODNAME:
          name: 'Pod名称'
          type: string
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    rst_pod_list_6:
      type: items
      properties:
        TYPE:
          name: 'Pod复位类型'
          type: string
          enum:
          - byId
          - byType
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PODTYPE:
          name: 'Pod类型'
          type: string
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FORCEFLAG:
          name: '强制复位'
          type: string
          enum:
          - false
          - true
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MEID:
          name: '网元ID'
          type: string
          maxLength: 40
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PODNAME:
          name: 'Pod名称'
          type: string
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    clr_cluster_list:
      type: items
      properties:
        SERVICETYPE:
          name: '业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_dbslocation_list:
      type: items
      properties:
        LOCID:
          name: 'Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '自定义。Location标识在以下网元中需要配置：主用局FE、主用局USCDB、容灾局FE、容灾局USCDB。'
          data_source: ''
          pattern: ''
          default: ''
    rst_msprocess_list:
      type: items
      properties:
        PROCOBJECT:
          name: '操作对象'
          type: string
          enum:
          - PROCNAME
          - PROCID
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROCNAME:
          name: '进程类型'
          type: string
          minLength: 1
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MEID:
          name: '网元ID'
          type: string
          minLength: 0
          maxLength: 40
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROCID:
          name: '进程ID'
          type: string
          minLength: 1
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsipaddr_list:
      type: items
      properties:
        DBSIPINDEX:
          name: 'Dbbroker IP索引'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '仅当本命令中的“IP类型”参数取值有效时该参数有效。用于指定“本地Location IPV4地址1”或“本地Location IPV6地址1”的VPN名称，必须由**ADD L3VPNINST**、**ADD VPNINSTAF**和**ADD AUTOSCALINGSERVICE**命令定义后才能在此处引用。'
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: '仅当本命令中的“IP类型”参数取值为“IPV4”时该参数有效。用于指定IPV4类型的本地IP地址。'
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: '仅当本命令中的“IP类型”参数取值为“IPV4”时该参数有效。用于指定本地IP地址的子网掩码。'
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '由运营商统一规划。 当“IPVER”为“IPV4”时，才会规划： * 本地Location IPV4地址1 * 本地Location IPV4网关1 * 本地Location IPV4子网掩码1 当“IPVER”为“IPV6”时，才会规划： * 本地Location IPV6地址1 * 本地Location IPV6网关1 * 本地Location IPV6前缀长度1'
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_hlbdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 32
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '由运营商统一规划。 当“IPVER”为“IPV4”时，才会规划IPV4地址。 当“IPVER”为“IPV6”时，才会规划IPV6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        HTTPSFUNC:
          name: 'HTTPS功能'
          type: string
          enum:
          - ON
          - OFF
          required: false
          description: '本端规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ON
        TOEDGE:
          name: '对接边缘'
          type: string
          enum:
          - NO
          - YES
          required: false
          description: '本端规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: NO
        CERTSCENE:
          name: '证书应用场景'
          type: string
          enum:
          - UPCF_HLB_Lcert
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TLSCFGID:
          name: 'TLS配置ID'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pmsvpn_list:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 32
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
    add_pmsdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '由运营商统一规划。 当“IPVER”为“IPV4”时，才会规划IPV4地址。 当“IPVER”为“IPV6”时，才会规划IPV6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    rst_msprocess_list_1:
      type: items
      properties:
        PROCOBJECT:
          name: '操作对象'
          type: string
          enum:
          - PROCNAME
          - PROCID
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROCNAME:
          name: '进程类型'
          type: string
          minLength: 1
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MEID:
          name: '网元ID'
          type: string
          minLength: 0
          maxLength: 40
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROCID:
          name: '进程ID'
          type: string
          minLength: 1
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dlbvpn_list:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 31
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
    add_dlbdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '由运营商统一规划。 当“IPVER”为“IPV4”时，才会规划IPV4地址。 当“IPVER”为“IPV6”时，才会规划IPV6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_sdrtrans_list:
      type: items
      properties:
        FLATTYPE:
          name: '通信平面类型'
          type: string
          enum:
          - BASE
          - FABRIC
          required: true
          description: '指定对应的网络平面，此处固定配置为FABRIC。'
          data_source: ''
          pattern: ''
          default: ''
        TRANSABILITY:
          name: '传输能力类型'
          type: string
          enum:
          - RELIABILITY
          - SECURITY
          required: true
          description: '标识SDR的传输能力类型，此处固定配置为RELIABILITY。'
          data_source: ''
          pattern: ''
          default: ''
        OPT:
          name: '选项开关'
          type: string
          enum:
          - DISABLEALL
          - ENABLEALL
          - NOTSET
          required: true
          description: '标识SDR传输能力的选项开关，此处固定配置为NOTSET。'
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list:
      type: items
      properties:
        INSPN:
          name: '软参名'
          type: string
          enum:
          - VRM_MAXIPCANSESNUMPERSPU
          - VRM_MAXAFSESNUMPERSPU
          - VRM_MAXSUBNUMPERSPU
          - VRM_UPGRADE
          - VRM_MAXRATBEARIDPERSES
          - VRM_SRVNUMPERUSR
          - VRM_MAXPAFNUM
          - VRM_MAXPCEFNUM
          - VRM_MAXRADIUSSRVNUM
          - VRM_MAXCONNECTIONPERPAF
          - VRM_MAXCONNECTIONPERPCEF
          - VRM_MAXLINKRADIUSSRV
          - VRM_SUBSRCIPTIONIDTYPE
          - VRM_GLBREFLASHINTERVAL
          - VRM_NOTIFYMSGMAXRECORDPERSUB
          - VRM_NOTIFYMSGMAXDAYPERSUB
          - VRM_REVALIDATIONTIMEMETHOD
          - VRM_NOSUBSCRIPTIONERRORCODE
          - VRM_NOTIFYMSGMAXWAITEDRECORDS
          - VRM_PRINTLOCALLOG
          - VRM_USRREVALIHRANGE
          - VRM_ONLINECHECK
          - VRM_TIMEZONEENHANCE
          - VRM_GXIMEIFORMAT
          - VRM_NOTIFYMSGMAXRECORDPERDSU
          - VRM_CLEARALLDYNCREATEDUSER
          - VRM_PEELDOMAINSWITCH
          - VRM_NOTIFYRCVER
          - VRM_FIRSTDAYOFWEEK
          - VRM_UPDATESPRSUBACTIVE
          - VRM_SUBCTRLRESULT
          - VRM_SPRSUBMAXOFFLINEDAYS
          - VRM_CHECKSUBSCRIBEDSERVICE
          - VRM_SUBACTCTRL
          - VRM_SESSIONCHECKINTERVAL
          - VRM_CHKSUBSRVSYTYPE
          - VRM_RARSENDSPEED
          - VRM_DIAREDIRECTSWITCH
          - VRM_PERIODVALUE
          - VRM_PROTECTTIMER
          - VRM_SENDUSERNUM
          - VRM_POLICYCASESENSITIVE
          - VRM_SESSIONRESTORATION
          - VRM_RXRPMAPRELATION
          - VRM_NOTIFYUSAGEUNITCONVERT
          - VRM_TIMEACCUMODE
          - VRM_SYSWITCH
          - VRM_PLMNMATCHPRIORITY
          - VRM_RESETNOTIFYRPT
          - VRM_REPORTINGLEVEL
          - VRM_RATINGGROUP
          - VRM_SERVICEIDENTIFIER
          - VRM_DFTCHARGINGPARA
          - VRM_LOGPRINTPERIOD
          - VRM_MAXBBERFNUM
          - VRM_MAXCONNECTIONPERBBERF
          - VRM_SPNOTIFYDOMAIN
          - VRM_EXSPRNOTIFICATION
          - VRM_SESSIONBACKUPSWITCH
          - VRM_DIAMHBINTERVAL
          - VRM_DIAMHBTIMES
          - VRM_EDRACCESSFORMATE
          - VRM_IPCANTERMSWITCH
          - VRM_DELBEAROPTION
          - VRM_LDAPREVBUFFERSIZE
          - VRM_NOTIFYOPTIMIZE
          - VRM_RESULTCODESWITCH
          - VRM_FMTIPADDR
          - VRM_GROUPDIAREDIRECTSWITCH
          - VRM_RMVSUBWITHOUTRAR
          - VRM_GRPMBRUSAGECACHE1
          - VRM_GRPMBRUSAGECACHE2
          - VRM_DYNRULEFORMAT
          - VRM_IPV6HASHLENGTH
          - VRM_DURATIONMKMATCH
          - VRM_SNRRECSPEED
          - VRM_DIAMTIMETHRD
          - VRM_LDAPTIMETHRD
          - VRM_RELGXBYRAATIMEOUT
          - VRM_SETHOMESRVZONE
          - VRM_MAXTDFNUM
          - VRM_TDFCCRUSPD
          - VRM_TDFCCRTSPD
          - VRM_PROCHEARTBEATTIMEOUT
          - VRM_MAXAUXILIARYAREA
          - VRM_AADIAREDIRECTSWITCH
          - VRM_DIAMFAILOVERSWITCH
          - VRM_DYNSMSMSISDN
          - VRM_SUBGRPCREATESUB
          - VRM_QUOTACROSSSERVICE
          - VRM_SYSUBIDTYPE
          - VRM_DEACTIVESERVICETIMER
          - VRM_QUOTALOGSWITCH
          - VRM_SIMPLEPOLICYSTATISTIC
          - VRM_GXTRIGGERCMP
          - VRM_QOSNEGOTIATIONSWITCH
          - VRM_IPFLOWANYCVT
          - VRM_SUBLISTNORULE
          - VRM_NTFOVERDUEMODE
          - VRM_DESTPEERMODE
          - VRM_SYNDATASWITCH
          - VRM_SYNDATAINTERVAL
          - VRM_TAIECGIMATCHMODE
          - VRM_SYCARRYSUBID
          - VRM_SYRESENDTIMES
          - VRM_DYNQUOTATIMEZONE
          - VRM_FIRSTGXSESSIONATTR
          - VRM_SESSIONIDHASHMODE
          - VRM_PEERFCDURATION
          - VRM_AFPOLICYRECALCULATE
          - VRM_SGWRESTORETIME
          - VRM_QUOTAUSEPRIORITY
          - VRM_SESSIONIDSWITCH
          - VRM_REPORTUSAGE
          - VRM_IMEIQUERYSERVICE
          - VRM_MCITRIGGERUDR
          - VRM_RXMAXUL
          - VRM_RXMAXDL
          - VRM_SYSESSIONCONTROLATTRIBUTE
          - VRM_SYSESSIONCONTROLVALUE
          - VRM_AUTORECUSRLOC
          - VRM_LINKDSPMODE
          - VRM_RXSTAINCAUTHAPPID
          - VRM_MAXAREANUM
          - VRM_GXSESSIONONLYVOLTE
          - VRM_LDAPDBTIMEOUT
          - VRM_OFFSETTIME
          - VRM_APNSENSITIVE
          - VRM_DYNGROUPNUMBERPERUSER
          - VRM_SYSESSIONBACKUP
          - VRM_NOTIFYATTRRESTRICTION
          - VRM_UNKNOWNRULEPROC
          - VRM_FORCEUPGRADEQOS
          - VRM_RMVGRPMEMBERACT
          - VRM_SYNUSRDATASPEED
          - VRM_SYCHARGINGCHARSWITCH
          - VRM_LICDSPMODE
          - VRM_GRPMBRPARENTSTATUSFLAG
          - VRM_TERMSESSNOTIFICATIONFLAG
          - VRM_DCIPRIORITY
          - VRM_SERVICEINFOSTATUSMODE
          - VRM_RXARPMAPPINGMODE
          - VRM_NOTIFYATTRENUMVALUEMODE
          - VRM_GLBSESDATAREFRESH
          - VRM_MAXPOCSCPNUM
          - VRM_SPUAUTOSWITCHOVER
          - VRM_PRAIDCODECMODE
          - VRM_DFTROAMINGSTATUS
          - VRM_MCIPROCMODE
          - VRM_VMSTORAGEFAULTRMSWITCH
          - VRM_PREBINDFORSESSIONBACKUP
          - VRM_SHARESYQUOTAMODE
          - VRM_MEMCHECKALARMSWITCH
          - VRM_QUOTASTATUSSTATISTIC
          - VRM_SUBIDCHOOSESWITCH
          - VRM_MCCMNCROAMREGION
          - VRM_TERMFIRSTSESSIONSWITCH
          - VRM_RECORDMEMSWITCH
          - VRM_Q922ERRMSGSWITCH
          - VRM_MEMFREERECORDSTKSWITCH
          - VRM_MEMFREERECORDSTKPOLICY
          - VRM_MSGFREERECORDSTKSWITCH
          - VRM_MSGFREERECORDSTKPOLICY
          - VRM_MEMALLOCFAILEDHOOKSWITCH
          - VRM_LOADINGALLAREADATA
          - VRM_MAXMSGTEMPLATENUM
          - VRM_PCEFHOSTTOGROUP
          - VRM_LINKBASEAPN
          - VRM_CBOVERRUNALMTH
          - VRM_CBRECOVERYALMTH
          - VRM_VOLTESESSINDEPENDENT
          - VRM_MEWORKROLE
          - VRM_RESETFORALLOCMEMFAILED
          - VRM_RESETFORALLOCMSGFAILED
          - VRM_ENABLEVOLTEAPNGXFLOWCTRL
          - VRM_CBWATCHTIME
          - VRM_DIAMMSGRELAYSWITCH
          - VRM_SYNTIMER
          - VRM_DEVAUDITACCELERATION
          - VRM_PENDINGTRANSACTIONNUM
          - VRM_VOLTEQRYSPR
          - VRM_TRIGGERRESTRICTTYPE
          - BLC_UPMUSERREQ
          - BLC_BEARUPDATE
          - BLC_WAITBEARTERM
          - BLC_ZONETYPE
          - BLC_SECPDPQOSCONTROL
          - RM_RATINGVOLRNDUNIT
          - RM_USGVOLRNDUNIT
          - RM_USGVOLRNDTHRESH
          - RM_RUSGVOLRNDUNIT
          - RM_RUSGVOLRNDTHRESH
          - RM_PLMNANDSGSNALM
          - RM_ALMCLRPERIOD
          - BLC_NOTIFYSENDINTERVAL
          - VRM_OCSCHARGEFLAGFORPRE
          - VRM_OCSCHARGEFLAGFORPOS
          - VRM_OCSCHARGEFLAGFOROTHER
          - BLC_DELSSINVALIDINTERVAL
          - BLC_DELSSINTERVAL
          - BLC_DELSSNUM
          - VRM_CHECKAPNIP
          - VRM_QCIUPGRADE
          - VRM_UNDERCONTROLTHRESHOLD
          - VRM_NORMALVALUE
          - UPM_SUBCTRL
          - UPM_ACCRARTIMEOUT
          - UPM_TIMERPLYCNTREQ
          - VRM_KPIMONITORINGSWITCH
          - VRM_TDFPOLICYMODE
          - VRM_RXBEARWITH5002
          - LIC_PREALMTH
          - VRM_QRYSPRPRIORITY
          - VRM_SDUROUTECONFILICTRAR
          - VRM_DBTIMERVALIDPERIOD
          - VRM_FORCERECOVERYSESSION
          - ALC_WAITAFTERM
          - VRM_RARWITHTRIGGER
          - VRM_RELEASERXTRIGGER
          - VRM_MAXIPCANNUMPERUSR
          - VRM_RETENTION_NOTIFYLOG
          - VRM_RETENTION_MNTLOG
          - VRM_RETENTION_EXPORT
          - VRM_MAXSESSBACKUPNUMPERSUB
          - VRM_SAVESYORGSTATUS
          - VRM_SNRSUPPORTSUBID
          - VRM_AUDITFAILEDCODE
          - VRM_ADJUSTSERVICEMODE
          - VRM_SYORIGINSTATEID
          - VRM_NOTRARWITHSAMEINSTALLRULE
          - VRM_CALCPRIBYSRVNAME
          - VRM_PENDINGTIME2LOCALTIME
          - VRM_MAXPCEFRADIUSNUM
          - VRM_RTPDRNOFLOW
          - VRM_SYDRASLRITIMEOUTSTRCTRL
          - VRM_GXREDIRECTACTION
          - VRM_GXRULEDEDUP
          - VRM_MCITOPGWSPEED
          - VRM_NRIPV6HASHLENGTH
          - VRM_SDCHARGINGCHARSWITCH
          - VRM_OFFLINESRVSWITCH
          - VRM_OFFLINEREDOLOG
          - VRM_VOLTESESSIONNOTUPDATE
          - VRM_BSFONLYVOLTE
          - VRM_BSFRESENDTIMES
          - VRM_BSFTIMEOUT
          - VRM_CHRGIDFMT
          - VRM_LONGTERMNTYRECORDPERSUB
          - VRM_GXQRYCHARINGSYSMODE
          - VRM_RECREATERULENOTIFICATION
          - VRM_PACKETFILTER
          - VRM_SNRWITHOUTHOSTMODE
          - VRM_SYCOUNTERTRANSMODE
          - VRM_MAXCONDITIONNUM
          - VRM_MAXQUOTANUM
          - VRM_RMVSYSRVBYRESULTCODE
          - VRM_VIRTUALSUBIDSWITCH
          - VRM_VOLTEPDPQRYSY
          - VRM_PACKETERRRATETYPE
          - VRM_IPDOMAINSENSITIVE
          - VRM_NRCOMBINEPRIORITYMODE
          - VRM_N15COMPATIBILITYSWITCH
          - VRM_HASHAUDITSWITCH
          - VRM_RECUSRLOCBASERAT
          - VRM_MULTIPCEFQRYDB
          - VRM_DEVAUDITSTARTTIME
          - VRM_MCIDELOLDSES
          - VRM_MCIDELOLDSESSPEED
          - VRM_CHECKSUBSRV
          - VRM_MASTERSLAVENOTIFYENHANCE
          - VRM_NEPEERSTATUS
          - VRM_NONOVERLOADERRORCODESW
          - VRM_AMFRESELECTSWITCH
          - VRM_REDIRECTSWITCH
          - VRM_POLICYASSOCIATESWITCH
          - VRM_DIAMDIRECTPATH
          - VRM_SMFALMWITHIPPORT
          - VRM_REGWITHINSTANCENAME
          - VRM_VIRTUALQUOTAREPORTUSAGE
          - VRM_SPONSORDYNRULEFORMAT
          - VRM_SRVTOKENNUM
          - VRM_UPDSMFSTA
          - VRM_N7CHGNORULESWITCH
          - VRM_QUOTAOBJNOTEXISTCALCMODE
          - VRM_SDRRELIABTRANSSWITCH
          - VRM_CALCULBYNR
          - VRM_GXSESSIONCHARGE
          - VRM_RARSPEEDDOWNCPU
          - VRM_RARSPEEDUPCPU
          - VRM_SUBSCRIBERGROUPMATCHMODE
          - VRM_SCANSTARTTIME
          - VRM_DISTRIQUERYMAXRECORD
          - VRM_GLBPARTITIONLOADINGSWITCH
          - VRM_COMPARECCRIUQOS
          - VRM_AUTORECUSRLOCEX
          - VRM_AVGCHILDPERPARENT
          - VRM_AVGPARENTPERCHILD
          - VRM_SELECTNTSMETHOD
          - VRM_QUOTADEDUCTMODE
          - VRM_MAXBEARNUMPERIPCAN
          - VRM_SDSESSIONBACKUP
          - VRM_SERVICEZONEAREAMATCHTYPE
          - VRM_USRLOCATION_VALUE
          - VRM_RULESUFFIXLENAPPMODE
          - VRM_TAIMATCHINGMODE
          - VRM_N7PCCNOCHGANINFOSW
          - VRM_N5SESSIONBACKUP
          - VRM_PROFILEUPDATEBASERULEPRI
          - VRM_AFSELBINDCFG
          - VRM_ROUTEQUERYRETRYTIMES
          - VRM_ROUTEQUERYRETRYINTERVAL
          - VRM_NOTIFYBEFOREEXPIRE
          - VRM_N36INTERFACESW
          - VRM_N36SUBSCRIPTIONSW
          - VRM_PCFLIPSELECTMODE
          - VRM_PESSRVDISCTIMER
          - VRM_EXATTR1DEFAULTVALUE
          - VRM_HTTPCLIENTREDIRECTTIMES
          - VRM_N23SWITCH
          - VRM_DIAMGETAPPID
          - VRM_N23SESSIONBACKUP
          - VRM_GLBDATAIDMAPSWITCH
          - VRM_PEERNFDEFAULTPRIORITY
          - VRM_N23SESADTMSGSPEED
          - VRM_IPDOMAINSRCFORGX
          - VRM_N15VIRTUALSUBIDSWITCH
          - VRM_SESSIONCOMPRESSTYPE
          - VRM_UPDAMFSTA
          - VRM_N23TIMEOUT
          - VRM_MAXAMSAUNUMPERSPU
          - VRM_N24AMSWITCH
          - VRM_N24AMTIMEOUT
          - VRM_CALLRXFIRSTSW
          - VRM_BACKFILLSESRULE
          - VRM_N7NWDAFLINKDOWNSW
          - VRM_N7POLICYCHGN23SW
          - VRM_RSTSYQUOTASW
          - VRM_HTTPLOCFILLMODE
          - VRM_DRALINKSTAMPUPTMODE
          - VRM_TRACECACHECHKSW
          - VRM_N15AREACODESW
          - VRM_USELASTPLMNIFNOTMATCHED
          - VRM_AUTORESETSWITCH4FSM
          - VRM_N23HDPCFIDMODE
          - VRM_CALCREDPRIBYNAME
          - VRM_STATEXTERNALRESTORATION
          - VRM_BSFBINDINGUPDATESW
          - VRM_SBICALLBACKVALUE
          - VRM_NGPOLICYCASESENSITIVE
          - VRM_N15QRYCHARINGSYSMODE
          - VRM_AFUPDATEUMMODE
          - VRM_HSRCTRLSW
          - VRM_CALCMEDRULEPRIBYNAME
          - VRM_DATAVIRTUALSUBIDSWITCH
          - VRM_INTRANETSESSEFFMODE
          - VRM_N28PENDINGTIME2LOCAL
          - VRM_MIDNIGHTGLBREFRESHSWITCH
          - VRM_SCANFROZENUSER
          - VRM_N1NOTIFYTIMER
          - VRM_MAXNWDAFSESNUMPERSPU
          - VRM_PCEFPARAMATCHMODE
          - VRM_N5VIRTUALMEDIA
          - VRM_SYQTAINSTMODE
          - VRM_N7UPDATECAFCRXMODE
          - VRM_N7ACTN23POLICYMODE
          - VRM_N23BAKCOMPATIBILITYSW
          - VRM_N7MAXDYNRULENUM
          - VRM_N7FAILRCPROCMETHOD
          - VRM_DELAYSTATAUTOENABLEDSW
          - VRM_AUTHSRVENCODEMODE
          - VRM_SUBLOCNUM
          - VRM_HPCFDELIVERLOCCHSW
          - VRM_N15RMVSPCMCCFROMGPSI
          - VRM_MODULERSTPROTECTTIME
          - VRM_N15DYNMATCHMODE
          - VRM_NESTATUSREFRESHCYCLE
          - VRM_SYCCFROMN7SWITCH
          - VRM_MAXSESSRESTOREDELAYTIME
          - VRM_SESSIONNUMCOUNTMODE
          - VRM_UEINITRESOURCEBYSMFSWITCH
          - VRM_SATT2TVOICESW
          - VRM_ROLLBACKN7LINKDOWN
          - VRM_DEVAUDITAUTO
          - VRM_N24NFSETRESENTTIMES
          - VRM_UNKNOWNLOCPROC
          - VRM_N15SUBCTRL
          - VRM_UPMUSERREQTIMERLEN
          - VRM_SYSLRIDATIME
          - VRM_MAXNXSESNUMPERSPU
          - VRM_NXNASTIMEOUT
          - VRM_NXNASRETRYTIMES
          - VRM_NZTIMEOUT
          - VRM_NZRETRYTIMES
          - VRM_NXPENDINGRETRYTIMES
          - VRM_NXNWDAFDICMODE
          - VRM_NXNZSESSIONBACKUP
          - VRM_SLRURESENDTIMES
          - VRM_CHECKNTSLINKSTATUS
          - VRM_ABSVALPRDSRVAUTOSW
          - VRM_N23USETAIDISCMODE
          - VRM_SYTOGXRCMODE
          - VRM_VONRLICSTATMODE
          - VRM_PROFILEUPTTIMELEN
          - VRM_SYNASSOCDATAINTERVAL
          - VRM_N7NWDAFLINKDOWNCYCLE
          - VRM_N7NWDAFLINKDOWNMAXTIMES
          - VRM_RXIPV6PCEFGROUPID
          - VRM_DLBPRQTIMERLEN
          - VRM_CLIENTPORTVERIFY
          - VRM_RECHARGENOTIFIRESTRAIN
          required: true
          description: '当新建局点时，需要手动将该软参取值修改为“1”。'
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '软参值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_compatswitch_list:
      type: items
      properties:
        SWNAME:
          name: '参数名'
          type: string
          enum:
          - N7ReleaseCause
          - SPRLicStatMode
          - UserLocCaseSensitive
          - LockSwitch
          - NRFSubFailRspRetry
          - RxRatTypeDataSource
          - N7EdrFormat
          - TAIMatchingMode
          - StatExternalAudit
          - SnssaiNoSdSW
          - CCDBAuditBatchSwitch
          - HBLinkStaSwitch
          - N7flowDesSw
          - AnInfoStatMode
          - APNLicSwitch
          - DualIPQryBindMode
          - SdMetricStatSwitch
          - AuditFailedASRSW
          - MulDnnRuleInstallMode
          - N15PolicySW
          - N15RfspSW
          - AARUResultCodeSw
          - SessionBackupType
          - NFStatusNtyProcScope
          - UePTICheckSwitch
          - QuotaDefaultStatusMode
          - RouteBatchSwitch
          - DciThreadSeparation
          - STAWIFILOCSW
          - N7UserLocInfoMatchMode
          - ChfRangeMatchEnhanceSW
          - DIAMREALMSELECT
          - HttpProblemDetailsSW
          - CCRUTriggerRxUpdate
          - SySelectPeerMethod
          - ServiceTypeUpdateSwitch
          - RelSesByNotifyTimeout
          - RACDecodeMode
          - N15CalcPLMN
          - NeedN23SubsDynSW
          - FlowDescChkSw
          - N5AFChargingIdMode
          - DciZeroCopy
          - GxPraMatchMode
          - N7VolteCheckSLR
          - UeApiPrefixSW
          - VplmnQosCalcMode
          - RoutingBindingInRspSwitch
          - DynSubDataAynUpdateSwitch
          - IpDomainCheck
          - CongMsgProcMode
          - AMFN1N2MsgUriMode
          - ShareUserCheckSGM
          - StaticCfgScpPortSelMode
          - N7SessionNumCountRuleEffectSw
          - UserMigRptRndQuota
          - DiscSrvNameMandatorySW
          - RARWithNonPCCRmv
          - NWDAFTACMatchMode
          - SecstatSwitch
          - DiamLocalIpPortChkSw
          - DBFlowCtrlProcMode
          - GxBlkMsgProcMode
          required: true
          description: '当新建局点时，需要手动将该软参取值修改为“0”。'
          data_source: ''
          pattern: ''
          default: ''
        SWVALUE:
          name: '参数值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - set_fesn_list:
    - SN: 0
    add_pcrf_list:
    - PCRFID: 1
      DN: 'huawei.com'
      HN: 'upcf01.huawei.com'
    rst_pod_list:
    - TYPE: byType
      PODTYPE: 'pcf-srvl1-pod231'
      FORCEFLAG: true
      MEID: '20'
      PODNAME: ''
    rst_pod_list_5:
    - TYPE: byType
      PODTYPE: 'pcf-srvs-pod231'
      FORCEFLAG: true
      MEID: '20'
      PODNAME: ''
    rst_pod_list_6:
    - TYPE: byType
      PODTYPE: 'dus-pod231'
      FORCEFLAG: true
      MEID: '20'
      PODNAME: ''
    clr_cluster_list:
    - SERVICETYPE: 'UPCF-SESSION'
    set_dbslocation_list:
    - LOCID: 241
    rst_msprocess_list:
    - PROCOBJECT: PROCNAME
      PROCNAME: 'CELL_UdrDbbroker'
      MEID: ''
      PROCID: ''
    add_dbsipaddr_list:
    - DBSIPINDEX: 1
      IP1VPNNAME: 'VRF_CC_DATA'
      IP2VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: '10.0.27.98'
      IPV4IP2: '10.0.27.99'
      IPV4MASK1: '255.255.255.255'
      IPV4MASK2: '255.255.255.255'
      IPVER: IPV4
      IPV4GW1: ''
      IPV4GW2: ''
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
    add_hlbdevaddr_list:
    - DEVAID: 1
      VPNNAME: 'VRF_SIG'
      IPVER: IPV4
      IP: '10.30.14.150'
      HTTPSFUNC: OFF
      TOEDGE: NO
      CERTSCENE: ''
      TLSCFGID: ''
      IPV6: ''
    add_pmsvpn_list:
    - VPNINDEX: 1
      VPNNAME: 'VRF_OM'
    add_pmsdevaddr_list:
    - DEVAID: 3
      VPNINDEX: 3
      IPVER: IPV4
      IP: '10.208.106.90'
      IPV6: ''
    rst_msprocess_list_1:
    - PROCOBJECT: PROCNAME
      PROCNAME: 'CELL_PcfPms'
      MEID: ''
      PROCID: ''
    add_dlbvpn_list:
    - VPNINDEX: 4
      VPNNAME: 'VRF_SIG'
    add_dlbdevaddr_list:
    - DEVAID: 4
      VPNINDEX: 4
      IPVER: IPV4
      IP: '10.208.106.91'
      IPV6: ''
    set_sdrtrans_list:
    - FLATTYPE: FABRIC
      TRANSABILITY: RELIABILITY
      OPT: NOTSET
    mod_insp_list:
    - INSPN: VRM_N15COMPATIBILITYSWITCH
      INSPV: 1
    mod_compatswitch_list:
    - SWNAME: LockSwitch
      SWVALUE: 0
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录OM Portal Web MML界面，在“应用管理>MML”中选择“UPCF”网元。

### 2 执行**SET FESN**命令，设置FE序号。

```jinja2
{%- for item in set_fesn_list -%}
    SET FESN:
    {#- --- 必选参数 --- -#}
    SN={{item.SN}},
    ;
{%- endfor -%}
```

### 3 执行**ADD PCRF**命令增加PCRF实体。

```jinja2
{%- for item in add_pcrf_list -%}
    ADD PCRF:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    DN="{{item.DN}}",
    HN="{{item.HN}}",
    ;
{%- endfor -%}
```

### 网元安装完成后，未进行**ADD PCRF**初始配置时：

### 产生“ALM-100595 进程状态未就绪”告警，告警参数中的“进程名称”为“CELL\_PcfOtes”或者“CELL\_PcfOtcs”，是正常现象，添加**ADD PCRF**配置后OTES或者OTCS服务正常。

### 登录OM Portal，选择“应用管理 > MML”，进入MML命令界面。选择UPCF网元，执行如下命令，查看OTES或者OTCS服务“进程状态”为非“Ready（就绪状态）”是正常现象，添加**ADD PCRF**配置后OTES或者OTCS服务正常。

### 4 执行**ADD PCRF**命令后，需要重启HLB、DLB、PES和DUS服务。

#### 4.1 登录“OM Portal”，在CSP网元下，执行**DSP POD**命令，查询pcf中的所有Pod类型。

#### 命令示例如下：

#### 4.2 执行**RST POD**命令，重启HLB、DLB、PES和DUS服务对应的Pod。

#### 重启虚拟机Pod命令示例如下：

#### /*重启HLB、DLB、DUS服务，如果没有部署SRV-L虚拟机，则无需复位pcf-srvl1-pod231和pcf-srvl2-pod231*/

```jinja2
{%- for item in rst_pod_list -%}
    RST POD:
    {#- --- 必选参数 --- -#}
    TYPE={{item.TYPE}},
    FORCEFLAG={{item.FORCEFLAG}},
    MEID="{{item.MEID}}",
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：TYPE=byType 时必选 --- -#}
    {%- if item.TYPE == 'byType' -%}
        PODTYPE="{{item.PODTYPE}}",
    {%- endif -%}
    {#- --- 条件必选：TYPE=byId 时必选 --- -#}
    {%- if item.TYPE == 'byId' -%}
        PODNAME="{{item.PODNAME}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

#### /*重启PES服务*/

```jinja2
{%- for item in rst_pod_list_5 -%}
    RST POD:
    {#- --- 必选参数 --- -#}
    TYPE={{item.TYPE}},
    FORCEFLAG={{item.FORCEFLAG}},
    MEID="{{item.MEID}}",
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：TYPE=byType 时必选 --- -#}
    {%- if item.TYPE == 'byType' -%}
        PODTYPE="{{item.PODTYPE}}",
    {%- endif -%}
    {#- --- 条件必选：TYPE=byId 时必选 --- -#}
    {%- if item.TYPE == 'byId' -%}
        PODNAME="{{item.PODNAME}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 重启裸机Pod命令示例如下：

#### /*重启HLB、DLB、DUS、PES服务*/

```jinja2
{%- for item in rst_pod_list_6 -%}
    RST POD:
    {#- --- 必选参数 --- -#}
    TYPE={{item.TYPE}},
    FORCEFLAG={{item.FORCEFLAG}},
    MEID="{{item.MEID}}",
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：TYPE=byType 时必选 --- -#}
    {%- if item.TYPE == 'byType' -%}
        PODTYPE="{{item.PODTYPE}}",
    {%- endif -%}
    {#- --- 条件必选：TYPE=byId 时必选 --- -#}
    {%- if item.TYPE == 'byId' -%}
        PODNAME="{{item.PODNAME}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 4.3 执行**DSP POD**命令查询Pod是否已经恢复：

#### 4.4 在USCDB网元下，执行**CLR CLUSTER**命令，清除Session备份数据。

#### 命令示例如下：

```jinja2
{%- for item in clr_cluster_list -%}
    CLR CLUSTER:
    {#- --- 必选参数 --- -#}
    SERVICETYPE="{{item.SERVICETYPE}}",
    ;
{%- endfor -%}
```

### 5 执行如下命令配置dbbroker信息，用于微服务和USCDB对接。

```jinja2
{%- for item in set_dbslocation_list -%}
    SET DBSLOCATION:
    {#- --- 必选参数 --- -#}
    LOCID={{item.LOCID}},
    ;
{%- endfor -%}
```

```jinja2
{%- for item in rst_msprocess_list -%}
    RST MSPROCESS:
    {#- --- 必选参数 --- -#}
    PROCOBJECT={{item.PROCOBJECT}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：PROCOBJECT=PROCNAME 时必选 --- -#}
    {%- if item.PROCOBJECT == 'PROCNAME' -%}
        PROCNAME="{{item.PROCNAME}}",
    {%- endif -%}
    {#- --- 条件必选：PROCOBJECT=PROCID 时必选 --- -#}
    {%- if item.PROCOBJECT == 'PROCID' -%}
        PROCID="{{item.PROCID}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：PROCOBJECT=PROCNAME/PROCID 时可选 --- -#}
    {%- if item.PROCOBJECT in ['PROCNAME', 'PROCID'] -%}
        {%- if item.MEID is not none -%}
            MEID="{{item.MEID}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

```jinja2
{%- for item in add_dbsipaddr_list -%}
    ADD DBSIPADDR:
    {#- --- 必选参数 --- -#}
    DBSIPINDEX={{item.DBSIPINDEX}},
    IPVER={{item.IPVER}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
    {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
        IP1VPNNAME="{{item.IP1VPNNAME}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4IP1="{{item.IPV4IP1}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6IP1="{{item.IPV6IP1}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6MASK1={{item.IPV6MASK1}},
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
    {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
        {%- if item.IP2VPNNAME is not none -%}
            IP2VPNNAME="{{item.IP2VPNNAME}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4IP2 is not none -%}
            IPV4IP2="{{item.IPV4IP2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4MASK1 is not none -%}
            IPV4MASK1="{{item.IPV4MASK1}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4MASK2 is not none -%}
            IPV4MASK2="{{item.IPV4MASK2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4GW1 is not none -%}
            IPV4GW1="{{item.IPV4GW1}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        {%- if item.IPV4GW2 is not none -%}
            IPV4GW2="{{item.IPV4GW2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6GW1 is not none -%}
            IPV6GW1="{{item.IPV6GW1}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6GW2 is not none -%}
            IPV6GW2="{{item.IPV6GW2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6IP2 is not none -%}
            IPV6IP2="{{item.IPV6IP2}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        {%- if item.IPV6MASK2 is not none -%}
            IPV6MASK2={{item.IPV6MASK2}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 6 执行**ADD HLBDEVADDR**命令配置HLB IP，用于和SMF网元通信。

### DEVAID自定义，IP地址参考LLD设计文档 ->业务IP对接设计页签 -> 业务接口IP，选择HTTP信令平面规划的IP地址。

### VPNNAME为5G信令面VPN，对应CSLB配置信令面的VPN名称。

### 如果需要配置HLB数字证书，请在完成基础数据配置后，参考配置HLB数字证书章节进行操作。

```jinja2
{%- for item in add_hlbdevaddr_list -%}
    ADD HLBDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNNAME="{{item.VPNNAME}}",
    IPVER={{item.IPVER}},
    {#- --- 可选参数 --- -#}
    {%- if item.HTTPSFUNC is not none -%}
        HTTPSFUNC={{item.HTTPSFUNC}},
    {%- endif -%}
    {%- if item.TOEDGE is not none -%}
        TOEDGE={{item.TOEDGE}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：HTTPSFUNC=ON 时必选 --- -#}
    {%- if item.HTTPSFUNC == 'ON' -%}
        CERTSCENE={{item.CERTSCENE}},
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    {#- --- 条件必选：HTTPSFUNC=ON 时必选 --- -#}
    {%- if item.HTTPSFUNC == 'ON' -%}
        TLSCFGID={{item.TLSCFGID}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 7 执行如下命令配置PMS IP，用于配置策略数据。

### DEVAID和VPNINDEX自定义，**ADD PMSVPN**与**ADD PMSDEVADDR**中的VPNINDEX取值需要一致。IP地址参考LLD设计文档 ->业务IP对接设计页签 -> 业务接口IP，选择PMS维护平面的IP地址。

```jinja2
{%- for item in add_pmsvpn_list -%}
    ADD PMSVPN:
    {#- --- 必选参数 --- -#}
    VPNINDEX={{item.VPNINDEX}},
    VPNNAME="{{item.VPNNAME}}",
    ;
{%- endfor -%}
```

```jinja2
{%- for item in add_pmsdevaddr_list -%}
    ADD PMSDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNINDEX={{item.VPNINDEX}},
    IPVER={{item.IPVER}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 8 执行**ADD PMSDEVADDR后需执行RST MSPROCESS**命令重启PMS服务，并通过**DSP MSPROCESS**查看服务是否恢复。

```jinja2
{%- for item in rst_msprocess_list_1 -%}
    RST MSPROCESS:
    {#- --- 必选参数 --- -#}
    PROCOBJECT={{item.PROCOBJECT}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：PROCOBJECT=PROCNAME 时必选 --- -#}
    {%- if item.PROCOBJECT == 'PROCNAME' -%}
        PROCNAME="{{item.PROCNAME}}",
    {%- endif -%}
    {#- --- 条件必选：PROCOBJECT=PROCID 时必选 --- -#}
    {%- if item.PROCOBJECT == 'PROCID' -%}
        PROCID="{{item.PROCID}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：PROCOBJECT=PROCNAME/PROCID 时可选 --- -#}
    {%- if item.PROCOBJECT in ['PROCNAME', 'PROCID'] -%}
        {%- if item.MEID is not none -%}
            MEID="{{item.MEID}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 完成PMS IP配置后，需要安装PMS证书，请参考替换系统初始数字证书进行操作。完成操作后，需要进一步参考UPCF的PMS WebUI客户端登录失败进行浏览器和安全配置。至此，PMS相关配置均已完成，待按顺序完成UPCF与USCDB对接数据后，PMS Web UI功能可以正常使用。

### 9 执行如下命令配置DLB IP，用于配置4G Diameter信令平面的业务地址。

### DEVAID和VPNINDEX自定义，IP地址参考LLD设计文档 ->业务IP对接设计页签 -> 业务接口IP，选择Diameter信令平面规划的IP地址。

### VPNNAME为4G信令面VPN，对应CSLB配置的信令面VPN名称。

```jinja2
{%- for item in add_dlbvpn_list -%}
    ADD DLBVPN:
    {#- --- 必选参数 --- -#}
    VPNINDEX={{item.VPNINDEX}},
    VPNNAME="{{item.VPNNAME}}",
    ;
{%- endfor -%}
```

```jinja2
{%- for item in add_dlbdevaddr_list -%}
    ADD DLBDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNINDEX={{item.VPNINDEX}},
    IPVER={{item.IPVER}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 10 执行**SET SDRTRANS**命令配置SDR的可靠性传输功能。

```jinja2
{%- for item in set_sdrtrans_list -%}
    SET SDRTRANS:
    {#- --- 必选参数 --- -#}
    FLATTYPE={{item.FLATTYPE}},
    TRANSABILITY={{item.TRANSABILITY}},
    OPT={{item.OPT}},
    ;
{%- endfor -%}
```

### 11 执行**MOD INSP**命令修改软参，开启N15接口兼容开关和修改业务token数量。

```jinja2
{%- for item in mod_insp_list -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    ;
{%- endfor -%}
```

### 12 执行**MOD COMPATSWITCH**命令修改软参，营帐消息通知开启抢锁机制。

```jinja2
{%- for item in mod_compatswitch_list -%}
    MOD COMPATSWITCH:
    {#- --- 必选参数 --- -#}
    SWNAME={{item.SWNAME}},
    SWVALUE={{item.SWVALUE}},
    ;
{%- endfor -%}
```

### 13 手动添加UPCF的营帐用户账号。

### 手动添加营帐用户帐号的详细操作请参见增加PGW和DMS用户。

