---
id: ''
name: 检查用户数据同步功能
ne_type: UPCF
type: feature
description: 在对容灾系统例行维护的过程中，指导操作人员检查主用UPCF和容灾UPCF之间的用户数据同步功能是否正常。  如果用户数据同步功能异常，将导致主用UPCF和容灾UPCF的用户数据不一致，用户无法正常使用业务。
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾维护","N*（1+1）FE+2*BE主备地理容灾方案","容灾日常维护","检查容灾系统数据同步功能","检查用户数据同步功能"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
在对容灾系统例行维护的过程中，指导操作人员检查主用UPCF和容灾UPCF之间的用户数据同步功能是否正常。如果用户数据同步功能异常，将导致主用UPCF和容灾UPCF的用户数据不一致，用户无法正常使用业务。

## 必备事项
前提条件

容灾系统已完成搭建。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 在主用UPCF上，登录“UPCF 业务管理”窗口。

### 2 执行**ADD PSUB**命令对测试用户进行开户。

### 3 在容灾UPCF上，登录“UPCF 业务管理”窗口。

### 4 执行**LST PSUB**命令查询测试用户的数据是否已经同步更新。

### 如果没有同步更新，请在华为技术支持工程师的指导下检查主用UPCF和容灾UPCF之间的承载网是否正常连通。

