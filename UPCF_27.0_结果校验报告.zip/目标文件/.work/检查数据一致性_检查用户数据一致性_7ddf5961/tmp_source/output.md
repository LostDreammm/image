---
id: ''
name: 检查用户数据一致性
ne_type: UPCF
type: feature
description: 在对容灾系统例行维护的过程中，指导操作人员检查主用UPCF和容灾UPCF之间的用户数据一致性。  用户数据不一致，容灾倒换后会出现业务异常。
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾维护","2*（FE+BE）主备地理容灾方案","容灾日常维护","检查数据一致性","检查用户数据一致性"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
在对容灾系统例行维护的过程中，指导操作人员检查主用UPCF和容灾UPCF之间的用户数据一致性。用户数据不一致，容灾倒换后会出现业务异常。

## 必备事项
前提条件

容灾系统已完成搭建。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 在主用UPCF上，登录“USCDB MML命令”界面。

### 2 执行**DSP MDBVERIFY**命令检查校验结果。

### 3 在容灾UPCF上，登录“USCDB MML命令”界面。

### 4 执行**DSP MDBVERIFY**命令检查校验结果。

### 5 查看每条输出结果中的“不一致对象”是否小于“10”。

### 是 => 主用UPCF和容灾UPCF的用户数据一致。

### 否 => 主用UPCF和容灾UPCF的用户数据不一致。请按照基线数据建立章节的操作重新建立基线数据。

### “不一致对象个数”表明系统发现的不一致数据的个数，这些不一致数据会被自动校正。当“不一致对象个数”较少，一般少于10时，则可认为正常，不需要重新建立基线数据。

