---
id: ''
name: 检查内存数据库数据备份
ne_type: UPCF
type: feature
description: 内存数据库即虚拟机内部基于内存存储的数据库，保存最新的用户数据和全局数据。内存数据库会在虚拟机掉电后清空，因此需要对其进行备份，以便在虚拟机重启时恢复数据。  内存数据库备份分为自动备份和手工备份：  * 对于自动备份，系统默认在每天03:38:00开始自动备份，故请第二天通过检查最新的数据文件是否生成来验证自动备份功能。 * 对于手工备份，请根据本章节操作步骤中介绍的方法进行验证，手工备份的操作对象只是单个节点，如果要备份所有节点，则需要在所有节点上执行备份操作。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（非SDN）","整网调测","调测系统基本功能","检查内存数据库数据备份"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
内存数据库即虚拟机内部基于内存存储的数据库，保存最新的用户数据和全局数据。内存数据库会在虚拟机掉电后清空，因此需要对其进行备份，以便在虚拟机重启时恢复数据。内存数据库备份分为自动备份和手工备份：* 对于自动备份，系统默认在每天03:38:00开始自动备份，故请第二天通过检查最新的数据文件是否生成来验证自动备份功能。* 对于手工备份，请根据本章节操作步骤中介绍的方法进行验证，手工备份的操作对象只是单个节点，如果要备份所有节点，则需要在所有节点上执行备份操作。

## 必备事项
前提条件

虚拟机模块状态处于“激活态”，请执行**DSP MODULESTAT**查看虚拟机模块状态。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    bkp_node_list:
      type: items
      properties:
        CID:
          name: 'Cluster标识'
          type: integer
          minimum: 0
          maximum: 4096
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        NID:
          name: '节点标识'
          type: integer
          minimum: 0
          maximum: 32768
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        BKPTYPE:
          name: '备份类型'
          type: string
          enum:
          - NORMAL
          - FORCED
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - bkp_node_list:
    - CID: 11
      NID: 13
      BKPTYPE: FORCED
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录OM Portal Web MML界面，在“应用管理>MML”中选择“USCDB”网元。

### 2 执行**LST NODE**查看当前系统中的节点信息。

### 3 执行**BKP NODE**命令备份指定DRU（Data Routing Unit）/DSU（Data Service Unit）模块的内存数据库。

### 以Cluster ID为11，Node ID为13的节点，备份类型为强制备份为例，执行以下命令：

```jinja2
{%- for item in bkp_node_list -%}
    BKP NODE:
    {#- --- 必选参数 --- -#}
    CID={{item.CID}},
    NID={{item.NID}},
    BKPTYPE={{item.BKPTYPE}},
    ;
{%- endfor -%}
```

### 操作结果如下：

### %%BKP NODE: CID=11, NID=13, BKPTYPE=FORCED;%%

### RETCODE = 0  操作成功

### ---    END

### 4 使用PuTTY登录虚拟机，进入备份节点所在虚拟机的操作终端界面。

### 5 切换到“/opt/uscdb/snp/Dump\_LID\_MID”目录，命令示例如下：

### **cd /opt/uscdb/snp/Dump\_LID\_MID**

### “LID”表示节点所在Location的标识。

### “MID”表示节点的模块号。

### 6 执行**ls**命令，检查节点新备份的文件是否存在。

### 存在 => 处理完毕。

### 不存在 => 请联系华为技术支持。

