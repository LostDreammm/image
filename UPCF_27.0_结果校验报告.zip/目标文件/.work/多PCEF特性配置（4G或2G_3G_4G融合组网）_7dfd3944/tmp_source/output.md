---
id: ''
name: 多PCEF特性配置（4G或2G/3G/4G融合组网）
ne_type: UPCF
type: feature
description: 当4G或2G/3G/4G融合组网用户创建IP-CAN会话时，如果有多个不同功能的PCEF（Policy and Charging Enforcement Function）设备向UPCF要求建立Gx会话，UPCF支持根据配置下发不同的策略给指定的PCEF；也支持使用相同的用户IP将这多个会话连接进行绑定，以实现不同PCEF之间的联动（比如从一个PCEF上线，可以给其他PCEF下发策略）。包括以下几种场景：  * 从指定的源PCEF上线、更新、下线，触发给指定的目的PCEF下发规则。 * 从指定的源PCEF上线、更新、下线，触发给该源PCEF下发规则。 * 从任意的源PCEF上线、更新、下线，触发给指定的目的PCEF下发规则。 * 从任意的源PCEF上线、更新、下线，触发给当前PCEF下发规则（同单PCEF场景）。  以第一种场景为例，UPCF同时连接GGSN和外置DPI，GGSN负责IP-CAN会话的QoS管理，外置DPI负责业务流层的控制和配额上报，UPCF向GGSN下发QoS策略。  UPCF向DPI下发P2P限流策略和配额分片；也支持根据DPI上报的配额状态动态调整QoS策略下发给GGSN。  以典型的上网流量包月业务为例，配置如下：  * 配额为2000MB，通过DPI进行累计。 * 每月1号01:00:00进行配额复位，剩余配额采用清零方式。 * 带宽控制：   + 当配额消耗小于50%时，通过向GGSN下发动态规则设置上行带宽为1 Mbit/s，下行带宽为2 Mbit/s。   + 当配额消耗小于50%时，通过向DPI下发预定义规则针对P2P业务进行基本的带宽策略控制。   + 当配额消耗大于等于50%但小于100%时，通过向DPI下发预定义规则针对P2P业务进行限流。   + 当配额消耗大于等于100%时，通过向GGSN下发动态规则将上行带宽降为250 kbit/s，下行带宽降为500 kbit/s。 * 配置动态规则。  各场景下的配置差异可参见表1。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611023 多PCEF","WHFD-611023 多PCEF特性配置","多PCEF特性配置（4G或2G/3G/4G融合组网）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当4G或2G/3G/4G融合组网用户创建IP-CAN会话时，如果有多个不同功能的PCEF（Policy and Charging Enforcement Function）设备向UPCF要求建立Gx会话，UPCF支持根据配置下发不同的策略给指定的PCEF；也支持使用相同的用户IP将这多个会话连接进行绑定，以实现不同PCEF之间的联动（比如从一个PCEF上线，可以给其他PCEF下发策略）。包括以下几种场景：* 从指定的源PCEF上线、更新、下线，触发给指定的目的PCEF下发规则。* 从指定的源PCEF上线、更新、下线，触发给该源PCEF下发规则。* 从任意的源PCEF上线、更新、下线，触发给指定的目的PCEF下发规则。* 从任意的源PCEF上线、更新、下线，触发给当前PCEF下发规则（同单PCEF场景）。以第一种场景为例，UPCF同时连接GGSN和外置DPI，GGSN负责IP-CAN会话的QoS管理，外置DPI负责业务流层的控制和配额上报，UPCF向GGSN下发QoS策略。UPCF向DPI下发P2P限流策略和配额分片；也支持根据DPI上报的配额状态动态调整QoS策略下发给GGSN。以典型的上网流量包月业务为例，配置如下：* 配额为2000MB，通过DPI进行累计。* 每月1号01:00:00进行配额复位，剩余配额采用清零方式。* 带宽控制：  + 当配额消耗小于50%时，通过向GGSN下发动态规则设置上行带宽为1 Mbit/s，下行带宽为2 Mbit/s。  + 当配额消耗小于50%时，通过向DPI下发预定义规则针对P2P业务进行基本的带宽策略控制。  + 当配额消耗大于等于50%但小于100%时，通过向DPI下发预定义规则针对P2P业务进行限流。  + 当配额消耗大于等于100%时，通过向GGSN下发动态规则将上行带宽降为250 kbit/s，下行带宽降为500 kbit/s。* 配置动态规则。各场景下的配置差异可参见表1。

## 必备事项
前提条件

操作员已了解WHFD-611023 多PCEF特性概述。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    mod_pcefabiitem_list:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pcefabiitem_list_1:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pcefabiitem_list_2:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ppcefcat_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFCATID:
          name: '对端PCEF类别标识'
          type: integer
          minimum: 1
          maximum: 16
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFCAT:
          name: '对端PCEF类别'
          type: string
          minLength: 0
          maxLength: 16
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TIMEOUTPROCESS:
          name: '会话超时后处理方式'
          type: string
          enum:
          - ReleaseSingleSession
          - ReleaseAllSession
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ReleaseSingleSession
        ISAPN:
          name: '设置APN'
          type: string
          enum:
          - NO
          - YES
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: NO
        APNID:
          name: 'APN标识'
          type: integer
          minimum: 0
          maximum: 319
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ppcef_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFID:
          name: '对端PCEF标识'
          type: integer
          minimum: 0
          maximum: 1023
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PN:
          name: '对端名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PT:
          name: '协议类型'
          type: string
          enum:
          - DIAMETER
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '对端域名'
          type: string
          minLength: 0
          maxLength: 64
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '对端主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DASWITCH:
          name: '审计开关'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFCAT:
          name: '对端PCEF类别'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DATIME:
          name: '设备间审计时长 （m）'
          type: integer
          minimum: 720
          maximum: 1440
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SKA:
          name: '业务保活时长 （s）'
          type: integer
          minimum: 0
          maximum: 3600
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: 90@90
    add_ppcefl_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFID:
          name: '对端PCEF标识'
          type: integer
          minimum: 0
          maximum: 1023
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LNKID:
          name: '对端链路标识'
          type: integer
          minimum: 0
          maximum: 3
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DISPMODE:
          name: '分发模式'
          type: string
          enum:
          - SpecialQuintuple
          - WellKnownPort
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TPTYPE:
          name: '传输协议类型'
          type: string
          enum:
          - SCTP
          - TCP
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LIP:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LPT:
          name: '本地侦听端口'
          type: integer
          minimum: 1
          maximum: 65534
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PIP:
          name: '对端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PPT:
          name: '对端端口'
          type: integer
          minimum: 0
          maximum: 65534
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ADSTS:
          name: '链路管理状态'
          type: string
          enum:
          - DISABLE
          - ENABLE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ENABLE
        DUALHOME:
          name: '双归属开关'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DIPVER:
          name: '双归属地址IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LKSID:
          name: '链路集标识'
          type: integer
          minimum: 0
          maximum: 511
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LPTMODE:
          name: '本地端口模式'
          type: string
          enum:
          - WellKnownPort
          - MultiplePorts
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: MultiplePorts
        LIPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PIPV6:
          name: '对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - mod_pcefabiitem_list:
    - ABILITYDICTID: 68
      ABILITYITEMID: R8QoS
      ABLITYVALUE: SupportedR8QoS
    mod_pcefabiitem_list_1:
    - ABILITYDICTID: 68
      ABILITYITEMID: UsageMonitor
      ABLITYVALUE: UsageMonitor3GPPR9
    mod_pcefabiitem_list_2:
    - ABILITYDICTID: 68
      ABILITYITEMID: MonitorKeyCodecModeForR9
      ABLITYVALUE: ASCIIMode
    add_ppcefcat_list:
    - PCRFID: 1
      PCEFCATID: 1
      PCEFCAT: 'GGSN'
      TIMEOUTPROCESS: ReleaseAllSession
      ISAPN: NO
      APNID: ''
    add_ppcef_list:
    - PCRFID: 1
      PCEFID: 1
      PN: 'ggsn'
      PT: DIAMETER
      DN: 'huawei.com'
      HN: 'pcef_ggsn.huawei.com'
      DASWITCH: OFF
      ABILITYDICTID: 68
      PCEFCAT: 'GGSN'
      DATIME: 720
      SKA: 90@90
    add_ppcefl_list:
    - PCRFID: 1
      PCEFID: 1
      LNKID: 0
      DISPMODE: SpecialQuintuple
      TPTYPE: TCP
      IPVER: IPV4
      LIP: '10.1.00.33'
      LPT: 8888
      PIP: '10.1.215.101'
      PPT: 8888
      ADSTS: ENABLE
      DUALHOME: ''
      DIPVER: ''
      LKSID: ''
      LPTMODE: MultiplePorts
      LIPV6: ''
      PIPV6: ''
    add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: '12345678901'
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: MBB
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: MULTIPCEF_Service
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 修改对端PCEF能力字典项。

#### 1.1 登录“UPCF MML命令”界面。

#### 1.2 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持R8标准的QoS。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 在4G或2G/3G/4G融合组网中，UPCF与华为UGW9811对接时，“ABILITYDICTID”需设置为“68”。实际的值可以通过如下方式查询：

#### 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。

#### 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。

#### 1.3 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，使其支持基于3GPP R9标准的Usage Monitoring机制。

#### 当配置的FUP业务需使用3GPP R9标准的Usage Monitoring机制时，才需配置“UsageMonitor3GPPR9”的能力，否则，略过此步骤。

#### 命令举例：

```jinja2
{%- set MOD_PCEFABIITEM=getValueList('MOD PCEFABIITEM') -%}
{%- if MOD_PCEFABIITEM -%}
    {%- for item in mod_pcefabiitem_list_1 -%}
        MOD PCEFABIITEM:
        {#- --- 必选参数 --- -#}
        ABILITYDICTID={{item.ABILITYDICTID}},
        ABILITYITEMID={{item.ABILITYITEMID}},
        {#- --- 可选参数 --- -#}
        {%- if item.ABLITYVALUE is not none -%}
            ABLITYVALUE={{item.ABLITYVALUE}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 1.4 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，设置Monitor Key以哪种字节长度处理。

#### Monitor Key的长度处理方式有如下三种：

#### FourBytesHex：MonitorKey按照十六进制4字节处理。

#### MaxFourBytesHex：MonitorKey按照十六进制最大4字节处理。

#### ASCIIMode：MonitorKey按照ASCII码处理。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list_2 -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 2 配置对端类别。

#### 2.1 登录“UPCF MML命令”界面。

#### 2.2 执行**ADD PPCEFCAT**，增加对端PCEF类别定义。

#### 命令举例：

```jinja2
{%- for item in add_ppcefcat_list -%}
    ADD PPCEFCAT:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    PCEFCATID={{item.PCEFCATID}},
    PCEFCAT="{{item.PCEFCAT}}",
    {#- --- 可选参数 --- -#}
    {%- if item.TIMEOUTPROCESS is not none -%}
        TIMEOUTPROCESS={{item.TIMEOUTPROCESS}},
    {%- endif -%}
    {%- if item.ISAPN is not none -%}
        ISAPN={{item.ISAPN}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：ISAPN=YES 时必选 --- -#}
    {%- if item.ISAPN == 'YES' -%}
        APNID={{item.APNID}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 对端类别（Peer PCEF category）用来区分多PCEF场景下不同功能对端PCEF，PCRF针对不同对端类别的PCEF下发不同的策略。如果多个PCEF的对端类别设置相同，那么用户无法通过这多个PCEF同时上线。

#### “会话超时后处理方式”：当PCRF向PCEF下发RAR消息，而PCEF返回响应超时。此时，系统通过该参数的设置来区分不同超时处理：选择ReleaseSingleSession时，系统只向当前处理会话的PCEF发送ASR；选择ReleaseAllSession，则系统会向所有绑定会话的PCEF发送ASR。

#### 2.3 执行**ADD PPCEF**，给对端指定对端PCEF类别。

#### ADD PPCEF使用举例：

```jinja2
{%- for item in add_ppcef_list -%}
    ADD PPCEF:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    PCEFID={{item.PCEFID}},
    PT={{item.PT}},
    HN="{{item.HN}}",
    {#- --- 可选参数 --- -#}
    {%- if item.PN is not none -%}
        PN="{{item.PN}}",
    {%- endif -%}
    {%- if item.PCEFCAT is not none -%}
        PCEFCAT="{{item.PCEFCAT}}",
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：PT=DIAMETER 时必选 --- -#}
    {%- if item.PT == 'DIAMETER' -%}
        DN="{{item.DN}}",
    {%- endif -%}
    {#- --- 条件必选：PT=DIAMETER 时必选 --- -#}
    {%- if item.PT == 'DIAMETER' -%}
        ABILITYDICTID={{item.ABILITYDICTID}},
    {%- endif -%}
    {#- --- 条件必选：DASWITCH=ON 时必选 --- -#}
    {%- if item.DASWITCH == 'ON' -%}
        DATIME={{item.DATIME}},
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：PT=DIAMETER 时可选 --- -#}
    {%- if item.PT == 'DIAMETER' -%}
        {%- if item.DASWITCH is not none -%}
            DASWITCH={{item.DASWITCH}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：PT=DIAMETER 时可选 --- -#}
    {%- if item.PT == 'DIAMETER' -%}
        {%- if item.SKA is not none -%}
            SKA={{item.SKA}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 2.4 执行**ADD PPCEFL**增加UPCF与对端PCEF的链路。

#### ADD PPCEFL使用举例：

```jinja2
{%- for item in add_ppcefl_list -%}
    ADD PPCEFL:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    PCEFID={{item.PCEFID}},
    LNKID={{item.LNKID}},
    DISPMODE={{item.DISPMODE}},
    TPTYPE={{item.TPTYPE}},
    PPT={{item.PPT}},
    {#- --- 可选参数 --- -#}
    {%- if item.ADSTS is not none -%}
        ADSTS={{item.ADSTS}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：TPTYPE=TCP 时必选 --- -#}
    {%- if item.TPTYPE == 'TCP' -%}
        IPVER={{item.IPVER}},
    {#- --- 条件必选：DUALHOME=OFF 时必选 --- -#}
    {%- elif item.DUALHOME == 'OFF' -%}
        IPVER={{item.IPVER}},
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
    {%- if item.DIPVER == 'IPV4' -%}
        LIP="{{item.LIP}}",
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- elif item.IPVER == 'IPV4' -%}
        LIP="{{item.LIP}}",
    {%- endif -%}
    {#- --- 条件必选：DISPMODE=SpecialQuintuple 时必选 --- -#}
    {%- if item.DISPMODE == 'SpecialQuintuple' -%}
        LPT={{item.LPT}},
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV4 时必选 --- -#}
    {%- if item.DIPVER == 'IPV4' -%}
        PIP="{{item.PIP}}",
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- elif item.IPVER == 'IPV4' -%}
        PIP="{{item.PIP}}",
    {%- endif -%}
    {#- --- 条件必选：DUALHOME=ON 时必选 --- -#}
    {%- if item.DUALHOME == 'ON' -%}
        DIPVER={{item.DIPVER}},
    {%- endif -%}
    {#- --- 条件必选：TPTYPE=SCTP 时必选 --- -#}
    {%- if item.TPTYPE == 'SCTP' -%}
        DUALHOME={{item.DUALHOME}},
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
    {%- if item.DIPVER == 'IPV6' -%}
        LIPV6="{{item.LIPV6}}",
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- elif item.IPVER == 'IPV6' -%}
        LIPV6="{{item.LIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：DIPVER=IPV6 时必选 --- -#}
    {%- if item.DIPVER == 'IPV6' -%}
        PIPV6="{{item.PIPV6}}",
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- elif item.IPVER == 'IPV6' -%}
        PIPV6="{{item.PIPV6}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：DISPMODE=SpecialQuintuple 时可选 --- -#}
    {%- if item.DISPMODE == 'SpecialQuintuple' -%}
        {%- if item.LKSID is not none -%}
            LKSID={{item.LKSID}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：DISPMODE=SpecialQuintuple 时可选 --- -#}
    {%- if item.DISPMODE == 'SpecialQuintuple' -%}
        {%- if item.LPTMODE is not none -%}
            LPTMODE={{item.LPTMODE}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 3 登录UPCF WebUI界面。

### 4 配置配额。

### 导航入口为“业务管理 > 业务 > 配额”。

### 配额（Quota）是指一个指定周期（或一个会话内）可以供用户使用的流量或在线时长。当业务的使用与流量、时间相关时，需要配置配额。

### “目的PEER”：表示该配额分片下发给哪个对端PCEF。该枚举项需要在OM Portal使用**ADD PPCEFCAT**命令定义才能显示在PMS（Policy Management Service）界面。

### 配额的数据规划表如表3所示，详细参数说明请参见配额参数表。

### **表3** 配额

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 配额 | 基本信息 | 名称 | MULTIPCEF\_Quota |

### |  |  | 配额管理归属 | UPCC |

### |  |  | 配额类型 | 流量 |

### |  |  | 类型 | 会话级 |

### |  |  | 监控键值 | 101 |

### |  |  | 值(KB) | 2048000 |

### |  |  | 分片类型 | 百分比 |

### |  |  | 分片(%) | 10 |

### |  |  | 目的PEER | DPI |

### |  | 复位设置 | 结帐模式 | 自然日历 |

### |  |  | 复位周期类型 | 月 |

### |  |  | 复位日 | 1 |

### |  |  | 复位时间 | 01:00:00 |

### |  |  | 剩余额处理方式 | 清零 |

### |  | 阈值设置 | Level1(%) | 50 |

### 5 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 需要配置8个条件组，数据规划表如表4所示，详细参数说明请参见条件组参数表。

### **表4** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | CG\_Basic1 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | Condition\_Basic1 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | MULTIPCEF\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Less Than |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示配额耗尽。 |

### |  | 条件2 | 名称 | Condition\_Source1 |

### |  |  | 对象属性 | * 对象：IPSession * 属性：SourcePCEF |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | GGSN |

### | 条件组2 | 基本信息 | 名称 | CG\_Basic2 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | Condition\_Basic2 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | MULTIPCEF\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Normal  说明：  “Normal”：表示配额阈值小于Level1。 |

### |  | 条件2 | 名称 | Condition\_Source2 |

### |  |  | 对象属性 | * 对象：IPSession * 属性：SourcePCEF |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | DPI |

### | 条件组3 | 基本信息 | 名称 | CG\_Basic3 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | Condition\_Change1 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | MULTIPCEF\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示配额耗尽。 |

### |  | 条件2 | 名称 | Condition\_Source1 |

### |  |  | 对象属性 | * 对象：IPSession * 属性：SourcePCEF |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | GGSN |

### | 条件组4 | 基本信息 | 名称 | CG\_Basic4 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | Condition\_Change2 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | MULTIPCEF\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Not Less Than |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Level1 |

### |  | 条件2 | 名称 | Condition\_Source2 |

### |  |  | 对象属性 | * 对象：IPSession * 属性：SourcePCEF |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | DPI |

### | 条件组5 | 基本信息 | 名称 | CG\_Change1 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | Condition\_Basic2 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | MULTIPCEF\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Normal  说明：  “Normal”：表示配额阈值小于Level1。 |

### | 条件组6 | 基本信息 | 名称 | CG\_Change2 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | Condition\_Change3 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | MULTIPCEF\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Level1 |

### | 条件组7 | 基本信息 | 名称 | CG\_Change3 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | Condition\_Change1 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | MULTIPCEF\_Quota  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Exhaust  说明：  “Exhaust”表示配额耗尽。 |

### | 条件组8 | 基本信息 | 名称 | CG\_Termination |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | Condition\_Termination |

### |  |  | 对象属性 | * 对象：IPSession * 属性：SourcePCEF |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | GGSN |

### 6 配置动作组。

### 导航入口为“策略管理 > 策略 > 动作组”。

### 若配置的规则为动态规则，则必须配置动作组。

### 若配置的规则为预定义规则或预定义规则组，“动作组”为可选。若需调整PCEF下发的QoS，则需配置动作QoSAction，并在配置业务时设置“QoS模式”。

### 此场景配置动态规则需考虑默认承载的QoS、调整带宽、计费动作和流量上报，则每个动作组需配置动作：DefaultBearerQoS、QoSAction、ChargingAction和UsageReport。相关应用场景如下：

#### 6.1 DefaultBearerQoS：当需要建立默认承载时必须配置此动作。

#### 6.2 QoSAction：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制QoS。

#### 6.3 ChargingAction：当需要做计费策略控制时，配置此动作（若对端为华为UGW9811，此动作必须配置）。其中属性“RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。

#### 6.4 UsageReport ：当需要进行流量上报时，配置此动作。

### 需要配置4个动作组，用于在配额未耗尽和配额耗尽时向GGSN下发动作。动作组的数据规划表如表5所示，详细参数说明请参见动作组参数表。

### **表5** 动作组

### | 类别 | 参数 |  |  | 取值样例 |

### | --- | --- | --- | --- | --- |

### | 动作组1 | 基本信息 | 名称 |  | AG1\_Basic1 |

### |  | 动作 | 动作 |  | DefaultBearerQoS |

### |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |

### |  |  |  | ARPLevel | * 值类型：Value * 值：1 |

### |  |  |  | PreemptionCapability | * 值类型：Value * 值：Disabled |

### |  |  |  | PreemptionVulnerability | * 值类型：Value * 值：Enabled |

### |  |  |  | AMBRDL | * 值类型：Value * 值(kbit/s)：2000 |

### |  |  |  | AMBRUL | * 值类型：Value * 值(kbit/s)：1000 |

### | 动作组2 | 基本信息 | 名称 |  | AG1\_Change1 |

### |  | 动作 | 动作 |  | DefaultBearerQoS |

### |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |

### |  |  |  | ARPLevel | * 值类型：Value * 值：1 |

### |  |  |  | PreemptionCapability | * 值类型：Value * 值：Disabled |

### |  |  |  | PreemptionVulnerability | * 值类型：Value * 值：Enabled |

### |  |  |  | AMBRDL | * 值类型：Value * 值(kbit/s)：500 |

### |  |  |  | AMBRUL | * 值类型：Value * 值(kbit/s)：250 |

### | 动作组3 | 基本信息 | 名称 |  | AG2\_Basic1 |

### |  | 动作1 | 动作 |  | QoSAction |

### |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |

### |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：1000 |

### |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：2000 |

### |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：1000 |

### |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：2000 |

### |  |  |  | ARPLevel | * 值类型：Value * 值：1 |

### |  | 动作2 | 动作 |  | ChargingAction |

### |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |

### |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示按月计费。 |

### |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |

### |  | 动作3 | 动作 |  | UsageReport |

### |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |

### | 动作组4 | 基本信息 | 名称 |  | AG2\_Change1 |

### |  | 动作1 | 动作 |  | QoSAction |

### |  |  | 动作元素 | QCI | * 值类型：Value * 值：8 |

### |  |  |  | MBRUL | * 值类型：Value * 值(kbit/s)：250 |

### |  |  |  | MBRDL | * 值类型：Value * 值(kbit/s)：500 |

### |  |  |  | GBRUL | * 值类型：Value * 值(kbit/s)：250 |

### |  |  |  | GBRDL | * 值类型：Value * 值(kbit/s)：500 |

### |  |  |  | ARPLevel | * 值类型：Value * 值：1 |

### |  | 动作2 | 动作 |  | ChargingAction |

### |  |  | 动作元素 | MeteringMethod | * 值类型：Value * 值：Volume |

### |  |  |  | RatingGroup | * 值类型：Value * 值：1 说明：  与计费系统协商一致。RatingGroup为1，表示按月计费。 |

### |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |

### |  | 动作3 | 动作 |  | UsageReport |

### |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |

### 7 配置业务流。

### 导航入口为“策略管理 > 策略 > 业务流”。

### 当对端为华为GGSN时，所有的动态规则都必须配置业务流。

### 业务流的数据规划如表6所示，详细参数说明请参见业务流参数表。

### **表6** 业务流

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务流 | 基本信息 | 名称 | Flow\_Filter |

### |  | 流过滤器1 | 名称 | up\_pass |

### |  |  | 流方向 | Up |

### |  |  | 协议 | Any IP Protocol |

### |  | 流过滤器2 | 名称 | down\_pass |

### |  |  | 流方向 | Down |

### |  |  | 协议 | Any IP Protocol |

### 8 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 关键参数配置原则如下：

### 只有当操作类型为“Change Rule”、“Install Rule”或“Term IP-Can Session”，“目的PEER”为可选。

### “目的PEER”：不设置该参数（默认值）表示该规则只下发给当前处理会话的对端；否则表示该规则下发给指定的对端。

### 规则的数据规划表如表7所示，详细参数说明请参见规则参数表。

### **表7** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | Rule1\_Default1 |

### |  |  | 类型 | Default Bearer QoS  说明：  默认承载QoS场景，规则类型必须为“Default Bearer QoS”。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Basic1  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG1\_Basic1  说明：  已在动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | Rule1\_Default2 |

### |  |  | 类型 | Default Bearer QoS  说明：  默认承载QoS场景，规则类型必须为“Default Bearer QoS”。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Basic3  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG1\_Change1  说明：  已在动作组中定义。 |

### | 规则3 | 基本信息 | 名称 | Rule2\_Default1 |

### |  |  | 类型 | Default Bearer QoS  说明：  默认承载QoS场景，规则类型必须为“Default Bearer QoS”。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Change1  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG1\_Basic1  说明：  已在动作组中定义。 |

### | 规则4 | 基本信息 | 名称 | Rule2\_Default2 |

### |  |  | 类型 | Default Bearer QoS  说明：  默认承载QoS场景，规则类型必须为“Default Bearer QoS”。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Change3  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG1\_Change1  说明：  已在动作组中定义。 |

### | 规则5 | 基本信息 | 名称 | Rule\_GGSN\_Basic1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Dynamic |

### |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |

### |  |  | 目的PEER | GGSN  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Basic1  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG2\_Basic1  说明：  已在动作组中定义。 |

### | 规则6 | 基本信息 | 名称 | Rule\_DPI\_Basic1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined |

### |  |  | 预定义名 | P2P\_Basic  说明：  与DPI协商一致。 |

### |  |  | 目的PEER | DPI  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Basic2  说明：  已在条件组中定义。 |

### | 规则7 | 基本信息 | 名称 | Rule\_DPI\_Basic2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined |

### |  |  | 预定义名 | P2P\_Control  说明：  与DPI协商一致。 |

### |  |  | 目的PEER | DPI  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Basic4  说明：  已在条件组中定义。 |

### | 规则8 | 基本信息 | 名称 | Rule\_GGSN\_Basic2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Dynamic |

### |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |

### |  |  | 目的PEER | GGSN  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Basic3  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG2\_Change1 |

### | 规则9 | 基本信息 | 名称 | Rule\_DPI\_Change1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined |

### |  |  | 预定义名 | P2P\_Basic  说明：  与DPI协商一致。 |

### |  |  | 目的PEER | DPI  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Change1  说明：  已在条件组中定义。 |

### | 规则10 | 基本信息 | 名称 | Rule\_GGSN\_Change1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Dynamic |

### |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |

### |  |  | 目的PEER | GGSN  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Change1  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG2\_Basic1  说明：  已在动作组中定义。 |

### | 规则11 | 基本信息 | 名称 | Rule\_DPI\_Change2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined |

### |  |  | 预定义名 | P2P\_Control  说明：  与DPI协商一致。 |

### |  |  | 目的PEER | DPI  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Change2  说明：  已在条件组中定义。 |

### | 规则12 | 基本信息 | 名称 | Rule\_GGSN\_Change2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Dynamic |

### |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |

### |  |  | 目的PEER | GGSN  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Change3  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG2\_Change1  说明：  已在动作组中定义。 |

### | 规则13 | 基本信息 | 名称 | Rule\_Termination |

### |  |  | 操作类型 | Term IP-CAN Session |

### |  |  | 目的PEER | DPI  说明：  已在登录“UPCF MML命令”界面，使用**ADD PPCEFCAT**命令自定义配置。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Termination  说明：  已在条件组中定义。 |

### 9 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表8所示，详细参数说明请参见策略参数表。

### **表8** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略1 | 基本信息 | 名称 | Policy\_Establish |

### |  | 触发器 | 名称 | IPCANSessionEstablish |

### |  | 规则 | 名称 | * Rule1\_Default1 * Rule1\_Default2 * Rule\_GGSN\_Basic1 * Rule\_DPI\_Basic1 * Rule\_DPI\_Basic2 * Rule\_GGSN\_Basic2 说明：  已在规则中定义。 |

### | 策略2 | 基本信息 | 名称 | Policy\_Using |

### |  | 触发器 | 名称 | UsageReport |

### |  | 规则 | 名称 | * Rule2\_Default1 * Rule2\_Default2 * Rule\_GGSN\_Change1 * Rule\_DPI\_Change1 * Rule\_DPI\_Change2 * Rule\_GGSN\_Change2 说明：  已在规则中定义。 |

### | 策略3 | 基本信息 | 名称 | Policy\_Termination |

### |  | 触发器 | 名称 | IPCANSessionTermination |

### |  | 规则 | 名称 | Rule\_Termination  说明：  已在规则中定义。 |

### 10 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

### 业务的数据规划如表9所示，详细参数说明请参见业务参数表。

### **表9** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | MULTIPCEF\_Service |

### |  |  | 类型 | BASIC\_SERVICE |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | * Policy\_Establish * Policy\_Using * Policy\_Termination 说明：  已在策略中定义。 |

### |  | 配额 | 名称 | MULTIPCEF\_Quota  说明：  已在配额中定义。 |

### 11 发放业务。

#### 11.1 登录“UPCF 业务管理”窗口。

#### 11.2 执行**ADD PSUB**增加一个用户。

#### “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=11.2 -->
```

#### 11.3 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=11.3 -->
```

