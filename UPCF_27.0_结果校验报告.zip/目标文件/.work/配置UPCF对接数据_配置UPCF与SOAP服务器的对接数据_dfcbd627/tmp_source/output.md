---
id: ''
name: 配置UPCF与SOAP服务器的对接数据
ne_type: UPCF
type: feature
description: UPCF可以与SOAP服务器对接，在用户使用量达到某个设定的门限值时，可以发送SOAP通知到SOAP服务器，转发给用户通知提醒消费情况。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（非SDN）","配置UPCF对接数据","配置UPCF与SOAP服务器的对接数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UPCF可以与SOAP服务器对接，在用户使用量达到某个设定的门限值时，可以发送SOAP通知到SOAP服务器，转发给用户通知提醒消费情况。

## 必备事项
前提条件

* 已完成软件安装。
* 已完成基础数据配置。
* UPCF与SOAP服务器的网络连接正常。
* 已经获得运营商规划的UPCF与SOAP服务器的对接IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_ntsvpn_list:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 31
          required: true
          description: '该参数需要与SPS网元的**ADD L3VPNINST**和**ADD VPNINSTAF**命令中“VPN实例名称”参数值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
    add_ntsdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 7
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 15
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划，由运营商提供。 只有当“IPVER”为“IPV4”时，才会规划IPv4地址。 当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ntspeer_list:
      type: items
      properties:
        PEERID:
          name: '对端服务器ID'
          type: integer
          minimum: 1
          maximum: 255
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        PEERNAME:
          name: '对端服务器名称'
          type: string
          minLength: 0
          maxLength: 128
          required: true
          description: '本端规划。'
          data_source: ''
          pattern: ''
          default: ''
        PEERTYPE:
          name: '对端服务器类型'
          type: string
          enum:
          - SMS
          - E-MAIL
          - SOAP
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    add_ntspeerlinkcfg_list:
      type: items
      properties:
        LINKID:
          name: '链路ID'
          type: integer
          minimum: 1
          maximum: 255
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        PEERID:
          name: '对端服务器ID'
          type: integer
          minimum: 1
          maximum: 255
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        LOCALROLE:
          name: '本地角色'
          type: string
          enum:
          - SOAPClient
          - SMTPClient
          - JMSClient
          - CMPPClient
          - SMPPClient
          - SGIPClient
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        WSDL:
          name: 'WSDL文件'
          type: string
          enum:
          - NwT
          - NlK
          - IrZ
          - Common
          - FrB
          - IdnX
          - Hwl
          required: false
          description: '由运营商提供，从对端配置中获取。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        LOCALIP:
          name: '本端IP地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商提供，从本端配置中获取。'
          data_source: ''
          pattern: ''
          default: ''
        PEERIP:
          name: '对端IP地址'
          type: string
          maxLength: 15
          required: false
          description: '由运营商提供，从对端配置中获取。'
          data_source: ''
          pattern: ''
          default: ''
        PEERPORT:
          name: '对端端口'
          type: integer
          minimum: 1
          maximum: 65534
          required: true
          description: '由运营商提供，从对端配置中获取。'
          data_source: ''
          pattern: ''
          default: ''
        SOAPURL:
          name: 'SOAP服务器URL'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '与对端服务器协商一致。'
          data_source: ''
          pattern: ''
          default: ''
        DEFLINK:
          name: '默认链路'
          type: string
          enum:
          - YES
          - NO
          required: false
          description: '在此场景下固定配置为“YES”。'
          data_source: ''
          pattern: ''
          default: ''
        CERTSCENE:
          name: '证书应用场景'
          type: string
          enum:
          - 'NULL'
          - UPCF_NTS_certForComSOAP
          - UPCF_NTS_certForSMPP
          - UPCF_NTS_certForCMPP
          - UPCF_NTS_certForSMTP
          required: false
          description: '在此场景下需要根据“SOAP服务器URL”配置情况判断是否加载证书。 * 当参数“SOAP服务器URL”配置值前缀为“https”时，该参数取值必须配置为“UPCF_NTS_certForComSOAP”。 * 当参数“SOAP服务器URL” 前缀不为“https”时，该参数需配置为“NULL”。'
          data_source: ''
          pattern: ''
          default: ''
        DESCRIPTION:
          name: '描述'
          type: string
          minLength: 0
          maxLength: 32
          required: false
          description: '与对端服务器协商一致。'
          data_source: ''
          pattern: ''
          default: ''
        LOCALIPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PEERIPV6:
          name: '对端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CFM:
          name: '确认密码'
          type: string
          minLength: 1
          maxLength: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ISENCRYPTED:
          name: '是否支持加密'
          type: string
          enum:
          - YES
          - NO
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LINKGRP:
          name: '链路组'
          type: string
          enum:
          - 'NULL'
          - Group1
          - Group2
          - Group3
          - Group4
          - Group5
          - Group6
          - Group7
          - Group8
          - Group9
          - Group10
          - Group11
          - Group12
          - Group13
          - Group14
          - Group15
          - Group16
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: 'NULL'
        PASSWD:
          name: '密码'
          type: string
          minLength: 1
          maxLength: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SENDER:
          name: '发送人'
          type: string
          minLength: 0
          maxLength: 96
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TLSCFGID:
          name: 'TLS配置ID'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRNAME:
          name: '用户名'
          type: string
          minLength: 0
          maxLength: 96
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LOGONURL:
          name: '认证服务器URL'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PRECEDENCE:
          name: '优先级'
          type: integer
          minimum: 0
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: 0
  examples:
  - add_ntsvpn_list:
    - VPNINDEX: 0
      VPNNAME: 'COMMON_VPN'
    add_ntsdevaddr_list:
    - DEVAID: 0
      VPNINDEX: 0
      IPVER: IPV4
      IP: '10.50.5.123'
      IPV6: ''
    add_ntspeer_list:
    - PEERID: 1
      PEERNAME: 'SOAP'
      PEERTYPE: SOAP
    add_ntspeerlinkcfg_list:
    - LINKID: 7
      PEERID: 1
      LOCALROLE: SOAPClient
      WSDL: Common
      IPVER: IPV4
      LOCALIP: '10.50.5.123'
      PEERIP: '10.0.0.105'
      PEERPORT: 7890
      SOAPURL: 'http://10.0.0.105:7890/mockScfPccSoapServiceEndpointBinding'
      DEFLINK: YES
      CERTSCENE: 'NULL'
      DESCRIPTION: 'soap link'
      LOCALIPV6: ''
      PEERIPV6: ''
      CFM: ''
      ISENCRYPTED: ''
      LINKGRP: 'NULL'
      PASSWD: ''
      SENDER: ''
      TLSCFGID: ''
      USRNAME: ''
      LOGONURL: ''
      PRECEDENCE: ''
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录OM Portal Web MML界面，在“应用管理>MML”中选择“UPCF”网元。

### 2 执行****ADD NTSVPN****命令增加UPCF通知中心的VPN信息。

```jinja2
{%- for item in add_ntsvpn_list -%}
    ADD NTSVPN:
    {#- --- 必选参数 --- -#}
    VPNINDEX={{item.VPNINDEX}},
    VPNNAME="{{item.VPNNAME}}",
    ;
{%- endfor -%}
```

### 3 执行**ADD NTSDEVADDR**命令增加UPCF与SOAP服务器对接的IP地址。以参数“IPVER”值为“IPV4”为例：

```jinja2
{%- for item in add_ntsdevaddr_list -%}
    ADD NTSDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNINDEX={{item.VPNINDEX}},
    IPVER={{item.IPVER}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 4 执行**ADD NTSPEER**命令增加UPCF与SOAP服务器对接的一条实体记录。

```jinja2
{%- for item in add_ntspeer_list -%}
    ADD NTSPEER:
    {#- --- 必选参数 --- -#}
    PEERID={{item.PEERID}},
    PEERNAME="{{item.PEERNAME}}",
    PEERTYPE={{item.PEERTYPE}},
    ;
{%- endfor -%}
```

### 5 执行****ADD NTSPEERLINKCFG****命令增加UPCF与SOAP服务器对接的链路信息。

```jinja2
{%- for item in add_ntspeerlinkcfg_list -%}
    ADD NTSPEERLINKCFG:
    {#- --- 必选参数 --- -#}
    LINKID={{item.LINKID}},
    PEERID={{item.PEERID}},
    LOCALROLE={{item.LOCALROLE}},
    IPVER={{item.IPVER}},
    PEERPORT={{item.PEERPORT}},
    {#- --- 可选参数 --- -#}
    {%- if item.DESCRIPTION is not none -%}
        DESCRIPTION="{{item.DESCRIPTION}}",
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：LOCALROLE=SOAPClient 时必选 --- -#}
    {%- if item.LOCALROLE == 'SOAPClient' -%}
        WSDL={{item.WSDL}},
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        LOCALIP="{{item.LOCALIP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        PEERIP="{{item.PEERIP}}",
    {%- endif -%}
    {#- --- 条件必选：LOCALROLE=SOAPClient 时必选 --- -#}
    {%- if item.LOCALROLE == 'SOAPClient' -%}
        SOAPURL="{{item.SOAPURL}}",
    {%- endif -%}
    {#- --- 条件必选：WSDL=Common/IdnX/Hwl 时必选 --- -#}
    {%- if item.WSDL in ['Common', 'IdnX', 'Hwl'] -%}
        DEFLINK={{item.DEFLINK}},
    {%- endif -%}
    {#- --- 条件必选：LOCALROLE=CMPPClient/SMPPClient/SMTPClient 时必选 --- -#}
    {%- if item.LOCALROLE in ['CMPPClient', 'SMPPClient', 'SMTPClient'] -%}
        CERTSCENE={{item.CERTSCENE}},
    {#- --- 条件必选：WSDL=Common/IdnX/Hwl 时必选 --- -#}
    {%- elif item.WSDL in ['Common', 'IdnX', 'Hwl'] -%}
        CERTSCENE={{item.CERTSCENE}},
    {%- endif -%}
    {#- --- 条件必选：LOCALROLE=CMPPClient/SMPPClient/SMTPClient 时必选 --- -#}
    {%- if item.LOCALROLE in ['CMPPClient', 'SMPPClient', 'SMTPClient'] -%}
        ISENCRYPTED={{item.ISENCRYPTED}},
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        LOCALIPV6="{{item.LOCALIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：WSDL=NwT 时必选 --- -#}
    {%- if item.WSDL == 'NwT' -%}
        LOGONURL="{{item.LOGONURL}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        PEERIPV6="{{item.PEERIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：LOCALROLE=SMPPClient/SMTPClient 时必选 --- -#}
    {%- if item.LOCALROLE in ['SMPPClient', 'SMTPClient'] -%}
        SENDER="{{item.SENDER}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：LOCALROLE=CMPPClient/SMPPClient 时可选 --- -#}
    {%- if item.LOCALROLE in ['CMPPClient', 'SMPPClient'] -%}
        {%- if item.LINKGRP is not none -%}
            LINKGRP={{item.LINKGRP}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：WSDL=Common/IdnX/Hwl 时可选 --- -#}
    {%- if item.WSDL in ['Common', 'IdnX', 'Hwl'] -%}
        {%- if item.PRECEDENCE is not none -%}
            PRECEDENCE={{item.PRECEDENCE}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：LOCALROLE=CMPPClient/SMPPClient/SOAPClient/SMTPClient 时可选 --- -#}
    {%- if item.LOCALROLE in ['CMPPClient', 'SMPPClient', 'SOAPClient', 'SMTPClient'] -%}
        {%- if item.TLSCFGID is not none -%}
            TLSCFGID={{item.TLSCFGID}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件必选/可选参数 --- -#}
    {#- --- 确认密码: 条件必选(本地角色=CMPPClient|SMPPClient|SGIPClient) / 条件可选(本地角色=SMTPClient) --- -#}
    {%- if (item.LOCALROLE in ['CMPPClient', 'SMPPClient', 'SGIPClient']) -%}
        CFM="{{item.CFM}}",
    {%- elif (item.LOCALROLE == 'SMTPClient') -%}
        {%- if item.CFM is not none -%}
            CFM="{{item.CFM}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 密码: 条件必选(本地角色=CMPPClient|SMPPClient|SGIPClient) / 条件可选(本地角色=SMTPClient) --- -#}
    {%- if (item.LOCALROLE in ['CMPPClient', 'SMPPClient', 'SGIPClient']) -%}
        PASSWD="{{item.PASSWD}}",
    {%- elif (item.LOCALROLE == 'SMTPClient') -%}
        {%- if item.PASSWD is not none -%}
            PASSWD="{{item.PASSWD}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 用户名: 条件必选(本地角色=CMPPClient|SMPPClient|SGIPClient) / 条件可选(本地角色=SMTPClient) --- -#}
    {%- if (item.LOCALROLE in ['CMPPClient', 'SMPPClient', 'SGIPClient']) -%}
        USRNAME="{{item.USRNAME}}",
    {%- elif (item.LOCALROLE == 'SMTPClient') -%}
        {%- if item.USRNAME is not none -%}
            USRNAME="{{item.USRNAME}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### UPCF与SOAP服务器对接时，配置参数如下：

### 参数“链路ID”包含4条系统缺省配置记录，所以此对接链路从“4”开始根据规划值进行配置。

### UPCF与短消息中心的对接协议包括：SOAP（Simple Object Access Protocol）、JMS（Java Messaging Service）、CMPP（China Mobile Peer To Peer protocol）和SMPP（Short Message Peer to Peer）四种协议，所以参数“本地角色”根据运营商需要可以选择“SOAPClient（SOAP客户端）”、“JMSClient（JMS客户端）”、“CMPPClient（CMPP客户端）”和“SMPPClient（SMPP客户端）”中的一种。当UPCF与短消息中心的对接协议为CMPP时，具体配置请参考当UPCF与短消息中心的对接协议为SMS协议时，具体配置请参考配置UPCF与短消息中心的对接数据。

### 保存通知消息（包含短消息和邮件）的记录数由如下软参控制：

### UPCF为每个用户保存的通知消息的最大记录数由软参**VRM\_NOTIFYMSGMAXRECORDPERSUB**控制，默认值为10条。

### UPCF为每个用户保存的通知消息的最大天数由软参**VRM\_NOTIFYMSGMAXDAYPERSUB**控制，默认值为31天。

### UPCF允许保存的待通知最大记录数由软参**VRM\_NOTIFYMSGMAXWAITEDRECORDS**控制，默认值为500000条。以上软参均通过**MOD INSP**命令修改，此操作要求在华为工程师的指导下操作。

### 当UPCF允许保存的待通知最大记录数存满时，将导致后续短信无法被记录和发送，将被直接丢弃。在部署用户通知业务时，请合理规划软参**VRM\_NOTIFYMSGMAXWAITEDRECORDS**的设置。

### 若已设置**VRM\_NOTIFYMSGMAXWAITEDRECORDS**软参，但仍出现短信无法发送问题，请执行**SET SCANSW**命令，设置“SW6”参数为打开抑制短信记录超期清理的开关，恢复用户通知业务。

