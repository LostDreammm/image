# 配置UPCF与SOAP服务器的对接数据

* 操作场景
* 必备事项
* 操作步骤
* 验证方法

## 操作场景

UPCF可以与SOAP服务器对接，在用户使用量达到某个设定的门限值时，可以发送SOAP通知到SOAP服务器，转发给用户通知提醒消费情况。

## 必备事项

前提条件

* 已完成软件安装。
* 已完成基础数据配置。
* UPCF与SOAP服务器的网络连接正常。
* 已经获得运营商规划的UPCF与SOAP服务器的对接IP地址。

数据

配置前规划的对接数据如表1所示。

**表1** 对接数据

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **ADD NTSVPN** | VPNINDEX（VPN索引） | 0 | 全网规划，由运营商提供。 |
|  | VPNNAME（VPN名称） | COMMON\_VPN | 该参数需要与SPS网元的**ADD L3VPNINST**和**ADD VPNINSTAF**命令中“VPN实例名称”参数值保持一致。 |
| **ADD NTSDEVADDR** | DEVAID 设备地址标识） | 0 | 本端规划，取值范围内不允许重复。 |
|  | VPNINDEX（VPN索引） | 0 | 全网规划，由运营商提供。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，由运营商提供。 |
|  | IP（IPV4地址） | 10.50.5.123 | 全网规划，由运营商提供。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
| **ADD NTSPEER** | PEERID（对端服务器ID） | 1 | 本端规划，取值范围内不允许重复。 |
|  | PEERNAME（对端服务器名称） | SOAP | 本端规划。 |
|  | PEERTYPE（对端服务器类型） | SOAP | 全网规划，由运营商提供。 |
| **ADD NTSPEERLINKCFG** | LINKID（链路ID） | 7 | 本端规划，取值范围内不允许重复。 |
|  | PEERID（对端服务器ID） | 1 | 全网规划，由运营商提供。 |
|  | LOCALROLE（本地角色） | SOAPClient | 全网规划，由运营商提供。 |
|  | WSDL（WSDL文件） | Common | 由运营商提供，从对端配置中获取。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，由运营商提供。 |
|  | LOCALIP（本端IP地址） | 10.50.5.123 | 由运营商提供，从本端配置中获取。 |
|  | PEERIP（对端IP地址） | 10.0.0.105 | 由运营商提供，从对端配置中获取。 |
|  | PEERPORT（对端端口） | 7890 | 由运营商提供，从对端配置中获取。 |
|  | SOAPURL（SOAP服务器URL） | http://10.0.0.105:7890/mockScfPccSoapServiceEndpointBinding | 与对端服务器协商一致。 |
|  | DEFLINK（默认链路） | YES | 在此场景下固定配置为“YES”。 |
|  | CERTSCENE（证书应用场景） | NULL | 在此场景下需要根据“SOAP服务器URL”配置情况判断是否加载证书。   * 当参数“SOAP服务器URL”配置值前缀为“https”时，该参数取值必须配置为“UPCF\_NTS\_certForComSOAP”。 * 当参数“SOAP服务器URL” 前缀不为“https”时，该参数需配置为“NULL”。 |
|  | DESCRIPTION（描述） | soap link | 与对端服务器协商一致。 |

## 操作步骤

1. 登录OM Portal Web MML界面，在“应用管理>MML”中选择“UPCF”网元。
2. 执行****ADD NTSVPN****命令增加UPCF通知中心的VPN信息。

   ```
   ADD NTSVPN: VPNINDEX=0, VPNNAME="COMMON_VPN";
   ```
3. 执行**ADD NTSDEVADDR**命令增加UPCF与SOAP服务器对接的IP地址。以参数“IPVER”值为“IPV4”为例：

   ```
   ADD NTSDEVADDR: DEVAID=0, VPNINDEX=0, IPVER=IPV4, IP="10.50.5.123";
   ```
4. 执行**ADD NTSPEER**命令增加UPCF与SOAP服务器对接的一条实体记录。

   ```
   ADD NTSPEER: PEERID=1, PEERNAME="SOAP", PEERTYPE=SOAP;
   ```
5. 执行****ADD NTSPEERLINKCFG****命令增加UPCF与SOAP服务器对接的链路信息。

   ```
   ADD NTSPEERLINKCFG: LINKID=7, PEERID=1, LOCALROLE=SOAPClient, WSDL=Common, IPVER=IPV4, LOCALIP="10.50.5.123", PEERIP="10.0.0.105", PEERPORT=7890, SOAPURL="http://10.0.0.105:7890/mockScfPccSoapServiceEndpointBinding", DEFLINK=YES, CERTSCENE=NULL, DESCRIPTION="soap link";
   ```

   UPCF与SOAP服务器对接时，配置参数如下：
   * 参数“链路ID”包含4条系统缺省配置记录，所以此对接链路从“4”开始根据规划值进行配置。
   * UPCF与短消息中心的对接协议包括：SOAP（Simple Object Access Protocol）、JMS（Java Messaging Service）、CMPP（China Mobile Peer To Peer protocol）和SMPP（Short Message Peer to Peer）四种协议，所以参数“本地角色”根据运营商需要可以选择“SOAPClient（SOAP客户端）”、“JMSClient（JMS客户端）”、“CMPPClient（CMPP客户端）”和“SMPPClient（SMPP客户端）”中的一种。当UPCF与短消息中心的对接协议为CMPP时，具体配置请参考当UPCF与短消息中心的对接协议为SMS协议时，具体配置请参考配置UPCF与短消息中心的对接数据。

   保存通知消息（包含短消息和邮件）的记录数由如下软参控制：
   * UPCF为每个用户保存的通知消息的最大记录数由软参**VRM\_NOTIFYMSGMAXRECORDPERSUB**控制，默认值为10条。
   * UPCF为每个用户保存的通知消息的最大天数由软参**VRM\_NOTIFYMSGMAXDAYPERSUB**控制，默认值为31天。
   * UPCF允许保存的待通知最大记录数由软参**VRM\_NOTIFYMSGMAXWAITEDRECORDS**控制，默认值为500000条。以上软参均通过**MOD INSP**命令修改，此操作要求在华为工程师的指导下操作。

   当UPCF允许保存的待通知最大记录数存满时，将导致后续短信无法被记录和发送，将被直接丢弃。在部署用户通知业务时，请合理规划软参**VRM\_NOTIFYMSGMAXWAITEDRECORDS**的设置。

   若已设置**VRM\_NOTIFYMSGMAXWAITEDRECORDS**软参，但仍出现短信无法发送问题，请执行**SET SCANSW**命令，设置“SW6”参数为打开抑制短信记录超期清理的开关，恢复用户通知业务。

## 验证方法

**检查链路**

登录“UPCF MML命令”界面，执行**DSP NTSPEERLINKCFG**命令查看“链路状态”是否为“在线”

* 是 => 检查完成。
* 否 => 1。

**检查数据**

如果链路连接正常，则不必检查数据。

1. SOAP服务器对端数据检查。

   1. 登录“UPCF MML命令”界面。
   2. 执行**LST NTSPEER**命令查询SOAP服务器对端数据：查看“应用类型”是否与规划数据一致。

      * 是 => 3。
      * 否 => 2。
2. 重新配置SOAP服务器对端和链路数据。

   1. 执行**RMV NTSPEERLINKCFG**命令删除该对端下的所有SOAP服务器链路。
   2. 执行**RMV NTSPEER**命令删除SOAP服务器对端数据。
   3. 执行**ADD NTSPEER**命令添加SOAP服务器对端。
   4. 执行**ADD NTSPEERLINKCFG**命令添加SOAP服务器链路。
3. SOAP服务器数据检查。

   执行**LST NTSPEERLINKCFG**命令查询SOAP服务器数据：查看链路ID、对端服务器ID、IP版本、本端IP地址、对端IP地址、对端端口、本地角色、WSDL文件、默认链路和SOAP服务器URL等数据是否与规划数据一致。

   * 是 => 结束。
   * 否 =>请执行**MOD NTSPEERLINKCFG**命令进行修改。

   实际规划请参考网络设计文档，该文档由华为工程师提供。

版权所有 © 华为技术有限公司
