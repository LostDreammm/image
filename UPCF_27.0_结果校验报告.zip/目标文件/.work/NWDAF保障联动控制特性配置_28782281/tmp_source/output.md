---
id: ''
name: NWDAF保障联动控制特性配置
ne_type: UPCF
type: feature
description: 用户通过归属地UPCF签约质差保障UELogo，当NWDAF已触发N5专载保障，SM-PCF的N7接口通过数据层订阅通知联动N15接口将签约的质差保障UELogo下发给AMF，AMF再下发给基站和终端，提升用户的体验感知。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611140 NWDAF保障联动控制","WHFD-611140 NWDAF保障联动控制特性配置","NWDAF保障联动控制特性配置"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
用户通过归属地UPCF签约质差保障UELogo，当NWDAF已触发N5专载保障，SM-PCF的N7接口通过数据层订阅通知联动N15接口将签约的质差保障UELogo下发给AMF，AMF再下发给基站和终端，提升用户的体验感知。

## 必备事项
前提条件

已完成license申请和加载。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_conditiongroup_list:
      type: items
      properties:
        CONDITIONGROUPNAME:
          name: 'CONDITIONGROUPNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RELATION:
          name: 'RELATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USETIMEZONE:
          name: 'USETIMEZONE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_condition_list:
      type: items
      properties:
        CONDITIONNAME:
          name: 'CONDITIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CONDITIONGROUPNAME:
          name: 'CONDITIONGROUPNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        OBJECTATTRIBUTE:
          name: 'OBJECTATTRIBUTE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        OPERATOR:
          name: 'OPERATOR'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RIGHTVALUETYPE:
          name: 'RIGHTVALUETYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RIGHTVALUE:
          name: 'RIGHTVALUE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_conditiongroup_list_1:
      type: items
      properties:
        CONDITIONGROUPNAME:
          name: 'CONDITIONGROUPNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RELATION:
          name: 'RELATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USETIMEZONE:
          name: 'USETIMEZONE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_condition_list_2:
      type: items
      properties:
        CONDITIONNAME:
          name: 'CONDITIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CONDITIONGROUPNAME:
          name: 'CONDITIONGROUPNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        OBJECTATTRIBUTE:
          name: 'OBJECTATTRIBUTE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        OPERATOR:
          name: 'OPERATOR'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RIGHTVALUETYPE:
          name: 'RIGHTVALUETYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RIGHTVALUE:
          name: 'RIGHTVALUE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ngaction_list:
      type: items
      properties:
        ACTIONNAME:
          name: 'ACTIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ngactionattr_list:
      type: items
      properties:
        ACTIONNAME:
          name: 'ACTIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ATTRNAME:
          name: 'ATTRNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VALUE:
          name: 'VALUE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ngaction_list_1:
      type: items
      properties:
        ACTIONNAME:
          name: 'ACTIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ngactionattr_list_1:
      type: items
      properties:
        ACTIONNAME:
          name: 'ACTIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ATTRNAME:
          name: 'ATTRNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VALUE:
          name: 'VALUE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ngaction_list_2:
      type: items
      properties:
        ACTIONNAME:
          name: 'ACTIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ngactionattr_list_3:
      type: items
      properties:
        ACTIONNAME:
          name: 'ACTIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ATTRNAME:
          name: 'ATTRNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VALUE:
          name: 'VALUE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rule_list:
      type: items
      properties:
        RULENAME:
          name: 'RULENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        OPERATION:
          name: 'OPERATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        EDR:
          name: 'EDR'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RELATION:
          name: 'RELATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ruleconditiongroup_list:
      type: items
      properties:
        RULENAME:
          name: 'RULENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CONDITIONGROUPNAME:
          name: 'CONDITIONGROUPNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rulengaction_list:
      type: items
      properties:
        RULENAME:
          name: 'RULENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ACTIONNAME:
          name: 'ACTIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rule_list_1:
      type: items
      properties:
        RULENAME:
          name: 'RULENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        OPERATION:
          name: 'OPERATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        EDR:
          name: 'EDR'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RELATION:
          name: 'RELATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ruleconditiongroup_list_1:
      type: items
      properties:
        RULENAME:
          name: 'RULENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CONDITIONGROUPNAME:
          name: 'CONDITIONGROUPNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rulengaction_list_1:
      type: items
      properties:
        RULENAME:
          name: 'RULENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ACTIONNAME:
          name: 'ACTIONNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_policy_list:
      type: items
      properties:
        POLICYNAME:
          name: 'POLICYNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_policyrule_list:
      type: items
      properties:
        POLICYNAME:
          name: 'POLICYNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RULENAME:
          name: 'RULENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_policytrigger_list:
      type: items
      properties:
        POLICYNAME:
          name: 'POLICYNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TRIGGERNAME:
          name: 'TRIGGERNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_policy_list_1:
      type: items
      properties:
        POLICYNAME:
          name: 'POLICYNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TYPE:
          name: 'TYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_policyrule_list_1:
      type: items
      properties:
        POLICYNAME:
          name: 'POLICYNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RULENAME:
          name: 'RULENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_policytrigger_list_1:
      type: items
      properties:
        POLICYNAME:
          name: 'POLICYNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TRIGGERNAME:
          name: 'TRIGGERNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_service_list:
      type: items
      properties:
        SERVICENAME:
          name: 'SERVICENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICETYPE:
          name: 'SERVICETYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ACTIVATEDBY:
          name: 'ACTIVATEDBY'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PRECEDENCE:
          name: 'PRECEDENCE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        QOSMODE:
          name: 'QOSMODE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SUBSCRIPTIONFORCED:
          name: 'SUBSCRIPTIONFORCED'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DESCRIPTION:
          name: 'DESCRIPTION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROBILLDATE:
          name: 'PROBILLDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        QUOTAALLOCATIONMODE:
          name: 'QUOTAALLOCATIONMODE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ISSETSHAREDMODE:
          name: 'ISSETSHAREDMODE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RESUBSCRIPTIONOPERATION:
          name: 'RESUBSCRIPTIONOPERATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ISGROUPSERVICE:
          name: 'ISGROUPSERVICE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ISTEMPLATE:
          name: 'ISTEMPLATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ISRECUSRLOC:
          name: 'ISRECUSRLOC'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        APNMATCHTYPE:
          name: 'APNMATCHTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HASBASESERVICE:
          name: 'HASBASESERVICE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ADDONLEVEL:
          name: 'ADDONLEVEL'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CALCVALIDFORDYNSUBGROUP:
          name: 'CALCVALIDFORDYNSUBGROUP'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CUSTOMIZEDRESET:
          name: 'CUSTOMIZEDRESET'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MASTER2MASTERSHARESERVICE:
          name: 'MASTER2MASTERSHARESERVICE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_servicepolicy_list:
      type: items
      properties:
        SERVICENAME:
          name: 'SERVICENAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        POLICYNAME:
          name: 'POLICYNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pcmccsub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATUS:
          name: 'USRSTATUS'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLINGTYPE:
          name: 'USRBILLINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRGRADE:
          name: 'USRGRADE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ESSTATUS:
          name: 'ESSTATUS'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PACKAGETYPE:
          name: 'PACKAGETYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_pcmccsrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICECODE:
          name: 'SERVICECODE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICESTARTDATETIME:
          name: 'SERVICESTARTDATETIME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICEENDDATETIME:
          name: 'SERVICEENDDATETIME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICEUSAGESTATE:
          name: 'SERVICEUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICEBILLINGTYPE:
          name: 'SERVICEBILLINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRAPN:
          name: 'USRAPN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICEATTRBUTE:
          name: 'SERVICEATTRBUTE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_conditiongroup_list:
    - CONDITIONGROUPNAME: N5_Guarantee_dnn_Con01
      RELATION: OR
      USETIMEZONE: No
    add_condition_list:
    - CONDITIONNAME: N5_Guarantee_dnn_C01
      CONDITIONGROUPNAME: N5_Guarantee_dnn_Con01
      OBJECTATTRIBUTE: SmfSession.Dnn
      OPERATOR: Equal
      RIGHTVALUETYPE: Value
      RIGHTVALUE: cmnet
    add_conditiongroup_list_1:
    - CONDITIONGROUPNAME: N5_Guarantee_AM_Con01
      RELATION: AND
      USETIMEZONE: No
    add_condition_list_2:
    - CONDITIONNAME: N5_Guarantee_AM_C01
      CONDITIONGROUPNAME: N5_Guarantee_AM_Con01
      OBJECTATTRIBUTE: Subscriber.N5Guarantee
      OPERATOR: Equal
      RIGHTVALUETYPE: Value
      RIGHTVALUE: True
    add_ngaction_list:
    - ACTIONNAME: N5_Guarantee_Ac01
      TYPE: CmdAssociationUpdate
    add_ngactionattr_list:
    - ACTIONNAME: N5_Guarantee_Ac01
      ATTRNAME: sessionAssociationType
      TYPE: Value
      VALUE: N5N15Session
    add_ngaction_list_1:
    - ACTIONNAME: N5_Guarantee_UeLogo_ID_Ac01
      TYPE: DynamicNetworkIdentity
    add_ngactionattr_list_1:
    - ACTIONNAME: N5_Guarantee_UeLogo_ID_Ac01
      ATTRNAME: fullName
      TYPE: Value
      VALUE: 保障中
    add_ngaction_list_2:
    - ACTIONNAME: N5_Guarantee_UELOGO_Ac01
      TYPE: AmPolicyAction
    add_ngactionattr_list_3:
    - ACTIONNAME: N5_Guarantee_UELOGO_Ac01
      ATTRNAME: dynamicNetworkIdentity
      TYPE: Reference ActionGroup
      VALUE: N5_Guarantee_UeLogo_ID_Ac01
    add_rule_list:
    - RULENAME: N5_Guarantee_SM_Rule_01
      OPERATION: Change Rule
      TYPE: Smf Pcc Rule 5G
      EDR: OFF
      RELATION: AND
    add_ruleconditiongroup_list:
    - RULENAME: N5_Guarantee_SM_Rule_01
      CONDITIONGROUPNAME: N5_Guarantee_dnn_Con01
    add_rulengaction_list:
    - RULENAME: N5_Guarantee_SM_Rule_01
      ACTIONNAME: N5_Guarantee_Ac01
    add_rule_list_1:
    - RULENAME: N5_Guarantee_AM_Rule_01
      OPERATION: Change Rule
      TYPE: Amf Pcc Rule 5G
      EDR: OFF
      RELATION: AND
    add_ruleconditiongroup_list_1:
    - RULENAME: N5_Guarantee_AM_Rule_01
      CONDITIONGROUPNAME: N5_Guarantee_AM_Con01
    add_rulengaction_list_1:
    - RULENAME: N5_Guarantee_AM_Rule_01
      ACTIONNAME: N5_Guarantee_UELOGO_Ac01
    add_policy_list:
    - POLICYNAME: N5_Guarantee_SM_Policy01
      TYPE: N7 Policy
    add_policyrule_list:
    - POLICYNAME: N5_Guarantee_SM_Policy01
      RULENAME: N5_Guarantee_SM_Rule_01
    add_policytrigger_list:
    - POLICYNAME: N5_Guarantee_SM_Policy01
      TRIGGERNAME: IPCAN_EST
    add_policy_list_1:
    - POLICYNAME: N5_Guarantee_AM_Policy01
      TYPE: N15 Policy
    add_policyrule_list_1:
    - POLICYNAME: N5_Guarantee_AM_Policy01
      RULENAME: N5_Guarantee_AM_Rule_01
    add_policytrigger_list_1:
    - POLICYNAME: N5_Guarantee_AM_Policy01
      TRIGGERNAME: AMPolicyCreateRequest
    add_service_list:
    - SERVICENAME: N5_Guarantee_UELogo_Service
      SERVICETYPE: VALUE_ADDED_SERVICE
      ACTIVATEDBY: PCEF
      PRECEDENCE: '0'
      QOSMODE: Replace
      SUBSCRIPTIONFORCED: Yes
      DESCRIPTION: 保障中logo
      PROBILLDATE: No
      QUOTAALLOCATIONMODE: None
      ISSETSHAREDMODE: No
      RESUBSCRIPTIONOPERATION: 'NULL'
      ISGROUPSERVICE: No
      ISTEMPLATE: No
      ISRECUSRLOC: No
      APNMATCHTYPE: Full Matching
      HASBASESERVICE: No
      ADDONLEVEL: Exhaust
      CALCVALIDFORDYNSUBGROUP: No
      CUSTOMIZEDRESET: No
      MASTER2MASTERSHARESERVICE: No
    add_servicepolicy_list:
    - SERVICENAME: N5_Guarantee_UELogo_Service
      POLICYNAME: N5_Guarantee_SM_Policy01
    add_pcmccsub_list:
    - USRIDENTIFIER: '460103810124001'
      USRSTATUS: Custom1
      USRBILLINGTYPE: Postpaid
      USRGRADE: 'NULL'
      USRBILLCYCLEDATE: '5'
      ESSTATUS: NotEmergency
      PACKAGETYPE: 'NULL'
    add_pcmccsrv_list:
    - USRIDENTIFIER: '460103810124001'
      SERVICECODE: N5_Guarantee_UELogo_Service
      SERVICESTARTDATETIME: 2026&05&27&11&28&55
      SERVICEENDDATETIME: 2026&08&27&11&28&56
      SERVICEUSAGESTATE: '5'
      SERVICEBILLINGTYPE: '5'
      USRAPN: APN_01
      SERVICEATTRBUTE: SA_01
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录UPCF WebUI界面进行业务配置，在“系统管理 > 批处理 > CLI导入”界面执行以下CLI命令。

### 登录UPCF WebUI界面可参考《UPCF 产品文档》>UPCF WebUI GUI参考 > UPCF WebUI > 登录UPCF WebUI界面。

### 下列配置中的名称仅供参考，可根据实际情况自行调整。

### 2 添加条件组“N5\_Guarantee\_dnn\_Con01”、“N5\_Guarantee\_snssai\_Con01”，匹配N7接口保障状态刷新动作。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_conditiongroup_list的变量区（command: ADD CONDITIONGROUP） -#}
<!-- MISSING_MACRO: command=ADD CONDITIONGROUP list_name=add_conditiongroup_list step_id=2 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_condition_list的变量区（command: ADD CONDITION） -#}
<!-- MISSING_MACRO: command=ADD CONDITION list_name=add_condition_list step_id=2 -->
```

### dnn取值仅供参考，需要按照实际情况设置，只有满足条件后才能根据保障状态下发UELogo。

### 3 添加条件组“N5\_Guarantee\_AM\_Con01”，匹配保障中状态。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_conditiongroup_list_1的变量区（command: ADD CONDITIONGROUP） -#}
<!-- MISSING_MACRO: command=ADD CONDITIONGROUP list_name=add_conditiongroup_list_1 step_id=3 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_condition_list_2的变量区（command: ADD CONDITION） -#}
<!-- MISSING_MACRO: command=ADD CONDITION list_name=add_condition_list_2 step_id=3 -->
```

### 4 添加5G动作组“N5\_Guarantee\_Ac01”，动作类型为CmdAssociationUpdate，用于配置SM-PCF将保障状态写入BE。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_ngaction_list的变量区（command: ADD NGACTION） -#}
<!-- MISSING_MACRO: command=ADD NGACTION list_name=add_ngaction_list step_id=4 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_ngactionattr_list的变量区（command: ADD NGACTIONATTR） -#}
<!-- MISSING_MACRO: command=ADD NGACTIONATTR list_name=add_ngactionattr_list step_id=4 -->
```

### 5 添加5G动作组“N5\_Guarantee\_UeLogo\_ID\_Ac01”，动作类型为DynamicNetworkIdentity，用于配置AmPolicyAction的关联动作。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_ngaction_list_1的变量区（command: ADD NGACTION） -#}
<!-- MISSING_MACRO: command=ADD NGACTION list_name=add_ngaction_list_1 step_id=5 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_ngactionattr_list_1的变量区（command: ADD NGACTIONATTR） -#}
<!-- MISSING_MACRO: command=ADD NGACTIONATTR list_name=add_ngactionattr_list_1 step_id=5 -->
```

### 核心网下发的实际UELogo具体以运营商定义为准，必须携带运营商标识开头，配置UELogo**不要超过10个字符**（支持中文汉字、“A-Z”、“a-z”、“0-9”、单空格和“-”，中文、英文和特殊字符都算是一个字符），且严禁配置中包含“5G”和“5GA”字样。

### 6 添加5G动作组“N5\_Guarantee\_UELOGO\_Ac01”，动作类型为AmPolicyAction，用于配置PCF下发UELogo策略信息。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_ngaction_list_2的变量区（command: ADD NGACTION） -#}
<!-- MISSING_MACRO: command=ADD NGACTION list_name=add_ngaction_list_2 step_id=6 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_ngactionattr_list_3的变量区（command: ADD NGACTIONATTR） -#}
<!-- MISSING_MACRO: command=ADD NGACTIONATTR list_name=add_ngactionattr_list_3 step_id=6 -->
```

### 7 添加规则“N5\_Guarantee\_SM\_Rule\_01”，规则类型为Smf Pcc Rule 5G，用于关联条件组"N5\_Guarantee\_dnn\_Con01"、“N5\_Guarantee\_snssai\_Con01”和动作组"N5\_Guarantee\_Ac01"。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_rule_list的变量区（command: ADD RULE） -#}
<!-- MISSING_MACRO: command=ADD RULE list_name=add_rule_list step_id=7 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_ruleconditiongroup_list的变量区（command: ADD RULECONDITIONGROUP） -#}
<!-- MISSING_MACRO: command=ADD RULECONDITIONGROUP list_name=add_ruleconditiongroup_list step_id=7 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_rulengaction_list的变量区（command: ADD RULENGACTION） -#}
<!-- MISSING_MACRO: command=ADD RULENGACTION list_name=add_rulengaction_list step_id=7 -->
```

### 8 添加规则“N5\_Guarantee\_AM\_Rule\_01”，规则类型为Amf Pcc Rule 5G，用于关联条件组"N5\_Guarantee\_AM\_Con01"和动作组"N5\_Guarantee\_UELOGO\_Ac01"。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_rule_list_1的变量区（command: ADD RULE） -#}
<!-- MISSING_MACRO: command=ADD RULE list_name=add_rule_list_1 step_id=8 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_ruleconditiongroup_list_1的变量区（command: ADD RULECONDITIONGROUP） -#}
<!-- MISSING_MACRO: command=ADD RULECONDITIONGROUP list_name=add_ruleconditiongroup_list_1 step_id=8 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_rulengaction_list_1的变量区（command: ADD RULENGACTION） -#}
<!-- MISSING_MACRO: command=ADD RULENGACTION list_name=add_rulengaction_list_1 step_id=8 -->
```

### 9 添加策略“N5\_Guarantee\_SM\_Policy01”，策略类型为N7 Policy，配置触发器IPCAN\_EST，同时关联规则“N5\_Guarantee\_SM\_Rule\_01”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_policy_list的变量区（command: ADD POLICY） -#}
<!-- MISSING_MACRO: command=ADD POLICY list_name=add_policy_list step_id=9 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_policyrule_list的变量区（command: ADD POLICYRULE） -#}
<!-- MISSING_MACRO: command=ADD POLICYRULE list_name=add_policyrule_list step_id=9 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_policytrigger_list的变量区（command: ADD POLICYTRIGGER） -#}
<!-- MISSING_MACRO: command=ADD POLICYTRIGGER list_name=add_policytrigger_list step_id=9 -->
```

### 10 添加策略“N5\_Guarantee\_AM\_Policy01”，策略类型为N15 Policy，配置触发器AMPolicyCreateRequest，同时关联规则“N5\_Guarantee\_AM\_Rule\_01”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_policy_list_1的变量区（command: ADD POLICY） -#}
<!-- MISSING_MACRO: command=ADD POLICY list_name=add_policy_list_1 step_id=10 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_policyrule_list_1的变量区（command: ADD POLICYRULE） -#}
<!-- MISSING_MACRO: command=ADD POLICYRULE list_name=add_policyrule_list_1 step_id=10 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_policytrigger_list_1的变量区（command: ADD POLICYTRIGGER） -#}
<!-- MISSING_MACRO: command=ADD POLICYTRIGGER list_name=add_policytrigger_list_1 step_id=10 -->
```

### 11 添加业务“N5\_Guarantee\_UELogo\_Service”，业务类型为VALUE\_ADDED\_SERVICE，用于关联策略“N5\_Guarantee\_SM\_Policy01”和“N5\_Guarantee\_AM\_Policy01”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_service_list的变量区（command: ADD SERVICE） -#}
<!-- MISSING_MACRO: command=ADD SERVICE list_name=add_service_list step_id=11 -->
```

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_servicepolicy_list的变量区（command: ADD SERVICEPOLICY） -#}
<!-- MISSING_MACRO: command=ADD SERVICEPOLICY list_name=add_servicepolicy_list step_id=11 -->
```

### 12 发放业务。

#### 12.1 执行**ADD PCMCCSUB**增加一个用户。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_pcmccsub_list的变量区（command: ADD PCMCCSUB） -#}
<!-- MISSING_MACRO: command=ADD PCMCCSUB list_name=add_pcmccsub_list step_id=12.1 -->
```

#### 12.2 执行**ADD PCMCCSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_pcmccsrv_list的变量区（command: ADD PCMCCSRV） -#}
<!-- MISSING_MACRO: command=ADD PCMCCSRV list_name=add_pcmccsrv_list step_id=12.2 -->
```

#### 该场景中开户和签约命令使用的是定制命令。通用场景下，开户和签约分别需要使用命令**ADD PSUB**和**ADD PSRV**。

