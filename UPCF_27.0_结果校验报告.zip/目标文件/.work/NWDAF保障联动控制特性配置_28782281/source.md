# NWDAF保障联动控制特性配置

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

## 操作场景

用户通过归属地UPCF签约质差保障UELogo，当NWDAF已触发N5专载保障，SM-PCF的N7接口通过数据层订阅通知联动N15接口将签约的质差保障UELogo下发给AMF，AMF再下发给基站和终端，提升用户的体验感知。

## 对系统的影响

启用该功能后，Session数据库备份内容会增加，MCI消息会增多，对FE和BE的性能有所影响。

## 必备事项

前提条件

已完成license申请和加载。

数据

**表1** 配置关系解释

| 名称 | 需求分解项 | 基本原则 |
| --- | --- | --- |
| 用户业务“N5\_Guarantee\_UELogo\_Service” | 配置PCF下发质差保障联动UELogo的特定业务，业务名称为N5\_Guarantee\_UELogo\_Service，业务类型为“VALUE\_ADDED\_SERVICE”，包含两个策略：N5\_Guarantee\_SM\_Policy01和N5\_Guarantee\_AM\_Policy01。 | 当用户触发NWDAF质差专载保障后，PCF给AMF下发特定业务对应的UELogo信息。 |
| 策略“N5\_Guarantee\_SM\_Policy01” | 此策略在用户SM-PCF上线N7会话后被调用，触发器为“IPCAN\_EST”，包含一个规则：N5\_Guarantee\_SM\_Rule\_01。 | 当触发器定义的事件发生时，SM-PCF才会进行相应的规则匹配并更新会话联动数据。 |
| 策略“N5\_Guarantee\_AM\_Policy01” | 此策略在用户在AM-PCF上线N15会话后被调用，触发器为“AMPolicyCreateRequest”，包含一个规则：N5\_Guarantee\_AM\_Rule\_01。 | 当触发器定义的事件发生时，AM-PCF才会进行相应的规则匹配并下发特定UELogo信息。 |
| 规则“N5\_Guarantee\_SM\_Rule\_01” | 配置SM策略下发的条件和动作：   * 条件组“N5\_Guarantee\_dnn\_Con01”：SmfSession.Dnn=xxx * 5G动作“N5\_Guarantee\_Ac01”（类型：CmdAssociationUpdate）： sessionAssociationType=N5N15Session   说明：  1. 此规则用于控制SM-PCF侧的N7会话是否支持在开始或结束NWDAF质差专载保障时，往BE写入保障状态数据。BE会感知保障状态变更，AM-PCF判断N15会话的保障状态，根据保障状态判断是否下发指定的UELogo。 2. 规则中的条件建议使用特定的dnn去控制使用场景。 | 当SM-PCF的用户上线N7会话后，只要签约了该业务且满足条件，SM-PCF会通知AM-PCF加载质差保障状态。 |
| 规则“N5\_Guarantee\_AM\_Rule\_01” | 配置AM策略下发的条件和动作：   * 条件“N5\_Guarantee\_AM\_Con01”：Subscriber.N5Guarantee=True * 5G动作“N5\_Guarantee\_UELOGO\_Ac01”（类型：AmPolicyAction）： DynamicNetworkIdentity=N5\_Guarantee\_UeLogo\_ID\_Ac01   说明：  此规则用于AM-PCF判断N15会话的保障状态，根据保障状态判断是否下发指定的UELogo。 | 当AM-PCF的用户上线N15会话后，只要签约了该业务且满足条件，AM-PCF根据保障状态向AMF下发指定的UELogo。 |

## 操作流程

此特性的配置流程图如图1所示。

**图1** 业务配置流程图

## 操作步骤

1. 登录UPCF WebUI界面进行业务配置，在“系统管理 > 批处理 > CLI导入”界面执行以下CLI命令。

   * 登录UPCF WebUI界面可参考《UPCF 产品文档》>UPCF WebUI GUI参考 > UPCF WebUI > 登录UPCF WebUI界面。
   * 下列配置中的名称仅供参考，可根据实际情况自行调整。
2. 添加条件组“N5\_Guarantee\_dnn\_Con01”、“N5\_Guarantee\_snssai\_Con01”，匹配N7接口保障状态刷新动作。

   ```
   ADD CONDITIONGROUP: CONDITIONGROUPNAME="N5_Guarantee_dnn_Con01", RELATION=OR, UseTimeZone=No;
   ADD CONDITION: CONDITIONNAME="N5_Guarantee_dnn_C01", CONDITIONGROUPNAME="N5_Guarantee_dnn_Con01", OBJECTATTRIBUTE="SmfSession.Dnn", OPERATOR=Equal, RIGHTVALUETYPE=Value, RIGHTVALUE="cmnet";
   ADD CONDITION: CONDITIONNAME="N5_Guarantee_dnn_C02", CONDITIONGROUPNAME="N5_Guarantee_dnn_Con01", OBJECTATTRIBUTE="SmfSession.Dnn", OPERATOR=Equal, RIGHTVALUETYPE=Value, RIGHTVALUE="cmwap";
   ```

   dnn取值仅供参考，需要按照实际情况设置，只有满足条件后才能根据保障状态下发UELogo。
3. 添加条件组“N5\_Guarantee\_AM\_Con01”，匹配保障中状态。

   ```
   ADD CONDITIONGROUP: CONDITIONGROUPNAME="N5_Guarantee_AM_Con01", RELATION=AND, UseTimeZone=No;
   ADD CONDITION: CONDITIONNAME="N5_Guarantee_AM_C01", CONDITIONGROUPNAME="N5_Guarantee_AM_Con01", OBJECTATTRIBUTE="Subscriber.N5Guarantee", OPERATOR=Equal, RIGHTVALUETYPE=Value, RIGHTVALUE="True";
   ```
4. 添加5G动作组“N5\_Guarantee\_Ac01”，动作类型为CmdAssociationUpdate，用于配置SM-PCF将保障状态写入BE。

   ```
   ADD NGACTION:ACTIONNAME="N5_Guarantee_Ac01",TYPE="CmdAssociationUpdate";
   ADD NGACTIONATTR: ACTIONNAME="N5_Guarantee_Ac01", ATTRNAME="sessionAssociationType", TYPE=Value, VALUE="N5N15Session";
   ```
5. 添加5G动作组“N5\_Guarantee\_UeLogo\_ID\_Ac01”，动作类型为DynamicNetworkIdentity，用于配置AmPolicyAction的关联动作。

   ```
   ADD NGACTION:ACTIONNAME="N5_Guarantee_UeLogo_ID_Ac01",TYPE="DynamicNetworkIdentity";
   ADD NGACTIONATTR:ACTIONNAME="N5_Guarantee_UeLogo_ID_Ac01",ATTRNAME="fullName",TYPE=Value,VALUE="保障中";
   ADD NGACTIONATTR:ACTIONNAME="N5_Guarantee_UeLogo_ID_Ac01",ATTRNAME="shortName",TYPE=Value,VALUE="保障中";
   ```

   核心网下发的实际UELogo具体以运营商定义为准，必须携带运营商标识开头，配置UELogo**不要超过10个字符**（支持中文汉字、“A-Z”、“a-z”、“0-9”、单空格和“-”，中文、英文和特殊字符都算是一个字符），且严禁配置中包含“5G”和“5GA”字样。
6. 添加5G动作组“N5\_Guarantee\_UELOGO\_Ac01”，动作类型为AmPolicyAction，用于配置PCF下发UELogo策略信息。

   ```
   ADD NGACTION:ACTIONNAME="N5_Guarantee_UELOGO_Ac01",TYPE="AmPolicyAction";
   ADD NGACTIONATTR:ACTIONNAME="N5_Guarantee_UELOGO_Ac01",ATTRNAME="dynamicNetworkIdentity",TYPE=Reference ActionGroup,VALUE="N5_Guarantee_UeLogo_ID_Ac01";
   ```
7. 添加规则“N5\_Guarantee\_SM\_Rule\_01”，规则类型为Smf Pcc Rule 5G，用于关联条件组"N5\_Guarantee\_dnn\_Con01"、“N5\_Guarantee\_snssai\_Con01”和动作组"N5\_Guarantee\_Ac01"。

   ```
   ADD RULE:RULENAME="N5_Guarantee_SM_Rule_01",OPERATION=Change Rule,TYPE=Smf Pcc Rule 5G,EDR=OFF,RELATION=AND;
   ADD RULECONDITIONGROUP:RULENAME="N5_Guarantee_SM_Rule_01",CONDITIONGROUPNAME="N5_Guarantee_dnn_Con01";
   ADD RULENGACTION:RULENAME="N5_Guarantee_SM_Rule_01",ACTIONNAME="N5_Guarantee_Ac01";
   ```
8. 添加规则“N5\_Guarantee\_AM\_Rule\_01”，规则类型为Amf Pcc Rule 5G，用于关联条件组"N5\_Guarantee\_AM\_Con01"和动作组"N5\_Guarantee\_UELOGO\_Ac01"。

   ```
   ADD RULE:RULENAME="N5_Guarantee_AM_Rule_01",OPERATION=Change Rule,TYPE=Amf Pcc Rule 5G,EDR=OFF,RELATION=AND;
   ADD RULECONDITIONGROUP:RULENAME="N5_Guarantee_AM_Rule_01",CONDITIONGROUPNAME="N5_Guarantee_AM_Con01";
   ADD RULENGACTION:RULENAME="N5_Guarantee_AM_Rule_01",ACTIONNAME="N5_Guarantee_UELOGO_Ac01";
   ```
9. 添加策略“N5\_Guarantee\_SM\_Policy01”，策略类型为N7 Policy，配置触发器IPCAN\_EST，同时关联规则“N5\_Guarantee\_SM\_Rule\_01”。

   ```
   ADD POLICY:POLICYNAME="N5_Guarantee_SM_Policy01",TYPE=N7 Policy;
   ADD POLICYRULE:POLICYNAME="N5_Guarantee_SM_Policy01",RULENAME="N5_Guarantee_SM_Rule_01";
   ADD POLICYTRIGGER:POLICYNAME="N5_Guarantee_SM_Policy01",TRIGGERNAME="IPCAN_EST";
   ```
10. 添加策略“N5\_Guarantee\_AM\_Policy01”，策略类型为N15 Policy，配置触发器AMPolicyCreateRequest，同时关联规则“N5\_Guarantee\_AM\_Rule\_01”。

    ```
    ADD POLICY:POLICYNAME="N5_Guarantee_AM_Policy01",TYPE=N15 Policy;
    ADD POLICYRULE:POLICYNAME="N5_Guarantee_AM_Policy01",RULENAME="N5_Guarantee_AM_Rule_01";
    ADD POLICYTRIGGER:POLICYNAME="N5_Guarantee_AM_Policy01",TRIGGERNAME="AMPolicyCreateRequest";
    ```
11. 添加业务“N5\_Guarantee\_UELogo\_Service”，业务类型为VALUE\_ADDED\_SERVICE，用于关联策略“N5\_Guarantee\_SM\_Policy01”和“N5\_Guarantee\_AM\_Policy01”。

    ```
    ADD SERVICE:SERVICENAME="N5_Guarantee_UELogo_Service",SERVICETYPE=VALUE_ADDED_SERVICE,ACTIVATEDBY=PCEF,PRECEDENCE=0,QOSMODE=Replace,SUBSCRIPTIONFORCED=Yes,DESCRIPTION="保障中logo",PROBILLDATE=No,QUOTAALLOCATIONMODE=None,ISSETSHAREDMODE=No,RESUBSCRIPTIONOPERATION=NULL,ISGROUPSERVICE=No,ISTEMPLATE=No,ISRECUSRLOC=No,APNMATCHTYPE=Full Matching,HASBASESERVICE=No,ADDONLEVEL=Exhaust,CALCVALIDFORDYNSUBGROUP=No,CUSTOMIZEDRESET=No,MASTER2MASTERSHARESERVICE=No;
    ADD SERVICEPOLICY:SERVICENAME="N5_Guarantee_UELogo_Service",POLICYNAME="N5_Guarantee_SM_Policy01";
    ADD SERVICEPOLICY:SERVICENAME="N5_Guarantee_UELogo_Service",POLICYNAME="N5_Guarantee_AM_Policy01";
    ```
12. 发放业务。
    1. 执行**ADD PCMCCSUB**增加一个用户。

       ```
       ADD PCMCCSUB: USRIDENTIFIER="460103810124001", USRSTATUS=Custom1, USRBILLINGTYPE=Postpaid, USRGRADE=NULL, USRBILLCYCLEDATE=5, ESSTATUS=NotEmergency, PACKAGETYPE=NULL;
       ```
    2. 执行**ADD PCMCCSRV**给用户签约业务。

       ```
       ADD PCMCCSRV: USRIDENTIFIER="460103810124001", SERVICECODE="N5_Guarantee_UELogo_Service", SERVICESTARTDATETIME=2026&05&27&11&28&55, SERVICEENDDATETIME=2026&08&27&11&28&56, SERVICEUSAGESTATE=5, SERVICEBILLINGTYPE=5, USRAPN="APN_01", SERVICEATTRBUTE="SA_01";
       ```

    该场景中开户和签约命令使用的是定制命令。通用场景下，开户和签约分别需要使用命令**ADD PSUB**和**ADD PSRV**。

## 任务示例

任务描述

配置质差保障联动UELogo下发。

脚本

```
ADD CONDITIONGROUP: CONDITIONGROUPNAME="N5_Guarantee_dnn_Con01", RELATION=OR, UseTimeZone=No;
ADD CONDITION: CONDITIONNAME="N5_Guarantee_dnn_C01", CONDITIONGROUPNAME="N5_Guarantee_dnn_Con01", OBJECTATTRIBUTE="SmfSession.Dnn", OPERATOR=Equal, RIGHTVALUETYPE=Value, RIGHTVALUE="cmnet";
ADD CONDITION: CONDITIONNAME="N5_Guarantee_dnn_C02", CONDITIONGROUPNAME="N5_Guarantee_dnn_Con01", OBJECTATTRIBUTE="SmfSession.Dnn", OPERATOR=Equal, RIGHTVALUETYPE=Value, RIGHTVALUE="cmwap";

ADD CONDITIONGROUP: CONDITIONGROUPNAME="N5_Guarantee_AM_Con01", RELATION=AND, UseTimeZone=No;
ADD CONDITION: CONDITIONNAME="N5_Guarantee_AM_C01", CONDITIONGROUPNAME="N5_Guarantee_AM_Con01", OBJECTATTRIBUTE="Subscriber.N5Guarantee", OPERATOR=Equal, RIGHTVALUETYPE=Value, RIGHTVALUE="True";

ADD NGACTION:ACTIONNAME="N5_Guarantee_Ac01",TYPE="CmdAssociationUpdate";
ADD NGACTIONATTR: ACTIONNAME="N5_Guarantee_Ac01", ATTRNAME="sessionAssociationType", TYPE=Value, VALUE="N5N15Session";

ADD NGACTION:ACTIONNAME="N5_Guarantee_UeLogo_ID_Ac01",TYPE="DynamicNetworkIdentity";
ADD NGACTIONATTR:ACTIONNAME="N5_Guarantee_UeLogo_ID_Ac01",ATTRNAME="fullName",TYPE=Value,VALUE="保障中";
ADD NGACTIONATTR:ACTIONNAME="N5_Guarantee_UeLogo_ID_Ac01",ATTRNAME="shortName",TYPE=Value,VALUE="保障中";

ADD NGACTION:ACTIONNAME="N5_Guarantee_UELOGO_Ac01",TYPE="AmPolicyAction";
ADD NGACTIONATTR:ACTIONNAME="N5_Guarantee_UELOGO_Ac01",ATTRNAME="dynamicNetworkIdentity",TYPE=Reference ActionGroup,VALUE="N5_Guarantee_UeLogo_ID_Ac01";

ADD RULE:RULENAME="N5_Guarantee_SM_Rule_01",OPERATION=Change Rule,TYPE=Smf Pcc Rule 5G,EDR=OFF,RELATION=AND;
ADD RULECONDITIONGROUP:RULENAME="N5_Guarantee_SM_Rule_01",CONDITIONGROUPNAME="N5_Guarantee_dnn_Con01";
ADD RULENGACTION:RULENAME="N5_Guarantee_SM_Rule_01",ACTIONNAME="N5_Guarantee_Ac01";

ADD RULE:RULENAME="N5_Guarantee_AM_Rule_01",OPERATION=Change Rule,TYPE=Amf Pcc Rule 5G,EDR=OFF,RELATION=AND;
ADD RULECONDITIONGROUP:RULENAME="N5_Guarantee_AM_Rule_01",CONDITIONGROUPNAME="N5_Guarantee_AM_Con01";
ADD RULENGACTION:RULENAME="N5_Guarantee_AM_Rule_01",ACTIONNAME="N5_Guarantee_UELOGO_Ac01";

ADD POLICY:POLICYNAME="N5_Guarantee_SM_Policy01",TYPE=N7 Policy;
ADD POLICYRULE:POLICYNAME="N5_Guarantee_SM_Policy01",RULENAME="N5_Guarantee_SM_Rule_01";
ADD POLICYTRIGGER:POLICYNAME="N5_Guarantee_SM_Policy01",TRIGGERNAME="IPCAN_EST";

ADD POLICY:POLICYNAME="N5_Guarantee_AM_Policy01",TYPE=N15 Policy;
ADD POLICYRULE:POLICYNAME="N5_Guarantee_AM_Policy01",RULENAME="N5_Guarantee_AM_Rule_01";
ADD POLICYTRIGGER:POLICYNAME="N5_Guarantee_AM_Policy01",TRIGGERNAME="AMPolicyCreateRequest";

ADD SERVICE:SERVICENAME="N5_Guarantee_UELogo_Service",SERVICETYPE=VALUE_ADDED_SERVICE,ACTIVATEDBY=PCEF,PRECEDENCE=0,QOSMODE=Replace,SUBSCRIPTIONFORCED=Yes,DESCRIPTION="保障中logo",PROBILLDATE=No,QUOTAALLOCATIONMODE=None,ISSETSHAREDMODE=No,RESUBSCRIPTIONOPERATION=NULL,ISGROUPSERVICE=No,ISTEMPLATE=No,ISRECUSRLOC=No,APNMATCHTYPE=Full Matching,HASBASESERVICE=No,ADDONLEVEL=Exhaust,CALCVALIDFORDYNSUBGROUP=No,CUSTOMIZEDRESET=No,MASTER2MASTERSHARESERVICE=No;
ADD SERVICEPOLICY:SERVICENAME="N5_Guarantee_UELogo_Service",POLICYNAME="N5_Guarantee_SM_Policy01";
ADD SERVICEPOLICY:SERVICENAME="N5_Guarantee_UELogo_Service",POLICYNAME="N5_Guarantee_AM_Policy01";
```

版权所有 © 华为技术有限公司
