---
id: ''
name: 配置UPCF与USCDB对接数据（自动建链，多USCDB应用共存模式）
ne_type: UPCF
type: feature
description: 多USCDB应用共存模式下，当使用网设工具CloudDesign生成开局MML时，可参考本页面内容。  当前现网会话备份应用越来越多，较多局点（容灾局点）部署的会话备份只有1对用于存储用户数据的USRSU虚拟机，N对用于存储会话数据的USRSU虚拟机。Session备份场景下，Session备份消息由用户数据USRSU虚拟机的DSG转发。当只有VOLTE会话时，用户数据USRSU虚拟机的DSG数量较少，导致USRSU虚拟机的DSG转发会话备份消息产生瓶颈，具体场景如图1所示。因此，FE侧需区分BE侧不同应用类型的DSG来分别建立链路（多USCDB应用共存模式），其实现原理如图2。  **图1** 具体场景  **图2** 多应用共存实现原理
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（非SDN）","配置基础数据","配置UPCF与USCDB对接数据","配置UPCF与USCDB对接数据（自动建链，多USCDB应用共存模式）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
多USCDB应用共存模式下，当使用网设工具CloudDesign生成开局MML时，可参考本页面内容。当前现网会话备份应用越来越多，较多局点（容灾局点）部署的会话备份只有1对用于存储用户数据的USRSU虚拟机，N对用于存储会话数据的USRSU虚拟机。Session备份场景下，Session备份消息由用户数据USRSU虚拟机的DSG转发。当只有VOLTE会话时，用户数据USRSU虚拟机的DSG数量较少，导致USRSU虚拟机的DSG转发会话备份消息产生瓶颈，具体场景如图1所示。因此，FE侧需区分BE侧不同应用类型的DSG来分别建立链路（多USCDB应用共存模式），其实现原理如图2。**图1** 具体场景**图2** 多应用共存实现原理

## 必备事项
前提条件

已经完成UPCF、USCDB的基础数据配置。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    set_groupswitch_list:
      type: items
      properties:
        GROUPNAME:
          name: '分组名称'
          type: string
          maxLength: 128
          required: true
          description: 'FE侧支持多应用共存的分组名称，固定取值为“UPCF”。'
          data_source: ''
          pattern: ''
          default: ''
        GROUPSWITCH:
          name: '分组开关'
          type: string
          enum:
          - OPEN
          - CLOSE
          required: true
          description: 'FE侧支持多应用共存的业务分组开关，表示分组功能是否打开。'
          data_source: ''
          pattern: ''
          default: ''
    add_dsglinkctrl_list:
      type: items
      properties:
        MID:
          name: '模块号'
          type: integer
          minimum: 1
          maximum: 2047
          required: false
          description: 'USCDB侧的DSG模块号。网元安装完成后，由运营商对已部署的DSG模块进行统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        DSGST:
          name: 'DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV4:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: 'USCDB侧的数据平面的IP地址，该参数必须先由USCDB侧的**ADD SRVIPADDR**命令配置，然后在此引用。  只有当“IPVER”为“IPV4”时，才会出现此参数。'
          data_source: ''
          pattern: ''
          default: ''
        SHAKEY:
          name: '校验码'
          type: string
          maxLength: 30
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dsglinkctrl_list_1:
      type: items
      properties:
        MID:
          name: '模块号'
          type: integer
          minimum: 1
          maximum: 2047
          required: false
          description: 'USCDB侧的DSG模块号。网元安装完成后，由运营商对已部署的DSG模块进行统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        DSGST:
          name: 'DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV4:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: 'USCDB侧的数据平面的IP地址，该参数必须先由USCDB侧的**ADD SRVIPADDR**命令配置，然后在此引用。  只有当“IPVER”为“IPV4”时，才会出现此参数。'
          data_source: ''
          pattern: ''
          default: ''
        SHAKEY:
          name: '校验码'
          type: string
          maxLength: 30
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: 'UPCF侧的Location标识，该参数已经支持VNFD自动规划配置，请在“UPCF MML命令界面”窗口执行**LST DBSLOCATION**命令进行查询，然后在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级值'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '优先级值越小，优先级越高。'
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: '仅当本命令的参数“远端网元类型”为“USCDB(USCDB)”时此参数才能配置为“Yes”，否则只能配置为“No”。'
          data_source: ''
          pattern: ''
          default: ''
    add_rlocation_list_2:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: 'UPCF侧的Location标识，该参数已经支持VNFD自动规划配置，请在“UPCF MML命令界面”窗口执行**LST DBSLOCATION**命令进行查询，然后在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级值'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '优先级值越小，优先级越高。'
          data_source: ''
          pattern: ''
          default: ''
        REDUNFLAG:
          name: '是否容灾关系'
          type: string
          enum:
          - No
          - Yes
          required: true
          description: '仅当本命令的参数“远端网元类型”为“USCDB(USCDB)”时此参数才能配置为“Yes”，否则只能配置为“No”。'
          data_source: ''
          pattern: ''
          default: ''
    add_rdsglinkctrl_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        RLINKCENTERTYPE:
          name: '远端链路中心类型'
          type: string
          enum:
          - DSG
          - DBS
          required: false
          description: '取值固定为“DBS”。'
          data_source: ''
          pattern: ''
          default: DSG
        IPV4:
          name: '远端Location IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: 'UPCF侧的数据平面的IP地址，该参数必须先由UPCF侧的**ADD DBSIPADDR**命令配置，然后在此引用。  只有当“IPVER”为“IPV4”时，才会出现此参数。'
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
        SHAKEY:
          name: '校验码'
          type: string
          maxLength: 30
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: '远端Location IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rdsglinkctrl_list_1:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        RLINKCENTERTYPE:
          name: '远端链路中心类型'
          type: string
          enum:
          - DSG
          - DBS
          required: false
          description: '取值固定为“DBS”。'
          data_source: ''
          pattern: ''
          default: DSG
        IPV4:
          name: '远端Location IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: 'UPCF侧的数据平面的IP地址，该参数必须先由UPCF侧的**ADD DBSIPADDR**命令配置，然后在此引用。  只有当“IPVER”为“IPV4”时，才会出现此参数。'
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
        SHAKEY:
          name: '校验码'
          type: string
          maxLength: 30
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: '远端Location IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_dbsgrpswitch_list:
      type: items
      properties:
        GROUPNAME:
          name: '分组名称'
          type: string
          minLength: 0
          maxLength: 128
          required: true
          description: 'FE侧支持多应用共存的分组名称，固定取值为“UPCF”。'
          data_source: ''
          pattern: ''
          default: ''
        GROUPSWITCH:
          name: '分组开关'
          type: string
          enum:
          - OPEN
          - CLOSE
          required: true
          description: 'FE侧支持多应用共存的业务分组开关，表示分组功能是否打开。'
          data_source: ''
          pattern: ''
          default: ''
    add_dbslinkctrl_list:
      type: items
      properties:
        SERVICENO:
          name: '服务模块号'
          type: integer
          minimum: 1
          maximum: 1024
          required: true
          description: '用于指定网元的DBS服务模块号。DBS服务模块号先由**LST DBSSERVICENO**命令查询，然后在此处索引。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '用于指定IPV4类型的本地IP地址。  该参数必须先由命令**ADD DBSIPADDR**定义才能在此处引用。'
          data_source: ''
          pattern: ''
          default: ''
        PASSWORD:
          name: '本地链路中心校验码'
          type: string
          minLength: 8
          maxLength: 30
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP:
          name: '本地链路中心IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_dbsrlocation_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: 'USCDB侧的Location标识，该参数已经支持VNFD自动规划配置，请在“USCDB MML命令界面”窗口执行**LST LOCATION**进行查询，然后在此引用。'
          data_source: ''
          pattern: ''
          default: ''
        RMT:
          name: '远端网元类型'
          type: string
          enum:
          - USCDB
          required: true
          description: '取值固定为“USCDB”。'
          data_source: ''
          pattern: ''
          default: ''
        LP:
          name: '位置ID优先级值'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '优先级值越小，优先级越高。'
          data_source: ''
          pattern: ''
          default: ''
    add_dbsrlinkctrl_list:
      type: items
      properties:
        INDEX:
          name: '配置索引'
          type: integer
          minimum: 1
          maximum: 64
          required: true
          description: '本端自定义。'
          data_source: ''
          pattern: ''
          default: ''
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '用于指定一个远端网元标识。该参数须在对接的远端网元中先定义，然后在本端UPCF网元通过命令**ADD DBSRLOCATION**配置后，才能在此处索引。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP:
          name: '远端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '用于指定远端UPCF的Location IPv4地址。  只有当“IPVER”为“IPV4”时，才会出现此参数。'
          data_source: ''
          pattern: ''
          default: ''
        PASSWORD:
          name: '远端链路中心校验码'
          type: string
          minLength: 8
          maxLength: 30
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '用于设置远端DSG网元的业务类型，该参数为联想参数列表，不能手动输入，其取值为命令**LST DBSSRVGROUP**查询获得的“业务类型名称”输出参数。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP:
          name: '远端链路中心IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    syn_rdsg_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
    syn_rdsg_list_1:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
    syn_ripaddr_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        RDPUST:
          name: '远端IP地址业务类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
    syn_ripaddr_list_1:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        RDPUST:
          name: '远端IP地址业务类型'
          type: string
          maxLength: 128
          required: true
          description: '固定取值，两个取值均需配置。'
          data_source: ''
          pattern: ''
          default: ''
    add_notifycfg_list:
      type: items
      properties:
        FETYPE:
          name: '订阅通知的FE类型'
          type: string
          maxLength: 128
          required: true
          description: '参数在成功加载FE插件包后才有效。'
          data_source: ''
          pattern: ''
          default: ''
        FEID:
          name: 'FE标识'
          type: integer
          minimum: 1
          maximum: 100
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        INFTYPE:
          name: '订阅通知的接口类型'
          type: string
          enum:
          - MCI
          - SOAP
          - FILE
          - THIRDPARTY
          required: true
          description: '在此场景下固定配置为“MCI”。'
          data_source: ''
          pattern: ''
          default: ''
        SYNCHROSWITCH:
          name: '同步开关'
          type: string
          enum:
          - ASYNC
          - SYNC
          required: false
          description: '固定配置。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LOCATIONID:
          name: '订阅通知发送的Location标识'
          type: integer
          minimum: 0
          maximum: 512
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        NOTIFYDEST:
          name: '通知目标'
          type: integer
          minimum: 0
          maximum: 2
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PERIOD:
          name: '文件生成周期'
          type: integer
          minimum: 5
          maximum: 86400
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PID:
          name: 'Partition标识'
          type: integer
          minimum: 0
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RBKLOCATIONID:
          name: '回退时订阅通知发送的Location标识'
          type: integer
          minimum: 0
          maximum: 512
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SAVEPATH:
          name: '文件保存路径'
          type: string
          maxLength: 20
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SAVEPERIOD:
          name: '文件保存周期'
          type: integer
          minimum: 1
          maximum: 30
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SUBERGRPID:
          name: '订阅组'
          type: integer
          minimum: 1
          maximum: 255
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        WAITTIMEOUT:
          name: '超时时长'
          type: integer
          minimum: 1
          maximum: 60
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_dsgsctppara_list:
      type: items
      properties:
        ID:
          name: 'SCTP参数标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: '-'
          data_source: ''
          pattern: ''
          default: ''
        LINKMODE:
          name: '建链模式'
          type: string
          enum:
          - SEQUENCE
          - PARITY
          required: false
          description: '与对接的远端网元中该参数配置值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        CHKSUMTX:
          name: '发送消息时计算校验和'
          type: string
          enum:
          - FALSE
          - TRUE
          required: false
          description: '与对接的远端网元中该参数配置值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        CHKSUMRX:
          name: '接收消息时检查校验和'
          type: string
          enum:
          - FALSE
          - TRUE
          required: false
          description: '与对接的远端网元中该参数配置值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        PINGBYPASS:
          name: '旁路ping结果'
          type: string
          enum:
          - FALSE
          - TRUE
          required: false
          description: '用于停止统计QOS任务。与对接的远端网元中该参数配置值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
    set_linknum_list:
      type: items
      properties:
        SERVICETYPE:
          name: '业务类型'
          type: string
          maxLength: 128
          required: true
          description: 'FE网元的业务类型。'
          data_source: ''
          pattern: ''
          default: ''
        LINKNUM:
          name: '链路数'
          type: integer
          minimum: 4
          maximum: 512
          required: true
          description: '由运营商统一规划。'
          data_source: ''
          pattern: ''
          default: ''
    syn_dbsrdsg_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '标识一条远端DSG配置记录的关键字段，用于指定需要同步哪一条远端Location标识的远端DSG记录，操作员可以使用**LST DBSRDSG**命令查询获得。远端Location和远端网元一一对应。'
          data_source: ''
          pattern: ''
          default: ''
        RDSGST:
          name: '远端DSG业务类型'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '用于标识远端DSG业务类型。该参数为联想参数列表，不能手动输入，其取值为**LST DBSSRVGROUP**命令查询获得的“业务类型名称”输出参数。'
          data_source: ''
          pattern: ''
          default: ''
    syn_dbsripaddr_list:
      type: items
      properties:
        RLOCID:
          name: '远端Location标识'
          type: integer
          minimum: 1
          maximum: 512
          required: true
          description: '标识一个远端网元IP地址的关键字段，用于指定需要同步哪一个远端Location标识的远端网元IP地址。操作员可以使用**LST DBSRIPADDR**命令查询获得。'
          data_source: ''
          pattern: ''
          default: ''
        RIPST:
          name: '远端IP地址业务类型'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: '用于指定远端网元IP地址的业务类型。该参数为联想参数列表，不能手动输入，其取值为**LST DBSSRVGROUP**命令查询获得的“业务类型名称”输出参数。'
          data_source: ''
          pattern: ''
          default: ''
    set_dbssctppara_list:
      type: items
      properties:
        ID:
          name: 'SCTP参数标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: '-'
          data_source: ''
          pattern: ''
          default: ''
        LINKMODE:
          name: '建链模式'
          type: string
          enum:
          - SEQUENCE
          - PARITY
          required: false
          description: '与对接的远端网元中该参数配置值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        CHKSUMTX:
          name: '发送消息时计算校验和'
          type: string
          enum:
          - FALSE
          - TRUE
          required: false
          description: '与对接的远端网元中该参数配置值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        CHKSUMRX:
          name: '接收消息时检查校验和'
          type: string
          enum:
          - FALSE
          - TRUE
          required: false
          description: '与对接的远端网元中该参数配置值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
        PINGBYPASS:
          name: '旁路ping结果'
          type: string
          enum:
          - FALSE
          - TRUE
          required: false
          description: '用于停止统计QOS任务。与对接的远端网元中该参数配置值保持一致。'
          data_source: ''
          pattern: ''
          default: ''
    set_dbssrvpara_list:
      type: items
      properties:
        SERVICETYPE:
          name: '业务类型'
          type: string
          minLength: 0
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LINKNUM:
          name: '链路数'
          type: integer
          minimum: 4
          maximum: 512
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    act_ipdisp_list:
      type: items
      properties: {}
    act_dbsipdisp_list:
      type: items
      properties: {}
    str_dbsrouting_list:
      type: items
      properties: {}
    rst_module_list:
      type: items
      properties:
        MID:
          name: '模块号'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MT:
          name: '模块类型'
          type: string
          enum:
          - DPU
          - NDF
          - DBG
          - DSG
          - DRU
          - DSU
          - PGW
          - DMA
          - CAG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    rst_msprocess_list:
      type: items
      properties:
        PROCOBJECT:
          name: '操作对象'
          type: string
          enum:
          - PROCNAME
          - PROCID
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROCNAME:
          name: '进程类型'
          type: string
          minLength: 1
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MEID:
          name: '网元ID'
          type: string
          minLength: 0
          maxLength: 40
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROCID:
          name: '进程ID'
          type: string
          minLength: 1
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - set_groupswitch_list:
    - GROUPNAME: 'UPCF'
      GROUPSWITCH: OPEN
    add_dsglinkctrl_list:
    - MID: 3
      DSGST: 'UPCF'
      IPVER: IPV4
      IPV4: '10.20.129.40'
      SHAKEY: 'NewPwd12'
      IPV6: ''
    add_dsglinkctrl_list_1:
    - MID: 3
      DSGST: 'UPCF'
      IPVER: IPV4
      IPV4: '10.10.10.16'
      SHAKEY: 'NewPwd12'
      IPV6: ''
    add_rlocation_list:
    - RLOCID: 231
      RMT: 'UPCF'
      LP: 1
      REDUNFLAG: No
    add_rlocation_list_2:
    - RLOCID: 231
      RMT: 'UPCF'
      LP: 1
      REDUNFLAG: No
    add_rdsglinkctrl_list:
    - RLOCID: 231
      IPVER: IPV4
      RLINKCENTERTYPE: DBS
      IPV4: '10.20.139.40'
      RDSGST: 'UPCF'
      SHAKEY: 'NewPwd12'
      IPV6: ''
    add_rdsglinkctrl_list_1:
    - RLOCID: 231
      IPVER: IPV4
      RLINKCENTERTYPE: DBS
      IPV4: '10.20.139.40'
      RDSGST: 'UPCF'
      SHAKEY: 'NewPwd12'
      IPV6: ''
    set_dbsgrpswitch_list:
    - GROUPNAME: 'UPCF'
      GROUPSWITCH: OPEN
    add_dbslinkctrl_list:
    - SERVICENO: 3
      IPVER: IPV4
      IPV4IP: '10.20.139.40'
      PASSWORD: 'NewPwd12'
      IPV6IP: ''
    add_dbsrlocation_list:
    - RLOCID: 81
      RMT: USCDB
      LP: 1
    add_dbsrlinkctrl_list:
    - INDEX: 1
      RLOCID: 81
      IPVER: IPV4
      IPV4IP: '10.20.129.40'
      PASSWORD: 'NewPwd12'
      RDSGST: 'UPCF'
      IPV6IP: ''
    syn_rdsg_list:
    - RLOCID: 231
      RDSGST: 'UPCF'
    syn_rdsg_list_1:
    - RLOCID: 231
      RDSGST: 'UPCF'
    syn_ripaddr_list:
    - RLOCID: 231
      RDPUST: 'UPCF'
    syn_ripaddr_list_1:
    - RLOCID: 231
      RDPUST: 'UPCF'
    add_notifycfg_list:
    - FETYPE: 'UPCF'
      FEID: 1
      INFTYPE: MCI
      SYNCHROSWITCH: ASYNC
      IPVER: ''
      LOCATIONID: ''
      NOTIFYDEST: ''
      PERIOD: ''
      PID: ''
      RBKLOCATIONID: ''
      SAVEPATH: ''
      SAVEPERIOD: ''
      SUBERGRPID: ''
      WAITTIMEOUT: ''
    set_dsgsctppara_list:
    - ID: 1
      LINKMODE: PARITY
      CHKSUMTX: TRUE
      CHKSUMRX: TRUE
      PINGBYPASS: TRUE
    set_linknum_list:
    - SERVICETYPE: 'UPCF'
      LINKNUM: X
    syn_dbsrdsg_list:
    - RLOCID: 81
      RDSGST: 'UPCF'
    syn_dbsripaddr_list:
    - RLOCID: 81
      RIPST: 'UPCF'
    set_dbssctppara_list:
    - ID: 1
      LINKMODE: PARITY
      CHKSUMTX: TRUE
      CHKSUMRX: TRUE
      PINGBYPASS: TRUE
    set_dbssrvpara_list:
    - SERVICETYPE: 'UPCF'
      LINKNUM: 6
    act_ipdisp_list:
    - {}
    act_dbsipdisp_list:
    - {}
    str_dbsrouting_list:
    - {}
    rst_module_list:
    - MID: 模块号
      MT: DSG
    rst_msprocess_list:
    - PROCOBJECT: PROCNAME
      PROCNAME: 'CELL_UdrDbbroker'
      MEID: ''
      PROCID: ''
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录“USCDB MML命令”界面。

### 2 执行**SET GROUPSWITCH**命令，将分组业务功能打开。

```jinja2
{%- for item in set_groupswitch_list -%}
    SET GROUPSWITCH:
    {#- --- 必选参数 --- -#}
    GROUPNAME="{{item.GROUPNAME}}",
    GROUPSWITCH={{item.GROUPSWITCH}},
    ;
{%- endfor -%}
```

### 3 执行**ADD DSGLINKCTRL**命令，增加本端DSG链路中心。

```jinja2
{%- for item in add_dsglinkctrl_list -%}
    ADD DSGLINKCTRL:
    {#- --- 必选参数 --- -#}
    DSGST="{{item.DSGST}}",
    IPVER={{item.IPVER}},
    SHAKEY="{{item.SHAKEY}}",
    {#- --- 可选参数 --- -#}
    {%- if item.MID is not none -%}
        MID={{item.MID}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4="{{item.IPV4}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 当配置USCDB基础数据添加的DSG的UPCF和UPCF-SESSION业务类型配置为相同IP时，此处DSG链路中心配置需要将**LST SRVIPADDR**中**IPV4IP1**和**IPV4IP2**分别规划给UPCF和UPCF-SESSION使用（IPV6场景同理）。

### 当启用多USCDB应用共存模式时，有多少种应用共存就需要配置多少种DSG链路中心。下面以UPCF/UPCF-SESSION共存为例给出某个BE的配置样例：

```jinja2
{%- for item in add_dsglinkctrl_list_1 -%}
    ADD DSGLINKCTRL:
    {#- --- 必选参数 --- -#}
    DSGST="{{item.DSGST}}",
    IPVER={{item.IPVER}},
    SHAKEY="{{item.SHAKEY}}",
    {#- --- 可选参数 --- -#}
    {%- if item.MID is not none -%}
        MID={{item.MID}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4="{{item.IPV4}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 4 执行**ADD RLOCATION**命令，增加远端Location信息。在增加对端时，必须先增加UPCF类型的Location信息，再增加UPCF-SESSION类型的Location信息。

```jinja2
{%- for item in add_rlocation_list -%}
    ADD RLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT="{{item.RMT}}",
    LP={{item.LP}},
    REDUNFLAG={{item.REDUNFLAG}},
    ;
{%- endfor -%}
```

### 当启用多USCDB应用共存模式时，有多少种应用共存就需要配置多少种远端Location信息。下面以UPCF/UPCF-SESSION共存为例给出到某个FE（RLOCID=231）的配置样例：

```jinja2
{%- for item in add_rlocation_list_2 -%}
    ADD RLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT="{{item.RMT}}",
    LP={{item.LP}},
    REDUNFLAG={{item.REDUNFLAG}},
    ;
{%- endfor -%}
```

### 5 执行**ADD RDSGLINKCTRL**命令，增加远端DBS链路中心。

```jinja2
{%- for item in add_rdsglinkctrl_list -%}
    ADD RDSGLINKCTRL:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    IPVER={{item.IPVER}},
    RDSGST="{{item.RDSGST}}",
    SHAKEY="{{item.SHAKEY}}",
    {#- --- 可选参数 --- -#}
    {%- if item.RLINKCENTERTYPE is not none -%}
        RLINKCENTERTYPE={{item.RLINKCENTERTYPE}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4="{{item.IPV4}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### BE网元的链路中心类型为DSG，FE网元的链路中心为DBS。MML命令**ADD RDSGLINKCTRL**可以用来设置BE网元对接的远端DSG或者DBS链路中心，命令下“RLINKCENTERTYPE”参数的选择取决于对端是FE网元还是BE网元。

### 举例说明：

### 当BE网元想增加FE网元的链路中心，由于对端FE的链路中心类型是DBS，所以在BE侧配置时，“RLINKCENTERTYPE”参数要选“DBS”。

### 当BE网元想增加BE网元的链路中心，由于对端BE的链路中心类型是DSG，所以在BE侧配置时，“RLINKCENTERTYPE”参数要选“DSG”。

### 当启用多USCDB应用共存模式时，有多少种应用共存就需要配置多少种远端DSG链路中心。下面以UPCF/UPCF-SESSION共存为例给出到某个FE（RLOCID=231）的配置样例：

```jinja2
{%- for item in add_rdsglinkctrl_list_1 -%}
    ADD RDSGLINKCTRL:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    IPVER={{item.IPVER}},
    RDSGST="{{item.RDSGST}}",
    SHAKEY="{{item.SHAKEY}}",
    {#- --- 可选参数 --- -#}
    {%- if item.RLINKCENTERTYPE is not none -%}
        RLINKCENTERTYPE={{item.RLINKCENTERTYPE}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4="{{item.IPV4}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 6 登录“UPCF MML命令”界面。

### 7 执行**SET DBSGRPSWITCH**命令，将分组业务功能打开。

```jinja2
{%- for item in set_dbsgrpswitch_list -%}
    SET DBSGRPSWITCH:
    {#- --- 必选参数 --- -#}
    GROUPNAME="{{item.GROUPNAME}}",
    GROUPSWITCH={{item.GROUPSWITCH}},
    ;
{%- endfor -%}
```

### 8 执行**ADD DBSLINKCTRL**命令，增加DBS链路中心。

```jinja2
{%- for item in add_dbslinkctrl_list -%}
    ADD DBSLINKCTRL:
    {#- --- 必选参数 --- -#}
    SERVICENO={{item.SERVICENO}},
    IPVER={{item.IPVER}},
    PASSWORD="{{item.PASSWORD}}",
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4IP="{{item.IPV4IP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6IP="{{item.IPV6IP}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 9 执行**ADD DBSRLOCATION**命令，增加远端Location信息。

```jinja2
{%- for item in add_dbsrlocation_list -%}
    ADD DBSRLOCATION:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RMT={{item.RMT}},
    LP={{item.LP}},
    ;
{%- endfor -%}
```

### 可以通过**RMV DBSRLOCATION**命令删除多余的远端Location信息。

### 单局点多USCDB应用共存模式下，UPCF侧只需增加1个远端USCDB的Location信息。

### 10 执行**ADD DBSRLINKCTRL**命令，用于增加远端DSG链路中心。

```jinja2
{%- for item in add_dbsrlinkctrl_list -%}
    ADD DBSRLINKCTRL:
    {#- --- 必选参数 --- -#}
    INDEX={{item.INDEX}},
    RLOCID={{item.RLOCID}},
    IPVER={{item.IPVER}},
    PASSWORD="{{item.PASSWORD}}",
    {#- --- 可选参数 --- -#}
    {%- if item.RDSGST is not none -%}
        RDSGST="{{item.RDSGST}}",
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IPV4IP="{{item.IPV4IP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6IP="{{item.IPV6IP}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 当配置USCDB基础数据添加的DSG的UPCF和UPCF-SESSION业务类型配置为相同IP时，此处DSG链路中心配置需要将**LST SRVIPADDR**中**IPV4IP1**和**IPV4IP2**分别规划给UPCF和UPCF-SESSION使用（IPV6场景同理）。

### 11 登录“USCDB MML命令”界面。

### USCDB侧、UPCF侧的本端DSG链路中心和远端DSG链路中心都已配置，需等待至少7秒，确保两侧互相接收到远端发来的消息后，再执行以下步骤。

### 12 执行**SYN RDSG**命令，同步对端DSG信息到数据库。

```jinja2
{%- for item in syn_rdsg_list -%}
    SYN RDSG:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RDSGST="{{item.RDSGST}}",
    ;
{%- endfor -%}
```

### 当启用多USCDB应用共存模式时，有多少种应用共存就需要同步多少种远端DSG信息。下面以UPCF/UPCF-SESSION共存为例给出到某个FE（RLOCID=231）的配置样例：

```jinja2
{%- for item in syn_rdsg_list_1 -%}
    SYN RDSG:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RDSGST="{{item.RDSGST}}",
    ;
{%- endfor -%}
```

### 13 执行**SYN RIPADDR**命令，同步对端IP信息到数据库。

```jinja2
{%- for item in syn_ripaddr_list -%}
    SYN RIPADDR:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RDPUST="{{item.RDPUST}}",
    ;
{%- endfor -%}
```

### 当启用多USCDB应用共存模式时，有多少种应用共存就需要同步多少种远端IP信息。下面以UPCF/UPCF-SESSION共存为例给出到某个FE（RLOCID=231）的配置样例：

```jinja2
{%- for item in syn_ripaddr_list_1 -%}
    SYN RIPADDR:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    RDPUST="{{item.RDPUST}}",
    ;
{%- endfor -%}
```

### 14 执行**ADD NOTIFYCFG**命令，增加订阅通知。

```jinja2
{%- for item in add_notifycfg_list -%}
    ADD NOTIFYCFG:
    {#- --- 必选参数 --- -#}
    FETYPE="{{item.FETYPE}}",
    FEID={{item.FEID}},
    INFTYPE={{item.INFTYPE}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：INFTYPE=SOAP 时必选 --- -#}
    {%- if item.INFTYPE == 'SOAP' -%}
        IPVER={{item.IPVER}},
    {%- endif -%}
    {#- --- 条件必选：INFTYPE=THIRDPARTY 时必选 --- -#}
    {%- if item.INFTYPE == 'THIRDPARTY' -%}
        SUBERGRPID={{item.SUBERGRPID}},
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- if item.INFTYPE == 'MCI' -%}
        {%- if item.LOCATIONID is not none -%}
            LOCATIONID={{item.LOCATIONID}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- if item.INFTYPE == 'MCI' -%}
        {%- if item.NOTIFYDEST is not none -%}
            NOTIFYDEST={{item.NOTIFYDEST}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
    {%- if item.INFTYPE == 'FILE' -%}
        {%- if item.PERIOD is not none -%}
            PERIOD={{item.PERIOD}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- if item.INFTYPE == 'MCI' -%}
        {%- if item.PID is not none -%}
            PID={{item.PID}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- if item.INFTYPE == 'MCI' -%}
        {%- if item.RBKLOCATIONID is not none -%}
            RBKLOCATIONID={{item.RBKLOCATIONID}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
    {%- if item.INFTYPE == 'FILE' -%}
        {%- if item.SAVEPATH is not none -%}
            SAVEPATH="{{item.SAVEPATH}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：INFTYPE=FILE 时可选 --- -#}
    {%- if item.INFTYPE == 'FILE' -%}
        {%- if item.SAVEPERIOD is not none -%}
            SAVEPERIOD={{item.SAVEPERIOD}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
    {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
        {%- if item.SYNCHROSWITCH is not none -%}
            SYNCHROSWITCH={{item.SYNCHROSWITCH}},
        {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI/THIRDPARTY 时可选 --- -#}
    {%- elif item.INFTYPE in ['MCI', 'THIRDPARTY'] -%}
        {%- if item.SYNCHROSWITCH is not none -%}
            SYNCHROSWITCH={{item.SYNCHROSWITCH}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
    {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
        {%- if item.WAITTIMEOUT is not none -%}
            WAITTIMEOUT={{item.WAITTIMEOUT}},
        {%- endif -%}
    {#- --- 条件可选：INFTYPE=MCI 时可选 --- -#}
    {%- elif item.INFTYPE == 'MCI' -%}
        {%- if item.WAITTIMEOUT is not none -%}
            WAITTIMEOUT={{item.WAITTIMEOUT}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 如果不需要增加订阅通知，可跳过该步骤。

### 15 设置BE和FE之间DSG的分组连接机制。

### 新建局场景下，按照FE、BE奇偶建链原则需要采用奇偶建链模式时，或新增BE场景下，存在FE与BE新增的对接时，需执行此步骤。否则，跳过此步骤。执行此步骤的操作如下：

### 新建局时，通过执行**SET DSGSCTPPARA**命令，设置“建链模式”为“PARITY（奇偶模式）”，“发送消息时计算校验和”为“TRUE（是）”，“接收消息时检查校验和”为“TRUE（是）”，“旁路ping结果”为“TRUE（是）”。**SET DSGSCTPPARA**命令中各参数的配置值需与FE侧对应参数的配置值保持一致。

```jinja2
{%- for item in set_dsgsctppara_list -%}
    SET DSGSCTPPARA:
    {#- --- 必选参数 --- -#}
    ID={{item.ID}},
    {#- --- 可选参数 --- -#}
    {%- if item.LINKMODE is not none -%}
        LINKMODE={{item.LINKMODE}},
    {%- endif -%}
    {%- if item.CHKSUMTX is not none -%}
        CHKSUMTX={{item.CHKSUMTX}},
    {%- endif -%}
    {%- if item.CHKSUMRX is not none -%}
        CHKSUMRX={{item.CHKSUMRX}},
    {%- endif -%}
    {%- if item.PINGBYPASS is not none -%}
        PINGBYPASS={{item.PINGBYPASS}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 新增BE时，需在新增的BE上执行**LST DSGSCTPPARA**命令查询各个参数值，确保与已经完成对接、正常运行的BE网元的各个参数值保持一致。如果参数值不一致，需在新增的BE上执行**SET DSGSCTPPARA**命令，将各个参数值设置一致。

### FE、BE奇偶建链原则如下：

#### 15.1 单局点部署场景下，奇偶建链原则如下：

##### 15.1.1 部署12对及以上的存储静态用户数据的USRSU虚拟机且FE和BE是合一部署局点采用奇偶建链模式。

##### 15.1.2 部署12对及以上的存储静态用户数据的USRSU虚拟机且FE和BE是分离部署局点采用顺序建链模式（默认模式）。

##### 15.1.3 部署少于12对的存储静态用户数据的USRSU虚拟机的局点均采用顺序建链模式（默认模式）。

#### 15.2 容灾组网下奇偶建链原则如下：

##### 15.2.1 两地容灾：部署12对及以上的存储静态用户数据的USRSU虚拟机时需要采用奇偶建链模式，部署少于12对存储静态用户数据的USRSU虚拟机时采用顺序建链模式（默认模式）。

##### 15.2.2 三地容灾：部署8对及以上的存储静态用户数据的USRSU虚拟机时需要采用奇偶建链模式，部署少于8对存储静态用户数据的USRSU虚拟机时采用顺序建链模式（默认模式）。

### 16 执行**SET LINKNUM**命令，设置“链路数”为“X”。

### FE和BE的“链路数”配置值需保持一致。

```jinja2
{%- for item in set_linknum_list -%}
    SET LINKNUM:
    {#- --- 必选参数 --- -#}
    SERVICETYPE="{{item.SERVICETYPE}}",
    LINKNUM={{item.LINKNUM}},
    ;
{%- endfor -%}
```

### USCDB网元下“链路数”的系统默认值为“8”，混合组网场景下“链路数”的配置，需要按照混合组网指导书配置计算。其他场景若从未修改默认值，则不需重新设置。若修改了默认值：

### 单局点及两地容灾场景下，当部署12对及以上的存储静态用户数据的USRSU虚拟机时，则需要修改“链路数”的值为“8”，部署小于12对的存储静态用户数据的USRSU虚拟机时保持现有配置值不变。

### 三地容灾场景下，当部署8对及以上的存储静态用户数据的USRSU虚拟机时，则需要修改“链路数”的值为“8”，部署小于8对的存储静态用户数据的USRSU虚拟机时保持现有配置值不变。

### 17 登录“UPCF MML命令”界面。

### 18 执行**SYN DBSRDSG**命令，同步对端DSG信息到数据库。

```jinja2
{%- for item in syn_dbsrdsg_list -%}
    SYN DBSRDSG:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    {#- --- 可选参数 --- -#}
    {%- if item.RDSGST is not none -%}
        RDSGST="{{item.RDSGST}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 19 执行**SYN DBSRIPADDR**命令，同步对端IP信息到数据库。

```jinja2
{%- for item in syn_dbsripaddr_list -%}
    SYN DBSRIPADDR:
    {#- --- 必选参数 --- -#}
    RLOCID={{item.RLOCID}},
    {#- --- 可选参数 --- -#}
    {%- if item.RIPST is not none -%}
        RIPST="{{item.RIPST}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 20 设置BE和FE之间DSG的分组连接机制。

### 新建局场景下，按照FE、BE奇偶建链原则需要采用奇偶建链模式时，或新增FE场景下，存在FE与BE新增的对接时，需执行此步骤。否则，跳过此步骤。执行此步骤的操作如下：

### 新建局时，通过执行**SET DBSSCTPPARA**命令，设置“建链模式”为“PARITY（奇偶模式）”，“发送消息时计算校验和”为“TRUE（是）”，“接收消息时检查校验和”为“TRUE（是）”，“旁路ping结果”为“TRUE（是）”。**SET DBSSCTPPARA**命令中各参数的配置值需与BE侧对应参数的配置值（可参见15）保持一致。

```jinja2
{%- for item in set_dbssctppara_list -%}
    SET DBSSCTPPARA:
    {#- --- 必选参数 --- -#}
    ID={{item.ID}},
    {#- --- 可选参数 --- -#}
    {%- if item.LINKMODE is not none -%}
        LINKMODE={{item.LINKMODE}},
    {%- endif -%}
    {%- if item.CHKSUMTX is not none -%}
        CHKSUMTX={{item.CHKSUMTX}},
    {%- endif -%}
    {%- if item.CHKSUMRX is not none -%}
        CHKSUMRX={{item.CHKSUMRX}},
    {%- endif -%}
    {%- if item.PINGBYPASS is not none -%}
        PINGBYPASS={{item.PINGBYPASS}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 新增FE时，需在新增的FE上执行**LST DBSSCTPPARA**命令查询各个参数值，确保与已经完成对接、正常运行的FE网元的各个参数值保持一致。如果参数值不一致，需在新增的FE上执行**SET DBSSCTPPARA**命令，将各个参数值设置一致。

### FE、BE奇偶建链原则如下：

#### 20.1 单局点部署场景下，奇偶建链原则如下：

##### 20.1.1 部署12对及以上的存储静态用户数据的USRSU虚拟机且FE和BE是合一部署局点采用奇偶建链模式。

##### 20.1.2 部署12对及以上的存储静态用户数据的USRSU虚拟机且FE和BE是分离部署局点采用顺序建链模式（默认模式）。

##### 20.1.3 部署少于12对的存储静态用户数据的USRSU虚拟机的局点均采用顺序建链模式（默认模式）。

#### 20.2 容灾组网下奇偶建链原则如下：

##### 20.2.1 两地容灾：部署12对及以上的存储静态用户数据的USRSU虚拟机时需要采用奇偶建链模式，部署少于12对存储静态用户数据的USRSU虚拟机时采用顺序建链模式（默认模式）。

##### 20.2.2 三地容灾：部署8对及以上的存储静态用户数据的USRSU虚拟机时需要采用奇偶建链模式，部署少于8对存储静态用户数据的USRSU虚拟机时采用顺序建链模式（默认模式）。

### 21 执行**SET DBSSRVPARA**命令，设置“链路数”。

### FE和BE的“链路数”配置值需保持一致。FE侧链路数与FE自身的DBS数量及对接BE的DSG模块数量都有关，1对USRSU虚拟机包含2个DSG模块，“LINKNUM”具体配置原则如表3所示。

### **表3** FE侧链路数配置原则

### | BE局点类型 | FE侧（对接BE）每DBS的连接数 LINKNUM1 | BE侧（对接FE）每DSG的连接数 LINKNUM2 | FE侧LINKNUM配置原则 |

### | --- | --- | --- | --- |

### | 单局点 | 存储静态用户数据的USRSU虚拟机对数×2 | UPSRV-S虚拟机数 + UPADD-P虚拟机数 + UPADD-B虚拟机数 + UPSGM虚拟机数 | 若LINKNUM1或LINKNUM2任一计算结果大于64，则设置参数“LINKNUM”=8；若LINKNUM1及LINKNUM2计算结果均小于等于64，则跳过此步骤，无需设置“LINKNUM”。 |

### | 两地容灾 | 存储静态用户数据的USRSU虚拟机对数×2×2 | UPSRV-S虚拟机数 + UPADD-P虚拟机数 + UPADD-B虚拟机数 + UPSGM虚拟机数+8 |  |

### | 三地容灾 | 存储静态用户数据的USRSU虚拟机对数×2×3 | UPSRV-S虚拟机数 + UPADD-P虚拟机数 + UPADD-B虚拟机数 + UPSGM虚拟机数+16 |  |

### UPCF网元下“链路数”的系统默认值为“8”，最多支持链路数为64。系统最大能力如下：

### 二地容灾的组网场景下，“链路数”为默认值情况下，最大支持2个BE和7个FE。当FE个数超过7时，需要调整“链路数”的值为“4”，此时调整后系统最大支持2个BE和15个FE。

### 三地容灾的组网场景下，“链路数”为默认值情况下，最大支持3个BE和6个FE。当FE个数超过6时，需要调整“链路数”的值为“4”，此时调整后系统最大支持3个BE和14个FE。

### 配置样例如下：

```jinja2
{%- for item in set_dbssrvpara_list -%}
    SET DBSSRVPARA:
    {#- --- 必选参数 --- -#}
    SERVICETYPE="{{item.SERVICETYPE}}",
    {#- --- 可选参数 --- -#}
    {%- if item.LINKNUM is not none -%}
        LINKNUM={{item.LINKNUM}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 22 登录“USCDB MML命令”界面。

### 23 执行**ACT IPDISP**命令，激活IP链路。

### 单局点，激活次序为先激活BE、后激活FE；有容灾局时，BE之间互联先激活LID小的BE，后激活LID大的BE，然后激活FE。

### 在先执行的命令成功返回后，再执行下一条命令。

### 在激活IP链路后，DSG模块的状态从“未就绪”变为“主用”。

```jinja2
ACT IPDISP:
;
```

### 在激活链路过程中，激活链路涉及的DSG模块不提供服务，剩余DSG模块负荷会升高。因此在系统负荷较低时执行该命令，在负荷较大时需谨慎。

### 执行该命令时，需等待MML命令返回成功报文后才能执行其他命令。

### 24 执行**DSP DSGSCTP**命令，查看DSG链路状态信息。

### 在执行结果中，如果参数如下所示，则说明链路正常。

### “链路状态”显示为“链路已激活”。

### “激活状态”显示为“未被手工去激活”。

### “拥塞状态”显示为“无拥塞”。

### 25 登录“UPCF MML命令”界面。

### 26 执行**ACT DBSIPDISP**命令，激活IP链路。

### 单局点，激活次序为先激活BE、后激活FE；有容灾局时，BE之间互联先激活LID小的BE，后激活LID大的BE，然后激活FE。

### 在先执行的命令成功返回后，再执行下一条命令。

### 在激活IP链路后，DSG模块的状态从“未就绪”变为“主用”。

```jinja2
ACT DBSIPDISP:
;
```

### 在激活链路过程中，激活链路涉及的DSG模块不提供服务，剩余DSG模块负荷会升高。因此在系统负荷较低时执行该命令，在负荷较大时需谨慎。

### 执行该命令时，需等待MML命令返回成功报文后才能执行其他命令。

### 27 执行**DSP DBSSCTP**命令，查看DSG链路状态信息。

### 在执行结果中，如果参数如下所示，则说明链路正常。

### “链路状态”显示为“链路已激活”。

### “激活状态”显示为“未被手工去激活”。

### “拥塞状态”显示为“无拥塞”。

### 28 登录告警台，检查是否存在ALM-22004 DSG SCTP链路故障告警。

### 29 执行**STR DBSROUTING**命令，DBS消息选择路由。

```jinja2
STR DBSROUTING:
;
```

### 执行此命令后，DBS消息自动选择到正常的最高优先级的BE局点。

### 30 登录“USCDB MML命令”界面。

### 31 执行**RST MODULE**命令，重启所有DSG模块。

### 若已通过步骤15执行**SET DSGSCTPPARA**命令设置FE与BE的分组连接机制，则需执行此步骤。否则，跳过此步骤。

```jinja2
{%- for item in rst_module_list -%}
    RST MODULE:
    {#- --- 必选参数 --- -#}
    MID={{item.MID}},
    MT={{item.MT}},
    ;
{%- endfor -%}
```

### 32 登录“UPCF MML命令”界面。

### 33 执行**RST MSPROCESS**命令，复位dbbroker微服务进程。

### 若已通过步骤20执行**SET DBSSCTPPARA**命令设置FE与BE的分组连接机制，则需执行此步骤。否则，跳过此步骤。

```jinja2
{%- for item in rst_msprocess_list -%}
    RST MSPROCESS:
    {#- --- 必选参数 --- -#}
    PROCOBJECT={{item.PROCOBJECT}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：PROCOBJECT=PROCNAME 时必选 --- -#}
    {%- if item.PROCOBJECT == 'PROCNAME' -%}
        PROCNAME="{{item.PROCNAME}}",
    {%- endif -%}
    {#- --- 条件必选：PROCOBJECT=PROCID 时必选 --- -#}
    {%- if item.PROCOBJECT == 'PROCID' -%}
        PROCID="{{item.PROCID}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：PROCOBJECT=PROCNAME/PROCID 时可选 --- -#}
    {%- if item.PROCOBJECT in ['PROCNAME', 'PROCID'] -%}
        {%- if item.MEID is not none -%}
            MEID="{{item.MEID}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

