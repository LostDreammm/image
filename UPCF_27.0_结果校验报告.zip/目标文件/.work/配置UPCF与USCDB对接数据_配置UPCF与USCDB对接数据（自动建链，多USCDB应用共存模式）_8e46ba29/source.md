# 配置UPCF与USCDB对接数据（自动建链，多USCDB应用共存模式）

* 操作场景
* 必备事项
* 操作流程
* 操作步骤
* 验证方法
* 任务示例

#### 操作场景

多USCDB应用共存模式下，当使用网设工具CloudDesign生成开局MML时，可参考本页面内容。

当前现网会话备份应用越来越多，较多局点（容灾局点）部署的会话备份只有1对用于存储用户数据的USRSU虚拟机，N对用于存储会话数据的USRSU虚拟机。Session备份场景下，Session备份消息由用户数据USRSU虚拟机的DSG转发。当只有VOLTE会话时，用户数据USRSU虚拟机的DSG数量较少，导致USRSU虚拟机的DSG转发会话备份消息产生瓶颈，具体场景如图1所示。因此，FE侧需区分BE侧不同应用类型的DSG来分别建立链路（多USCDB应用共存模式），其实现原理如图2。

**图1** 具体场景

**图2** 多应用共存实现原理

#### 必备事项

**前提条件**

已经完成UPCF、USCDB的基础数据配置。

**数据**

* 登录OM Portal的“admin”用户的密码。
* 执行操作前，USCDB侧规划的数据如表1所示。

  **表1** USCDB侧数据

  | 类别 | 参数名称 | 取值样例 | 说明 |
  | --- | --- | --- | --- |
  | **SET GROUPSWITCH** | GROUPNAME（分组名称） | UPCF | FE侧支持多应用共存的分组名称，固定取值为“UPCF”。 |
  |  | GROUPSWITCH（分组开关） | OPEN | FE侧支持多应用共存的业务分组开关，表示分组功能是否打开。 |
  | **ADD DSGLINKCTRL** | MID（模块号） | + 3 + 6 | USCDB侧的DSG模块号。网元安装完成后，由运营商对已部署的DSG模块进行统一规划。 |
  |  | DSGST（DSG业务类型） | + UPCF + UPCF-SESSION | 固定取值，两个取值均需配置。 |
  |  | IPVER（IP类型） | IPV4 | 全网规划，由运营商提供。 |
  |  | IPV4 （本端IPV4地址） | + 10.20.129.40 + 10.20.129.41 | USCDB侧的数据平面的IP地址，该参数必须先由USCDB侧的**ADD SRVIPADDR**命令配置，然后在此引用。  只有当“IPVER”为“IPV4”时，才会出现此参数。 |
  |  | SHAKEY（校验码） | NewPwd12 | 全网规划，由运营商提供。 |
  | **ADD RLOCATION** | RLOCID（远端Location标识） | 231 | UPCF侧的Location标识，该参数已经支持VNFD自动规划配置，请在“UPCF MML命令界面”窗口执行**LST DBSLOCATION**命令进行查询，然后在此引用。 |
  |  | RMT（远端网元类型） | + UPCF + UPCF-SESSION | 固定取值，两个取值均需配置。 |
  |  | LP （位置ID优先级值） | + 1 + 2 | 优先级值越小，优先级越高。 |
  |  | REDUNFLAG（是否容灾关系） | No | 仅当本命令的参数“远端网元类型”为“USCDB(USCDB)”时此参数才能配置为“Yes”，否则只能配置为“No”。 |
  | **ADD RDSGLINKCTRL** | RLOCID（远端Location标识） | 231 | 与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。 |
  |  | IPVER（IP类型） | IPV4 | 全网规划，由运营商提供。 |
  |  | RLINKCENTERTYPE（远端链路中心类型） | DBS | 取值固定为“DBS”。 |
  |  | IPV4 （远端Location IPV4地址） | + 10.20.139.40 + 10.20.139.41 | UPCF侧的数据平面的IP地址，该参数必须先由UPCF侧的**ADD DBSIPADDR**命令配置，然后在此引用。  只有当“IPVER”为“IPV4”时，才会出现此参数。 |
  |  | RDSGST（远端DSG业务类型） | + UPCF + UPCF-SESSION | 固定取值，两个取值均需配置。 |
  |  | SHAKEY（校验码） | NewPwd12 | 全网规划，由运营商提供。 |
  | **SYN RDSG** | RLOCID（远端Location标识） | 231 | 与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。 |
  |  | RDSGST（远端DSG业务类型） | + UPCF + UPCF-SESSION | 固定取值，两个取值均需配置。 |
  | **SYN RIPADDR** | RLOCID（远端Location标识） | 231 | 与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。 |
  |  | RDPUST（远端IP地址业务类型） | + UPCF + UPCF-SESSION | 固定取值，两个取值均需配置。 |
  | **ADD NOTIFYCFG** | FETYPE（订阅通知的FE类型） | UPCF | 参数在成功加载FE插件包后才有效。 |
  |  | FEID（FE标识） | 1 | 本端规划，取值范围内不允许重复。 |
  |  | INFTYPE（订阅通知的接口类型） | MCI | 在此场景下固定配置为“MCI”。 |
  |  | SYNCHROSWITCH（同步开关） | ASYNC | 固定配置。 |
  | **SET DSGSCTPPARA** | ID（SCTP参数标识） | 1 | - |
  |  | LINKMODE（建链模式） | PARITY | 与对接的远端网元中该参数配置值保持一致。 |
  |  | CHKSUMTX（发送消息时计算校验和） | TRUE | 与对接的远端网元中该参数配置值保持一致。 |
  |  | CHKSUMRX（接收消息时检查校验和） | TRUE | 与对接的远端网元中该参数配置值保持一致。 |
  |  | PINGBYPASS（旁路ping结果） | TRUE | 用于停止统计QOS任务。与对接的远端网元中该参数配置值保持一致。 |
  | **SET LINKNUM** | SERVICETYPE（业务类型） | UPCF | FE网元的业务类型。 |
  |  | LINKNUM（链路数） | 8 | 由运营商统一规划。 |
  | **DSP DSGSCTP** | RLOCID（远端Location标识） | 231 | 与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。 |
* 执行操作前，UPCF侧规划的数据如表2所示。

  **表2** UPCF侧数据

  | 类别 | 参数名称 | 取值样例 | 说明 |
  | --- | --- | --- | --- |
  | **SET DBSGRPSWITCH** | GROUPNAME（分组名称） | UPCF | FE侧支持多应用共存的分组名称，固定取值为“UPCF”。 |
  |  | GROUPSWITCH（分组开关） | OPEN | FE侧支持多应用共存的业务分组开关，表示分组功能是否打开。 |
  | **ADD DBSLINKCTRL** | SERVICENO（服务模块号） | 3 | 用于指定网元的DBS服务模块号。DBS服务模块号先由**LST DBSSERVICENO**命令查询，然后在此处索引。 |
  |  | IPVER（IP类型） | IPV4 | 全网规划，由运营商提供。 |
  |  | IPV4IP （本端IPV4地址） | 10.20.139.40 | 用于指定IPV4类型的本地IP地址。  该参数必须先由命令**ADD DBSIPADDR**定义才能在此处引用。 |
  |  | PASSWORD（本地链路中心校验码） | NewPwd12 | 全网规划，由运营商提供。 |
  | **ADD DBSRLOCATION** | RLOCID（远端Location标识） | 81 | USCDB侧的Location标识，该参数已经支持VNFD自动规划配置，请在“USCDB MML命令界面”窗口执行**LST LOCATION**进行查询，然后在此引用。 |
  |  | RMT（远端网元类型） | USCDB | 取值固定为“USCDB”。 |
  |  | LP （位置ID优先级值） | 1 | 优先级值越小，优先级越高。 |
  | **ADD DBSRLINKCTRL** | INDEX（配置索引） | + 1 + 2 | 本端自定义。 |
  |  | RLOCID（远端Location标识） | 81 | 用于指定一个远端网元标识。该参数须在对接的远端网元中先定义，然后在本端UPCF网元通过命令**ADD DBSRLOCATION**配置后，才能在此处索引。 |
  |  | IPVER（IP类型） | IPV4 | 全网规划，由运营商提供。 |
  |  | IPV4IP （远端IPV4地址） | + 10.20.129.40 + 10.20.129.41 | 用于指定远端UPCF的Location IPv4地址。  只有当“IPVER”为“IPV4”时，才会出现此参数。 |
  |  | RDSGST（远端DSG业务类型） | UPCF | 用于设置远端DSG网元的业务类型，该参数为联想参数列表，不能手动输入，其取值为命令**LST DBSSRVGROUP**查询获得的“业务类型名称”输出参数。 |
  |  | PASSWORD（远端链路中心校验码） | + NewPwd12 + NewPwd12 | 全网规划，由运营商提供。 |
  | **SYN DBSRDSG** | RLOCID（远端Location标识） | 81 | 标识一条远端DSG配置记录的关键字段，用于指定需要同步哪一条远端Location标识的远端DSG记录，操作员可以使用**LST DBSRDSG**命令查询获得。远端Location和远端网元一一对应。 |
  |  | RDSGST（远端DSG业务类型） | UPCF | 用于标识远端DSG业务类型。该参数为联想参数列表，不能手动输入，其取值为**LST DBSSRVGROUP**命令查询获得的“业务类型名称”输出参数。 |
  | **SYN DBSRIPADDR** | RLOCID（远端Location标识） | 81 | 标识一个远端网元IP地址的关键字段，用于指定需要同步哪一个远端Location标识的远端网元IP地址。操作员可以使用**LST DBSRIPADDR**命令查询获得。 |
  |  | RIPST（远端IP地址业务类型） | UPCF | 用于指定远端网元IP地址的业务类型。该参数为联想参数列表，不能手动输入，其取值为**LST DBSSRVGROUP**命令查询获得的“业务类型名称”输出参数。 |
  | **SET DBSSCTPPARA** | ID（SCTP参数标识） | 1 | - |
  |  | LINKMODE（建链模式） | PARITY | 与对接的远端网元中该参数配置值保持一致。 |
  |  | CHKSUMTX（发送消息时计算校验和） | TRUE | 与对接的远端网元中该参数配置值保持一致。 |
  |  | CHKSUMRX（接收消息时检查校验和） | TRUE | 与对接的远端网元中该参数配置值保持一致。 |
  |  | PINGBYPASS（旁路ping结果） | TRUE | 用于停止统计QOS任务。与对接的远端网元中该参数配置值保持一致。 |
  | **DSP DBSSCTP** | RLOCID（远端Location标识） | 81 | 与远端location信息中的“RLOCID（远端Location标识）”取值保持一致。 |

#### 操作流程

配置UPCF与USCDB的对接数据，流程如图3所示。

**图3** 配置UPCF与USCDB的对接数据

#### 操作步骤

1. 登录“USCDB MML命令”界面。
2. 执行**SET GROUPSWITCH**命令，将分组业务功能打开。

   ```
   SET GROUPSWITCH: GROUPNAME="UPCF", GROUPSWITCH=OPEN;
   ```
3. 执行**ADD DSGLINKCTRL**命令，增加本端DSG链路中心。

   ```
   ADD DSGLINKCTRL: MID=模块号, DSGST=DSG业务类型, IPVER=IP类型, IPV4=本端IPV4地址, SHAKEY=校验码;
   ```

   * 当配置USCDB基础数据添加的DSG的UPCF和UPCF-SESSION业务类型配置为相同IP时，此处DSG链路中心配置需要将**LST SRVIPADDR**中**IPV4IP1**和**IPV4IP2**分别规划给UPCF和UPCF-SESSION使用（IPV6场景同理）。
   * 当启用多USCDB应用共存模式时，有多少种应用共存就需要配置多少种DSG链路中心。下面以UPCF/UPCF-SESSION共存为例给出某个BE的配置样例：

     ```
     ADD DSGLINKCTRL: MID=3, DSGST="UPCF", IPVER=IPV4, IPV4=10.10.10.16, SHAKEY="NewPwd12";
     ADD DSGLINKCTRL: MID=6, DSGST="UPCF-SESSION", IPVER=IPV4, IPV4=10.10.10.17, SHAKEY="NewPwd12";
     ```
4. 执行**ADD RLOCATION**命令，增加远端Location信息。在增加对端时，必须先增加UPCF类型的Location信息，再增加UPCF-SESSION类型的Location信息。

   ```
   ADD RLOCATION: RLOCID=远端Location标识, RMT="UPCF", LP=位置ID优先级, REDUNFLAG=No;
   ADD RLOCATION: RLOCID=远端Location标识, RMT="UPCF-SESSION", LP=位置ID优先级, REDUNFLAG=No;
   ```

   当启用多USCDB应用共存模式时，有多少种应用共存就需要配置多少种远端Location信息。下面以UPCF/UPCF-SESSION共存为例给出到某个FE（RLOCID=231）的配置样例：

   ```
   ADD RLOCATION: RLOCID=231, RMT="UPCF", LP=1, REDUNFLAG=No;
   ADD RLOCATION: RLOCID=231, RMT="UPCF-SESSION", LP=2, REDUNFLAG=No;
   ```
5. 执行**ADD RDSGLINKCTRL**命令，增加远端DBS链路中心。

   ```
   ADD RDSGLINKCTRL: RLOCID=远端Location标识, IPVER=IP类型, RLINKCENTERTYPE=DBS, IPV4=远端Location IPV4地址, RDSGST=远端DSG业务类型, SHAKEY=校验码;
   ```

   * BE网元的链路中心类型为DSG，FE网元的链路中心为DBS。MML命令**ADD RDSGLINKCTRL**可以用来设置BE网元对接的远端DSG或者DBS链路中心，命令下“RLINKCENTERTYPE”参数的选择取决于对端是FE网元还是BE网元。

     举例说明：

     1. 当BE网元想增加FE网元的链路中心，由于对端FE的链路中心类型是DBS，所以在BE侧配置时，“RLINKCENTERTYPE”参数要选“DBS”。
     2. 当BE网元想增加BE网元的链路中心，由于对端BE的链路中心类型是DSG，所以在BE侧配置时，“RLINKCENTERTYPE”参数要选“DSG”。
   * 当启用多USCDB应用共存模式时，有多少种应用共存就需要配置多少种远端DSG链路中心。下面以UPCF/UPCF-SESSION共存为例给出到某个FE（RLOCID=231）的配置样例：

     ```
     ADD RDSGLINKCTRL: RLOCID=231, IPVER=IPV4, RLINKCENTERTYPE=DBS, IPV4=10.20.139.40, RDSGST="UPCF", SHAKEY="NewPwd12";
     ADD RDSGLINKCTRL: RLOCID=231, IPVER=IPV4, RLINKCENTERTYPE=DBS, IPV4=10.20.139.40, RDSGST="UPCF-SESSION", SHAKEY="NewPwd12";
     ```
6. 登录“UPCF MML命令”界面。
7. 执行**SET DBSGRPSWITCH**命令，将分组业务功能打开。

   ```
   SET DBSGRPSWITCH: GROUPNAME="UPCF", GROUPSWITCH=OPEN;
   ```
8. 执行**ADD DBSLINKCTRL**命令，增加DBS链路中心。

   ```
   ADD DBSLINKCTRL: SERVICENO=服务模块号, IPVER=IP类型, IPV4IP=本地链路中心IPV4地址, PASSWORD=本地链路中心校验码;
   ```
9. 执行**ADD DBSRLOCATION**命令，增加远端Location信息。

   ```
   ADD DBSRLOCATION: RLOCID=远端Location标识, RMT=USCDB, LP=位置ID优先级;
   ```

   * 可以通过**RMV DBSRLOCATION**命令删除多余的远端Location信息。
   * 单局点多USCDB应用共存模式下，UPCF侧只需增加1个远端USCDB的Location信息。
10. 执行**ADD DBSRLINKCTRL**命令，用于增加远端DSG链路中心。

    ```
    ADD DBSRLINKCTRL: INDEX=配置索引, RLOCID=远端Location标识, IPVER=IP类型, IPV4IP=远端链路中心IPV4地址1, PASSWORD=远端链路中心校验码, RDSGST=远端DSG业务类型;
    ADD DBSRLINKCTRL: INDEX=配置索引, RLOCID=远端Location标识, IPVER=IP类型, IPV4IP=远端链路中心IPV4地址2, PASSWORD=远端链路中心校验码, RDSGST=远端DSG业务类型;
    ```

    当配置USCDB基础数据添加的DSG的UPCF和UPCF-SESSION业务类型配置为相同IP时，此处DSG链路中心配置需要将**LST SRVIPADDR**中**IPV4IP1**和**IPV4IP2**分别规划给UPCF和UPCF-SESSION使用（IPV6场景同理）。
11. 登录“USCDB MML命令”界面。

    USCDB侧、UPCF侧的本端DSG链路中心和远端DSG链路中心都已配置，需等待至少7秒，确保两侧互相接收到远端发来的消息后，再执行以下步骤。
12. 执行**SYN RDSG**命令，同步对端DSG信息到数据库。

    ```
    SYN RDSG: RLOCID=远端Location标识, RDSGST=远端DSG业务类型;
    ```

    当启用多USCDB应用共存模式时，有多少种应用共存就需要同步多少种远端DSG信息。下面以UPCF/UPCF-SESSION共存为例给出到某个FE（RLOCID=231）的配置样例：

    ```
    SYN RDSG: RLOCID=231, RDSGST="UPCF";
    SYN RDSG: RLOCID=231, RDSGST="UPCF-SESSION";
    ```
13. 执行**SYN RIPADDR**命令，同步对端IP信息到数据库。

    ```
    SYN RIPADDR: RLOCID=远端Location标识, RDPUST=远端IP地址业务类型;
    ```

    当启用多USCDB应用共存模式时，有多少种应用共存就需要同步多少种远端IP信息。下面以UPCF/UPCF-SESSION共存为例给出到某个FE（RLOCID=231）的配置样例：

    ```
    SYN RIPADDR: RLOCID=231, RDPUST="UPCF";
    SYN RIPADDR: RLOCID=231, RDPUST="UPCF-SESSION";
    ```
14. 执行**ADD NOTIFYCFG**命令，增加订阅通知。

    ```
    ADD NOTIFYCFG: FETYPE=订阅通知的FE类型, FEID=FE标识, INFTYPE=订阅通知的接口类型;
    ```

    如果不需要增加订阅通知，可跳过该步骤。
15. 设置BE和FE之间DSG的分组连接机制。

    新建局场景下，按照FE、BE奇偶建链原则需要采用奇偶建链模式时，或新增BE场景下，存在FE与BE新增的对接时，需执行此步骤。否则，跳过此步骤。执行此步骤的操作如下：

    * 新建局时，通过执行**SET DSGSCTPPARA**命令，设置“建链模式”为“PARITY（奇偶模式）”，“发送消息时计算校验和”为“TRUE（是）”，“接收消息时检查校验和”为“TRUE（是）”，“旁路ping结果”为“TRUE（是）”。**SET DSGSCTPPARA**命令中各参数的配置值需与FE侧对应参数的配置值保持一致。

      ```
      SET DSGSCTPPARA: ID=SCTP参数标识, LINKMODE=PARITY, CHKSUMTX=TRUE, CHKSUMRX=TRUE, PINGBYPASS=TRUE;
      ```
    * 新增BE时，需在新增的BE上执行**LST DSGSCTPPARA**命令查询各个参数值，确保与已经完成对接、正常运行的BE网元的各个参数值保持一致。如果参数值不一致，需在新增的BE上执行**SET DSGSCTPPARA**命令，将各个参数值设置一致。

    FE、BE奇偶建链原则如下：
    * 单局点部署场景下，奇偶建链原则如下：
      + 部署12对及以上的存储静态用户数据的USRSU虚拟机且FE和BE是合一部署局点采用奇偶建链模式。
      + 部署12对及以上的存储静态用户数据的USRSU虚拟机且FE和BE是分离部署局点采用顺序建链模式（默认模式）。
      + 部署少于12对的存储静态用户数据的USRSU虚拟机的局点均采用顺序建链模式（默认模式）。
    * 容灾组网下奇偶建链原则如下：
      + 两地容灾：部署12对及以上的存储静态用户数据的USRSU虚拟机时需要采用奇偶建链模式，部署少于12对存储静态用户数据的USRSU虚拟机时采用顺序建链模式（默认模式）。
      + 三地容灾：部署8对及以上的存储静态用户数据的USRSU虚拟机时需要采用奇偶建链模式，部署少于8对存储静态用户数据的USRSU虚拟机时采用顺序建链模式（默认模式）。
16. 执行**SET LINKNUM**命令，设置“链路数”为“X”。

    FE和BE的“链路数”配置值需保持一致。

    ```
    SET LINKNUM: SERVICETYPE=业务类型, LINKNUM=X;
    ```

    USCDB网元下“链路数”的系统默认值为“8”，混合组网场景下“链路数”的配置，需要按照混合组网指导书配置计算。其他场景若从未修改默认值，则不需重新设置。若修改了默认值：
    * 单局点及两地容灾场景下，当部署12对及以上的存储静态用户数据的USRSU虚拟机时，则需要修改“链路数”的值为“8”，部署小于12对的存储静态用户数据的USRSU虚拟机时保持现有配置值不变。
    * 三地容灾场景下，当部署8对及以上的存储静态用户数据的USRSU虚拟机时，则需要修改“链路数”的值为“8”，部署小于8对的存储静态用户数据的USRSU虚拟机时保持现有配置值不变。
17. 登录“UPCF MML命令”界面。
18. 执行**SYN DBSRDSG**命令，同步对端DSG信息到数据库。

    ```
    SYN DBSRDSG: RLOCID=远端Location标识, RDSGST=远端DSG业务类型;
    ```
19. 执行**SYN DBSRIPADDR**命令，同步对端IP信息到数据库。

    ```
    SYN DBSRIPADDR: RLOCID=远端Location标识, RIPST=远端IP地址业务类型;
    ```
20. 设置BE和FE之间DSG的分组连接机制。

    新建局场景下，按照FE、BE奇偶建链原则需要采用奇偶建链模式时，或新增FE场景下，存在FE与BE新增的对接时，需执行此步骤。否则，跳过此步骤。执行此步骤的操作如下：

    * 新建局时，通过执行**SET DBSSCTPPARA**命令，设置“建链模式”为“PARITY（奇偶模式）”，“发送消息时计算校验和”为“TRUE（是）”，“接收消息时检查校验和”为“TRUE（是）”，“旁路ping结果”为“TRUE（是）”。**SET DBSSCTPPARA**命令中各参数的配置值需与BE侧对应参数的配置值（可参见15）保持一致。

      ```
      SET DBSSCTPPARA: ID=SCTP参数标识, LINKMODE=PARITY, CHKSUMTX=TRUE, CHKSUMRX=TRUE, PINGBYPASS=TRUE;
      ```
    * 新增FE时，需在新增的FE上执行**LST DBSSCTPPARA**命令查询各个参数值，确保与已经完成对接、正常运行的FE网元的各个参数值保持一致。如果参数值不一致，需在新增的FE上执行**SET DBSSCTPPARA**命令，将各个参数值设置一致。

    FE、BE奇偶建链原则如下：
    * 单局点部署场景下，奇偶建链原则如下：
      + 部署12对及以上的存储静态用户数据的USRSU虚拟机且FE和BE是合一部署局点采用奇偶建链模式。
      + 部署12对及以上的存储静态用户数据的USRSU虚拟机且FE和BE是分离部署局点采用顺序建链模式（默认模式）。
      + 部署少于12对的存储静态用户数据的USRSU虚拟机的局点均采用顺序建链模式（默认模式）。
    * 容灾组网下奇偶建链原则如下：
      + 两地容灾：部署12对及以上的存储静态用户数据的USRSU虚拟机时需要采用奇偶建链模式，部署少于12对存储静态用户数据的USRSU虚拟机时采用顺序建链模式（默认模式）。
      + 三地容灾：部署8对及以上的存储静态用户数据的USRSU虚拟机时需要采用奇偶建链模式，部署少于8对存储静态用户数据的USRSU虚拟机时采用顺序建链模式（默认模式）。
21. 执行**SET DBSSRVPARA**命令，设置“链路数”。

    FE和BE的“链路数”配置值需保持一致。FE侧链路数与FE自身的DBS数量及对接BE的DSG模块数量都有关，1对USRSU虚拟机包含2个DSG模块，“LINKNUM”具体配置原则如表3所示。

    **表3** FE侧链路数配置原则

    | BE局点类型 | FE侧（对接BE）每DBS的连接数 LINKNUM1 | BE侧（对接FE）每DSG的连接数 LINKNUM2 | FE侧LINKNUM配置原则 |
    | --- | --- | --- | --- |
    | 单局点 | 存储静态用户数据的USRSU虚拟机对数×2 | UPSRV-S虚拟机数 + UPADD-P虚拟机数 + UPADD-B虚拟机数 + UPSGM虚拟机数 | 若LINKNUM1或LINKNUM2任一计算结果大于64，则设置参数“LINKNUM”=8；若LINKNUM1及LINKNUM2计算结果均小于等于64，则跳过此步骤，无需设置“LINKNUM”。 |
    | 两地容灾 | 存储静态用户数据的USRSU虚拟机对数×2×2 | UPSRV-S虚拟机数 + UPADD-P虚拟机数 + UPADD-B虚拟机数 + UPSGM虚拟机数+8 |  |
    | 三地容灾 | 存储静态用户数据的USRSU虚拟机对数×2×3 | UPSRV-S虚拟机数 + UPADD-P虚拟机数 + UPADD-B虚拟机数 + UPSGM虚拟机数+16 |  |

    UPCF网元下“链路数”的系统默认值为“8”，最多支持链路数为64。系统最大能力如下：

    * 二地容灾的组网场景下，“链路数”为默认值情况下，最大支持2个BE和7个FE。当FE个数超过7时，需要调整“链路数”的值为“4”，此时调整后系统最大支持2个BE和15个FE。
    * 三地容灾的组网场景下，“链路数”为默认值情况下，最大支持3个BE和6个FE。当FE个数超过6时，需要调整“链路数”的值为“4”，此时调整后系统最大支持3个BE和14个FE。

    配置样例如下：

    ```
    SET DBSSRVPARA: SERVICETYPE="UPCF", LINKNUM=6;
    SET DBSSRVPARA: SERVICETYPE="UPCF-SESSION", LINKNUM=6;
    ```
22. 登录“USCDB MML命令”界面。
23. 执行**ACT IPDISP**命令，激活IP链路。

    * 单局点，激活次序为先激活BE、后激活FE；有容灾局时，BE之间互联先激活LID小的BE，后激活LID大的BE，然后激活FE。
    * 在先执行的命令成功返回后，再执行下一条命令。
    * 在激活IP链路后，DSG模块的状态从“未就绪”变为“主用”。

    ```
    ACT IPDISP:;
    ```

    * 在激活链路过程中，激活链路涉及的DSG模块不提供服务，剩余DSG模块负荷会升高。因此在系统负荷较低时执行该命令，在负荷较大时需谨慎。
    * 执行该命令时，需等待MML命令返回成功报文后才能执行其他命令。
24. 执行**DSP DSGSCTP**命令，查看DSG链路状态信息。

    ```
    DSP DSGSCTP: RLOCID=远端Location标识;
    ```

    在执行结果中，如果参数如下所示，则说明链路正常。
    * “链路状态”显示为“链路已激活”。
    * “激活状态”显示为“未被手工去激活”。
    * “拥塞状态”显示为“无拥塞”。
25. 登录“UPCF MML命令”界面。
26. 执行**ACT DBSIPDISP**命令，激活IP链路。

    * 单局点，激活次序为先激活BE、后激活FE；有容灾局时，BE之间互联先激活LID小的BE，后激活LID大的BE，然后激活FE。
    * 在先执行的命令成功返回后，再执行下一条命令。
    * 在激活IP链路后，DSG模块的状态从“未就绪”变为“主用”。

    ```
    ACT DBSIPDISP:;
    ```

    * 在激活链路过程中，激活链路涉及的DSG模块不提供服务，剩余DSG模块负荷会升高。因此在系统负荷较低时执行该命令，在负荷较大时需谨慎。
    * 执行该命令时，需等待MML命令返回成功报文后才能执行其他命令。
27. 执行**DSP DBSSCTP**命令，查看DSG链路状态信息。

    ```
    DSP DBSSCTP: RLOCID=远端Location标识;
    ```

    在执行结果中，如果参数如下所示，则说明链路正常。
    * “链路状态”显示为“链路已激活”。
    * “激活状态”显示为“未被手工去激活”。
    * “拥塞状态”显示为“无拥塞”。
28. 登录告警台，检查是否存在ALM-22004 DSG SCTP链路故障告警。
29. 执行**STR DBSROUTING**命令，DBS消息选择路由。

    ```
    STR DBSROUTING:;
    ```

    执行此命令后，DBS消息自动选择到正常的最高优先级的BE局点。
30. 登录“USCDB MML命令”界面。
31. 执行**RST MODULE**命令，重启所有DSG模块。

    若已通过步骤15执行**SET DSGSCTPPARA**命令设置FE与BE的分组连接机制，则需执行此步骤。否则，跳过此步骤。

    ```
    RST MODULE: MID=模块号, MT=DSG;
    ```
32. 登录“UPCF MML命令”界面。
33. 执行**RST MSPROCESS**命令，复位dbbroker微服务进程。

    若已通过步骤20执行**SET DBSSCTPPARA**命令设置FE与BE的分组连接机制，则需执行此步骤。否则，跳过此步骤。

    ```
    RST MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_UdrDbbroker";
    ```

#### 验证方法

1. 登录“UPCF MML命令”界面 。
2. 执行**DSP DBSSCTP**命令，查询“链路状态”是否为“链路已激活”。

   ```
   DSP DBSSCTP:;
   ```

   * 是 => 3
   * 否 => 根据操作流程检查UPCF侧配置的数据是否正确，包括与USCDB的对接配置数据。
3. 登录“USCDB MML命令”界面。
4. 执行**DSP DSGSCTP**命令，查询“链路状态”是否为“链路已激活”。

   ```
   DSP DSGSCTP:;
   ```

   * 是 => 检查完成。
   * 否 => 根据操作流程检查USCDB侧配置的数据是否正确，包括与UPCF的对接配置数据。

#### 任务示例

**任务描述**

在同一个UPCF网元下，UPCF和UPCF-SESSION两种应用共存时，须配置USCDB基础数据。完成USCDB与UPCF基础数据的配置及USCDB与UPCF对接数据的配置，使USCDB与UPCF之间互通正常。

**脚本**

```
/*登录到USCDB MML命令界面*/
USE ME: MEID=81;  //机机接口命令，无须手动执行

/*打开分组业务功能*/
SET GROUPSWITCH:GROUPNAME="UPCF",GROUPSWITCH=OPEN;

/*增加本端DSG链路中心*/
ADD DSGLINKCTRL: MID=3, DSGST="UPCF", IPVER=IPV4, IPV4=10.20.129.40, SHAKEY="NewPwd12";
ADD DSGLINKCTRL: MID=6, DSGST="UPCF-SESSION", IPVER=IPV4, IPV4=10.20.129.41, SHAKEY="NewPwd12";

/*增加远端Location信息，对端UPCF的Location标识已经在VNFD中自动规划添加，可以在UPCF MML命令界面通过LST LOCATION命令进行查询。这里给出RLOCID=231作为示例。*/
ADD RLOCATION: RLOCID=231, RMT="UPCF", LP=1, REDUNFLAG=No;
ADD RLOCATION: RLOCID=231, RMT="UPCF-SESSION", LP=2, REDUNFLAG=No;

/*增加远端DSG链路中心*/
ADD RDSGLINKCTRL: RLOCID=231, IPVER=IPV4, RLINKCENTERTYPE=DBS, IPV4=10.20.139.40, RDSGST="UPCF", SHAKEY="NewPwd12";
ADD RDSGLINKCTRL: RLOCID=231, IPVER=IPV4, RLINKCENTERTYPE=DBS, IPV4=10.20.139.41, RDSGST="UPCF-SESSION", SHAKEY="NewPwd12";

/*登录到UPCF MML命令界面*/
USE ME: MEID=231;  //机机接口命令，无须手动执行

/*打开分组业务功能*/
SET DBSGRPSWITCH: GROUPNAME="UPCF", GROUPSWITCH=OPEN;

/*增加本端DSG链路中心*/
ADD DBSLINKCTRL: SERVICENO=3, IPVER=IPV4, IPV4IP="10.20.139.40", PASSWORD="NewPwd12";

/*增加远端Location信息，对端USCDB的Location标识已经在VNFD中自动规划添加，可以在USCDB MML命令界面通过LST DBSLOCATION命令进行查询。这里给出RLOCID=81作为示例。*/
ADD DBSRLOCATION: RLOCID=81, RMT=USCDB, LP=1;

/*增加远端DSG链路中心*/
ADD DBSRLINKCTRL: INDEX=1, RLOCID=81, IPVER=IPV4, IPV4IP="10.20.129.40", PASSWORD="NewPwd12", RDSGST="UPCF";
ADD DBSRLINKCTRL: INDEX=2, RLOCID=81, IPVER=IPV4, IPV4IP="10.20.129.41", PASSWORD="NewPwd12", RDSGST="UPCF";

/*登录到USCDB MML命令界面*/
USE ME: MEID=81;

/*同步远端DSG配置*/
SYN RDSG: RLOCID=231, RDSGST="UPCF";
SYN RDSG: RLOCID=231, RDSGST="UPCF-SESSION";

/*同步远端IP配置*/
SYN RIPADDR: RLOCID=231, RDPUST="UPCF";
SYN RIPADDR: RLOCID=231, RDPUST="UPCF-SESSION";

/*增加订阅通知*/
ADD NOTIFYCFG: FETYPE="UPCF", FEID=1, INFTYPE=MCI, SYNCHROSWITCH=ASYNC;

/*设置BE和FE之间的分组连接机制*/
SET DSGSCTPPARA: ID=1, LINKMODE=PARITY, CHKSUMTX=TRUE, CHKSUMRX=TRUE, PINGBYPASS=TRUE;

/*设置链路数*/
SET LINKNUM: SERVICETYPE="UPCF", LINKNUM=8;

/*登录到UPCF MML命令界面*/
USE ME: MEID=231;

/*同步远端DSG配置*/
SYN DBSRDSG: RLOCID=81, RDSGST="UPCF";

/*同步远端IP配置*/
SYN DBSRIPADDR: RLOCID=81, RIPST="UPCF";

/*设置BE和FE之间的分组连接机制*/
SET DBSSCTPPARA: ID=1, LINKMODE=PARITY, CHKSUMTX=TRUE, CHKSUMRX=TRUE, PINGBYPASS=TRUE;

/*设置链路数*/
SET DBSSRVPARA: SERVICETYPE="UPCF", LINKNUM=6;
SET DBSSRVPARA: SERVICETYPE="UPCF-SESSION", LINKNUM=6;

/*登录到USCDB MML命令界面*/
USE ME: MEID=81;

/*激活链路*/
ACT IPDISP:;

/*登录到UPCF MML命令界面*/
USE ME: MEID=231;

/*激活链路*/
ACT DBSIPDISP:;

/*启动DSG消息选择路由操作*/
STR DBSROUTING:;

/*登录到USCDB MML命令界面*/
USE ME: MEID=81;

/*重启DSG模块*/
RST MODULE: MID=3, MT=DSG;
RST MODULE: MID=6, MT=DSG;

/*登录到UPCF MML命令界面*/
USE ME: MEID=231;

/*复位dbbroker微服务进程*/
RST MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_UdrDbbroker";
```

版权所有 © 华为技术有限公司
