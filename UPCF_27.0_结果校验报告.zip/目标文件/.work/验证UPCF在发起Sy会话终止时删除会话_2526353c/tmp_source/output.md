---
id: ''
name: 验证UPCF在发起Sy会话终止时删除会话
ne_type: UPCF
type: feature
description: 验证用户在线时UPCF能主动发起STR删除Sy会话。  具体场景为：用户已经建立IP-CAN会话并且建立了Sy会话，当用户最后一个Sy业务被去签约时， UPCF发起STR消息删除Sy会话。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611058 Sy接口(使用Diameter协议)策略控制","WHFD-611058 Sy接口(使用Diameter协议)策略控制特性调测","验证UPCF在发起Sy会话终止时删除会话"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
验证用户在线时UPCF能主动发起STR删除Sy会话。具体场景为：用户已经建立IP-CAN会话并且建立了Sy会话，当用户最后一个Sy业务被去签约时， UPCF发起STR消息删除Sy会话。

## 必备事项
前提条件

* Sy接口开关已启用，即软参VRM\_SYSWITCH（Sy接口开关）已设置为非“0”值。
* 已完成Sy会话的业务配置，业务名称为“Service\_Sy\_040401”，具体的配置方法参见Sy接口(使用Diameter协议)策略控制特性配置。
* 已增加用户，并为用户签约“Service\_Sy\_040401”业务。配置方法如下：
  1. 登录“UPCF 业务管理”窗口。
  2. 执行ADD PSUB命令，增加用户。

     ADD PSUB: USRIDENTIFIER="用户标识", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=eMBB;
  3. 执行ADD PSRV命令，为用户签约“Service\_Sy\_040401”业务。

     ADD PSRV: USRIDENTIFIER="用户标识", SRVNAME="Service\_Sy\_040401", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    rmv_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - rmv_psrv_list:
    - USRIDENTIFIER: 用户标识
      SRVNAME: Service_Sy_040401
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 在OM Portal界面上创建“用户消息跟踪”任务。

#### 1.1 选择“监控分析 > 消息跟踪 > 任务管理 > upcf\_XXXX\_N”。

#### “upcf\_XXXX\_N”选项中“N”表示网元的ID，“XXXX”表示网元的名称。

#### 1.2 单击“用户消息跟踪”，在“用户消息跟踪”任务对话框点击“创建跟踪任务”。

#### 1.3 填写“任务名称”、“跟踪时长”和用户的“用户标识”，并选中“Gx”和“Sy”接口。其中，“用户标识”为开户时“USRIDENTIFIER”参数的值。

#### 1.4 单击“确认”。

### 2 验证UPCF能够发起Sy会话建立请求。

#### 2.1 用户A接入网络，进行网页浏览或者文件下载。

#### 2.2 通过OM Portal消息跟踪结果查看SLR-Initial消息中的信息。

#### **表1** 用户A上线验证结果

#### | 消息名称 | 验证信息 | 预期结果 |

#### | --- | --- | --- |

#### | SLR-Initial | session-id | 消息中有携带该信元。 |

#### |  | Subscription-Id | 消息中有携带该信元。 |

#### |  | subscription-id-type | 取值为“end-user-imsi(1)”。 |

#### |  | subscription-id-data | 取值为接入网络用户的用户标识。 |

#### |  | SL-Request-Type | 取值为“0”。 |

### 3 验证UPCF收到OCS返回成功的SLA-Initial响应后能够通过CCA-I下发策略。

#### 3.1 在消息跟踪结果中，存在SLA-Initial消息和CCA-I消息。

#### 3.2 查看SLA-Initial消息和CCA-I消息相关信元的取值。如表2所示。

#### **表2** SLA-Initial消息和CCA-I消息

#### | 消息名称 | 验证信息 | 预期结果 |

#### | --- | --- | --- |

#### | SLA-Initial | session-id | 与步骤2中的“session-id”一致。 |

#### |  | result-code | 取值为“diameter-success(2001)”。 |

#### |  | Policy-Counter-Identifier | 取值为“SyQuota”，即已在UPCF上配置的配额名称。 |

#### |  | Policy-Counter-Status | 取值为“0”，即已在UPCF上配置的配额“SyQuota”对应的“Normal”状态。 |

#### | CCA-I | result-code | 取值为“diameter-success（2001）”。 |

#### |  | charging-rule-name | 取值为“BT-2M”，即已在PCEF上配置的预定义规则名称。 |

### 4 修改用户签约信息。执行**RMV PSRV**命令，给用户去签约“Service\_Sy\_040401”业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该rmv_psrv_list的变量区（command: RMV PSRV） -#}
<!-- MISSING_MACRO: command=RMV PSRV list_name=rmv_psrv_list step_id=4 -->
```

### 5 验证UPCF发起STR释放Sy会话请求。

#### 5.1 在消息跟踪结果中，存在STR消息。

#### 5.2 查看STR消息相关信元的取值。如表3所示。

#### **表3** STR消息

#### | 消息名称 | 验证信息 | 预期结果 |

#### | --- | --- | --- |

#### | STR | session-id | 与步骤2中的“session-id”一致。 |

#### |  | termination-cause | 取值为“diameter-logout(1)”。 |

### 6 验证OCS回复STA响应消息给UPCF。

#### 6.1 在消息跟踪结果中，存在STA消息。

#### 6.2 查看STA消息相关信元的取值。如表4所示。

#### **表4** STA消息

#### | 消息名称 | 验证信息 | 预期结果 |

#### | --- | --- | --- |

#### | STA | session-id | 与步骤2中的“session-id”一致。 |

#### |  | result-code | 取值为“diameter-success(2001)”。 |

