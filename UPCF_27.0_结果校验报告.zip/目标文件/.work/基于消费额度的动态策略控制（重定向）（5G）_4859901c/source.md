# 基于消费额度的动态策略控制（重定向）（5G）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 验证方法
* 任务示例

## 操作场景

当5G组网用户在一个周期内（日、周、月）消费的金额达到某个阈值时，运营商将用户重定向到某个网站。重定向分两种场景：

* 一次重定向：只进行一次重定向到固定网站以示提醒，后续用户可正常使用业务。
* 始终重定向：用户每次使用业务都重定向到固定网站，阻塞用户的所有业务，待用户充值成功后才允许继续使用。

以如下应用场景，UPCF对接华为UNC为例：

* 账户金额为200欧元。
* 每月1号的01:00:00进行账户复位，剩余账户金额采用清零方式。
* 策略控制：
  + 用户处于本地时，账户正常，上下行带宽为5 Mbit/s，按1欧元/MB计费。
  + 用户处于本地时，账户耗尽，重定向到充值网站。
  + 用户处于漫游区时，账户正常，上下行带宽为5 Mbit/s，按2欧元/MB计费。
  + 用户处于漫游区时，账户耗尽，重定向到充值网站。
* 配置动态规则。

## 对系统的影响

对系统正常运行没有影响。

## 必备事项

前提条件

操作员已了解WHFD-611008 基于消费额度的动态策略控制特性概述，且通过4G/5G业务配置差异介绍已经了解5G规则配置原理。

数据

根据应用场景，参考业务拆解总体原则，此场景下的业务配置逻辑关系如图1所示。

**图1** 此场景下的PMS业务配置逻辑

此图配置逻辑仅针对当前业务配置场景。因此图中“必须配置的动作类型”也仅是针对当前场景而言，其他不同场景须参考对应的配置逻辑。常见的基于N7接口的PDU会话建立过程配置方法不唯一，此处仅提供了一种通用配置逻辑。

分解的业务配置关系如图2所示，详细解释如表1所示。

**图2** 业务配置关系

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 业务5G\_Service\_Rating | 此漫游限额重定向业务即为一个独立的业务（service）。 | - |
| 账户5G\_Account\_Rating | * 配置用户的账户金额、复位时间及阈值等。 * 阈值取默认配置Normal和Exhaust。 | - |
| 策略5G\_Policy\_Rating | 此策略在用户上线、账户状态变化和用户所处位置的MCC（Mobile Country Code）/MNC（Mobile Network Code）改变时被调用，触发器分别为IPCAN\_EST、AccountStatusChange、PLMN\_CH和US\_RE，包含所有规则。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配并下发策略给SMF。 |
| 规则5G\_Rule\_Rating1 | * 条件：本地、账户正常。 * 5G动作：  QoSData：上下行带宽均为5 Mbit/s。  UsageMonitoringData：“umId”取值与本地的“费率”中“监控键值”相同。 * 费率：按1欧元/MB计费。 | * 条件组的个数：多种条件的组合控制，最多要定义N个条件组，其中N=条件1的状态数×条件2的状态数× … ×条件n的状态数。条件的状态数是指条件出现的状态的个数。  此场景中，条件1为漫游状态，有本地、外地两种，那么条件状态数为2；条件2为账户使用量，如果有Normal和Exhaust两种，则该条件的状态数为2。此场景条件组个数=2×2=4。 * 条件组的合并：如果几个条件组对应的动作（含通知、重定向、费率）一样，那么这几个条件组可以考虑合并，无法合并的，则设立独立的条件组。  此场景中，4个条件组排列组合，对应的动作分别如下：    + 本地、账户正常：上下行带宽为5 Mbit/s，按1欧元/MB计费。   + 本地、账户耗尽：重定向   + 漫游、账户正常：上下行带宽为5 Mbit/s，按2欧元/MB计费。   + 漫游、账户耗尽：重定向 根据条件组合并原则，“本地、账户耗尽”和“漫游、账户耗尽”动作相同，故合并为一个条件组，包含条件“账户耗尽”即可。 * 动作UsageMonitoringData：基于消费额度的动态策略控制时，规则中需通过此动作下发“umId”，以便在流量上报时关联对应的费率，并进行账户扣减。 |
| 规则5G\_Rule\_Rating2 | * 条件：漫游、账户正常。 * 5G动作：  QoSData：上下行带宽均为5 Mbit/s。  UsageMonitoringData：“umId”取值与漫游的“费率”中“监控键值”相同。 * 费率：按2欧元/MB计费。 |  |
| 规则5G\_Rule\_Rating3 | * 条件：账户耗尽。 * 5G动作：  QoSData：上下行带宽均为5 Mbit/s。  RedirectInformation：重定向网址为http://example.com/。 |  |

## 操作流程

业务的配置流程图如图3所示。

**图3** 业务配置流程图

## 操作步骤

1. 配置软参。

   当某局点的计费系统的最小计费单位不是1字节时，需要通过修改该软参将流量转换为金额时的取整单位设置为该计费系统对应的最小计费单位。此软参详细含义请参考RM\_RATINGVOLRNDUNIT。

   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD INSP**命令，配置参数RM\_RATINGVOLRNDUNIT，用于设置流量换算成金额时，将流量按多少字节取整。

      命令举例：

      ```
      MOD INSP: INSPN=RM_RATINGVOLRNDUNIT, INSPV=10;
      ```
2. 登录UPCF Web UI界面。
3. 配置PLMN。

   导航入口为“位置管理 > 位置 > PLMN”。

   PLMN（Public Land Mobile Network）的数据规划如表2所示，详细参数说明请参见PLMN参数表。

   **表2** PLMN

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | PLMN1 | 基本信息 | PLMN标识 | PLMN\_1 |
   |  |  | 类型 | 本地 |
   |  |  | MCC | 460 |
   |  |  | MNC | 003 |
   | PLMN2 | 基本信息 | PLMN标识 | PLMN\_2 |
   |  |  | 类型 | 外地 |
   |  |  | MCC | 460 |
   |  |  | MNC | 002 |
4. 配置账户。

   导航入口为“业务管理 > 业务 > 账户”。

   账户的数据规划如表3所示，详细参数说明请参见帐户参数表。

   **表3** 账户

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 账户 | 基本信息 | 名称 | 5G\_Account\_Rating |
   |  |  | 值 | 200 |
   |  |  | 分片(％) | 10 |
   |  | 复位设置 | 结帐模式 | 自然日历 |
   |  |  | 复位周期类型 | 月 |
   |  |  | 复位日 | 1 |
   |  |  | 复位时间 | 01:00:00 |
   |  |  | 剩余额处理方式 | 清零 |
5. 增加费率。

   导航入口为“策略管理 > 策略 > 费率”。

   需要配置2个费率，用于账户的漫游状态为本地或漫游时流量与金额的转换。费率的数据规划如表4所示，详细参数说明请参见费率参数表。

   **表4** 费率

   | 类别 | 参数 | 取值样例 |
   | --- | --- | --- |
   | 费率1 | 名称 | 5G\_Rating1 |
   |  | 监控键值 | 200 |
   |  | 金额 | 1 |
   |  | 流量（KB） | 1024 |
   | 费率2 | 名称 | 5G\_Rating2 |
   |  | 监控键值 | 201 |
   |  | 金额 | 2 |
   |  | 流量（KB） | 1024 |
6. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置3个条件组，用于判断账户的漫游状态为本地且账户正常、漫游状态为漫游且账户正常或账户耗尽。条件组的数据规划如表5所示，详细参数说明请参见条件组参数表。

   **表5** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | 5G\_CG\_Rating1 |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | 5G\_C\_Rating\_Native |
   |  |  | 对象属性 | * 对象：SmfSession * 属性：RoamingStatus |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Native  说明：  “Native”：表示本地。 |
   |  | 条件2 | 名称 | 5G\_C\_Rating\_Norm |
   |  |  | 对象属性 | * 对象：Account * 属性：AccountStatus |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Normal  说明：  “Normal”：表示账户金额未耗尽。 |
   | 条件组2 | 基本信息 | 名称 | 5G\_CG\_Rating2 |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | 5G\_C\_Rating\_Roaming |
   |  |  | 对象属性 | * 对象：SmfSession * 属性：RoamingStatus |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Roaming  说明：  “Roaming”：表示外地漫游。 |
   |  | 条件2 | 名称 | 5G\_C\_Rating\_Norm2 |
   |  |  | 对象属性 | * 对象：Account * 属性：AccountStatus |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Normal  说明：  “Normal”：表示账户金额未耗尽。 |
   | 条件组3 | 基本信息 | 名称 | 5G\_CG\_Rating3 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | 5G\_C\_Rating\_Exhaust |
   |  |  | 对象属性 | * 对象：Account * 属性：AccountStatus |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示账户金额耗尽。 |
7. 配置5G动作组。

   导航入口为“策略管理 > 策略 > 5G动作组”.

   * 若配置的规则为动态规则，则必须配置动作组。
   * 此场景配置5G动作组需要考虑流信息、业务流开关、流量上报、带宽调整和重定向，则需配置动作：FlowInformation、TrafficControlData、UsageMonitoringData、QoSData和RedirectInformation。相关应用场景如下：
     + FlowInformation：当需要下发流信息时需配置此动作。
     + TrafficControlData：当需要做门限控制时，配置此动作。在下发流描述时，如果不配默认为放通该流，当需要限制流时，此动作必须配置。
     + UsageMonitoringData：当需要进行流量上报时，配置此动作。UsageMonitoringData动作类型中的umId必须与费率的“监控键值”配置一致。
     + QoSData：当需要进行带宽控制时，配置此动作。
     + RedirectInformation：选择永久重定向，即每次访问都重定向到固定页面。若用户在此次会话过程中充值，则需删除此动作，否则仍将重定向。

   需要配置3个“DynamicPccRule”类型的5G动作组，用于在账户的漫游状态为本地且账户正常、漫游状态为漫游且账户正常或账户耗尽时动作的下发。动作组的数据规划如表6所示，详细参数说明请参见5G动作参数表。

   **表6** 5G动作组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 5G动作组1 | 基本信息 | 名称 | 5G\_AG\_Rating\_FlowD |
   |  |  | 类型 | FlowDescription |
   |  | 属性 | action | * 类型：Value * 值：PERMIT |
   |  |  | direction | * 类型：Value * 值：BIDIRECTIONAL |
   |  |  | protocol | * 类型：Value * 值：ANY |
   |  |  | sourceIP | * 类型：Value * 值：any |
   |  |  | destinationIP | * 类型：Value * 值：any |
   | 5G动作组2 | 基本信息 | 名称 | 5G\_AG\_Rating\_FlowInfo |
   |  |  | 类型 | FlowInformation |
   |  | 属性 | flowDescription | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_FlowD  说明：  已在5G动作组中定义。 |
   |  |  | flowDirection | * 类型：Value * 值：BIDIRECTIONAL |
   | 5G动作组3 | 基本信息 | 名称 | 5G\_AG\_Rating\_arp |
   |  |  | 类型 | Arp |
   |  | 属性 | priorityLevel | * 类型：Object Attribute * 值：SmfSession.SubsDefQosPriorityLevel |
   |  |  | preemptCap | * 类型：Value * 值：NOT\_PREEMPT |
   |  |  | preemptVuln | * 类型：Value * 值：NOT\_PREEMPTABLE |
   | 5G动作组4 | 基本信息 | 名称 | 5G\_AG\_Rating\_QoSData |
   |  |  | 类型 | QoSData |
   |  | 属性 | qosId | * 类型：Value * 值：5G\_AG\_Rating\_QoSData |
   |  |  | 5qi | * 类型：Object Attribute * 值：SmfSession.SubsDefQos5qi |
   |  |  | arp | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_arp 说明：  已在5G动作组中定义。 |
   |  |  | maxbrUl | * 类型：Value * 值：5 Mbps |
   |  |  | maxbrDl | * 类型：Value * 值：5 Mbps |
   | 5G动作组5 | 基本信息 | 名称 | 5G\_AG\_Rating\_UmData1 |
   |  |  | 类型 | UsageMonitoringData |
   |  | 属性 | umId | * 类型：Value * 值：200  说明：  需与对应的“费率1”中配置的“监控键值”取值相同。 |
   |  |  | volumeThreshold | * 类型：Value * 值：20480 |
   | 5G动作组6 | 基本信息 | 名称 | 5G\_AG\_Rating\_UmData2 |
   |  |  | 类型 | UsageMonitoringData |
   |  | 属性 | umId | * 类型：Value * 值：201  说明：  需与对应的“费率2”中配置的“监控键值”取值相同。 |
   |  |  | volumeThreshold | * 类型：Value * 值：20480 |
   | 5G动作组7 | 基本信息 | 名称 | 5G\_AG\_Rating\_redirectInfo |
   |  |  | 类型 | RedirectInformation |
   |  | 属性 | redirectEnabled | * 类型：Value * 值：True |
   |  |  | redirectAddressType | * 类型：Value * 值：URL |
   |  |  | redirectServerAddress | * 类型：Value * 值：http://www.example.com/ |
   | 5G动作组8 | 基本信息 | 名称 | 5G\_AG\_Rating\_TcData1 |
   |  |  | 类型 | TrafficControlData |
   |  | 属性 | tcId | * 类型：Value * 值：5G\_AG\_Rating\_TcData1 |
   |  |  | flowStatus | * 类型：Value * 值：ENABLED |
   | 5G动作组9 | 基本信息 | 名称 | 5G\_AG\_Rating\_TcData2 |
   |  |  | 类型 | TrafficControlData |
   |  | 属性 | tcId | * 类型：Value * 值：5G\_AG\_Rating\_TcData2 |
   |  |  | flowStatus | * 类型：Value * 值：ENABLED |
   |  |  | redirectInfo | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_redirectInfo 说明：  已在5G动作组中定义。 |
   | 5G动作组10 | 基本信息 | 名称 | 5G\_AG\_Rating\_PccRule1 |
   |  |  | 类型 | DynamicPccRule |
   |  | 属性 | pccRuleId | * 类型：Value * 值：5G\_AG\_Rating\_PccRule1 |
   |  |  | flowInfos | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_FlowInfo 说明：  已在5G动作组中定义。 |
   |  |  | precedence | * 类型：Value * 值：1 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_QoSData 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_TcData1 说明：  已在5G动作组中定义。 |
   |  |  | refUmData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_UmData1 说明：  已在5G动作组中定义。 |
   | 5G动作组11 | 基本信息 | 名称 | 5G\_AG\_Rating\_PccRule2 |
   |  |  | 类型 | DynamicPccRule |
   |  | 属性 | pccRuleId | * 类型：Value * 值：5G\_AG\_Rating\_PccRule2 |
   |  |  | flowInfos | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_FlowInfo 说明：  已在5G动作组中定义。 |
   |  |  | precedence | * 类型：Value * 值：1 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_QoSData 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_TcData1 说明：  已在5G动作组中定义。 |
   |  |  | refUmData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_UmData2 说明：  已在5G动作组中定义。 |
   | 5G动作组12 | 基本信息 | 名称 | 5G\_AG\_Rating\_PccRule3 |
   |  |  | 类型 | DynamicPccRule |
   |  | 属性 | pccRuleId | * 类型：Value * 值：5G\_AG\_Rating\_PccRule3 |
   |  |  | flowInfos | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_FlowInfo 说明：  已在5G动作组中定义。 |
   |  |  | precedence | * 类型：Value * 值：1 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_QoSData 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_TcData2 说明：  已在5G动作组中定义。 |
8. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   规则的数据规划如表7所示，详细参数说明请参见规则参数表。

   **表7** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | 5G\_Rule\_Rating1 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule |
   |  |  | 费率 | 5G\_Rating1  说明：  已在费率中定义。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | 5G\_CG\_Rating1  说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | 5G\_AG\_Rating\_PccRule1  说明：  已在5G动作组中定义。 |
   | 规则2 | 基本信息 | 名称 | 5G\_Rule\_Rating2 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule |
   |  |  | 费率 | 5G\_Rating2  说明：  已在费率中定义。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | 5G\_CG\_Rating2  说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | 5G\_AG\_Rating\_PccRule2  说明：  已在5G动作组中定义。 |
   | 规则3 | 基本信息 | 名称 | 5G\_Rule\_Rating3 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | 5G\_CG\_Rating3  说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | 5G\_AG\_Rating\_PccRule3  说明：  已在5G动作组中定义。 |
9. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   策略的数据规划如表8所示，详细参数说明请参见策略参数表。

   **表8** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略 | 基本信息 | 名称 | 5G\_Policy\_Rating |
   |  |  | 策略类型 | N7 Policy |
   |  | 触发器 | 名称 | * IPCAN\_EST * PLMN\_CH * US\_RE * AccountStatusChange |
   |  | 规则 | 名称 | * 5G\_Rule\_Rating1 * 5G\_Rule\_Rating2 * 5G\_Rule\_Rating3 说明：  已在规则中定义。 |
10. 配置业务。

    导航入口为“业务管理 > 业务 > 业务”。

    完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

    业务的数据规划如表9所示，详细参数说明请参见业务参数表。

    **表9** 业务

    | 类别 | 参数 |  | 取值样例 |
    | --- | --- | --- | --- |
    | 业务 | 基本信息 | 名称 | 5G\_Service\_Rating |
    |  |  | 类型 | VALUE\_ADDED\_SERVICE |
    |  |  | 账户 | 5G\_Account\_Rating  说明：  已在账户中配置。 |
    |  |  | 是否记入基本配额 | 是 |
    |  |  | 激活方式 | PCEF |
    |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
    |  |  | QoS模式 | 替换 |
    |  |  | 签约后才能使用 | 是 |
    |  | 策略 | 名称 | 5G\_Policy\_Rating  说明：  已在策略中定义。 |
11. 登录“UPCF 业务管理”窗口。
12. 发放业务。
    1. 执行**ADD PSUB**增加一个用户。

       “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

       ```
       ADD PSUB: USRIDENTIFIER="46010381012****", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB, USRLANGUAGE=NULL, USRSMSRECEIVEFLAG=All, USRVERSTATUS=Normal;
       ```
    2. 执行**ADD PSRV**给用户签约业务。

       ```
       ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="5G_Service_Rating", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL, SRVCONTACTMETHOD=None, SRVCREATESUBSCRIBER=No, PAYMENTFLAG=Yes;
       ```

## 验证方法

## 任务示例

任务描述

配置基于N7接口的消费额度业务。

脚本

CLI脚本

版权所有 © 华为技术有限公司
