---
id: ''
name: 基于消费额度的动态策略控制（重定向）（5G）
ne_type: UPCF
type: feature
description: 当5G组网用户在一个周期内（日、周、月）消费的金额达到某个阈值时，运营商将用户重定向到某个网站。重定向分两种场景：  * 一次重定向：只进行一次重定向到固定网站以示提醒，后续用户可正常使用业务。 * 始终重定向：用户每次使用业务都重定向到固定网站，阻塞用户的所有业务，待用户充值成功后才允许继续使用。  以如下应用场景，UPCF对接华为UNC为例：  * 账户金额为200欧元。 * 每月1号的01:00:00进行账户复位，剩余账户金额采用清零方式。 * 策略控制：   + 用户处于本地时，账户正常，上下行带宽为5 Mbit/s，按1欧元/MB计费。   + 用户处于本地时，账户耗尽，重定向到充值网站。   + 用户处于漫游区时，账户正常，上下行带宽为5 Mbit/s，按2欧元/MB计费。   + 用户处于漫游区时，账户耗尽，重定向到充值网站。 * 配置动态规则。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611008 基于消费额度的动态策略控制","WHFD-611008 基于消费额度的动态策略控制特性配置","基于消费额度的动态策略控制（重定向）（5G）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
当5G组网用户在一个周期内（日、周、月）消费的金额达到某个阈值时，运营商将用户重定向到某个网站。重定向分两种场景：* 一次重定向：只进行一次重定向到固定网站以示提醒，后续用户可正常使用业务。* 始终重定向：用户每次使用业务都重定向到固定网站，阻塞用户的所有业务，待用户充值成功后才允许继续使用。以如下应用场景，UPCF对接华为UNC为例：* 账户金额为200欧元。* 每月1号的01:00:00进行账户复位，剩余账户金额采用清零方式。* 策略控制：  + 用户处于本地时，账户正常，上下行带宽为5 Mbit/s，按1欧元/MB计费。  + 用户处于本地时，账户耗尽，重定向到充值网站。  + 用户处于漫游区时，账户正常，上下行带宽为5 Mbit/s，按2欧元/MB计费。  + 用户处于漫游区时，账户耗尽，重定向到充值网站。* 配置动态规则。

## 必备事项
前提条件

操作员已了解WHFD-611008 基于消费额度的动态策略控制特性概述，且通过4G/5G业务配置差异介绍已经了解5G规则配置原理。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    mod_insp_list:
      type: items
      properties:
        INSPN:
          name: '参数名'
          type: string
          enum:
          - VRM_MAXIPCANSESNUMPERSPU
          - VRM_MAXAFSESNUMPERSPU
          - VRM_MAXSUBNUMPERSPU
          - VRM_UPGRADE
          - VRM_MAXRATBEARIDPERSES
          - VRM_SRVNUMPERUSR
          - VRM_MAXPAFNUM
          - VRM_MAXPCEFNUM
          - VRM_MAXRADIUSSRVNUM
          - VRM_MAXCONNECTIONPERPAF
          - VRM_MAXCONNECTIONPERPCEF
          - VRM_MAXLINKRADIUSSRV
          - VRM_SUBSRCIPTIONIDTYPE
          - VRM_GLBREFLASHINTERVAL
          - VRM_NOTIFYMSGMAXRECORDPERSUB
          - VRM_NOTIFYMSGMAXDAYPERSUB
          - VRM_REVALIDATIONTIMEMETHOD
          - VRM_NOSUBSCRIPTIONERRORCODE
          - VRM_NOTIFYMSGMAXWAITEDRECORDS
          - VRM_PRINTLOCALLOG
          - VRM_USRREVALIHRANGE
          - VRM_ONLINECHECK
          - VRM_TIMEZONEENHANCE
          - VRM_GXIMEIFORMAT
          - VRM_NOTIFYMSGMAXRECORDPERDSU
          - VRM_CLEARALLDYNCREATEDUSER
          - VRM_PEELDOMAINSWITCH
          - VRM_NOTIFYRCVER
          - VRM_FIRSTDAYOFWEEK
          - VRM_UPDATESPRSUBACTIVE
          - VRM_SUBCTRLRESULT
          - VRM_SPRSUBMAXOFFLINEDAYS
          - VRM_CHECKSUBSCRIBEDSERVICE
          - VRM_SUBACTCTRL
          - VRM_SESSIONCHECKINTERVAL
          - VRM_CHKSUBSRVSYTYPE
          - VRM_RARSENDSPEED
          - VRM_DIAREDIRECTSWITCH
          - VRM_PERIODVALUE
          - VRM_PROTECTTIMER
          - VRM_SENDUSERNUM
          - VRM_POLICYCASESENSITIVE
          - VRM_SESSIONRESTORATION
          - VRM_RXRPMAPRELATION
          - VRM_NOTIFYUSAGEUNITCONVERT
          - VRM_TIMEACCUMODE
          - VRM_SYSWITCH
          - VRM_PLMNMATCHPRIORITY
          - VRM_RESETNOTIFYRPT
          - VRM_REPORTINGLEVEL
          - VRM_RATINGGROUP
          - VRM_SERVICEIDENTIFIER
          - VRM_DFTCHARGINGPARA
          - VRM_LOGPRINTPERIOD
          - VRM_MAXBBERFNUM
          - VRM_MAXCONNECTIONPERBBERF
          - VRM_SPNOTIFYDOMAIN
          - VRM_EXSPRNOTIFICATION
          - VRM_SESSIONBACKUPSWITCH
          - VRM_DIAMHBINTERVAL
          - VRM_DIAMHBTIMES
          - VRM_EDRACCESSFORMATE
          - VRM_IPCANTERMSWITCH
          - VRM_DELBEAROPTION
          - VRM_LDAPREVBUFFERSIZE
          - VRM_NOTIFYOPTIMIZE
          - VRM_RESULTCODESWITCH
          - VRM_FMTIPADDR
          - VRM_GROUPDIAREDIRECTSWITCH
          - VRM_RMVSUBWITHOUTRAR
          - VRM_GRPMBRUSAGECACHE1
          - VRM_GRPMBRUSAGECACHE2
          - VRM_DYNRULEFORMAT
          - VRM_IPV6HASHLENGTH
          - VRM_DURATIONMKMATCH
          - VRM_SNRRECSPEED
          - VRM_DIAMTIMETHRD
          - VRM_LDAPTIMETHRD
          - VRM_RELGXBYRAATIMEOUT
          - VRM_SETHOMESRVZONE
          - VRM_MAXTDFNUM
          - VRM_TDFCCRUSPD
          - VRM_TDFCCRTSPD
          - VRM_PROCHEARTBEATTIMEOUT
          - VRM_MAXAUXILIARYAREA
          - VRM_AADIAREDIRECTSWITCH
          - VRM_DIAMFAILOVERSWITCH
          - VRM_DYNSMSMSISDN
          - VRM_SUBGRPCREATESUB
          - VRM_QUOTACROSSSERVICE
          - VRM_SYSUBIDTYPE
          - VRM_DEACTIVESERVICETIMER
          - VRM_QUOTALOGSWITCH
          - VRM_SIMPLEPOLICYSTATISTIC
          - VRM_GXTRIGGERCMP
          - VRM_QOSNEGOTIATIONSWITCH
          - VRM_IPFLOWANYCVT
          - VRM_SUBLISTNORULE
          - VRM_NTFOVERDUEMODE
          - VRM_DESTPEERMODE
          - VRM_SYNDATASWITCH
          - VRM_SYNDATAINTERVAL
          - VRM_TAIECGIMATCHMODE
          - VRM_SYCARRYSUBID
          - VRM_SYRESENDTIMES
          - VRM_DYNQUOTATIMEZONE
          - VRM_FIRSTGXSESSIONATTR
          - VRM_SESSIONIDHASHMODE
          - VRM_PEERFCDURATION
          - VRM_AFPOLICYRECALCULATE
          - VRM_SGWRESTORETIME
          - VRM_QUOTAUSEPRIORITY
          - VRM_SESSIONIDSWITCH
          - VRM_REPORTUSAGE
          - VRM_IMEIQUERYSERVICE
          - VRM_MCITRIGGERUDR
          - VRM_RXMAXUL
          - VRM_RXMAXDL
          - VRM_SYSESSIONCONTROLATTRIBUTE
          - VRM_SYSESSIONCONTROLVALUE
          - VRM_AUTORECUSRLOC
          - VRM_LINKDSPMODE
          - VRM_RXSTAINCAUTHAPPID
          - VRM_MAXAREANUM
          - VRM_GXSESSIONONLYVOLTE
          - VRM_LDAPDBTIMEOUT
          - VRM_OFFSETTIME
          - VRM_APNSENSITIVE
          - VRM_DYNGROUPNUMBERPERUSER
          - VRM_SYSESSIONBACKUP
          - VRM_NOTIFYATTRRESTRICTION
          - VRM_UNKNOWNRULEPROC
          - VRM_FORCEUPGRADEQOS
          - VRM_RMVGRPMEMBERACT
          - VRM_SYNUSRDATASPEED
          - VRM_SYCHARGINGCHARSWITCH
          - VRM_LICDSPMODE
          - VRM_GRPMBRPARENTSTATUSFLAG
          - VRM_TERMSESSNOTIFICATIONFLAG
          - VRM_DCIPRIORITY
          - VRM_SERVICEINFOSTATUSMODE
          - VRM_RXARPMAPPINGMODE
          - VRM_NOTIFYATTRENUMVALUEMODE
          - VRM_GLBSESDATAREFRESH
          - VRM_MAXPOCSCPNUM
          - VRM_SPUAUTOSWITCHOVER
          - VRM_PRAIDCODECMODE
          - VRM_DFTROAMINGSTATUS
          - VRM_MCIPROCMODE
          - VRM_VMSTORAGEFAULTRMSWITCH
          - VRM_PREBINDFORSESSIONBACKUP
          - VRM_SHARESYQUOTAMODE
          - VRM_MEMCHECKALARMSWITCH
          - VRM_QUOTASTATUSSTATISTIC
          - VRM_SUBIDCHOOSESWITCH
          - VRM_MCCMNCROAMREGION
          - VRM_TERMFIRSTSESSIONSWITCH
          - VRM_RECORDMEMSWITCH
          - VRM_Q922ERRMSGSWITCH
          - VRM_MEMFREERECORDSTKSWITCH
          - VRM_MEMFREERECORDSTKPOLICY
          - VRM_MSGFREERECORDSTKSWITCH
          - VRM_MSGFREERECORDSTKPOLICY
          - VRM_MEMALLOCFAILEDHOOKSWITCH
          - VRM_LOADINGALLAREADATA
          - VRM_MAXMSGTEMPLATENUM
          - VRM_PCEFHOSTTOGROUP
          - VRM_LINKBASEAPN
          - VRM_CBOVERRUNALMTH
          - VRM_CBRECOVERYALMTH
          - VRM_VOLTESESSINDEPENDENT
          - VRM_MEWORKROLE
          - VRM_RESETFORALLOCMEMFAILED
          - VRM_RESETFORALLOCMSGFAILED
          - VRM_ENABLEVOLTEAPNGXFLOWCTRL
          - VRM_CBWATCHTIME
          - VRM_DIAMMSGRELAYSWITCH
          - VRM_SYNTIMER
          - VRM_DEVAUDITACCELERATION
          - VRM_PENDINGTRANSACTIONNUM
          - VRM_VOLTEQRYSPR
          - VRM_TRIGGERRESTRICTTYPE
          - BLC_UPMUSERREQ
          - BLC_BEARUPDATE
          - BLC_WAITBEARTERM
          - BLC_ZONETYPE
          - BLC_SECPDPQOSCONTROL
          - RM_RATINGVOLRNDUNIT
          - RM_USGVOLRNDUNIT
          - RM_USGVOLRNDTHRESH
          - RM_RUSGVOLRNDUNIT
          - RM_RUSGVOLRNDTHRESH
          - RM_PLMNANDSGSNALM
          - RM_ALMCLRPERIOD
          - BLC_NOTIFYSENDINTERVAL
          - VRM_OCSCHARGEFLAGFORPRE
          - VRM_OCSCHARGEFLAGFORPOS
          - VRM_OCSCHARGEFLAGFOROTHER
          - BLC_DELSSINVALIDINTERVAL
          - BLC_DELSSINTERVAL
          - BLC_DELSSNUM
          - VRM_CHECKAPNIP
          - VRM_QCIUPGRADE
          - VRM_UNDERCONTROLTHRESHOLD
          - VRM_NORMALVALUE
          - UPM_SUBCTRL
          - UPM_ACCRARTIMEOUT
          - UPM_TIMERPLYCNTREQ
          - VRM_KPIMONITORINGSWITCH
          - VRM_TDFPOLICYMODE
          - VRM_RXBEARWITH5002
          - LIC_PREALMTH
          - VRM_QRYSPRPRIORITY
          - VRM_SDUROUTECONFILICTRAR
          - VRM_DBTIMERVALIDPERIOD
          - VRM_FORCERECOVERYSESSION
          - ALC_WAITAFTERM
          - VRM_RARWITHTRIGGER
          - VRM_RELEASERXTRIGGER
          - VRM_MAXIPCANNUMPERUSR
          - VRM_RETENTION_NOTIFYLOG
          - VRM_RETENTION_MNTLOG
          - VRM_RETENTION_EXPORT
          - VRM_MAXSESSBACKUPNUMPERSUB
          - VRM_SAVESYORGSTATUS
          - VRM_SNRSUPPORTSUBID
          - VRM_AUDITFAILEDCODE
          - VRM_ADJUSTSERVICEMODE
          - VRM_SYORIGINSTATEID
          - VRM_NOTRARWITHSAMEINSTALLRULE
          - VRM_CALCPRIBYSRVNAME
          - VRM_PENDINGTIME2LOCALTIME
          - VRM_MAXPCEFRADIUSNUM
          - VRM_RTPDRNOFLOW
          - VRM_SYDRASLRITIMEOUTSTRCTRL
          - VRM_GXREDIRECTACTION
          - VRM_GXRULEDEDUP
          - VRM_MCITOPGWSPEED
          - VRM_NRIPV6HASHLENGTH
          - VRM_SDCHARGINGCHARSWITCH
          - VRM_OFFLINESRVSWITCH
          - VRM_OFFLINEREDOLOG
          - VRM_VOLTESESSIONNOTUPDATE
          - VRM_BSFONLYVOLTE
          - VRM_BSFRESENDTIMES
          - VRM_BSFTIMEOUT
          - VRM_CHRGIDFMT
          - VRM_LONGTERMNTYRECORDPERSUB
          - VRM_GXQRYCHARINGSYSMODE
          - VRM_RECREATERULENOTIFICATION
          - VRM_PACKETFILTER
          - VRM_SNRWITHOUTHOSTMODE
          - VRM_SYCOUNTERTRANSMODE
          - VRM_MAXCONDITIONNUM
          - VRM_MAXQUOTANUM
          - VRM_RMVSYSRVBYRESULTCODE
          - VRM_VIRTUALSUBIDSWITCH
          - VRM_VOLTEPDPQRYSY
          - VRM_PACKETERRRATETYPE
          - VRM_IPDOMAINSENSITIVE
          - VRM_NRCOMBINEPRIORITYMODE
          - VRM_N15COMPATIBILITYSWITCH
          - VRM_HASHAUDITSWITCH
          - VRM_RECUSRLOCBASERAT
          - VRM_MULTIPCEFQRYDB
          - VRM_DEVAUDITSTARTTIME
          - VRM_MCIDELOLDSES
          - VRM_MCIDELOLDSESSPEED
          - VRM_CHECKSUBSRV
          - VRM_MASTERSLAVENOTIFYENHANCE
          - VRM_NEPEERSTATUS
          - VRM_NONOVERLOADERRORCODESW
          - VRM_AMFRESELECTSWITCH
          - VRM_REDIRECTSWITCH
          - VRM_POLICYASSOCIATESWITCH
          - VRM_DIAMDIRECTPATH
          - VRM_SMFALMWITHIPPORT
          - VRM_REGWITHINSTANCENAME
          - VRM_VIRTUALQUOTAREPORTUSAGE
          - VRM_SPONSORDYNRULEFORMAT
          - VRM_SRVTOKENNUM
          - VRM_UPDSMFSTA
          - VRM_N7CHGNORULESWITCH
          - VRM_QUOTAOBJNOTEXISTCALCMODE
          - VRM_SDRRELIABTRANSSWITCH
          - VRM_CALCULBYNR
          - VRM_GXSESSIONCHARGE
          - VRM_RARSPEEDDOWNCPU
          - VRM_RARSPEEDUPCPU
          - VRM_SUBSCRIBERGROUPMATCHMODE
          - VRM_SCANSTARTTIME
          - VRM_DISTRIQUERYMAXRECORD
          - VRM_GLBPARTITIONLOADINGSWITCH
          - VRM_COMPARECCRIUQOS
          - VRM_AUTORECUSRLOCEX
          - VRM_AVGCHILDPERPARENT
          - VRM_AVGPARENTPERCHILD
          - VRM_SELECTNTSMETHOD
          - VRM_QUOTADEDUCTMODE
          - VRM_MAXBEARNUMPERIPCAN
          - VRM_SDSESSIONBACKUP
          - VRM_SERVICEZONEAREAMATCHTYPE
          - VRM_USRLOCATION_VALUE
          - VRM_RULESUFFIXLENAPPMODE
          - VRM_TAIMATCHINGMODE
          - VRM_N7PCCNOCHGANINFOSW
          - VRM_N5SESSIONBACKUP
          - VRM_PROFILEUPDATEBASERULEPRI
          - VRM_AFSELBINDCFG
          - VRM_ROUTEQUERYRETRYTIMES
          - VRM_ROUTEQUERYRETRYINTERVAL
          - VRM_NOTIFYBEFOREEXPIRE
          - VRM_N36INTERFACESW
          - VRM_N36SUBSCRIPTIONSW
          - VRM_PCFLIPSELECTMODE
          - VRM_PESSRVDISCTIMER
          - VRM_EXATTR1DEFAULTVALUE
          - VRM_HTTPCLIENTREDIRECTTIMES
          - VRM_N23SWITCH
          - VRM_DIAMGETAPPID
          - VRM_N23SESSIONBACKUP
          - VRM_GLBDATAIDMAPSWITCH
          - VRM_PEERNFDEFAULTPRIORITY
          - VRM_N23SESADTMSGSPEED
          - VRM_IPDOMAINSRCFORGX
          - VRM_N15VIRTUALSUBIDSWITCH
          - VRM_SESSIONCOMPRESSTYPE
          - VRM_UPDAMFSTA
          - VRM_N23TIMEOUT
          - VRM_MAXAMSAUNUMPERSPU
          - VRM_N24AMSWITCH
          - VRM_N24AMTIMEOUT
          - VRM_CALLRXFIRSTSW
          - VRM_BACKFILLSESRULE
          - VRM_N7NWDAFLINKDOWNSW
          - VRM_N7POLICYCHGN23SW
          - VRM_RSTSYQUOTASW
          - VRM_HTTPLOCFILLMODE
          - VRM_DRALINKSTAMPUPTMODE
          - VRM_TRACECACHECHKSW
          - VRM_N15AREACODESW
          - VRM_USELASTPLMNIFNOTMATCHED
          - VRM_AUTORESETSWITCH4FSM
          - VRM_N23HDPCFIDMODE
          - VRM_CALCREDPRIBYNAME
          - VRM_STATEXTERNALRESTORATION
          - VRM_BSFBINDINGUPDATESW
          - VRM_SBICALLBACKVALUE
          - VRM_NGPOLICYCASESENSITIVE
          - VRM_N15QRYCHARINGSYSMODE
          - VRM_AFUPDATEUMMODE
          - VRM_HSRCTRLSW
          - VRM_CALCMEDRULEPRIBYNAME
          - VRM_DATAVIRTUALSUBIDSWITCH
          - VRM_INTRANETSESSEFFMODE
          - VRM_N28PENDINGTIME2LOCAL
          - VRM_MIDNIGHTGLBREFRESHSWITCH
          - VRM_SCANFROZENUSER
          - VRM_N1NOTIFYTIMER
          - VRM_MAXNWDAFSESNUMPERSPU
          - VRM_PCEFPARAMATCHMODE
          - VRM_N5VIRTUALMEDIA
          - VRM_SYQTAINSTMODE
          - VRM_N7UPDATECAFCRXMODE
          - VRM_N7ACTN23POLICYMODE
          - VRM_N23BAKCOMPATIBILITYSW
          - VRM_N7MAXDYNRULENUM
          - VRM_N7FAILRCPROCMETHOD
          - VRM_DELAYSTATAUTOENABLEDSW
          - VRM_AUTHSRVENCODEMODE
          - VRM_SUBLOCNUM
          - VRM_HPCFDELIVERLOCCHSW
          - VRM_N15RMVSPCMCCFROMGPSI
          - VRM_MODULERSTPROTECTTIME
          - VRM_N15DYNMATCHMODE
          - VRM_NESTATUSREFRESHCYCLE
          - VRM_SYCCFROMN7SWITCH
          - VRM_MAXSESSRESTOREDELAYTIME
          - VRM_SESSIONNUMCOUNTMODE
          - VRM_UEINITRESOURCEBYSMFSWITCH
          - VRM_SATT2TVOICESW
          - VRM_ROLLBACKN7LINKDOWN
          - VRM_DEVAUDITAUTO
          - VRM_N24NFSETRESENTTIMES
          - VRM_UNKNOWNLOCPROC
          - VRM_N15SUBCTRL
          - VRM_UPMUSERREQTIMERLEN
          - VRM_SYSLRIDATIME
          - VRM_MAXNXSESNUMPERSPU
          - VRM_NXNASTIMEOUT
          - VRM_NXNASRETRYTIMES
          - VRM_NZTIMEOUT
          - VRM_NZRETRYTIMES
          - VRM_NXPENDINGRETRYTIMES
          - VRM_NXNWDAFDICMODE
          - VRM_NXNZSESSIONBACKUP
          - VRM_SLRURESENDTIMES
          - VRM_CHECKNTSLINKSTATUS
          - VRM_ABSVALPRDSRVAUTOSW
          - VRM_N23USETAIDISCMODE
          - VRM_SYTOGXRCMODE
          - VRM_VONRLICSTATMODE
          - VRM_PROFILEUPTTIMELEN
          - VRM_SYNASSOCDATAINTERVAL
          - VRM_N7NWDAFLINKDOWNCYCLE
          - VRM_N7NWDAFLINKDOWNMAXTIMES
          - VRM_RXIPV6PCEFGROUPID
          - VRM_DLBPRQTIMERLEN
          - VRM_CLIENTPORTVERIFY
          - VRM_RECHARGENOTIFIRESTRAIN
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '参数值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRLANGUAGE:
          name: 'USRLANGUAGE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSMSRECEIVEFLAG:
          name: 'USRSMSRECEIVEFLAG'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRVERSTATUS:
          name: 'USRVERSTATUS'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVCONTACTMETHOD:
          name: 'SRVCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVCREATESUBSCRIBER:
          name: 'SRVCREATESUBSCRIBER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PAYMENTFLAG:
          name: 'PAYMENTFLAG'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - mod_insp_list:
    - INSPN: RM_RATINGVOLRNDUNIT
      INSPV: 10
    add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: '12345678901'
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: MBB
      USRLANGUAGE: 'NULL'
      USRSMSRECEIVEFLAG: All
      USRVERSTATUS: Normal
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: 5G_Service_Rating
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
      SRVCONTACTMETHOD: None
      SRVCREATESUBSCRIBER: No
      PAYMENTFLAG: Yes
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 配置软参。

### 当某局点的计费系统的最小计费单位不是1字节时，需要通过修改该软参将流量转换为金额时的取整单位设置为该计费系统对应的最小计费单位。此软参详细含义请参考RM\_RATINGVOLRNDUNIT。

#### 1.1 登录“UPCF MML命令”界面。

#### 1.2 执行**MOD INSP**命令，配置参数RM\_RATINGVOLRNDUNIT，用于设置流量换算成金额时，将流量按多少字节取整。

#### 命令举例：

```jinja2
{%- for item in mod_insp_list -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    ;
{%- endfor -%}
```

### 2 登录UPCF Web UI界面。

### 3 配置PLMN。

### 导航入口为“位置管理 > 位置 > PLMN”。

### PLMN（Public Land Mobile Network）的数据规划如表2所示，详细参数说明请参见PLMN参数表。

### **表2** PLMN

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | PLMN1 | 基本信息 | PLMN标识 | PLMN\_1 |

### |  |  | 类型 | 本地 |

### |  |  | MCC | 460 |

### |  |  | MNC | 003 |

### | PLMN2 | 基本信息 | PLMN标识 | PLMN\_2 |

### |  |  | 类型 | 外地 |

### |  |  | MCC | 460 |

### |  |  | MNC | 002 |

### 4 配置账户。

### 导航入口为“业务管理 > 业务 > 账户”。

### 账户的数据规划如表3所示，详细参数说明请参见帐户参数表。

### **表3** 账户

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 账户 | 基本信息 | 名称 | 5G\_Account\_Rating |

### |  |  | 值 | 200 |

### |  |  | 分片(％) | 10 |

### |  | 复位设置 | 结帐模式 | 自然日历 |

### |  |  | 复位周期类型 | 月 |

### |  |  | 复位日 | 1 |

### |  |  | 复位时间 | 01:00:00 |

### |  |  | 剩余额处理方式 | 清零 |

### 5 增加费率。

### 导航入口为“策略管理 > 策略 > 费率”。

### 需要配置2个费率，用于账户的漫游状态为本地或漫游时流量与金额的转换。费率的数据规划如表4所示，详细参数说明请参见费率参数表。

### **表4** 费率

### | 类别 | 参数 | 取值样例 |

### | --- | --- | --- |

### | 费率1 | 名称 | 5G\_Rating1 |

### |  | 监控键值 | 200 |

### |  | 金额 | 1 |

### |  | 流量（KB） | 1024 |

### | 费率2 | 名称 | 5G\_Rating2 |

### |  | 监控键值 | 201 |

### |  | 金额 | 2 |

### |  | 流量（KB） | 1024 |

### 6 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 需要配置3个条件组，用于判断账户的漫游状态为本地且账户正常、漫游状态为漫游且账户正常或账户耗尽。条件组的数据规划如表5所示，详细参数说明请参见条件组参数表。

### **表5** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | 5G\_CG\_Rating1 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | 5G\_C\_Rating\_Native |

### |  |  | 对象属性 | * 对象：SmfSession * 属性：RoamingStatus |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Native  说明：  “Native”：表示本地。 |

### |  | 条件2 | 名称 | 5G\_C\_Rating\_Norm |

### |  |  | 对象属性 | * 对象：Account * 属性：AccountStatus |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Normal  说明：  “Normal”：表示账户金额未耗尽。 |

### | 条件组2 | 基本信息 | 名称 | 5G\_CG\_Rating2 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | 5G\_C\_Rating\_Roaming |

### |  |  | 对象属性 | * 对象：SmfSession * 属性：RoamingStatus |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Roaming  说明：  “Roaming”：表示外地漫游。 |

### |  | 条件2 | 名称 | 5G\_C\_Rating\_Norm2 |

### |  |  | 对象属性 | * 对象：Account * 属性：AccountStatus |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Normal  说明：  “Normal”：表示账户金额未耗尽。 |

### | 条件组3 | 基本信息 | 名称 | 5G\_CG\_Rating3 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | 5G\_C\_Rating\_Exhaust |

### |  |  | 对象属性 | * 对象：Account * 属性：AccountStatus |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示账户金额耗尽。 |

### 7 配置5G动作组。

### 导航入口为“策略管理 > 策略 > 5G动作组”.

### 若配置的规则为动态规则，则必须配置动作组。

### 此场景配置5G动作组需要考虑流信息、业务流开关、流量上报、带宽调整和重定向，则需配置动作：FlowInformation、TrafficControlData、UsageMonitoringData、QoSData和RedirectInformation。相关应用场景如下：

#### 7.1 FlowInformation：当需要下发流信息时需配置此动作。

#### 7.2 TrafficControlData：当需要做门限控制时，配置此动作。在下发流描述时，如果不配默认为放通该流，当需要限制流时，此动作必须配置。

#### 7.3 UsageMonitoringData：当需要进行流量上报时，配置此动作。UsageMonitoringData动作类型中的umId必须与费率的“监控键值”配置一致。

#### 7.4 QoSData：当需要进行带宽控制时，配置此动作。

#### 7.5 RedirectInformation：选择永久重定向，即每次访问都重定向到固定页面。若用户在此次会话过程中充值，则需删除此动作，否则仍将重定向。

### 需要配置3个“DynamicPccRule”类型的5G动作组，用于在账户的漫游状态为本地且账户正常、漫游状态为漫游且账户正常或账户耗尽时动作的下发。动作组的数据规划如表6所示，详细参数说明请参见5G动作参数表。

### **表6** 5G动作组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 5G动作组1 | 基本信息 | 名称 | 5G\_AG\_Rating\_FlowD |

### |  |  | 类型 | FlowDescription |

### |  | 属性 | action | * 类型：Value * 值：PERMIT |

### |  |  | direction | * 类型：Value * 值：BIDIRECTIONAL |

### |  |  | protocol | * 类型：Value * 值：ANY |

### |  |  | sourceIP | * 类型：Value * 值：any |

### |  |  | destinationIP | * 类型：Value * 值：any |

### | 5G动作组2 | 基本信息 | 名称 | 5G\_AG\_Rating\_FlowInfo |

### |  |  | 类型 | FlowInformation |

### |  | 属性 | flowDescription | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_FlowD  说明：  已在5G动作组中定义。 |

### |  |  | flowDirection | * 类型：Value * 值：BIDIRECTIONAL |

### | 5G动作组3 | 基本信息 | 名称 | 5G\_AG\_Rating\_arp |

### |  |  | 类型 | Arp |

### |  | 属性 | priorityLevel | * 类型：Object Attribute * 值：SmfSession.SubsDefQosPriorityLevel |

### |  |  | preemptCap | * 类型：Value * 值：NOT\_PREEMPT |

### |  |  | preemptVuln | * 类型：Value * 值：NOT\_PREEMPTABLE |

### | 5G动作组4 | 基本信息 | 名称 | 5G\_AG\_Rating\_QoSData |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：5G\_AG\_Rating\_QoSData |

### |  |  | 5qi | * 类型：Object Attribute * 值：SmfSession.SubsDefQos5qi |

### |  |  | arp | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_arp 说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：5 Mbps |

### |  |  | maxbrDl | * 类型：Value * 值：5 Mbps |

### | 5G动作组5 | 基本信息 | 名称 | 5G\_AG\_Rating\_UmData1 |

### |  |  | 类型 | UsageMonitoringData |

### |  | 属性 | umId | * 类型：Value * 值：200  说明：  需与对应的“费率1”中配置的“监控键值”取值相同。 |

### |  |  | volumeThreshold | * 类型：Value * 值：20480 |

### | 5G动作组6 | 基本信息 | 名称 | 5G\_AG\_Rating\_UmData2 |

### |  |  | 类型 | UsageMonitoringData |

### |  | 属性 | umId | * 类型：Value * 值：201  说明：  需与对应的“费率2”中配置的“监控键值”取值相同。 |

### |  |  | volumeThreshold | * 类型：Value * 值：20480 |

### | 5G动作组7 | 基本信息 | 名称 | 5G\_AG\_Rating\_redirectInfo |

### |  |  | 类型 | RedirectInformation |

### |  | 属性 | redirectEnabled | * 类型：Value * 值：True |

### |  |  | redirectAddressType | * 类型：Value * 值：URL |

### |  |  | redirectServerAddress | * 类型：Value * 值：http://www.example.com/ |

### | 5G动作组8 | 基本信息 | 名称 | 5G\_AG\_Rating\_TcData1 |

### |  |  | 类型 | TrafficControlData |

### |  | 属性 | tcId | * 类型：Value * 值：5G\_AG\_Rating\_TcData1 |

### |  |  | flowStatus | * 类型：Value * 值：ENABLED |

### | 5G动作组9 | 基本信息 | 名称 | 5G\_AG\_Rating\_TcData2 |

### |  |  | 类型 | TrafficControlData |

### |  | 属性 | tcId | * 类型：Value * 值：5G\_AG\_Rating\_TcData2 |

### |  |  | flowStatus | * 类型：Value * 值：ENABLED |

### |  |  | redirectInfo | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_redirectInfo 说明：  已在5G动作组中定义。 |

### | 5G动作组10 | 基本信息 | 名称 | 5G\_AG\_Rating\_PccRule1 |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：5G\_AG\_Rating\_PccRule1 |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_FlowInfo 说明：  已在5G动作组中定义。 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_QoSData 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_TcData1 说明：  已在5G动作组中定义。 |

### |  |  | refUmData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_UmData1 说明：  已在5G动作组中定义。 |

### | 5G动作组11 | 基本信息 | 名称 | 5G\_AG\_Rating\_PccRule2 |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：5G\_AG\_Rating\_PccRule2 |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_FlowInfo 说明：  已在5G动作组中定义。 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_QoSData 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_TcData1 说明：  已在5G动作组中定义。 |

### |  |  | refUmData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_UmData2 说明：  已在5G动作组中定义。 |

### | 5G动作组12 | 基本信息 | 名称 | 5G\_AG\_Rating\_PccRule3 |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：5G\_AG\_Rating\_PccRule3 |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_FlowInfo 说明：  已在5G动作组中定义。 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_QoSData 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：5G\_AG\_Rating\_TcData2 说明：  已在5G动作组中定义。 |

### 8 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 规则的数据规划如表7所示，详细参数说明请参见规则参数表。

### **表7** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | 5G\_Rule\_Rating1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  |  | 费率 | 5G\_Rating1  说明：  已在费率中定义。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | 5G\_CG\_Rating1  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | 5G\_AG\_Rating\_PccRule1  说明：  已在5G动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | 5G\_Rule\_Rating2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  |  | 费率 | 5G\_Rating2  说明：  已在费率中定义。 |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | 5G\_CG\_Rating2  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | 5G\_AG\_Rating\_PccRule2  说明：  已在5G动作组中定义。 |

### | 规则3 | 基本信息 | 名称 | 5G\_Rule\_Rating3 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | 5G\_CG\_Rating3  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | 5G\_AG\_Rating\_PccRule3  说明：  已在5G动作组中定义。 |

### 9 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表8所示，详细参数说明请参见策略参数表。

### **表8** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略 | 基本信息 | 名称 | 5G\_Policy\_Rating |

### |  |  | 策略类型 | N7 Policy |

### |  | 触发器 | 名称 | * IPCAN\_EST * PLMN\_CH * US\_RE * AccountStatusChange |

### |  | 规则 | 名称 | * 5G\_Rule\_Rating1 * 5G\_Rule\_Rating2 * 5G\_Rule\_Rating3 说明：  已在规则中定义。 |

### 10 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

### 业务的数据规划如表9所示，详细参数说明请参见业务参数表。

### **表9** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | 5G\_Service\_Rating |

### |  |  | 类型 | VALUE\_ADDED\_SERVICE |

### |  |  | 账户 | 5G\_Account\_Rating  说明：  已在账户中配置。 |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | 5G\_Policy\_Rating  说明：  已在策略中定义。 |

### 11 登录“UPCF 业务管理”窗口。

### 12 发放业务。

#### 12.1 执行**ADD PSUB**增加一个用户。

#### “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=12.1 -->
```

#### 12.2 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=12.2 -->
```

