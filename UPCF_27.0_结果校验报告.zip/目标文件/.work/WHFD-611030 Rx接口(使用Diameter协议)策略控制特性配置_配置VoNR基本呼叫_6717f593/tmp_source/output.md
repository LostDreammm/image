---
id: ''
name: 配置VoNR基本呼叫
ne_type: UPCF
type: feature
description: UPCF支持VoNR方案，用于部署IMS应用，为基本呼叫业务提供保障的带宽，确保用户享用优质语音和高清视频。当5G用户接入IMS网络发起基本呼叫时，AF（即IMS域的P-CSCF）通过Rx接口向UPCF发起资源预留请求，将会话相关的属性，如应用标识、媒体类型、媒体流状态、媒体流描述等上报给UPCF，UPCF根据AF上报的信息和本地配置的业务策略进行策略判断，将生成的QoS规则通过N7接口下发给SMF执行策略控制。
risk_level: ''
doc_source: ["特性","特性部署","UPCF基础特性","WHFD-611030 Rx接口(使用Diameter协议)策略控制","WHFD-611030 Rx接口(使用Diameter协议)策略控制特性配置","配置VoNR基本呼叫"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UPCF支持VoNR方案，用于部署IMS应用，为基本呼叫业务提供保障的带宽，确保用户享用优质语音和高清视频。当5G用户接入IMS网络发起基本呼叫时，AF（即IMS域的P-CSCF）通过Rx接口向UPCF发起资源预留请求，将会话相关的属性，如应用标识、媒体类型、媒体流状态、媒体流描述等上报给UPCF，UPCF根据AF上报的信息和本地配置的业务策略进行策略判断，将生成的QoS规则通过N7接口下发给SMF执行策略控制。

## 必备事项
前提条件

* 操作员已了解WHFD-606007 Rx接口(使用Diameter协议)VoNR策略控制特性概述。
* 操作员已了解“VoNR业务和特性描述”。
* 已完成配置UPCF与AF（基于Diameter协议）的对接数据。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_apn_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        APNID:
          name: 'APN标识'
          type: integer
          minimum: 0
          maximum: 319
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        APNNAME:
          name: 'APN名称'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        APNTYPE:
          name: 'APN类型'
          type: string
          enum:
          - Revalidation-APN
          - Multi-PCEF-APN
          - Emergency-APN
          - VoLTE-APN
          - Force-Sy-APN
          - Statistics-APN
          - Ignore-SPR-APN
          - Realm-Replace-APN
          - Bypass-IP-APN
          - FWA-CPE-APN
          - FWA-HG-APN
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: Revalidation-APN
        APNMATCHTYPE:
          name: 'APN匹配类型'
          type: string
          enum:
          - FullMatching
          - LongestPrefixMatching
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: FullMatching
        IFTYPE:
          name: '接口类型'
          type: string
          enum:
          - Gx
          - N7
          - GxN7
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SPECDN:
          name: '指定本地域名'
          type: string
          minLength: 0
          maxLength: 64
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_insp_list:
      type: items
      properties:
        INSPN:
          name: '参数名'
          type: string
          enum:
          - VRM_MAXIPCANSESNUMPERSPU
          - VRM_MAXAFSESNUMPERSPU
          - VRM_MAXSUBNUMPERSPU
          - VRM_UPGRADE
          - VRM_MAXRATBEARIDPERSES
          - VRM_SRVNUMPERUSR
          - VRM_MAXPAFNUM
          - VRM_MAXPCEFNUM
          - VRM_MAXRADIUSSRVNUM
          - VRM_MAXCONNECTIONPERPAF
          - VRM_MAXCONNECTIONPERPCEF
          - VRM_MAXLINKRADIUSSRV
          - VRM_SUBSRCIPTIONIDTYPE
          - VRM_GLBREFLASHINTERVAL
          - VRM_NOTIFYMSGMAXRECORDPERSUB
          - VRM_NOTIFYMSGMAXDAYPERSUB
          - VRM_REVALIDATIONTIMEMETHOD
          - VRM_NOSUBSCRIPTIONERRORCODE
          - VRM_NOTIFYMSGMAXWAITEDRECORDS
          - VRM_PRINTLOCALLOG
          - VRM_USRREVALIHRANGE
          - VRM_ONLINECHECK
          - VRM_TIMEZONEENHANCE
          - VRM_GXIMEIFORMAT
          - VRM_NOTIFYMSGMAXRECORDPERDSU
          - VRM_CLEARALLDYNCREATEDUSER
          - VRM_PEELDOMAINSWITCH
          - VRM_NOTIFYRCVER
          - VRM_FIRSTDAYOFWEEK
          - VRM_UPDATESPRSUBACTIVE
          - VRM_SUBCTRLRESULT
          - VRM_SPRSUBMAXOFFLINEDAYS
          - VRM_CHECKSUBSCRIBEDSERVICE
          - VRM_SUBACTCTRL
          - VRM_SESSIONCHECKINTERVAL
          - VRM_CHKSUBSRVSYTYPE
          - VRM_RARSENDSPEED
          - VRM_DIAREDIRECTSWITCH
          - VRM_PERIODVALUE
          - VRM_PROTECTTIMER
          - VRM_SENDUSERNUM
          - VRM_POLICYCASESENSITIVE
          - VRM_SESSIONRESTORATION
          - VRM_RXRPMAPRELATION
          - VRM_NOTIFYUSAGEUNITCONVERT
          - VRM_TIMEACCUMODE
          - VRM_SYSWITCH
          - VRM_PLMNMATCHPRIORITY
          - VRM_RESETNOTIFYRPT
          - VRM_REPORTINGLEVEL
          - VRM_RATINGGROUP
          - VRM_SERVICEIDENTIFIER
          - VRM_DFTCHARGINGPARA
          - VRM_LOGPRINTPERIOD
          - VRM_MAXBBERFNUM
          - VRM_MAXCONNECTIONPERBBERF
          - VRM_SPNOTIFYDOMAIN
          - VRM_EXSPRNOTIFICATION
          - VRM_SESSIONBACKUPSWITCH
          - VRM_DIAMHBINTERVAL
          - VRM_DIAMHBTIMES
          - VRM_EDRACCESSFORMATE
          - VRM_IPCANTERMSWITCH
          - VRM_DELBEAROPTION
          - VRM_LDAPREVBUFFERSIZE
          - VRM_NOTIFYOPTIMIZE
          - VRM_RESULTCODESWITCH
          - VRM_FMTIPADDR
          - VRM_GROUPDIAREDIRECTSWITCH
          - VRM_RMVSUBWITHOUTRAR
          - VRM_GRPMBRUSAGECACHE1
          - VRM_GRPMBRUSAGECACHE2
          - VRM_DYNRULEFORMAT
          - VRM_IPV6HASHLENGTH
          - VRM_DURATIONMKMATCH
          - VRM_SNRRECSPEED
          - VRM_DIAMTIMETHRD
          - VRM_LDAPTIMETHRD
          - VRM_RELGXBYRAATIMEOUT
          - VRM_SETHOMESRVZONE
          - VRM_MAXTDFNUM
          - VRM_TDFCCRUSPD
          - VRM_TDFCCRTSPD
          - VRM_PROCHEARTBEATTIMEOUT
          - VRM_MAXAUXILIARYAREA
          - VRM_AADIAREDIRECTSWITCH
          - VRM_DIAMFAILOVERSWITCH
          - VRM_DYNSMSMSISDN
          - VRM_SUBGRPCREATESUB
          - VRM_QUOTACROSSSERVICE
          - VRM_SYSUBIDTYPE
          - VRM_DEACTIVESERVICETIMER
          - VRM_QUOTALOGSWITCH
          - VRM_SIMPLEPOLICYSTATISTIC
          - VRM_GXTRIGGERCMP
          - VRM_QOSNEGOTIATIONSWITCH
          - VRM_IPFLOWANYCVT
          - VRM_SUBLISTNORULE
          - VRM_NTFOVERDUEMODE
          - VRM_DESTPEERMODE
          - VRM_SYNDATASWITCH
          - VRM_SYNDATAINTERVAL
          - VRM_TAIECGIMATCHMODE
          - VRM_SYCARRYSUBID
          - VRM_SYRESENDTIMES
          - VRM_DYNQUOTATIMEZONE
          - VRM_FIRSTGXSESSIONATTR
          - VRM_SESSIONIDHASHMODE
          - VRM_PEERFCDURATION
          - VRM_AFPOLICYRECALCULATE
          - VRM_SGWRESTORETIME
          - VRM_QUOTAUSEPRIORITY
          - VRM_SESSIONIDSWITCH
          - VRM_REPORTUSAGE
          - VRM_IMEIQUERYSERVICE
          - VRM_MCITRIGGERUDR
          - VRM_RXMAXUL
          - VRM_RXMAXDL
          - VRM_SYSESSIONCONTROLATTRIBUTE
          - VRM_SYSESSIONCONTROLVALUE
          - VRM_AUTORECUSRLOC
          - VRM_LINKDSPMODE
          - VRM_RXSTAINCAUTHAPPID
          - VRM_MAXAREANUM
          - VRM_GXSESSIONONLYVOLTE
          - VRM_LDAPDBTIMEOUT
          - VRM_OFFSETTIME
          - VRM_APNSENSITIVE
          - VRM_DYNGROUPNUMBERPERUSER
          - VRM_SYSESSIONBACKUP
          - VRM_NOTIFYATTRRESTRICTION
          - VRM_UNKNOWNRULEPROC
          - VRM_FORCEUPGRADEQOS
          - VRM_RMVGRPMEMBERACT
          - VRM_SYNUSRDATASPEED
          - VRM_SYCHARGINGCHARSWITCH
          - VRM_LICDSPMODE
          - VRM_GRPMBRPARENTSTATUSFLAG
          - VRM_TERMSESSNOTIFICATIONFLAG
          - VRM_DCIPRIORITY
          - VRM_SERVICEINFOSTATUSMODE
          - VRM_RXARPMAPPINGMODE
          - VRM_NOTIFYATTRENUMVALUEMODE
          - VRM_GLBSESDATAREFRESH
          - VRM_MAXPOCSCPNUM
          - VRM_SPUAUTOSWITCHOVER
          - VRM_PRAIDCODECMODE
          - VRM_DFTROAMINGSTATUS
          - VRM_MCIPROCMODE
          - VRM_VMSTORAGEFAULTRMSWITCH
          - VRM_PREBINDFORSESSIONBACKUP
          - VRM_SHARESYQUOTAMODE
          - VRM_MEMCHECKALARMSWITCH
          - VRM_QUOTASTATUSSTATISTIC
          - VRM_SUBIDCHOOSESWITCH
          - VRM_MCCMNCROAMREGION
          - VRM_TERMFIRSTSESSIONSWITCH
          - VRM_RECORDMEMSWITCH
          - VRM_Q922ERRMSGSWITCH
          - VRM_MEMFREERECORDSTKSWITCH
          - VRM_MEMFREERECORDSTKPOLICY
          - VRM_MSGFREERECORDSTKSWITCH
          - VRM_MSGFREERECORDSTKPOLICY
          - VRM_MEMALLOCFAILEDHOOKSWITCH
          - VRM_LOADINGALLAREADATA
          - VRM_MAXMSGTEMPLATENUM
          - VRM_PCEFHOSTTOGROUP
          - VRM_LINKBASEAPN
          - VRM_CBOVERRUNALMTH
          - VRM_CBRECOVERYALMTH
          - VRM_VOLTESESSINDEPENDENT
          - VRM_MEWORKROLE
          - VRM_RESETFORALLOCMEMFAILED
          - VRM_RESETFORALLOCMSGFAILED
          - VRM_ENABLEVOLTEAPNGXFLOWCTRL
          - VRM_CBWATCHTIME
          - VRM_DIAMMSGRELAYSWITCH
          - VRM_SYNTIMER
          - VRM_DEVAUDITACCELERATION
          - VRM_PENDINGTRANSACTIONNUM
          - VRM_VOLTEQRYSPR
          - VRM_TRIGGERRESTRICTTYPE
          - BLC_UPMUSERREQ
          - BLC_BEARUPDATE
          - BLC_WAITBEARTERM
          - BLC_ZONETYPE
          - BLC_SECPDPQOSCONTROL
          - RM_RATINGVOLRNDUNIT
          - RM_USGVOLRNDUNIT
          - RM_USGVOLRNDTHRESH
          - RM_RUSGVOLRNDUNIT
          - RM_RUSGVOLRNDTHRESH
          - RM_PLMNANDSGSNALM
          - RM_ALMCLRPERIOD
          - BLC_NOTIFYSENDINTERVAL
          - VRM_OCSCHARGEFLAGFORPRE
          - VRM_OCSCHARGEFLAGFORPOS
          - VRM_OCSCHARGEFLAGFOROTHER
          - BLC_DELSSINVALIDINTERVAL
          - BLC_DELSSINTERVAL
          - BLC_DELSSNUM
          - VRM_CHECKAPNIP
          - VRM_QCIUPGRADE
          - VRM_UNDERCONTROLTHRESHOLD
          - VRM_NORMALVALUE
          - UPM_SUBCTRL
          - UPM_ACCRARTIMEOUT
          - UPM_TIMERPLYCNTREQ
          - VRM_KPIMONITORINGSWITCH
          - VRM_TDFPOLICYMODE
          - VRM_RXBEARWITH5002
          - LIC_PREALMTH
          - VRM_QRYSPRPRIORITY
          - VRM_SDUROUTECONFILICTRAR
          - VRM_DBTIMERVALIDPERIOD
          - VRM_FORCERECOVERYSESSION
          - ALC_WAITAFTERM
          - VRM_RARWITHTRIGGER
          - VRM_RELEASERXTRIGGER
          - VRM_MAXIPCANNUMPERUSR
          - VRM_RETENTION_NOTIFYLOG
          - VRM_RETENTION_MNTLOG
          - VRM_RETENTION_EXPORT
          - VRM_MAXSESSBACKUPNUMPERSUB
          - VRM_SAVESYORGSTATUS
          - VRM_SNRSUPPORTSUBID
          - VRM_AUDITFAILEDCODE
          - VRM_ADJUSTSERVICEMODE
          - VRM_SYORIGINSTATEID
          - VRM_NOTRARWITHSAMEINSTALLRULE
          - VRM_CALCPRIBYSRVNAME
          - VRM_PENDINGTIME2LOCALTIME
          - VRM_MAXPCEFRADIUSNUM
          - VRM_RTPDRNOFLOW
          - VRM_SYDRASLRITIMEOUTSTRCTRL
          - VRM_GXREDIRECTACTION
          - VRM_GXRULEDEDUP
          - VRM_MCITOPGWSPEED
          - VRM_NRIPV6HASHLENGTH
          - VRM_SDCHARGINGCHARSWITCH
          - VRM_OFFLINESRVSWITCH
          - VRM_OFFLINEREDOLOG
          - VRM_VOLTESESSIONNOTUPDATE
          - VRM_BSFONLYVOLTE
          - VRM_BSFRESENDTIMES
          - VRM_BSFTIMEOUT
          - VRM_CHRGIDFMT
          - VRM_LONGTERMNTYRECORDPERSUB
          - VRM_GXQRYCHARINGSYSMODE
          - VRM_RECREATERULENOTIFICATION
          - VRM_PACKETFILTER
          - VRM_SNRWITHOUTHOSTMODE
          - VRM_SYCOUNTERTRANSMODE
          - VRM_MAXCONDITIONNUM
          - VRM_MAXQUOTANUM
          - VRM_RMVSYSRVBYRESULTCODE
          - VRM_VIRTUALSUBIDSWITCH
          - VRM_VOLTEPDPQRYSY
          - VRM_PACKETERRRATETYPE
          - VRM_IPDOMAINSENSITIVE
          - VRM_NRCOMBINEPRIORITYMODE
          - VRM_N15COMPATIBILITYSWITCH
          - VRM_HASHAUDITSWITCH
          - VRM_RECUSRLOCBASERAT
          - VRM_MULTIPCEFQRYDB
          - VRM_DEVAUDITSTARTTIME
          - VRM_MCIDELOLDSES
          - VRM_MCIDELOLDSESSPEED
          - VRM_CHECKSUBSRV
          - VRM_MASTERSLAVENOTIFYENHANCE
          - VRM_NEPEERSTATUS
          - VRM_NONOVERLOADERRORCODESW
          - VRM_AMFRESELECTSWITCH
          - VRM_REDIRECTSWITCH
          - VRM_POLICYASSOCIATESWITCH
          - VRM_DIAMDIRECTPATH
          - VRM_SMFALMWITHIPPORT
          - VRM_REGWITHINSTANCENAME
          - VRM_VIRTUALQUOTAREPORTUSAGE
          - VRM_SPONSORDYNRULEFORMAT
          - VRM_SRVTOKENNUM
          - VRM_UPDSMFSTA
          - VRM_N7CHGNORULESWITCH
          - VRM_QUOTAOBJNOTEXISTCALCMODE
          - VRM_SDRRELIABTRANSSWITCH
          - VRM_CALCULBYNR
          - VRM_GXSESSIONCHARGE
          - VRM_RARSPEEDDOWNCPU
          - VRM_RARSPEEDUPCPU
          - VRM_SUBSCRIBERGROUPMATCHMODE
          - VRM_SCANSTARTTIME
          - VRM_DISTRIQUERYMAXRECORD
          - VRM_GLBPARTITIONLOADINGSWITCH
          - VRM_COMPARECCRIUQOS
          - VRM_AUTORECUSRLOCEX
          - VRM_AVGCHILDPERPARENT
          - VRM_AVGPARENTPERCHILD
          - VRM_SELECTNTSMETHOD
          - VRM_QUOTADEDUCTMODE
          - VRM_MAXBEARNUMPERIPCAN
          - VRM_SDSESSIONBACKUP
          - VRM_SERVICEZONEAREAMATCHTYPE
          - VRM_USRLOCATION_VALUE
          - VRM_RULESUFFIXLENAPPMODE
          - VRM_TAIMATCHINGMODE
          - VRM_N7PCCNOCHGANINFOSW
          - VRM_N5SESSIONBACKUP
          - VRM_PROFILEUPDATEBASERULEPRI
          - VRM_AFSELBINDCFG
          - VRM_ROUTEQUERYRETRYTIMES
          - VRM_ROUTEQUERYRETRYINTERVAL
          - VRM_NOTIFYBEFOREEXPIRE
          - VRM_N36INTERFACESW
          - VRM_N36SUBSCRIPTIONSW
          - VRM_PCFLIPSELECTMODE
          - VRM_PESSRVDISCTIMER
          - VRM_EXATTR1DEFAULTVALUE
          - VRM_HTTPCLIENTREDIRECTTIMES
          - VRM_N23SWITCH
          - VRM_DIAMGETAPPID
          - VRM_N23SESSIONBACKUP
          - VRM_GLBDATAIDMAPSWITCH
          - VRM_PEERNFDEFAULTPRIORITY
          - VRM_N23SESADTMSGSPEED
          - VRM_IPDOMAINSRCFORGX
          - VRM_N15VIRTUALSUBIDSWITCH
          - VRM_SESSIONCOMPRESSTYPE
          - VRM_UPDAMFSTA
          - VRM_N23TIMEOUT
          - VRM_MAXAMSAUNUMPERSPU
          - VRM_N24AMSWITCH
          - VRM_N24AMTIMEOUT
          - VRM_CALLRXFIRSTSW
          - VRM_BACKFILLSESRULE
          - VRM_N7NWDAFLINKDOWNSW
          - VRM_N7POLICYCHGN23SW
          - VRM_RSTSYQUOTASW
          - VRM_HTTPLOCFILLMODE
          - VRM_DRALINKSTAMPUPTMODE
          - VRM_TRACECACHECHKSW
          - VRM_N15AREACODESW
          - VRM_USELASTPLMNIFNOTMATCHED
          - VRM_AUTORESETSWITCH4FSM
          - VRM_N23HDPCFIDMODE
          - VRM_CALCREDPRIBYNAME
          - VRM_STATEXTERNALRESTORATION
          - VRM_BSFBINDINGUPDATESW
          - VRM_SBICALLBACKVALUE
          - VRM_NGPOLICYCASESENSITIVE
          - VRM_N15QRYCHARINGSYSMODE
          - VRM_AFUPDATEUMMODE
          - VRM_HSRCTRLSW
          - VRM_CALCMEDRULEPRIBYNAME
          - VRM_DATAVIRTUALSUBIDSWITCH
          - VRM_INTRANETSESSEFFMODE
          - VRM_N28PENDINGTIME2LOCAL
          - VRM_MIDNIGHTGLBREFRESHSWITCH
          - VRM_SCANFROZENUSER
          - VRM_N1NOTIFYTIMER
          - VRM_MAXNWDAFSESNUMPERSPU
          - VRM_PCEFPARAMATCHMODE
          - VRM_N5VIRTUALMEDIA
          - VRM_SYQTAINSTMODE
          - VRM_N7UPDATECAFCRXMODE
          - VRM_N7ACTN23POLICYMODE
          - VRM_N23BAKCOMPATIBILITYSW
          - VRM_N7MAXDYNRULENUM
          - VRM_N7FAILRCPROCMETHOD
          - VRM_DELAYSTATAUTOENABLEDSW
          - VRM_AUTHSRVENCODEMODE
          - VRM_SUBLOCNUM
          - VRM_HPCFDELIVERLOCCHSW
          - VRM_N15RMVSPCMCCFROMGPSI
          - VRM_MODULERSTPROTECTTIME
          - VRM_N15DYNMATCHMODE
          - VRM_NESTATUSREFRESHCYCLE
          - VRM_SYCCFROMN7SWITCH
          - VRM_MAXSESSRESTOREDELAYTIME
          - VRM_SESSIONNUMCOUNTMODE
          - VRM_UEINITRESOURCEBYSMFSWITCH
          - VRM_SATT2TVOICESW
          - VRM_ROLLBACKN7LINKDOWN
          - VRM_DEVAUDITAUTO
          - VRM_N24NFSETRESENTTIMES
          - VRM_UNKNOWNLOCPROC
          - VRM_N15SUBCTRL
          - VRM_UPMUSERREQTIMERLEN
          - VRM_SYSLRIDATIME
          - VRM_MAXNXSESNUMPERSPU
          - VRM_NXNASTIMEOUT
          - VRM_NXNASRETRYTIMES
          - VRM_NZTIMEOUT
          - VRM_NZRETRYTIMES
          - VRM_NXPENDINGRETRYTIMES
          - VRM_NXNWDAFDICMODE
          - VRM_NXNZSESSIONBACKUP
          - VRM_SLRURESENDTIMES
          - VRM_CHECKNTSLINKSTATUS
          - VRM_ABSVALPRDSRVAUTOSW
          - VRM_N23USETAIDISCMODE
          - VRM_SYTOGXRCMODE
          - VRM_VONRLICSTATMODE
          - VRM_PROFILEUPTTIMELEN
          - VRM_SYNASSOCDATAINTERVAL
          - VRM_N7NWDAFLINKDOWNCYCLE
          - VRM_N7NWDAFLINKDOWNMAXTIMES
          - VRM_RXIPV6PCEFGROUPID
          - VRM_DLBPRQTIMERLEN
          - VRM_CLIENTPORTVERIFY
          - VRM_RECHARGENOTIFIRESTRAIN
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        INSPV:
          name: '参数值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_apn_list:
    - PCRFID: 1
      APNID: 1
      APNNAME: 'ims'
      APNTYPE: VoLTE-APN
      APNMATCHTYPE: FullMatching
      IFTYPE: ''
      SPECDN: ''
    mod_insp_list:
    - INSPN: VRM_SERVICEINFOSTATUSMODE
      INSPV: 2
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录“UPCF MML命令”界面。

#### 1.1 执行ADD APN命令，添加“VoLTE-APN”类型的APN。

#### 该命令用来防止数据业务的规则下发给IMS。命令举例如下：

```jinja2
{%- for item in add_apn_list -%}
    ADD APN:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    APNID={{item.APNID}},
    APNNAME="{{item.APNNAME}}",
    {#- --- 可选参数 --- -#}
    {%- if item.APNTYPE is not none -%}
        APNTYPE={{item.APNTYPE}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：APNTYPE=Revalidation-APN 时必选 --- -#}
    {%- if item.APNTYPE == 'Revalidation-APN' -%}
        IFTYPE={{item.IFTYPE}},
    {%- endif -%}
    {#- --- 条件必选：APNTYPE=Realm-Replace-APN 时必选 --- -#}
    {%- if item.APNTYPE == 'Realm-Replace-APN' -%}
        SPECDN="{{item.SPECDN}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：APNTYPE=Emergency-APN/VoLTE-APN/Revalidation-APN/Force-Sy-APN/Ignore-SPR-APN/Realm-Replace-APN 时可选 --- -#}
    {%- if item.APNTYPE in ['Emergency-APN', 'VoLTE-APN', 'Revalidation-APN', 'Force-Sy-APN', 'Ignore-SPR-APN', 'Realm-Replace-APN'] -%}
        {%- if item.APNMATCHTYPE is not none -%}
            APNMATCHTYPE={{item.APNMATCHTYPE}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 1.2 执行**MOD INSP**命令，修改软参VRM\_SERVICEINFOSTATUSMODE的取值。

```jinja2
{%- for item in mod_insp_list -%}
    MOD INSP:
    {#- --- 必选参数 --- -#}
    INSPN={{item.INSPN}},
    INSPV={{item.INSPV}},
    ;
{%- endfor -%}
```

#### 早期预留场景下，需要根据实际场景配置软参“VRM\_SERVICEINFOSTATUSMODE”的值，该场景软参配置为“2”。

### 2 登录UPCF Web UI界面。

### 3 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 需要配置4个条件组，用于分别判断用户语音呼叫、视频呼叫或媒体流的使用方式是否为RTCP。条件组的数据规划如表2所示，详细参数说明请参见条件组参数表。

### **表2** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | CG\_Audio\_VoNR |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_Audio\_VoNR |

### |  |  | 对象属性 | * 对象：ApplicationSession * 属性：MediaType |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Audio  说明：  表示媒体类型为语音呼叫。 |

### | 条件组2 | 基本信息 | 名称 | CG\_Video\_VoNR |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_Video\_VoNR |

### |  |  | 对象属性 | * 对象：ApplicationSession * 属性：MediaType |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Video  说明：  表示媒体类型为视频呼叫。 |

### | 条件组3 | 基本信息 | 名称 | CG\_FlowUsage\_NoEq\_RTC |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | cond\_FlowUsage\_NoEq\_RTCP |

### |  |  | 对象属性 | * 对象：ApplicationSession * 属性：FlowUsage |

### |  |  | 操作符 | Not Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | RTCP |

### | 条件组4 | 基本信息 | 名称 | CG\_FlowUsage\_Eq\_RTCP |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | cond\_FlowUsage\_Eq\_RTCP |

### |  |  | 对象属性 | * 对象：ApplicationSession * 属性：FlowUsage |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | RTCP |

### 4 配置5G动作组。

### 导航入口为“策略管理 > 策略 > 5G动作组”。

### 此场景需配置5G动作：Ambr、Arp、DefaultQosInformation、SessionRuleAction、BasicInfoAction、FlowDescription、FlowInformation、QoSData、TrafficControlData、DynamicPccRule和DynamicPccRuleIMS，相关应用场景如下：

### Ambr：用于设置会话类型的上下行带宽。

### Arp：当需要配置“类型”为“QoSData”和“DefaultQosInformation”的动作组时必须配置此动作。

### DefaultQosInformation：用于设置会话类型的QoS信息。

### SessionRuleAction：需要配置会话类型规则，需要配置此动作。

### BasicInfoAction：用于设置QoS流的方式为IMS信令。

### FlowDescription：当需要下发流方向时需配置此动作。

### FlowInformation：当需要下发流信息时需配置此动作。

### QoSData：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制Qos。

### TrafficControlData：当需要做门限控制时，配置此动作。在下发流描述时，如果不配默认为放通该流，当需要限制流时，此动作必须配置。此场景根据AF请求的Flow-Status，下发门限策略。

### DynamicPccRule：需要配置动态类的业务规则，需要配置此动作。

### DynamicPccRuleIMS：VoNR场景需要配置此动作。

### 请增加如下5G动作组和动作：

### 动作组AG\_N7\_ambr：动作类型为Ambr

### 动作组AG\_VoNR\_ARP：动作类型为Arp

### 动作组AG\_N7\_def：动作类型为DefaultQosInformation

### 动作组AG\_N7\_sessRule：动作类型为SessionRuleAction

### 动作组AG\_BasicRule：动作类型为BasicInfoAction

### 动作组AG\_N7\_FlowD：动作类型为FlowDescription

### 动作组AG\_N7\_Finfo：动作类型为FlowInformation

### 动作组AG\_N7\_QoSData、AG\_VoNR\_QoSData1、AG\_VoNR\_QoSData2和AG\_PreReserved\_QoSData：动作类型为QoSData

### 动作组AG\_N7\_TrafficCtrl和AG\_VoNR\_TrafficControlData：动作类型为TrafficControlData

### 动作组AG\_N7\_pccRule和AG\_PreReserved\_IMS：动作类型为DynamicPccRule

### 动作组AG\_VoNR\_DynamicPccRuleIMS1、AG\_VoNR\_DynamicPccRuleIMS1\_B、AG\_VoNR\_DynamicPccRuleIMS2、AG\_VoNR\_DynamicPccRuleIMS2\_B：动作类型为DynamicPccRuleIMS

### 5G动作组的数据规划如表3所示，详细参数说明请参见5G动作组参数表。

### **表3** 5G动作组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 5G动作组1 | 基本信息 | 名称 | AG\_N7\_ambr |

### |  |  | 类型 | Ambr |

### |  | 属性 | uplink | 2 Gbps |

### |  |  | downlink | 2 Gbps |

### | 5G动作组2 | 基本信息 | 名称 | AG\_VoNR\_ARP |

### |  |  | 类型 | Arp |

### |  | 属性 | priorityLevel | * 类型：Value * 值：2 |

### |  |  | preemptCap | * 类型：Value * 值：NOT\_PREEMPT |

### |  |  | preemptVuln | * 类型：Value * 值：NOT\_PREEMPTABLE |

### | 5G动作组3 | 基本信息 | 名称 | AG\_N7\_def |

### |  |  | 类型 | DefaultQosInformation |

### |  | 属性 | 5qi | * 类型：Value * 值：5 |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP  说明：  已在5G动作组中定义。 |

### | 5G动作组4 | 基本信息 | 名称 | AG\_N7\_sessRule |

### |  |  | 类型 | SessionRuleAction |

### |  | 属性 | sessRuleId | * 类型：Value * 值：123 |

### |  |  | authSessAmbr | * 类型：Reference ActionGroup * 值：AG\_N7\_ambr  说明：  已在5G动作组中定义。 |

### |  |  | authDefQos | * 类型：Reference ActionGroup * 值：AG\_N7\_def  说明：  已在5G动作组中定义。 |

### | 5G动作组5 | 基本信息 | 名称 | AG\_N7\_FlowD |

### |  |  | 类型 | FlowDescription |

### |  | 属性 | action | * 类型：Value * 值：PERMIT |

### |  |  | direction | * 类型：Value * 值：OUT |

### |  |  | protocol | * 类型：Value * 值：ANY |

### |  |  | sourceIP | * 类型：Value * 值：any |

### |  |  | destinationIP | * 类型：Value * 值：any |

### | 5G动作组6 | 基本信息 | 名称 | AG\_N7\_Finfo |

### |  |  | 类型 | FlowInformation |

### |  | 属性 | flowDescription | * 类型：Reference ActionGroup * 值：AG\_N7\_FlowD  说明：  已在5G动作组中定义。 |

### |  |  | flowDirection | * 类型：Value * 值：BIDIRECTIONAL |

### | 5G动作组7 | 基本信息 | 名称 | AG\_N7\_TrafficCtrl |

### |  |  | 类型 | TrafficControlData |

### |  | 属性 | tcId | * 类型：Value * 值：100 |

### |  |  | flowStatus | * 类型：Value * 值：ENABLED |

### | 5G动作组8 | 基本信息 | 名称 | AG\_N7\_QoSData |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：200 |

### |  |  | 5qi | * 类型：Value * 值：5 |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP 说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：2 Gbps |

### |  |  | maxbrDl | * 类型：Value * 值：2 Gbps |

### | 5G动作组9 | 基本信息 | 名称 | AG\_N7\_pccRule |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：pccRuleId\_Norm |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG\_N7\_Finfo 说明：  已在5G动作组中定义。 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_N7\_QoSData 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_N7\_TrafficCtrl 说明：  已在5G动作组中定义。 |

### | 5G动作组10 | 基本信息 | 名称 | AG\_BasicRule |

### |  |  | 类型 | BasicInfoAction |

### |  | 属性 | qosFlowUsage | * 类型：Value * 值：IMS\_SIG |

### | 5G动作组11 | 基本信息 | 名称 | AG\_VoNR\_QoSData1 |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：201 |

### |  |  | 5qi | * 类型：Value * 值：1 |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP 说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：2 Gbps |

### |  |  | maxbrDl | * 类型：Value * 值：2 Gbps |

### |  |  | gbrUl | * 类型：Value * 值：2 Gbps |

### |  |  | gbrDl | * 类型：Value * 值：2 Gbps |

### | 5G动作组12 | 基本信息 | 名称 | AG\_VoNR\_TrafficControlData |

### |  |  | 类型 | TrafficControlData |

### |  | 属性 | tcId | * 类型：Value * 值：A\_TCD\_01 |

### |  |  | flowStatus | * 类型：Value * 值：ENABLED |

### | 5G动作组13 | 基本信息 | 名称 | AG\_VoNR\_DynamicPccRuleIMS1 |

### |  |  | 类型 | DynamicPccRuleIMS |

### |  | 属性 | pccRuleId | * 类型：Value * 值：1001 |

### |  |  | precedence | * 类型：Value * 值：1 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_QoSData1 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_TrafficControlData 说明：  已在5G动作组中定义。 |

### | 5G动作组14 | 基本信息 | 名称 | AG\_VoNR\_DynamicPccRuleIMS1\_B |

### |  |  | 类型 | DynamicPccRuleIMS |

### |  | 属性 | pccRuleId | * 类型：Value * 值：1002 |

### |  |  | precedence | * 类型：Value * 值：2 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_QoSData1 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_TrafficControlData 说明：  已在5G动作组中定义。 |

### | 5G动作组15 | 基本信息 | 名称 | AG\_VoNR\_QoSData2 |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：202 |

### |  |  | 5qi | * 类型：Value * 值(kbit/s)：2 |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP 说明：  已在5G动作组中定义。 |

### |  |  | maxbrUl | * 类型：Value * 值：4 Gbps |

### |  |  | maxbrDl | * 类型：Value * 值：4 Gbps |

### |  |  | gbrUl | * 类型：Value * 值：4 Gbps |

### |  |  | gbrDl | * 类型：Value * 值：4 Gbps |

### | 5G动作组16 | 基本信息 | 名称 | AG\_VoNR\_DynamicPccRuleIMS2 |

### |  |  | 类型 | DynamicPccRuleIMS |

### |  | 属性 | pccRuleId | * 类型：Value * 值：490 |

### |  |  | precedence | * 类型：Value * 值：7 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_QoSData2 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_TrafficControlData 说明：  已在5G动作组中定义。 |

### | 5G动作组17 | 基本信息 | 名称 | AG\_VoNR\_DynamicPccRuleIMS2\_B |

### |  |  | 类型 | DynamicPccRuleIMS |

### |  | 属性 | pccRuleId | * 类型：Value * 值：500 |

### |  |  | precedence | * 类型：Value * 值：8 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_QoSData2 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_TrafficControlData 说明：  已在5G动作组中定义。 |

### | 5G动作组18 | 基本信息 | 名称 | AG\_PreReserved\_QoSData |

### |  |  | 类型 | QoSData |

### |  | 属性 | qosId | * 类型：Value * 值：AG\_PreReserved\_QoSData |

### |  |  | 5qi | * 类型：Value * 值(kbit/s)：5 |

### |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP 说明：  已在5G动作组中定义。 |

### |  |  | defQosFlowIndication | * 类型：Value * 值：True 说明：  用于将AF请求的媒体流直接绑定到默认QoS Flow上。 |

### | 5G动作组19 | 基本信息 | 名称 | AG\_PreReserved\_IMS |

### |  |  | 类型 | DynamicPccRule |

### |  | 属性 | pccRuleId | * 类型：Value * 值：AG\_PreReserved\_IMS |

### |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG\_N7\_Finfo 说明：  已在5G动作组中定义。 |

### |  |  | precedence | * 类型：Value * 值：255 |

### |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_PreReserved\_QoSData 说明：  已在5G动作组中定义。 |

### |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_N7\_TrafficCtrl 说明：  已在5G动作组中定义。 |

### 5 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### VoNR场景下，规则的“类型”需要配置为“5G Smf Pcc Rule for IMS”。

### 当Rx接口携带多个QoS请求能力不同的流信息时，因不同的流QoS能力不同，则需配置不同的条件组和refQosData动作被不同的“类型”为“5G Smf Pcc Rule for IMS”的规则关联。

### 规则的数据规划如表4所示，详细参数说明请参见规则参数表。

### **表4** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | N7\_VoNR\_Rule1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Session Rule |

### |  | 5G动作组 | 5G动作组 | AG\_N7\_sessRule  说明：  已在5G动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | N7\_VoNR\_Rule2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  | 5G动作组 | 5G动作组 | AG\_N7\_pccRule  说明：  已在5G动作组中定义。 |

### | 规则3 | 基本信息 | 名称 | N7\_VoNR\_Rule3 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Basic Rule |

### |  | 5G动作组 | 5G动作组 | AG\_BasicRule  说明：  已在5G动作组中定义。 |

### | 规则4 | 基本信息 | 名称 | IMS\_VoNR\_Rule1 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule for IMS |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | * CG\_Audio\_VoNR * CG\_FlowUsage\_NoEq\_RTCP 说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_VoNR\_DynamicPccRuleIMS1  说明：  已在5G动作组中定义。 |

### | 规则5 | 基本信息 | 名称 | IMS\_VoNR\_Rule1\_B |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule for IMS |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | * CG\_Audio\_VoNR * CG\_FlowUsage\_Eq\_RTCP 说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_VoNR\_DynamicPccRuleIMS1\_B  说明：  已在5G动作组中定义。 |

### | 规则6 | 基本信息 | 名称 | IMS\_VoNR\_Rule2 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule for IMS |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | * CG\_Video\_VoNR * CG\_FlowUsage\_NoEq\_RTCP 说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_VoNR\_DynamicPccRuleIMS2  说明：  已在5G动作组中定义。 |

### | 规则7 | 基本信息 | 名称 | IMS\_VoNR\_Rule2\_B |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule for IMS |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | * CG\_Video\_VoNR * CG\_FlowUsage\_Eq\_RTCP 说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_VoNR\_DynamicPccRuleIMS2\_B  说明：  已在5G动作组中定义。 |

### | 规则8 | 基本信息 | 名称 | IMS\_PreReserved\_Rule |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Smf Pcc Rule |

### |  | 5G动作组 | 5G动作组 | AG\_PreReserved\_IMS  说明：  已在5G动作组中定义。 |

### 6 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 请增加如下策略：

### P\_N7\_VoNR：用户从5G网络上线时被调用的策略，触发器为IPCAN\_EST。

### P\_Audio\_VoNR：UPCF接收到VoNR应用会话请求时触发的策略，触发器为AFSessionAuthorization。

### 策略的数据规划如表5所示，详细参数说明请参见策略参数表。

### **表5** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略1 | 基本信息 | 名称 | P\_N7\_VoNR |

### |  |  | 策略类型 | N7 Policy |

### |  | 触发器 | 名称 | IPCAN\_EST |

### |  | 规则 | 名称 | * N7\_VoNR\_Rule1 * N7\_VoNR\_Rule2 * N7\_VoNR\_Rule3 说明：  已在规则中定义。 |

### | 策略2 | 基本信息 | 名称 | P\_Audio\_VoNR |

### |  |  | 策略类型 | N7 Policy |

### |  | 触发器 | 名称 | AFSessionAuthorization |

### |  | 规则 | 名称 | * IMS\_VoNR\_Rule1 * IMS\_VoNR\_Rule1\_B * IMS\_VoNR\_Rule2 * IMS\_VoNR\_Rule2\_B * IMS\_PreReserved\_Rule 说明：  已在规则中定义。 |

### 7 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 请增加如下业务：

### Data\_N7\_Service：由PCEF激活的业务，用于创建IMS信令默认QoS Flow。

### IMS\_VoNR\_Service：由AF激活的VoNR业务，如语音、视频等。因为此业务不需要用户签约，故参数“签约后才能使用”必须配置为“否”。

### 业务的数据规划如表6 所示，详细参数说明请参见业务参数表。

### **表6** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务1 | 基本信息 | 名称 | Data\_N7\_Service |

### |  |  | 类型 | BASIC\_SERVICE |

### |  |  | APN | ims  说明：  需要与1中**ADD APN**命令的参数“APN名称”取值保持一致。 |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | P\_N7\_VoNR  说明：  已在策略中定义。 |

### | 业务2 | 基本信息 | 名称 | IMS\_VoNR\_Service |

### |  |  | 类型 | BASIC\_SERVICE |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | AF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 否  说明：  若业务激活方式为AF，但用户没有订购该业务，则需要将业务的参数“签约后才能使用”设置为“否”。 |

### |  | 策略 | 名称 | P\_Audio\_VoNR  说明：  已在策略中定义。 |

### 8 配置应用业务映射。

### 导航入口为“业务管理 > 业务 > 应用业务映射”。

### 配置AF激活的基本呼叫业务时，必须配置应用业务映射。其中，“应用标识”必须和AF侧协商一致；“业务”为7中已定义的VoNR基本呼叫业务。

### 应用业务映射的数据规划如表7所示，详细参数说明请参见应用业务映射参数表。

### **表7** 应用业务映射

### | 类别 | 参数 | 取值样例 |

### | --- | --- | --- |

### | 应用业务映射 | 应用标识 | IMS  说明：  和AF中定义的应用标识协商一致。 |

### |  | 业务 | IMS\_VoNR\_Service  说明：  已在业务中定义的由AF激活的业务（VoNR基本呼叫业务）。 |

### 9 配置用户组。

### 导航入口为“用户管理 > 用户 > 用户组”。

### 动态用户组的数据规划如表8所示，详细参数说明请参见动态用户组参数表。

### **表8** 动态用户组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 用户组 | 基本信息 | 名称 | SG\_IMS\_Default |

### |  |  | 类型 | 动态 |

### |  |  | APN | ims  说明：  需要与1中**ADD APN**命令的参数“APN名称”取值保持一致。 |

### |  |  | 应用类型 | 缺省方式 |

### |  | 业务 | 名称 | Data\_N7\_Service  说明：  已在业务中定义。 |

