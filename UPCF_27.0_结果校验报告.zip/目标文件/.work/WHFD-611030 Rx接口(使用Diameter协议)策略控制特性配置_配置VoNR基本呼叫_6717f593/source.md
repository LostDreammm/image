# 配置VoNR基本呼叫

* 操作场景
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

## 操作场景

UPCF支持VoNR方案，用于部署IMS应用，为基本呼叫业务提供保障的带宽，确保用户享用优质语音和高清视频。当5G用户接入IMS网络发起基本呼叫时，AF（即IMS域的P-CSCF）通过Rx接口向UPCF发起资源预留请求，将会话相关的属性，如应用标识、媒体类型、媒体流状态、媒体流描述等上报给UPCF，UPCF根据AF上报的信息和本地配置的业务策略进行策略判断，将生成的QoS规则通过N7接口下发给SMF执行策略控制。

## 必备事项

前提条件

* 操作员已了解WHFD-606007 Rx接口(使用Diameter协议)VoNR策略控制特性概述。
* 操作员已了解“VoNR业务和特性描述”。
* 已完成配置UPCF与AF（基于Diameter协议）的对接数据。

数据

根据应用场景，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 用户基本呼叫业务 | 此用户业务包含2个业务：   * Data\_N7\_Service：Activated By PCEF。 * IMS\_VoNR\_Service：Activated By AF。 | * 定义一个IMS APN业务（Activated By PCEF）给SMF下发QoS（5qi=5）。此时信元“qosFlowUsage”下发的取值为“IMS\_SIG”。 * 定义一个IMS VoNR业务（Activated By AF）给AF侧激活的基本呼叫业务建立媒体专有QoS Flow。 |
| 动态用户组SG\_IMS\_Default | 动态用户组签约Data\_N7\_Service业务，则匹配此动态用户组的一类用户上线时均可使用该业务。 | 匹配条件：用户从IMS APN上线。 |
| IMS APN业务Data\_N7\_Service | 此业务包括一个策略：P\_N7\_VoNR。 | 此业务用于建立N7会话，只在用户上线时触发（IPCAN\_EST）。 |
| IMS VoNR业务IMS\_VoNR\_Service | 此业务包括一个策略：P\_Audio\_VoNR。 | 此业务用来建立IMS基本呼叫业务的专有QoS Flow，只在收到来自AF的授权请求时触发（AFSessionAuthorization）。  说明：  * 需要配置一个应用映射将AF侧的业务标识（IMS）与UPCF上配置的AF激活的业务（IMS\_VoNR\_Service）对应起来。 * AF激活的业务不需要用户签约。当用户使用语音呼叫或视频呼叫等VoNR业务时，AF会向UPCF发送AAR消息请求建立媒体专有QoS Flow，消息中携带业务标识AVP“AF-Application-Identifier”，通过UPCF上配置的应用映射来激活UPCF上对应的业务。 |
| 策略P\_N7\_VoNR | 此策略在用户上线时被调用，触发器为IPCAN\_EST，包含规则：   * N7\_VoNR\_Rule1 * N7\_VoNR\_Rule2 * N7\_VoNR\_Rule3 | - |
| 策略P\_Audio\_VoNR | 此策略在用户从IMS网络上线使用IMS VoNR业务时被调用，触发器为AFSessionAuthorization，包含规则：   * IMS\_VoNR\_Rule1 * IMS\_VoNR\_Rule1\_B * IMS\_VoNR\_Rule2 * IMS\_VoNR\_Rule2\_B * IMS\_PreReserved\_Rule | 用户使用IMS VoNR业务，可以根据媒体流的使用方式以及用户请求的媒体类型（如语音呼叫、视频呼叫）不同的来设置条件。  须知：  Rx请求消息中携带的每一对媒体流只支持关联一个规则，规则IMS\_VoNR\_Rule1、IMS\_VoNR\_Rule1\_B、IMS\_VoNR\_Rule2、IMS\_VoNR\_Rule2\_B和IMS\_PreReserved\_Rule关联的条件组需要互斥。 |
| 规则N7\_VoNR\_Rule1 | * 条件：无 * 动作：    + Ambr（uplink/downlink=2 Gbps）   + DefaultQosInformation（5qi=5） | 用户上线，下发会话类型的规则。 |
| 规则N7\_VoNR\_Rule2 | * 条件：无 * 动作：QoSData（maxbrUl/maxbrDl=2 Gbps，5qi=5） | 用户上线，下发PCC类型的规则。 |
| 规则N7\_VoNR\_Rule3 | * 条件：无 * 动作：BasicInfoAction（qosFlowUsage=IMS\_SIG） | 用户上线，下发Basic类型的规则。 |
| 规则IMS\_VoNR\_Rule1 | * 条件：   + 媒体类型是语音呼叫（MediaType=Audio）   + 媒体流的使用方式不为RTCP（FlowUsage≠RTCP） * 动作：   + QoSData（maxbrUl/maxbrDl=2 Gbps）   + DynamicPccRuleIMS（precedence=1）   + TrafficControlData：flowStatus为ApplicationSession.FlowStatus | * 定义基于AF应用会话媒体类型的策略时，条件“对象属性”选用对象ApplicationSession下的MediaType属性。 * 定义基于媒体流的使用方式的策略时，条件“对象属性”选用对象ApplicationSession下的FlowUsage属性。不同媒体流的使用方式下发的规则优先级precedence需要不同。 * 动作QoSData：媒体类型为语音时，建议maxbrUl和maxbrDl配置为2 Gbps；媒体类型为视频时，建议maxbrUl和maxbrDl配置为4 Gbps。 * 动作TrafficControlData：参数“flowStatus”的取值为AF在AAR消息中携带的Flow-Status AVP取值。 * AF侧激活的业务下规则“类型”都需配置为“5G Smf Pcc Rule for IMS”。 |
| 规则IMS\_VoNR\_Rule1\_B | * 条件：   + 媒体类型是语音呼叫（MediaType=Audio）   + 媒体流的使用方式为RTCP（FlowUsage=RTCP） * 动作：   + QoSData（maxbrUl/maxbrDl=2 Gbps）   + DynamicPccRuleIMS（precedence=2）   + TrafficControlData：flowStatus为ApplicationSession.FlowStatus |  |
| 规则IMS\_VoNR\_Rule2 | * 条件：   + 媒体类型是视频呼叫（MediaType=Video）   + 媒体流的使用方式不为RTCP（FlowUsage≠RTCP） * 动作：   + QoSData（maxbrUl/maxbrDl=4 Gbps）   + DynamicPccRuleIMS（precedence=7）   + TrafficControlData：flowStatus为ApplicationSession.FlowStatus |  |
| 规则IMS\_VoNR\_Rule2\_B | * 条件：   + 媒体类型是视频呼叫（MediaType=Video）   + 媒体流的使用方式为RTCP（FlowUsage=RTCP） * 动作：   + QoSData（maxbrUl/maxbrDl=4 Gbps）   + DynamicPccRuleIMS（precedence=8）   + TrafficControlData：flowStatus为ApplicationSession.FlowStatus |  |
| 规则IMS\_PreReserved\_Rule | * 条件：无 * 动作：   + QoSData（5qi=5）   + DynamicPccRule（precedence=255）   + TrafficControlData：flowStatus为ENABLED | 该规则适用于早期资源预留场景。   * 如果该规则中没有配置条件组，系统会优先匹配有条件的规则，则该规则的匹配优先级最低。 * 如果该规则中有配置条件组，则该规则关联的条件组需要与规则IMS\_VoNR\_Rule1、IMS\_VoNR\_Rule1\_B、IMS\_VoNR\_Rule2和IMS\_VoNR\_Rule2\_B关联的条件组互斥。 * QoSData中的5qi与默认QoS Flow的5qi相同。 |

## 操作流程

此特性的配置流程图如图2所示。

**图2** VoNR基本呼叫业务配置流程图

## 操作步骤

1. 登录“UPCF MML命令”界面。
   1. 执行ADD APN命令，添加“VoLTE-APN”类型的APN。

      该命令用来防止数据业务的规则下发给IMS。命令举例如下：

      ```
      ADD APN: PCRFID=1, APNID=1, APNNAME="ims", APNTYPE=VoLTE-APN, APNMATCHTYPE=FullMatching;
      ```
   2. 执行**MOD INSP**命令，修改软参VRM\_SERVICEINFOSTATUSMODE的取值。

      ```
      MOD INSP:INSPN=VRM_SERVICEINFOSTATUSMODE, INSPV=2;
      ```

      早期预留场景下，需要根据实际场景配置软参“VRM\_SERVICEINFOSTATUSMODE”的值，该场景软参配置为“2”。
2. 登录UPCF Web UI界面。
3. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置4个条件组，用于分别判断用户语音呼叫、视频呼叫或媒体流的使用方式是否为RTCP。条件组的数据规划如表2所示，详细参数说明请参见条件组参数表。

   **表2** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_Audio\_VoNR |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_Audio\_VoNR |
   |  |  | 对象属性 | * 对象：ApplicationSession * 属性：MediaType |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Audio  说明：  表示媒体类型为语音呼叫。 |
   | 条件组2 | 基本信息 | 名称 | CG\_Video\_VoNR |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_Video\_VoNR |
   |  |  | 对象属性 | * 对象：ApplicationSession * 属性：MediaType |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Video  说明：  表示媒体类型为视频呼叫。 |
   | 条件组3 | 基本信息 | 名称 | CG\_FlowUsage\_NoEq\_RTC |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | cond\_FlowUsage\_NoEq\_RTCP |
   |  |  | 对象属性 | * 对象：ApplicationSession * 属性：FlowUsage |
   |  |  | 操作符 | Not Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | RTCP |
   | 条件组4 | 基本信息 | 名称 | CG\_FlowUsage\_Eq\_RTCP |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | cond\_FlowUsage\_Eq\_RTCP |
   |  |  | 对象属性 | * 对象：ApplicationSession * 属性：FlowUsage |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | RTCP |
4. 配置5G动作组。

   导航入口为“策略管理 > 策略 > 5G动作组”。

   此场景需配置5G动作：Ambr、Arp、DefaultQosInformation、SessionRuleAction、BasicInfoAction、FlowDescription、FlowInformation、QoSData、TrafficControlData、DynamicPccRule和DynamicPccRuleIMS，相关应用场景如下：
   * Ambr：用于设置会话类型的上下行带宽。
   * Arp：当需要配置“类型”为“QoSData”和“DefaultQosInformation”的动作组时必须配置此动作。
   * DefaultQosInformation：用于设置会话类型的QoS信息。
   * SessionRuleAction：需要配置会话类型规则，需要配置此动作。
   * BasicInfoAction：用于设置QoS流的方式为IMS信令。
   * FlowDescription：当需要下发流方向时需配置此动作。
   * FlowInformation：当需要下发流信息时需配置此动作。
   * QoSData：当需要进行带宽控制时均需配置此动作，若不配置则表示不限制Qos。
   * TrafficControlData：当需要做门限控制时，配置此动作。在下发流描述时，如果不配默认为放通该流，当需要限制流时，此动作必须配置。此场景根据AF请求的Flow-Status，下发门限策略。
   * DynamicPccRule：需要配置动态类的业务规则，需要配置此动作。
   * DynamicPccRuleIMS：VoNR场景需要配置此动作。

   请增加如下5G动作组和动作：

   * 动作组AG\_N7\_ambr：动作类型为Ambr
   * 动作组AG\_VoNR\_ARP：动作类型为Arp
   * 动作组AG\_N7\_def：动作类型为DefaultQosInformation
   * 动作组AG\_N7\_sessRule：动作类型为SessionRuleAction
   * 动作组AG\_BasicRule：动作类型为BasicInfoAction
   * 动作组AG\_N7\_FlowD：动作类型为FlowDescription
   * 动作组AG\_N7\_Finfo：动作类型为FlowInformation
   * 动作组AG\_N7\_QoSData、AG\_VoNR\_QoSData1、AG\_VoNR\_QoSData2和AG\_PreReserved\_QoSData：动作类型为QoSData
   * 动作组AG\_N7\_TrafficCtrl和AG\_VoNR\_TrafficControlData：动作类型为TrafficControlData
   * 动作组AG\_N7\_pccRule和AG\_PreReserved\_IMS：动作类型为DynamicPccRule
   * 动作组AG\_VoNR\_DynamicPccRuleIMS1、AG\_VoNR\_DynamicPccRuleIMS1\_B、AG\_VoNR\_DynamicPccRuleIMS2、AG\_VoNR\_DynamicPccRuleIMS2\_B：动作类型为DynamicPccRuleIMS

   5G动作组的数据规划如表3所示，详细参数说明请参见5G动作组参数表。

   **表3** 5G动作组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 5G动作组1 | 基本信息 | 名称 | AG\_N7\_ambr |
   |  |  | 类型 | Ambr |
   |  | 属性 | uplink | 2 Gbps |
   |  |  | downlink | 2 Gbps |
   | 5G动作组2 | 基本信息 | 名称 | AG\_VoNR\_ARP |
   |  |  | 类型 | Arp |
   |  | 属性 | priorityLevel | * 类型：Value * 值：2 |
   |  |  | preemptCap | * 类型：Value * 值：NOT\_PREEMPT |
   |  |  | preemptVuln | * 类型：Value * 值：NOT\_PREEMPTABLE |
   | 5G动作组3 | 基本信息 | 名称 | AG\_N7\_def |
   |  |  | 类型 | DefaultQosInformation |
   |  | 属性 | 5qi | * 类型：Value * 值：5 |
   |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP  说明：  已在5G动作组中定义。 |
   | 5G动作组4 | 基本信息 | 名称 | AG\_N7\_sessRule |
   |  |  | 类型 | SessionRuleAction |
   |  | 属性 | sessRuleId | * 类型：Value * 值：123 |
   |  |  | authSessAmbr | * 类型：Reference ActionGroup * 值：AG\_N7\_ambr  说明：  已在5G动作组中定义。 |
   |  |  | authDefQos | * 类型：Reference ActionGroup * 值：AG\_N7\_def  说明：  已在5G动作组中定义。 |
   | 5G动作组5 | 基本信息 | 名称 | AG\_N7\_FlowD |
   |  |  | 类型 | FlowDescription |
   |  | 属性 | action | * 类型：Value * 值：PERMIT |
   |  |  | direction | * 类型：Value * 值：OUT |
   |  |  | protocol | * 类型：Value * 值：ANY |
   |  |  | sourceIP | * 类型：Value * 值：any |
   |  |  | destinationIP | * 类型：Value * 值：any |
   | 5G动作组6 | 基本信息 | 名称 | AG\_N7\_Finfo |
   |  |  | 类型 | FlowInformation |
   |  | 属性 | flowDescription | * 类型：Reference ActionGroup * 值：AG\_N7\_FlowD  说明：  已在5G动作组中定义。 |
   |  |  | flowDirection | * 类型：Value * 值：BIDIRECTIONAL |
   | 5G动作组7 | 基本信息 | 名称 | AG\_N7\_TrafficCtrl |
   |  |  | 类型 | TrafficControlData |
   |  | 属性 | tcId | * 类型：Value * 值：100 |
   |  |  | flowStatus | * 类型：Value * 值：ENABLED |
   | 5G动作组8 | 基本信息 | 名称 | AG\_N7\_QoSData |
   |  |  | 类型 | QoSData |
   |  | 属性 | qosId | * 类型：Value * 值：200 |
   |  |  | 5qi | * 类型：Value * 值：5 |
   |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP 说明：  已在5G动作组中定义。 |
   |  |  | maxbrUl | * 类型：Value * 值：2 Gbps |
   |  |  | maxbrDl | * 类型：Value * 值：2 Gbps |
   | 5G动作组9 | 基本信息 | 名称 | AG\_N7\_pccRule |
   |  |  | 类型 | DynamicPccRule |
   |  | 属性 | pccRuleId | * 类型：Value * 值：pccRuleId\_Norm |
   |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG\_N7\_Finfo 说明：  已在5G动作组中定义。 |
   |  |  | precedence | * 类型：Value * 值：1 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_N7\_QoSData 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_N7\_TrafficCtrl 说明：  已在5G动作组中定义。 |
   | 5G动作组10 | 基本信息 | 名称 | AG\_BasicRule |
   |  |  | 类型 | BasicInfoAction |
   |  | 属性 | qosFlowUsage | * 类型：Value * 值：IMS\_SIG |
   | 5G动作组11 | 基本信息 | 名称 | AG\_VoNR\_QoSData1 |
   |  |  | 类型 | QoSData |
   |  | 属性 | qosId | * 类型：Value * 值：201 |
   |  |  | 5qi | * 类型：Value * 值：1 |
   |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP 说明：  已在5G动作组中定义。 |
   |  |  | maxbrUl | * 类型：Value * 值：2 Gbps |
   |  |  | maxbrDl | * 类型：Value * 值：2 Gbps |
   |  |  | gbrUl | * 类型：Value * 值：2 Gbps |
   |  |  | gbrDl | * 类型：Value * 值：2 Gbps |
   | 5G动作组12 | 基本信息 | 名称 | AG\_VoNR\_TrafficControlData |
   |  |  | 类型 | TrafficControlData |
   |  | 属性 | tcId | * 类型：Value * 值：A\_TCD\_01 |
   |  |  | flowStatus | * 类型：Value * 值：ENABLED |
   | 5G动作组13 | 基本信息 | 名称 | AG\_VoNR\_DynamicPccRuleIMS1 |
   |  |  | 类型 | DynamicPccRuleIMS |
   |  | 属性 | pccRuleId | * 类型：Value * 值：1001 |
   |  |  | precedence | * 类型：Value * 值：1 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_QoSData1 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_TrafficControlData 说明：  已在5G动作组中定义。 |
   | 5G动作组14 | 基本信息 | 名称 | AG\_VoNR\_DynamicPccRuleIMS1\_B |
   |  |  | 类型 | DynamicPccRuleIMS |
   |  | 属性 | pccRuleId | * 类型：Value * 值：1002 |
   |  |  | precedence | * 类型：Value * 值：2 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_QoSData1 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_TrafficControlData 说明：  已在5G动作组中定义。 |
   | 5G动作组15 | 基本信息 | 名称 | AG\_VoNR\_QoSData2 |
   |  |  | 类型 | QoSData |
   |  | 属性 | qosId | * 类型：Value * 值：202 |
   |  |  | 5qi | * 类型：Value * 值(kbit/s)：2 |
   |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP 说明：  已在5G动作组中定义。 |
   |  |  | maxbrUl | * 类型：Value * 值：4 Gbps |
   |  |  | maxbrDl | * 类型：Value * 值：4 Gbps |
   |  |  | gbrUl | * 类型：Value * 值：4 Gbps |
   |  |  | gbrDl | * 类型：Value * 值：4 Gbps |
   | 5G动作组16 | 基本信息 | 名称 | AG\_VoNR\_DynamicPccRuleIMS2 |
   |  |  | 类型 | DynamicPccRuleIMS |
   |  | 属性 | pccRuleId | * 类型：Value * 值：490 |
   |  |  | precedence | * 类型：Value * 值：7 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_QoSData2 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_TrafficControlData 说明：  已在5G动作组中定义。 |
   | 5G动作组17 | 基本信息 | 名称 | AG\_VoNR\_DynamicPccRuleIMS2\_B |
   |  |  | 类型 | DynamicPccRuleIMS |
   |  | 属性 | pccRuleId | * 类型：Value * 值：500 |
   |  |  | precedence | * 类型：Value * 值：8 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_QoSData2 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_VoNR\_TrafficControlData 说明：  已在5G动作组中定义。 |
   | 5G动作组18 | 基本信息 | 名称 | AG\_PreReserved\_QoSData |
   |  |  | 类型 | QoSData |
   |  | 属性 | qosId | * 类型：Value * 值：AG\_PreReserved\_QoSData |
   |  |  | 5qi | * 类型：Value * 值(kbit/s)：5 |
   |  |  | arp | * 类型：Reference ActionGroup * 值：AG\_VoNR\_ARP 说明：  已在5G动作组中定义。 |
   |  |  | defQosFlowIndication | * 类型：Value * 值：True 说明：  用于将AF请求的媒体流直接绑定到默认QoS Flow上。 |
   | 5G动作组19 | 基本信息 | 名称 | AG\_PreReserved\_IMS |
   |  |  | 类型 | DynamicPccRule |
   |  | 属性 | pccRuleId | * 类型：Value * 值：AG\_PreReserved\_IMS |
   |  |  | flowInfos | * 类型：Reference ActionGroup * 值：AG\_N7\_Finfo 说明：  已在5G动作组中定义。 |
   |  |  | precedence | * 类型：Value * 值：255 |
   |  |  | refQosData | * 类型：Reference ActionGroup * 值：AG\_PreReserved\_QoSData 说明：  已在5G动作组中定义。 |
   |  |  | refTcData | * 类型：Reference ActionGroup * 值：AG\_N7\_TrafficCtrl 说明：  已在5G动作组中定义。 |
5. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   * VoNR场景下，规则的“类型”需要配置为“5G Smf Pcc Rule for IMS”。
   * 当Rx接口携带多个QoS请求能力不同的流信息时，因不同的流QoS能力不同，则需配置不同的条件组和refQosData动作被不同的“类型”为“5G Smf Pcc Rule for IMS”的规则关联。

   规则的数据规划如表4所示，详细参数说明请参见规则参数表。

   **表4** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | N7\_VoNR\_Rule1 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Session Rule |
   |  | 5G动作组 | 5G动作组 | AG\_N7\_sessRule  说明：  已在5G动作组中定义。 |
   | 规则2 | 基本信息 | 名称 | N7\_VoNR\_Rule2 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule |
   |  | 5G动作组 | 5G动作组 | AG\_N7\_pccRule  说明：  已在5G动作组中定义。 |
   | 规则3 | 基本信息 | 名称 | N7\_VoNR\_Rule3 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Basic Rule |
   |  | 5G动作组 | 5G动作组 | AG\_BasicRule  说明：  已在5G动作组中定义。 |
   | 规则4 | 基本信息 | 名称 | IMS\_VoNR\_Rule1 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule for IMS |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | * CG\_Audio\_VoNR * CG\_FlowUsage\_NoEq\_RTCP 说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | AG\_VoNR\_DynamicPccRuleIMS1  说明：  已在5G动作组中定义。 |
   | 规则5 | 基本信息 | 名称 | IMS\_VoNR\_Rule1\_B |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule for IMS |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | * CG\_Audio\_VoNR * CG\_FlowUsage\_Eq\_RTCP 说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | AG\_VoNR\_DynamicPccRuleIMS1\_B  说明：  已在5G动作组中定义。 |
   | 规则6 | 基本信息 | 名称 | IMS\_VoNR\_Rule2 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule for IMS |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | * CG\_Video\_VoNR * CG\_FlowUsage\_NoEq\_RTCP 说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | AG\_VoNR\_DynamicPccRuleIMS2  说明：  已在5G动作组中定义。 |
   | 规则7 | 基本信息 | 名称 | IMS\_VoNR\_Rule2\_B |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule for IMS |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | * CG\_Video\_VoNR * CG\_FlowUsage\_Eq\_RTCP 说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | AG\_VoNR\_DynamicPccRuleIMS2\_B  说明：  已在5G动作组中定义。 |
   | 规则8 | 基本信息 | 名称 | IMS\_PreReserved\_Rule |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Smf Pcc Rule |
   |  | 5G动作组 | 5G动作组 | AG\_PreReserved\_IMS  说明：  已在5G动作组中定义。 |
6. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   请增加如下策略：

   * P\_N7\_VoNR：用户从5G网络上线时被调用的策略，触发器为IPCAN\_EST。
   * P\_Audio\_VoNR：UPCF接收到VoNR应用会话请求时触发的策略，触发器为AFSessionAuthorization。

   策略的数据规划如表5所示，详细参数说明请参见策略参数表。

   **表5** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略1 | 基本信息 | 名称 | P\_N7\_VoNR |
   |  |  | 策略类型 | N7 Policy |
   |  | 触发器 | 名称 | IPCAN\_EST |
   |  | 规则 | 名称 | * N7\_VoNR\_Rule1 * N7\_VoNR\_Rule2 * N7\_VoNR\_Rule3 说明：  已在规则中定义。 |
   | 策略2 | 基本信息 | 名称 | P\_Audio\_VoNR |
   |  |  | 策略类型 | N7 Policy |
   |  | 触发器 | 名称 | AFSessionAuthorization |
   |  | 规则 | 名称 | * IMS\_VoNR\_Rule1 * IMS\_VoNR\_Rule1\_B * IMS\_VoNR\_Rule2 * IMS\_VoNR\_Rule2\_B * IMS\_PreReserved\_Rule 说明：  已在规则中定义。 |
7. 配置业务。

   导航入口为“业务管理 > 业务 > 业务”。

   请增加如下业务：

   * Data\_N7\_Service：由PCEF激活的业务，用于创建IMS信令默认QoS Flow。
   * IMS\_VoNR\_Service：由AF激活的VoNR业务，如语音、视频等。因为此业务不需要用户签约，故参数“签约后才能使用”必须配置为“否”。

   业务的数据规划如表6 所示，详细参数说明请参见业务参数表。

   **表6** 业务

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务1 | 基本信息 | 名称 | Data\_N7\_Service |
   |  |  | 类型 | BASIC\_SERVICE |
   |  |  | APN | ims  说明：  需要与1中**ADD APN**命令的参数“APN名称”取值保持一致。 |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | P\_N7\_VoNR  说明：  已在策略中定义。 |
   | 业务2 | 基本信息 | 名称 | IMS\_VoNR\_Service |
   |  |  | 类型 | BASIC\_SERVICE |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 激活方式 | AF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 否  说明：  若业务激活方式为AF，但用户没有订购该业务，则需要将业务的参数“签约后才能使用”设置为“否”。 |
   |  | 策略 | 名称 | P\_Audio\_VoNR  说明：  已在策略中定义。 |
8. 配置应用业务映射。

   导航入口为“业务管理 > 业务 > 应用业务映射”。

   配置AF激活的基本呼叫业务时，必须配置应用业务映射。其中，“应用标识”必须和AF侧协商一致；“业务”为7中已定义的VoNR基本呼叫业务。

   应用业务映射的数据规划如表7所示，详细参数说明请参见应用业务映射参数表。

   **表7** 应用业务映射

   | 类别 | 参数 | 取值样例 |
   | --- | --- | --- |
   | 应用业务映射 | 应用标识 | IMS  说明：  和AF中定义的应用标识协商一致。 |
   |  | 业务 | IMS\_VoNR\_Service  说明：  已在业务中定义的由AF激活的业务（VoNR基本呼叫业务）。 |
9. 配置用户组。

   导航入口为“用户管理 > 用户 > 用户组”。

   动态用户组的数据规划如表8所示，详细参数说明请参见动态用户组参数表。

   **表8** 动态用户组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 用户组 | 基本信息 | 名称 | SG\_IMS\_Default |
   |  |  | 类型 | 动态 |
   |  |  | APN | ims  说明：  需要与1中**ADD APN**命令的参数“APN名称”取值保持一致。 |
   |  |  | 应用类型 | 缺省方式 |
   |  | 业务 | 名称 | Data\_N7\_Service  说明：  已在业务中定义。 |

## 任务示例

任务描述

配置业务。

脚本

* IMS APN业务和语音业务脚本：Data\_N7\_Service+IMS\_VoNR\_Service CLI脚本
* 早期预留场景下，语音业务IMS\_VoNR\_Service中还需要增加规则IMS\_PreReserved\_Rule的配置脚本：IMS\_PreReserved\_Rule CLI脚本

版权所有 © 华为技术有限公司
