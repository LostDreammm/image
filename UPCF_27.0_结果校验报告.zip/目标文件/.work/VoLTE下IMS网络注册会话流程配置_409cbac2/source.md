# VoLTE下IMS网络注册会话流程配置

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

IMS网络注册是VoLTE用户使用IMS网络提供业务的前提，UPCF支持用户在IMS网络的注册会话流程。

IMS网络注册会话流程仅用于VoLTE组网下的AF（即P-CSCF）容灾场景，当VoLTE用户发起IMS网络的注册会话时，AF通过Rx接口向UPCF发起AAR消息。UPCF根据AF上报的媒体流信息（包含AF地址）、本地配置的业务策略和用户签约信息进行策略判断，将生成的规则和AF地址通过RAR消息下发给PCEF。PCEF获知用户选择的AF地址，当该AF故障时，PCEF将通知用户向其他AF重新发起IMS网络注册请求。

#### 对系统的影响

本特性对系统无影响。

#### 必备事项

**前提条件**

* 操作员已了解WHFD-606006 Rx接口(使用Diameter协议)VoLTE策略控制特性概述。
* 已完成配置UPCF与AF（基于Diameter协议）的对接数据。

**数据**

根据应用场景，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| IMS用户注册业务  Default\_Signalling\_Service | 用户在IMS网络注册过程即为一个业务，此业务为AF激活的业务。 | 定义一个IMS用户注册业务（Activated By AF），用于支持IMS用户注册流程，透传AF侧的地址给PCEF。  说明：  在VoLTE容灾场景下，当需要UPCF支持用户在IMS网络注册会话流程，即“用户注册流程时透传AF侧的地址”，需配置此业务，否则略过。 |
| 策略Default\_Signalling\_Policy | 此策略在用户使用IMS用户注册业务时被调用，触发器为AFSessionAuthorization，包含所有规则。 | 用户使用IMS用户注册业务，可以根据媒体部件编号来设置条件。 |
| 规则Default\_Signalling\_Rule | * 条件：媒体部件编号为IMS域媒体部件标识（ApplicationSession.MediaComponentNumber=0）。 * 动作：ChargingAction：RatingGroup为5。 | 条件“对象属性”选用对象ApplicationSession下的MediaComponentNumber属性。 |

#### 操作流程

此特性的配置流程图如图2所示。

**图2** Rx接口业务配置流程图

#### 操作步骤

1. 配置Rx特性的相关软参。
   1. 在OM Portal界面选择“应用管理 > MML”，进入Web MML配置界面。
   2. 选择UPCF网元执行**MOD INSP**命令，设置参数“UPM\_SUBCTRL”为“1”，即宽松签约模式。

      ```
      MOD INSP: INSPN=UPM_SUBCTRL, INSPV=1;
      ```
2. 登录UPCF WebUI界面。
3. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置一个用于判断媒体部件编号的条件组。条件组的数据规划如表2所示，详细参数说明请参见条件组参数表。

   **表2** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组 | 基本信息 | 名称 | CG\_Default\_Signalling |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | Signalling\_Condition\_Default |
   |  |  | 对象属性 | * 对象：ApplicationSession * 属性：MediaComponentNumber |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | 0 |
4. 配置动作组。

   导航入口为“策略管理 > 策略 > 动作组”。

   此场景需配置动作：ChargingAction，相关应用场景如下：

   ChargingAction：当需要做计费策略控制时，配置此动作（若对端为华为GGSN或者华为PDN-GW，此动作必须配置）。其中属性“RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。

   动作组的数据规划如表3所示，详细参数说明请参见动作组参数表。

   **表3** 动作组

   | 类别 | 参数 |  |  | 取值样例 |
   | --- | --- | --- | --- | --- |
   | 动作组 | 基本信息 | 名称 |  | AG\_Default\_Signalling |
   |  | 动作 | 动作 |  | ChargingAction |
   |  |  | 动作元素 | Offline | * 值类型：Value * 值：EnableOffline |
   |  |  |  | Online | * 值类型：Value * 值：DisableOnline |
   |  |  |  | MeteringMethod | * 值类型：Value * 值：Volume |
   |  |  |  | RatingGroup | * 值类型：Value * 值：5 |
   |  |  |  | ReportingLevel | * 值类型：Value * 值：Rating Group Level |
5. 配置业务流。

   导航入口为“策略管理 > 策略 > 业务流”。

   * 当对端为华为PDN-GW时，所有的动态规则都必须配置业务流。
   * 若Rx请求消息携带流信息，则会以Rx请求携带的流为准。

   业务流的数据规划如表4所示，详细参数说明请参见业务流参数表。

   **表4** 业务流

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务流 | 基本信息 | 名称 | Flow\_Filter |
   |  | 流过滤器1 | 名称 | up\_pass |
   |  |  | 流方向 | Up |
   |  |  | 协议 | Any IP Protocol |
   |  | 流过滤器2 | 名称 | down\_pass |
   |  |  | 流方向 | Down |
   |  |  | 协议 | Any IP Protocol |
6. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   * 除配置的动作DefaultBearerQoS，必须在规则“类型”为“Default Bearer QoS”时才有效外，其他情况AF业务下的规则“类型”建议都配置为“Dynamic”。
   * 在多PCEF场景下，若业务中的“激活方式”为“AF”，则业务下的规则都必须配置“目的PEER”。

   规则的数据规划如表5所示，详细参数说明请参见规则参数表。

   **表5** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则 | 基本信息 | 名称 | Default\_Signalling\_Rule |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Dynamic |
   |  |  | 业务流 | Flow\_Filter  说明：  已在业务流中定义。 |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Default\_Signalling  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_Default\_Signalling |
7. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   请增加Default\_Signalling\_Policy策略：用户IMS网络注册，UPCF接收到VoLTE应用会话请求时触发的策略，触发器为AFSessionAuthorization。

   策略的数据规划如表6所示，详细参数说明请参见策略参数表。

   **表6** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略 | 基本信息 | 名称 | Default\_Signalling\_Policy |
   |  |  | 策略类型 | Gx Policy |
   |  | 触发器 | 名称 | AFSessionAuthorization |
   |  | 规则 | 名称 | Default\_Signalling\_Rule  说明：  已在规则中定义。 |
8. 配置业务。

   导航入口为“业务管理 > 业务 > 业务”。

   请增加Default\_Signalling\_Service业务：由AF激活的IMS用户注册业务，用于VoLTE容灾场景下，用户注册流程时透传AF侧的地址给PCEF。因为此业务不需要用户签约，故参数“签约后才能使用”必须配置为“否”。

   业务的数据规划如表7所示，详细参数说明请参见业务参数表。

   **表7** 业务

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务 | 基本信息 | 名称 | Default\_Signalling\_Service |
   |  |  | 类型 | BASIC\_SERVICE |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 激活方式 | AF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 否  说明：  若业务激活方式为AF，但用户没有订购该业务，则需要将业务的参数“签约后才能使用”设置为“否”。 |
   |  | 策略 | 名称 | Default\_Signalling\_Policy  说明：  已在策略中定义。 |
9. 配置应用业务映射。

   导航入口为“业务管理 > 业务 > 应用业务映射”。

   配置AF激活的IMS用户注册业务时，必须配置应用业务映射。其中，“应用标识”必须和AF侧协商一致；“业务”为8中已定义的VoLTE业务。

   应用业务映射的数据规划如表8所示，详细参数说明请参见应用业务映射参数表。

   **表8** 应用业务映射

   | 类别 | 参数 | 取值样例 |
   | --- | --- | --- |
   | 应用业务映射 | 应用标识 | IMS\_Signalling  说明：  和AF中定义的应用标识协商一致。 |
   |  | 业务 | Default\_Signalling\_Service  说明：  已在业务中定义的由AF激活的业务（IMS用户注册业务）。 |

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
