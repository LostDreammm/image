---
id: ''
name: 登录“UPCF 业务管理”窗口
ne_type: UPCF
type: feature
description: UPCF“业务管理”界面用于执行UPCF的全局数据命令组和用户数据命令组的命令。
risk_level: ''
doc_source: ["参考（如命令、软参、测量指标、GUI等）","PGW Web LMT用户数据和全局数据管理","UPCF PGW Web LMT GUI参考","PGW Web LMT","登录“UPCF 业务管理”窗口"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UPCF“业务管理”界面用于执行UPCF的全局数据命令组和用户数据命令组的命令。

## 必备事项
前提条件

PGW Web LMT界面能正常登录和使用。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录PGW Web LMT。

#### 1.1 打开浏览器，在浏览器的地址栏输入地址**http://***PGW（Provisioning Gateway）服务IP地址*后按“Enter”键，打开网页，进入PGW Web LMT的登录界面。如图1所示。

#### **图1** PGW Web LMT登录界面

#### “PGW服务IP地址”为运营商规划数据，可以从运营商的操作维护人员处获得，也可以登录“USCDB MML命令”界面执行**LST SRVIPADDR**命令获得。

#### 登录PGW Web LMT界面的默认用户名和密码请参见《USCDB应用用户默认帐号》。

#### 1.2 选择“用户类型”，有如下两种登录方式，进入PGW Web LMT MML命令界面，如图2所示。

#### “用户类型”为“Local”时，在登录界面分别输入“用户名”、“密码”和“验证码”，单击“立即登录”。

#### “用户类型”为“SSO”时，单击“立即登录”，登录界面会跳转到网管登录界面，输入网管的“用户名”和“密码”，单击“登录”。

#### **图2** PGW Web LMT MML命令界面

#### 进入PGW Web LMT MML命令界面，系统默认登录“系统管理”界面。如图2所示。

### 2 登录UPCF“业务管理”界面。

### 在“MML导航树”下拉列表中选择“UPCF 业务管理”选项，系统进入UPCF业务管理界面，如图3所示。

### **图3** UPCF业务管理界面

