# 配置全局数据导出

* 操作场景
* 必备事项
* 操作步骤

#### 操作场景

全局数据需要定时备份，当配置出现问题时可以收集备份数据，便于对数据进行分析和回退。

* 本产品在提供数据导出功能时，将不可避免的使用用户的个人数据，如：IMSI等，因此您需遵循所适用国家的法律或贵公司的用户隐私政策并采取足够的措施，以确保用户的个人数据受到充分的保护。
* 建议每天凌晨5点导出全局数据（系统只保留最近10个导出文件）。
* 全局数据范围可以通过以下方式进行获取：

  登录UPCF WebUI界面，在左侧导航选择“系统管理>系统维护>配置使用率”，打开“配置使用率”窗口，查看全局数据范围。

#### 必备事项

**前提条件**

* 系统中已部署DMA（Data Management Agent）模块。

  可通过在“应用管理 > MML”中选择“USCDB”网元，执行**LST MODULE**命令查询。如未部署DMA模块，请执行**ADD MODULE**命令部署。
* 已经获取相应的“Export\_ADPPKG\_\*\*\*.tar”导出适配包，并保存在本地PC上。

  该适配包随版本发布，通过解压缩“UPCF\_2\*.\*\*\*.\*\*\*.\*\*\*\_PLUG.zip”后获取。

**数据**

该操作无需准备数据。

#### 操作步骤

1. 登录OM Portal，选择“系统 > 文件传输”，如图1所示。进入指定目录“CGPLite文件 > 软件包”，单击添加文件，将Export\_ADPPKG\_\*\*\*.tar适配包上传到该路径下。

   **图1** 选择文件传输
2. 在文件传输界面，选择“CGPLite文件 >网元文件”，查看是否有“ADAPTER”文件夹，如图2所示。

   * 有 -> 执行4加载导出适配包。
   * 没有 -> 执行3。

   **图2** 查看是否有“ADAPTER”文件夹
3. 单击“新建文件夹”，新建“ADAPTER”文件夹，如图3所示。

   **图3** 新建ADAPTER文件夹
4. 选择CSP网元，执行**LOD PKG**命令加载UPCF导出适配包，命令举例如下：

   ```
   LOD PKG: FNM="Export_ADPPKG_***.tar";
   ```

   LOD PKG执行后，操作员可通过**LST PKG**命令查看适配包是否加载成功。
5. 选择USCDB网元执行**LOD ADPPKG**命令加载UPCF导出适配包，命令举例如下：

   ```
   LOD ADPPKG: ADPPKGNAME="Export_ADPPKG_***.tar", PKGTYPE=EXPORT, SERVICETYPE="UPCF";
   ```

   LOD ADPPKG执行后，操作员可通过**LST ADPPKG**命令查看适配包是否加载成功。
6. 选择USCDB网元执行**STR INSTENV**命令创建策略数据全局表，命令举例如下：

   ```
   STR INSTENV: ENVTYPE=FESQL, SERVICETYPE="UPCF", OPTYPE=CREATE;
   ```

   该创建策略数据全局表信息步骤只需要在导出策略数据时执行。
7. 执行**LST SRVIPADDR**查看是否已配置DMA IP。

   * 如果有，执行9
   * 如果没有，执行8
8. 添加DMA IP。

   a.执行**ADD SRVIPADDR**添加DMA类型的IP，命令举例如下：

   ```
   //**如下命令实例中的"xx.xx.xx.xx"请替换为实际的IP地址**//
   ADD SRVIPADDR: SRVINDEX=3, SRVIPTYPE=DMA, DPUMID=19, IPVER=IPV4, IP1VPNNAME="VRF_CC_DATA", IPV4IP1="xx.xx.xx.xx", IPV4GW1="192.168.100.0", IPV4MASK1="255.255.255.255", IP2VPNNAME="VRF_CC_DATA1", IPV4IP2="xx.xx.xx.xx", IPV4GW2="192.168.200.0", IPV4MASK2="255.255.255.255";
   ```

   b.执行**RST MODULE**复位DPU模块，命令举例如下：

   ```
   RST MODULE: MID=19, MT=DPU;
   ```
9. 添加导出任务。
   1. 登录PGW Web LMT MML命令界面。
   2. 应用类型选择“系统管理”。
   3. 执行**ADD EXPTASK**命令添加导出任务。

      命令举例如下：

      ```
      ADD EXPTASK: FETYPE="UPCF", TPLNAME="SQLPolicyDataTemplate", TASKTYPE=ONCE, SERVERNAME="ftpserver1;
      ```

      ```
      %%ADD EXPTASK: FETYPE="UPCF", TPLNAME="SQLPolicyDataTemplate", TASKTYPE=ONCE, SERVERNAME="ftpserver1";%% 
      RETCODE = 0 操作成功 任务ID：25. 使用DSP EXPTASK指令可查看此导出任务的执行情况

      There is together 1 report

      --- END
      ```

      * “TPLNAME”为本次任务需要导出的模板的名称。
      * “SERVERNAME”用于指定导出文件上传到远端FTP/SFTP服务器的服务器名称。该参数必须通过OM Portal的**ADD RFTPSERVER**或**ADD RSFTPSERVER**命令定义后才可使用。该参数是联想参数，不能手动输入，必须选择已配置的FTP/SFTP服务器。**ADD RFTPSERVER**命令举例如下：

        ```
        //**如下命令实例中的"xx.xx.xx.xx"请替换为实际的IP地址**//
        ADD RFTPSERVER: SERVERTYPE=DATAMTN, SERVERNAME="ftpserver1", IPVER=IPV4, SERVERIPV4="xx.xx.xx.xx", SERVERPORT=21, USERNAME="root", PWD="*****", CFM="*****", RWORKDIR="realtime", LWORKDIR="UPLOADEXPORTFILE", TRANSDIRECTION=UPLOAD, LOCALIPV4="xx.xx.xx.xx";
        ```

        选择用户数据导出模板，增加数据导出任务后，DMA开始导出UPCF用户数据。
10. 查询导出任务状态。
    1. 等待导出任务开始后，执行**DSP EXPTASK**命令查询导出任务状态。

       命令举例如下：

       ```
       DSP EXPTASK: TASKID=25, FETYPE="UPCF";
       ```

       ```
       %%DSP EXPTASK: TASKID=25, FETYPE="UPCF";%%
       RETCODE = 0 Operation is successful
       <TASK ID>   <Service type>   <Status>         <Task type>      <Export file number>   <Successfully exported number>   <Failed exported number>   <Cycle unit>     <Cycle value>    <Correlation ID>   <Export time>        <Start time>         <Upload time>        <Finish time>        <MML CMD> 25           UPCF             COMPLETED        ONCE             1                      41                               0                          NULL             0                0                                       2021-09-03 03:49:02  2021-09-03 03:49:07  2021-09-03 03:49:12  /*HWHandle=386*/ADD EXPTASK: FETYPE="UPCF", TPLNAME="SQLPolicyDataTemplate", TASKTYPE=ONCE, SERVERNAME="ftpserver1";  

       Total count = 1  

       There is together 1 report  

       ---    END
       ```

       “TASK ID”为9.c中返回的任务ID。
    2. 根据返回报文中的“任务状态”的取值，判断导出任务已完成。
11. 下载结果文件。
    1. 登录FTP服务器。
    2. 在FTP服务器中选择通过**ADD RFTPSERVER**命令配置的“RWORKDIR”的路径。检查该路径下是否有导出的结果文件。

       导出结果文件命名方式：“OK\_METYPE\_TASKID\_TIME\_\*\_PCRF.PolicyData.zip”，其中“OK”标识文件上传成功，“METYPE”为网元类型，“TASKID”为9.c中返回的任务ID（即本次导出任务的任务ID），“TIME”为导出的时间点，“\*”为导出结果文件的序号。
    3. 在“本地目录”中选择需要下载的目标位置。
    4. 右键选中该文件，选择“下载”。
12. 解压下载的结果文件，查看文件格式是否为SQL格式。

    SQL格式文件命名方式：“METYPE\_TASKID\_TIME\_\*\_PCRF.PolicyData.dat”，其中“METYPE”为网元类型，“TASKID”为9.c中返回的任务ID（即本次导出任务的任务ID），“TIME”为导出的时间点，“\*”为导出结果文件的序号。

版权所有 © 华为技术有限公司
