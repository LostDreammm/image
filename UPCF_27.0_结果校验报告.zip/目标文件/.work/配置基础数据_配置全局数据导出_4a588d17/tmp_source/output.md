---
id: ''
name: 配置全局数据导出
ne_type: UPCF
type: feature
description: 全局数据需要定时备份，当配置出现问题时可以收集备份数据，便于对数据进行分析和回退。  * 本产品在提供数据导出功能时，将不可避免的使用用户的个人数据，如：IMSI等，因此您需遵循所适用国家的法律或贵公司的用户隐私政策并采取足够的措施，以确保用户的个人数据受到充分的保护。 * 建议每天凌晨5点导出全局数据（系统只保留最近10个导出文件）。 * 全局数据范围可以通过以下方式进行获取：    登录UPCF WebUI界面，在左侧导航选择“系统管理>系统维护>配置使用率”，打开“配置使用率”窗口，查看全局数据范围。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（非SDN）","配置基础数据","配置全局数据导出"]
refs: []
metadata:
  DepOnLiveCfg: true
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
全局数据需要定时备份，当配置出现问题时可以收集备份数据，便于对数据进行分析和回退。* 本产品在提供数据导出功能时，将不可避免的使用用户的个人数据，如：IMSI等，因此您需遵循所适用国家的法律或贵公司的用户隐私政策并采取足够的措施，以确保用户的个人数据受到充分的保护。* 建议每天凌晨5点导出全局数据（系统只保留最近10个导出文件）。* 全局数据范围可以通过以下方式进行获取：  登录UPCF WebUI界面，在左侧导航选择“系统管理>系统维护>配置使用率”，打开“配置使用率”窗口，查看全局数据范围。

## 必备事项
前提条件

* 系统中已部署DMA（Data Management Agent）模块。

  可通过在“应用管理 > MML”中选择“USCDB”网元，执行**LST MODULE**命令查询。如未部署DMA模块，请执行**ADD MODULE**命令部署。
* 已经获取相应的“Export\_ADPPKG\_\*\*\*.tar”导出适配包，并保存在本地PC上。

  该适配包随版本发布，通过解压缩“UPCF\_2\*.\*\*\*.\*\*\*.\*\*\*\_PLUG.zip”后获取。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    lod_pkg_list:
      type: items
      properties:
        FNM:
          name: '文件名称'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    lod_adppkg_list:
      type: items
      properties:
        ADPPKGNAME:
          name: '适配包名称'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PKGTYPE:
          name: '适配包加载类型'
          type: string
          enum:
          - EXPORT
          - IMPORT
          - MIGRATE
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICETYPE:
          name: '服务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_export_policy_data:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '选择USCDB网元执行**STR INSTENV**命令创建策略数据全局表，命令举例如下：'
      data_source: ''
      pattern: ''
      default: TRUE
    str_instenv_list:
      type: items
      properties:
        ENVTYPE:
          name: '安装环境类型'
          type: string
          enum:
          - LocalDisk
          - FESQL
          - SINGLEDB
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICETYPE:
          name: '业务类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        OPTYPE:
          name: '操作类型'
          type: string
          enum:
          - CREATE
          - DELETE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_srvipaddr_list:
      type: items
      properties:
        SRVINDEX:
          name: '业务IP索引'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVIPTYPE:
          name: '业务IP类型'
          type: string
          enum:
          - DSG
          - PGW
          - DMA
          - PRV
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DPUMID:
          name: 'DPU模块号'
          type: integer
          minimum: 1
          maximum: 4080
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP1VPNNAME:
          name: 'IP地址1的VPN名称'
          type: string
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP1:
          name: '本地Location IPV4地址1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW1:
          name: '本地Location IPV4网关1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK1:
          name: '本地Location IPV4子网掩码1'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IP2VPNNAME:
          name: 'IP地址2的VPN名称'
          type: string
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4IP2:
          name: '本地Location IPV4地址2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4GW2:
          name: '本地Location IPV4网关2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV4MASK2:
          name: '本地Location IPV4子网掩码2'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW1:
          name: '本地Location IPV6网关1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6GW2:
          name: '本地Location IPV6网关2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP1:
          name: '本地Location IPV6地址1'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6IP2:
          name: '本地Location IPV6地址2'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK1:
          name: '本地Location IPV6前缀长度1'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPV6MASK2:
          name: '本地Location IPV6前缀长度2'
          type: integer
          minimum: 1
          maximum: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPQOSVALUE:
          name: 'IP QoS值'
          type: string
          enum:
          - BIT0
          - BIT1
          - BIT2
          - BIT3
          - BIT4
          - BIT5
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVICETYPE:
          name: '业务类型'
          type: string
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    rst_module_list:
      type: items
      properties:
        MID:
          name: '模块号'
          type: integer
          minimum: 1
          maximum: 4080
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MT:
          name: '模块类型'
          type: string
          enum:
          - DPU
          - NDF
          - DBG
          - DSG
          - DRU
          - DSU
          - PGW
          - DMA
          - CAG
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_exptask_list:
      type: items
      properties:
        FETYPE:
          name: 'FETYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TPLNAME:
          name: 'TPLNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TASKTYPE:
          name: 'TASKTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVERNAME:
          name: 'SERVERNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_rftpserver_list:
      type: items
      properties:
        SERVERTYPE:
          name: '远端服务器类型'
          type: string
          enum:
          - PROV
          - DATAMTN
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVERNAME:
          name: '远端服务器名称'
          type: string
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP类型'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVERIPV4:
          name: '服务端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVERPORT:
          name: '服务端端口'
          type: integer
          minimum: 1
          maximum: 65535
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USERNAME:
          name: '用户名称'
          type: string
          maxLength: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PWD:
          name: '密码'
          type: string
          maxLength: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CFM:
          name: '确认密码'
          type: string
          maxLength: 31
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        RWORKDIR:
          name: 'FTP远端工作目录'
          type: string
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LWORKDIR:
          name: 'FTP本端工作目录'
          type: string
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TRANSDIRECTION:
          name: '传输方向'
          type: string
          enum:
          - UPLOAD
          - DOWNLOAD
          - TIMDOWNLOAD
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LOCALIPV4:
          name: '本端IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        LOCALIPV6:
          name: '本端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SERVERIPV6:
          name: '服务端IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FILTER:
          name: '过滤条件'
          type: string
          maxLength: 63
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        BACKUPFLAG:
          name: '是否备份标示'
          type: string
          enum:
          - YES
          - NO
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        CYCLE:
          name: '获取周期'
          type: string
          maxLength: 15
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DELFILEFLAG:
          name: '删除文件标示'
          type: string
          enum:
          - YES
          - NO
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ENDTIME:
          name: '结束时间'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: 'HH&MM&SS'
        STRTIME:
          name: '开始时间'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: 'HH&MM&SS'
  examples:
  - lod_pkg_list:
    - FNM: 'Export_ADPPKG_***.tar'
    lod_adppkg_list:
    - ADPPKGNAME: 'Export_ADPPKG_***.tar'
      PKGTYPE: EXPORT
      SERVICETYPE: 'UPCF'
    is_scenario_export_policy_data: TRUE
    str_instenv_list:
    - ENVTYPE: FESQL
      SERVICETYPE: 'UPCF'
      OPTYPE: CREATE
    add_srvipaddr_list:
    - SRVINDEX: 3
      SRVIPTYPE: DMA
      DPUMID: 19
      IPVER: IPV4
      IP1VPNNAME: 'VRF_CC_DATA'
      IPV4IP1: 'xx.xx.xx.xx'
      IPV4GW1: '192.168.100.0'
      IPV4MASK1: '255.255.255.255'
      IP2VPNNAME: 'VRF_CC_DATA1'
      IPV4IP2: 'xx.xx.xx.xx'
      IPV4GW2: '192.168.200.0'
      IPV4MASK2: '255.255.255.255'
      IPV6GW1: ''
      IPV6GW2: ''
      IPV6IP1: ''
      IPV6IP2: ''
      IPV6MASK1: ''
      IPV6MASK2: ''
      IPQOSVALUE: ''
      SERVICETYPE: ''
    rst_module_list:
    - MID: 19
      MT: DPU
    add_exptask_list:
    - FETYPE: UPCF
      TPLNAME: SQLPolicyDataTemplate
      TASKTYPE: ONCE
      SERVERNAME: '"ftpserver1'
    add_rftpserver_list:
    - SERVERTYPE: DATAMTN
      SERVERNAME: 'ftpserver1'
      IPVER: IPV4
      SERVERIPV4: 'xx.xx.xx.xx'
      SERVERPORT: 21
      USERNAME: 'root'
      PWD: '*****'
      CFM: '*****'
      RWORKDIR: 'realtime'
      LWORKDIR: 'UPLOADEXPORTFILE'
      TRANSDIRECTION: UPLOAD
      LOCALIPV4: 'xx.xx.xx.xx'
      LOCALIPV6: ''
      SERVERIPV6: ''
      FILTER: ''
      BACKUPFLAG: ''
      CYCLE: ''
      DELFILEFLAG: ''
      ENDTIME: 'HH&MM&SS'
      STRTIME: 'HH&MM&SS'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录OM Portal，选择“系统 > 文件传输”，如图1所示。进入指定目录“CGPLite文件 > 软件包”，单击添加文件，将Export\_ADPPKG\_\*\*\*.tar适配包上传到该路径下。

### **图1** 选择文件传输

### 2 在文件传输界面，选择“CGPLite文件 >网元文件”，查看是否有“ADAPTER”文件夹，如图2所示。

### 有 -> 执行4加载导出适配包。

### 没有 -> 执行3。

### **图2** 查看是否有“ADAPTER”文件夹

### 3 单击“新建文件夹”，新建“ADAPTER”文件夹，如图3所示。

### **图3** 新建ADAPTER文件夹

### 4 选择CSP网元，执行**LOD PKG**命令加载UPCF导出适配包，命令举例如下：

```jinja2
{%- for item in lod_pkg_list -%}
    LOD PKG:
    {#- --- 必选参数 --- -#}
    FNM="{{item.FNM}}",
    ;
{%- endfor -%}
```

### LOD PKG执行后，操作员可通过**LST PKG**命令查看适配包是否加载成功。

### 5 选择USCDB网元执行**LOD ADPPKG**命令加载UPCF导出适配包，命令举例如下：

```jinja2
{%- for item in lod_adppkg_list -%}
    LOD ADPPKG:
    {#- --- 必选参数 --- -#}
    ADPPKGNAME="{{item.ADPPKGNAME}}",
    PKGTYPE={{item.PKGTYPE}},
    SERVICETYPE="{{item.SERVICETYPE}}",
    ;
{%- endfor -%}
```

### LOD ADPPKG执行后，操作员可通过**LST ADPPKG**命令查看适配包是否加载成功。

### 6 选择USCDB网元执行**STR INSTENV**命令创建策略数据全局表，命令举例如下：

```jinja2
{%- if is_scenario_export_policy_data -%}
    {%- for item in str_instenv_list -%}
        STR INSTENV:
        {#- --- 必选参数 --- -#}
        ENVTYPE={{item.ENVTYPE}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：ENVTYPE=FESQL 时必选 --- -#}
        {%- if item.ENVTYPE == 'FESQL' -%}
            OPTYPE={{item.OPTYPE}},
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：ENVTYPE=FESQL 时可选 --- -#}
        {%- if item.ENVTYPE == 'FESQL' -%}
            {%- if item.SERVICETYPE is not none -%}
                SERVICETYPE="{{item.SERVICETYPE}}",
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

### 该创建策略数据全局表信息步骤只需要在导出策略数据时执行。

### 7 执行**LST SRVIPADDR**查看是否已配置DMA IP。

### 如果有，执行9

### 如果没有，执行8

### 8 添加DMA IP。

#### 8.1 a.执行**ADD SRVIPADDR**添加DMA类型的IP，命令举例如下：

##### 8.1.1 //**如下命令实例中的"xx.xx.xx.xx"请替换为实际的IP地址**//

```jinja2
{%- set LST_SRVIPADDR=getValueList('LST SRVIPADDR') -%}
{%- if not LST_SRVIPADDR -%}
    {%- for item in add_srvipaddr_list -%}
        ADD SRVIPADDR:
        {#- --- 必选参数 --- -#}
        SRVINDEX={{item.SRVINDEX}},
        SRVIPTYPE={{item.SRVIPTYPE}},
        IPVER={{item.IPVER}},
        {#- --- 条件必选参数 --- -#}
        {#- --- 条件必选：SRVIPTYPE=PGW/DMA 时必选 --- -#}
        {%- if item.SRVIPTYPE in ['PGW', 'DMA'] -%}
            DPUMID={{item.DPUMID}},
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4/IPV6 时必选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            IP1VPNNAME="{{item.IP1VPNNAME}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            IPV4IP1="{{item.IPV4IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6IP1="{{item.IPV6IP1}}",
        {%- endif -%}
        {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            IPV6MASK1={{item.IPV6MASK1}},
        {%- endif -%}
        {#- --- 条件必选：SRVIPTYPE=DSG 时必选 --- -#}
        {%- if item.SRVIPTYPE == 'DSG' -%}
            SERVICETYPE="{{item.SERVICETYPE}}",
        {%- endif -%}
        {#- --- 条件可选参数 --- -#}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW1 is not none -%}
                IPV4GW1="{{item.IPV4GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK1 is not none -%}
                IPV4MASK1="{{item.IPV4MASK1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4/IPV6 时可选 --- -#}
        {%- if item.IPVER in ['IPV4', 'IPV6'] -%}
            {%- if item.IP2VPNNAME is not none -%}
                IP2VPNNAME="{{item.IP2VPNNAME}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4IP2 is not none -%}
                IPV4IP2="{{item.IPV4IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4GW2 is not none -%}
                IPV4GW2="{{item.IPV4GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV4 时可选 --- -#}
        {%- if item.IPVER == 'IPV4' -%}
            {%- if item.IPV4MASK2 is not none -%}
                IPV4MASK2="{{item.IPV4MASK2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：SRVIPTYPE=PGW/DMA/PRV 时可选 --- -#}
        {%- if item.SRVIPTYPE in ['PGW', 'DMA', 'PRV'] -%}
            {%- if item.IPQOSVALUE is not none -%}
                IPQOSVALUE={{item.IPQOSVALUE}},
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW1 is not none -%}
                IPV6GW1="{{item.IPV6GW1}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6GW2 is not none -%}
                IPV6GW2="{{item.IPV6GW2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6IP2 is not none -%}
                IPV6IP2="{{item.IPV6IP2}}",
            {%- endif -%}
        {%- endif -%}
        {#- --- 条件可选：IPVER=IPV6 时可选 --- -#}
        {%- if item.IPVER == 'IPV6' -%}
            {%- if item.IPV6MASK2 is not none -%}
                IPV6MASK2={{item.IPV6MASK2}},
            {%- endif -%}
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 8.2 b.执行**RST MODULE**复位DPU模块，命令举例如下：

```jinja2
{%- if not LST_SRVIPADDR -%}
    {%- for item in rst_module_list -%}
        RST MODULE:
        {#- --- 必选参数 --- -#}
        MID={{item.MID}},
        MT={{item.MT}},
        ;
    {%- endfor -%}
{%- endif -%}
```

### 9 添加导出任务。

#### 9.1 登录PGW Web LMT MML命令界面。

#### 9.2 应用类型选择“系统管理”。

#### 9.3 执行**ADD EXPTASK**命令添加导出任务。

#### 命令举例如下：

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_exptask_list的变量区（command: ADD EXPTASK） -#}
<!-- MISSING_MACRO: command=ADD EXPTASK list_name=add_exptask_list step_id=9.3 -->
```

#### %%ADD EXPTASK: FETYPE="UPCF", TPLNAME="SQLPolicyDataTemplate", TASKTYPE=ONCE, SERVERNAME="ftpserver1";%%

#### RETCODE = 0 操作成功 任务ID：25. 使用DSP EXPTASK指令可查看此导出任务的执行情况

#### There is together 1 report

#### --- END

#### “TPLNAME”为本次任务需要导出的模板的名称。

#### “SERVERNAME”用于指定导出文件上传到远端FTP/SFTP服务器的服务器名称。该参数必须通过OM Portal的**ADD RFTPSERVER**或**ADD RSFTPSERVER**命令定义后才可使用。该参数是联想参数，不能手动输入，必须选择已配置的FTP/SFTP服务器。**ADD RFTPSERVER**命令举例如下：

##### 9.3.1 //**如下命令实例中的"xx.xx.xx.xx"请替换为实际的IP地址**//

```jinja2
{%- for item in add_rftpserver_list -%}
    ADD RFTPSERVER:
    {#- --- 必选参数 --- -#}
    SERVERTYPE={{item.SERVERTYPE}},
    SERVERNAME="{{item.SERVERNAME}}",
    IPVER={{item.IPVER}},
    SERVERPORT={{item.SERVERPORT}},
    USERNAME="{{item.USERNAME}}",
    PWD="{{item.PWD}}",
    CFM="{{item.CFM}}",
    RWORKDIR="{{item.RWORKDIR}}",
    LWORKDIR="{{item.LWORKDIR}}",
    TRANSDIRECTION={{item.TRANSDIRECTION}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        SERVERIPV4="{{item.SERVERIPV4}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        LOCALIPV4="{{item.LOCALIPV4}}",
    {%- endif -%}
    {#- --- 条件必选：TRANSDIRECTION=TIMDOWNLOAD 时必选 --- -#}
    {%- if item.TRANSDIRECTION == 'TIMDOWNLOAD' -%}
        ENDTIME={{item.ENDTIME}},
    {#- --- 条件必选：TRANSDIRECTION=TIMDOWNLOAD 时必选 --- -#}
    {%- elif item.TRANSDIRECTION == 'TIMDOWNLOAD' -%}
        ENDTIME={{item.ENDTIME}},
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        LOCALIPV6="{{item.LOCALIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        SERVERIPV6="{{item.SERVERIPV6}}",
    {%- endif -%}
    {#- --- 条件必选：TRANSDIRECTION=TIMDOWNLOAD 时必选 --- -#}
    {%- if item.TRANSDIRECTION == 'TIMDOWNLOAD' -%}
        STRTIME={{item.STRTIME}},
    {#- --- 条件必选：TRANSDIRECTION=TIMDOWNLOAD 时必选 --- -#}
    {%- elif item.TRANSDIRECTION == 'TIMDOWNLOAD' -%}
        STRTIME={{item.STRTIME}},
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：TRANSDIRECTION=UPLOAD 时可选 --- -#}
    {%- if item.TRANSDIRECTION == 'UPLOAD' -%}
        {%- if item.BACKUPFLAG is not none -%}
            BACKUPFLAG={{item.BACKUPFLAG}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：TRANSDIRECTION=DOWNLOAD 时可选 --- -#}
    {%- if item.TRANSDIRECTION == 'DOWNLOAD' -%}
        {%- if item.CYCLE is not none -%}
            CYCLE="{{item.CYCLE}}",
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：TRANSDIRECTION=DOWNLOAD 时可选 --- -#}
    {%- if item.TRANSDIRECTION == 'DOWNLOAD' -%}
        {%- if item.DELFILEFLAG is not none -%}
            DELFILEFLAG={{item.DELFILEFLAG}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：SERVERTYPE=PROV 时可选 --- -#}
    {%- if item.SERVERTYPE == 'PROV' -%}
        {%- if item.FILTER is not none -%}
            FILTER="{{item.FILTER}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 选择用户数据导出模板，增加数据导出任务后，DMA开始导出UPCF用户数据。

### 10 查询导出任务状态。

#### 10.1 等待导出任务开始后，执行**DSP EXPTASK**命令查询导出任务状态。

#### 命令举例如下：

#### %%DSP EXPTASK: TASKID=25, FETYPE="UPCF";%%

#### RETCODE = 0 Operation is successful

#### <TASK ID> <Service type> <Status> <Task type> <Export file number> <Successfully exported number> <Failed exported number> <Cycle unit> <Cycle value> <Correlation ID> <Export time> <Start time> <Upload time> <Finish time> <MML CMD> 25 UPCF COMPLETED ONCE 1 41 0 NULL 0 0 2021-09-03 03:49:02 2021-09-03 03:49:07 2021-09-03 03:49:12 /*HWHandle=386*/ADD EXPTASK: FETYPE="UPCF", TPLNAME="SQLPolicyDataTemplate", TASKTYPE=ONCE, SERVERNAME="ftpserver1";

#### Total count = 1

#### There is together 1 report

#### ---    END

#### “TASK ID”为9.c中返回的任务ID。

#### 10.2 根据返回报文中的“任务状态”的取值，判断导出任务已完成。

### 11 下载结果文件。

#### 11.1 登录FTP服务器。

#### 11.2 在FTP服务器中选择通过**ADD RFTPSERVER**命令配置的“RWORKDIR”的路径。检查该路径下是否有导出的结果文件。

#### 导出结果文件命名方式：“OK\_METYPE\_TASKID\_TIME\_\*\_PCRF.PolicyData.zip”，其中“OK”标识文件上传成功，“METYPE”为网元类型，“TASKID”为9.c中返回的任务ID（即本次导出任务的任务ID），“TIME”为导出的时间点，“\*”为导出结果文件的序号。

#### 11.3 在“本地目录”中选择需要下载的目标位置。

#### 11.4 右键选中该文件，选择“下载”。

### 12 解压下载的结果文件，查看文件格式是否为SQL格式。

### SQL格式文件命名方式：“METYPE\_TASKID\_TIME\_\*\_PCRF.PolicyData.dat”，其中“METYPE”为网元类型，“TASKID”为9.c中返回的任务ID（即本次导出任务的任务ID），“TIME”为导出的时间点，“\*”为导出结果文件的序号。

