# 配置CSLB基础数据（非SDN，基于IPv4场景+静态路由+BGP+单臂BFD方式）

* 操作场景
* 必备事项
* 操作流程
* 操作步骤
* 验证方法

## 操作场景

CSLB（Cloud Session Load Balancer）云虚拟化环境下的业务负载均衡，除支持基于IP/TCP/UDP数据流的负载均衡技术外，针对3GPP业务特点，同时支持基于用户和会话的负载均衡技术。CSLB在IP汇聚层，用于L3（IP层）和L4（TCP/SCTP/UDP）的消息转发和负载均衡处理。开局时，需要配置CSLB微服务的基础数据。

BGP（Border Gateway Protocol）边界网关协议是一种用于AS（Autonomous System）之间的动态路由协议，其自身不能发现和计算路由，主要用于在自治系统AS间控制路由的传播和选择最佳路由，当网络结构复杂且无法规划在同一自治区域内时，可以采用配置BGP平面数据实现VNF与对端设备的网络层互通。

非SDN组网场景下，CSLB支持静态路由、OSPF、静态路由+BGP+非单臂BFD或静态路由+BGP+单臂BFD四种方式进行配置。

本章介绍非SDN组网场景下，基于静态路由+BGP+单臂BFD规划进行CSLB基础数据配置。根据数据配置范例，可依次完成FE及BE规划的各VRF配置。

## 必备事项

前提条件

执行操作前准备工作如下：

* 已完成软件安装。
* 已经获取运营商规划的IP地址。
* 已经完成交换机网络配置检查。

数据

* 已获取OM Portal的IP地址以及登录OM Portal的用户名及密码。
* 执行操作前规划的数据如表1和表2所示。

  进行操作前，用户可以获取到其他局点已经完成CSLB配置的脚本，然后对照网设LLD文档、VNFD文件，只对如下表格中的数据进行现场修改，导入即可。

  **表1** CSLB基础数据规划（UPCF侧）

  | 类别 | 参数名称 | 取值样例 | 说明 |
  | --- | --- | --- | --- |
  | **SET AUTOCONFIG** | SWITCHFLAG（自动配置开关） | + FALSE + TRUE | 设置自动化配置开关。  + 配置基础数据前，选择“FALSE”关闭自动配置。 + 完成数据配置后，选择“TRUE”打开自动配置。 |
  | **ADD L3VPNINST** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 增加L3VPN实例，FE各VPN实例含义如下：  + VRF\_CC\_DATA：FE/BE对接数据平面。 + VRF\_CC\_DIAMETER：4G信令平面。 + VRF\_CC\_SBI：5G信令平面。 + VRF\_CC\_OM：PMS策略维护平面。 |
  | **ADD VPNINSTAF** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 增加L3VPN实例地址族，VPN实例名称应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | AFTYPE（地址族类型） | ipv4uni | 表示L3VPN实例地址族类型。 |
  | **ADD INTERFACE** | IFNAME（接口名） | Loopback13 | 该参数用于指定接口名称。 |
  |  | IFADMINSTATUS（管理状态） | up | 该参数用于设置该接口的管理状态。 |
  | **ADD IPBINDVPN** | IFNAME（接口名） | Loopback13 | 该参数用于表示绑定VPN的接口名。需先由**ADD INTERFACE**命令定义后才能引用。 |
  |  | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 该参数用于指定接口绑定的VPN实例名称。需先由**ADD L3VPNINST**命令定义后才能在此引用。 |
  | **ADD IFIPV4ADDRESS** | IFNAME（接口名） | Loopback13 | 该参数用于指定需要配置IP地址的接口名称。需先由**ADD INTERFACE**命令定义后才能引用。 |
  |  | IFIPADDR（IPv4地址） | + 10.32.34.19 + 10.33.34.19 + 10.34.34.19 + 10.35.34.19 | 该参数用于指定需要配置的接口IP地址。 |
  |  | SUBNETMASK（IPv4地址掩码） | 255.255.255.255 | 该参数用于指定需要配置的接口IPv4地址的网络掩码。 |
  | **SET BGP** | BGPENABLE（使能BGP） | TRUE | 用于创建BGP协议并设置BGP协议参数。使能BGP，配置为TRUE支持BGP，本端规划。 |
  |  | ASNUM（BGP自治域号） | 64631 | 当“使能BGP”配置为“TRUE”时，该参数继续配置，用于标识BGP自治域号。 |
  | **ADD BGPVRF** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 用于标识VPN实例名称，根据不同进程，填写对应VPN实例名称，应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | DEFAULTAFTYPE（默认地址族） | ipv4uni | 该参数用于指定该VPN默认的地址族类型。 |
  |  | ROUTERID（路由器ID） | + 10.32.34.19 + 10.33.34.19 + 10.34.34.19 + 10.35.34.19 | 该参数用于指定BGP VPN实例的路由器ID。 |
  | **MOD BGPVRFAF** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | VPN实例名称应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | AFTYPE（地址族类型） | ipv4uni | 参考LLD中的路由设计进行配置。 |
  |  | MAXIMUMLOADBALANCE（最大等价路由数） | 2 | 固定取值。 |
  | **ADD BGPPEER** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 该参数用于指定用户所配置的VPN实例名称，需先由**ADD L3VPNINST**命令定义后才能在此引用。 |
  |  | ADDRESSTYPE（地址类型） | ipv4 | 该参数用于指定对等体的地址类型。当该参数配置为noaf时，VRFNAME不能为\_public\_。 |
  |  | PEERADDR（IPv4对等体地址） | + 10.10.34.19 + 10.10.34.20 | 该参数在“ADDRESSTYPE”配置为“noaf” 或 “ipv4”时为必选参数。 该参数用于指定连接对等体的IPv4接口地址。此处IP为在LLD网设里BFD设计中的VPN名称所对应的BFD IP。 |
  |  | REMOTEAS（对等体AS号） | 100 | 该参数在“ADDRESSTYPE”配置为“noaf”、“ipv4” 或 “ipv6”时为可选参数。该参数用于指定对等体所在AS号，参考LLD中“路由设计”页签。 |
  |  | LOCALIFNAME（本地接口名称） | Loopback13 | 该参数在“ADDRESSTYPE”配置为“noaf”、“ipv4” 或 “ipv6”时为可选参数。该参数用于指定与对等体相连的本地接口名称。 |
  |  | EBGPMAXHOP（EBGP最大跳数） | 100 | 该参数在“ADDRESSTYPE”配置为“noaf”、“ipv4” 或 “ipv6”时为可选参数。该参数用于指定BGP同非直连网络上的对等体建立EBGP连接时允许的最大跳数。 |
  | **ADD IMPORTROUTE** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 该参数用于指定BGP VPN实例，需先由**ADD L3VPNINST**命令定义后才能在此引用。 |
  |  | AFTYPE（地址族类型） | ipv4uni | 该参数用于指定BGP VPN实例下的地址族。 |
  |  | IMPORTPROTOCOL（路由协议） | wlr | 用户设定引入其他协议路由时的策略名称。 |
  | **ADD AUTOSCALINGSERVICE** | SERVICENAME（服务名称） | \_\_cslb\_service\_1\_\_ | 增加自动部署参数，服务名称**\_\_cslb\_service***\_X\_***\_**为固定格式，必须按照此格式进行配置。 |
  |  | VPNNAME（VPN实例名称） | VRF\_CC\_DATA | 用于标识VPN实例名称，根据不同服务名称，填写对应VPN实例名称，应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | AFTYPE（地址族） | IPv4 | 用于标识地址族，应与**ADD VPNINSTAF**中“VPN实例名称（VRFNAME）”的“AFTYPE（地址族）”一致。  当“AFTYPE（地址族）”为“IPv4”时，才会规划：  + IPv4地址分配方式 + （IPv4）起始地址 + （IPv4）结束地址 + （IPv4）掩码长度 当“AFTYPE（地址族）”为“IPv6”时，才会规划：  + IPv6地址分配方式 + （IPv6）起始地址 + （IPv6）结束地址 + （IPv6）掩码长度 |
  |  | IPALLOCTYPE4（IPv4地址分配方式） | USER\_CONFIG | 用于指定IPv4地址分配方式。 |
  |  | AUTOCFGIFTYPE（自动化配置接口类型） | VNIC | 本端规划，默认选择“VNIC(虚拟网卡)”。 |
  |  | VNICID（虚拟网卡ID） | VPN实例为VRF\_CC\_DATA时，该参数设置为：4 | 用于标识虚拟网卡ID，来自LLD文件中的“业务IP设计”页签，根据不同的VPN网络选择对应的vNIC ID。 |
  |  | VLANID（VLAN ID） | 1030 | 来自LLD文件中的“逻辑网络设计”页签，根据不同的VPN网络选择对应的VLAN ID。 |
  |  | BEGINADDR4（起始地址） | 10.0.30.2 | 仅当本命令中“IPv4地址分配方式（IPALLOCTYPE4）”设置为“用户配置方式”时，该参数有效，用于标识IPv4地址的起始地址。 |
  |  | ENDADDR4（结束地址） | 10.0.30.254 | 仅当本命令中“IPv4地址分配方式（IPALLOCTYPE4）”设置为“用户配置方式”时，该参数有效，用于标识IPv4地址的结束地址。 |
  |  | MASKLEN（地址池掩码长度） | 24 | 仅当本命令中“IPv4地址分配方式（IPALLOCTYPE4）”设置为“用户配置方式”时，该参数有效，用于标识IPv4地址的掩码长度。 |
  |  | OSPFENABLE（使能OSPF） | FALSE | 使用BGP路由方式，关闭接口OSPF使能。 |
  |  | TPINENABLE（使能入方向的流量策略） | FALSE | 该参数用于指定是否使能入方向的流量策略。 |
  |  | TPOUTENABLE（使能出方向的流量策略） | FALSE | 该参数用于指定是否使能出方向的流量策略。 |
  |  | FLOWMODE（引流模式） | FLOW\_MODE\_TYPE\_ROUTE | 该参数用于指定引流模式。该引流模式用于配置接口的WLR业务引流重定向功能。配置引流表模式时将接口收到的来自DPU的报文与WLR引流表进行匹配，如果匹配成功，则将报文引流到CSLB\_VNFC中进行处理；否则，再查找路由表转发报文。配置路由模式时仅匹配路由表进行报文引流。 |
  |  | OSPFGRPENABLE（使能OSPF进程组） | FALSE | 该参数在“OSPFENABLE”配置为“FALSE”时为可选参数。 |
  | **SET BFD** | BFDENABLE（BFD使能标志） | TRUE | 控制BFD全局使能或是全局去使能。本端规划。 |
  | **ADD AUTOSCALINGBFD** | TEMPLATENAME（模板名称） | VRF\_CC\_DATA | 在本端定义一个BFD模板。建议命名复用VRF实例名称，便于整个配置脚本的易读性和后续维护。 |
  |  | SERVICENAME（服务名称） | \_\_cslb\_service\_1\_\_ | 用于表示接口自动化配置服务模板名称。需要与配置UPCF基础数据中**ADD AUTOSCALINGSERVICE**命令配置的“服务名称（SERVICENAME）”参数保持一致。 |
  |  | BFDTYPE（BFD类型） | Static | 配置BFD类型，请根据LLD的路由设计进行配置。 |
  |  | IPVERSION（IP版本） | IPv4 | 与上述配置中的IP地址类型保持一致。 |
  |  | DESTADDR4（目的地址） | 10.10.34.1 | 指定下一跳的网关地址，请根据LLD的路由设计进行配置。 |
  | **ADD AUTOSCALINGSRROUTE** | 服务名称（SERVICENAME） | \_\_cslb\_service\_1\_\_ | 用于标识VPN实例名称，根据不同服务名称，填写对应VPN实例名称，应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | VPN实例名称（VRFNAME） | VRF\_CC\_DATA | 用于标识VPN实例名称，根据不同服务名称，填写对应VPN实例名称，应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | 地址族（IPVERSION） | IPv4 | 本端规划。 |
  |  | 路由前缀IPv4（PREFIX4） | + 10.10.34.19 + 10.10.34.20 + 0.0.0.0 | 本端规划。 |
  |  | 路由掩码长度（MASKLENGTH） | 0 | 本端规划。 |
  |  | IPv4路由下一跳分配方式（NEXTHOPALLOCTYPE4） | CONFIG | 表示手动指定配置下一跳地址。 |
  |  | 路由下一跳IPv4（NEXTHOP4） | 10.10.34.1 | 指定下一跳的网关地址，参考LLD中的路由设计进行配置。 |
  |  | BFD使能标识（BFDENABLE） | TRUE | 开启BFD使能。 |
  |  | BFDTEMPLATENAME（BFD模板名称） | VRF\_CC\_DATA | 由**ADD AUTOSCALINGBFD**的“TEMPLATENAME（模板名称）”进行配置，并在此进行引用。 |

  **表2** CSLB基础数据规划（USCDB侧）

  | 类别 | 参数名称 | 取值样例 | 说明 |
  | --- | --- | --- | --- |
  | **SET AUTOCONFIG** | SWITCHFLAG（自动配置开关） | + FALSE + TRUE | 设置自动化配置开关。  + 配置基础数据前，选择“FALSE”关闭自动配置。 + 完成数据配置后，选择“TRUE”打开自动配置。 |
  | **ADD L3VPNINST** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 增加L3VPN实例，BE各VPN实例含义如下：  + VRF\_CC\_DATA：FE/BE对接数据平面。 + VRF\_CC\_OM：PGW Web LMT维护平面。 + VRF\_CC\_Provisioning：业务发放平面。 |
  | **ADD VPNINSTAF** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 增加L3VPN实例地址族，VPN实例名称应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | AFTYPE（地址族类型） | ipv4uni | 表示L3VPN实例地址族类型。 |
  | **ADD INTERFACE** | IFNAME（接口名） | Loopback9 | 该参数用于指定接口名称。 |
  |  | IFADMINSTATUS（管理状态） | up | 该参数用于设置该接口的管理状态。 |
  | **ADD IPBINDVPN** | IFNAME（接口名） | Loopback9 | 该参数用于表示绑定VPN的接口名。需先由**ADD INTERFACE**命令定义后才能引用。 |
  |  | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 该参数用于指定接口绑定的VPN实例名称。VPN实例名称应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  | **ADD IFIPV4ADDRESS** | IFNAME（接口名） | Loopback9 | 该参数用于指定需要配置IP地址的接口名称。需先由**ADD INTERFACE**命令定义后才能引用。 |
  |  | IFIPADDR（IPv4地址） | + 10.32.34.19 + 10.32.35.19 + 10.32.36.19 | 该参数用于指定需要配置的接口IP地址。 |
  |  | SUBNETMASK（IPv4地址掩码） | 255.255.255.255 | 该参数用于指定需要配置的接口IPv4地址的网络掩码。 |
  | **SET BGP** | BGPENABLE（使能BGP） | TRUE | 用于创建BGP协议并设置BGP协议参数。使能BGP，配置为TRUE支持BGP，本端规划。 |
  |  | ASNUM（BGP自治域号） | 64631 | 当“使能BGP”配置为“TRUE”时，该参数继续配置，用于标识BGP自治域号。 |
  | **ADD BGPVRF** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 该参数用于指定BGP VPN实例。VPN实例名称应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）””一致。 |
  |  | DEFAULTAFTYPE（默认地址族） | ipv4uni | 该参数用于指定该VPN默认的地址族类型。 |
  |  | ROUTERID（路由器ID） | 10.32.34.19 | 该参数用于指定BGP VPN实例的路由器ID。 |
  | **MOD BGPVRFAF** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | VPN实例名称应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | AFTYPE（地址族类型） | ipv4uni | 参考LLD中的路由设计进行配置。 |
  |  | MAXIMUMLOADBALANCE（最大等价路由数） | 2 | 固定取值。 |
  | **ADD BGPPEER** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 该参数用于指定用户所配置的VPN实例名称，VPN实例名称应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | ADDRESSTYPE（地址类型） | ipv4 | 该参数用于指定对等体的地址类型。当该参数配置为noaf时，VRFNAME不能为\_public\_。 |
  |  | PEERADDR（IPv4对等体地址） | + 10.10.34.19 + 10.10.34.20 | 该参数在“ADDRESSTYPE”配置为“noaf” 或 “ipv4”时为必选参数。 该参数用于指定连接对等体的IPv4接口地址。此处IP为在LLD网设里BFD设计中的VPN名称所对应的BFD IP。 |
  |  | REMOTEAS（对等体AS号） | 100 | 该参数在“ADDRESSTYPE”配置为“noaf”、“ipv4” 或 “ipv6”时为可选参数。该参数用于指定对等体所在AS号，参考LLD中“路由设计”页签。 |
  |  | LOCALIFNAME（本地接口名称） | Loopback9 | 该参数在“ADDRESSTYPE”配置为“noaf”、“ipv4” 或 “ipv6”时为可选参数。该参数用于指定与对等体相连的本地接口名称。 |
  |  | EBGPMAXHOP（EBGP最大跳数） | 100 | 该参数在“ADDRESSTYPE”配置为“noaf”、“ipv4” 或 “ipv6”时为可选参数。该参数用于指定BGP同非直连网络上的对等体建立EBGP连接时允许的最大跳数。 |
  | **ADD IMPORTROUTE** | VRFNAME（VPN实例名称） | VRF\_CC\_DATA | 该参数用于指定BGP VPN实例，需先由**ADD L3VPNINST**命令定义后才能在此引用。 |
  |  | AFTYPE（地址族类型） | ipv4uni | 该参数用于指定BGP VPN实例下的地址族。 |
  |  | IMPORTPROTOCOL（路由协议） | wlr | 用户设定引入其他协议路由时的策略名称。 |
  | **ADD AUTOSCALINGSERVICE** | SERVICENAME（服务名称） | \_\_cslb\_service\_1\_\_ | 该参数用于指定接口自动化配置服务模板的名称。服务名称**\_\_cslb\_service***\_X\_***\_**为固定格式，必须按照此格式进行配置。 |
  |  | VPNNAME（VPN实例名称） | VRF\_CC\_DATA | 用于标识VPN实例名称，根据不同服务名称，填写对应VPN实例名称，应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | AFTYPE（地址族） | IPv4 | 用于标识地址族，应与**ADD VPNINSTAF**中“VPN实例名称（VRFNAME）”的“AFTYPE（地址族）”一致。  当“AFTYPE（地址族）”为“IPv4”时，才会规划：  + IPv4地址分配方式 + （IPv4）起始地址 + （IPv4）结束地址 + （IPv4）掩码长度 当“AFTYPE（地址族）”为“IPv6”时，才会规划：  + IPv6地址分配方式 + （IPv6）起始地址 + （IPv6）结束地址 + （IPv6）掩码长度 |
  |  | IPALLOCTYPE4（IPv4地址分配方式） | USER\_CONFIG | 表示采用手动指定的方式分配IP地址。 |
  |  | AUTOCFGIFTYPE（自动化配置接口类型） | VNIC | 本端规划，默认选择“VNIC(虚拟网卡)”。 |
  |  | VNICID（虚拟网卡ID） | VPN实例为VRF\_CC\_DATA时，该参数设置为：4 | 用于标识虚拟网卡ID，来自LLD文件中的“业务IP设计”页签，根据不同的VPN网络选择对应的vNIC ID。 |
  |  | VLANID（VLAN ID） | 1028 | 来自LLD文件中的“逻辑网络设计”页签，根据不同的VPN网络选择对应的VLAN ID。 |
  |  | BEGINADDR4（起始地址） | 10.0.28.2 | 仅当本命令中“IPv4地址分配方式（IPALLOCTYPE4）”设置为“用户配置方式”时，该参数有效，用于标识IPv4地址的起始地址。 |
  |  | ENDADDR4（结束地址） | 10.0.28.254 | 仅当本命令中“IPv4地址分配方式（IPALLOCTYPE4）”设置为“用户配置方式”时，该参数有效，用于标识IPv4地址的结束地址。 |
  |  | MASKLEN（地址池掩码长度） | 24 | 仅当本命令中“IPv4地址分配方式（IPALLOCTYPE4）”设置为“用户配置方式”时，该参数有效，用于标识IPv4地址的掩码长度。 |
  |  | OSPFENABLE（使能OSPF） | FALSE | 使用BGP路由方式，关闭接口OSPF使能。 |
  |  | TPINENABLE（使能入方向的流量策略） | FALSE | 该参数用于指定是否使能入方向的流量策略。 |
  |  | TPOUTENABLE（使能出方向的流量策略） | FALSE | 该参数用于指定是否使能出方向的流量策略。 |
  |  | FLOWMODE（引流模式） | FLOW\_MODE\_TYPE\_ROUTE | 该参数用于指定引流模式。该引流模式用于配置接口的WLR业务引流重定向功能。配置引流表模式时将接口收到的来自DPU的报文与WLR引流表进行匹配，如果匹配成功，则将报文引流到CSLB\_VNFC中进行处理；否则，再查找路由表转发报文。配置路由模式时仅匹配路由表进行报文引流。 |
  |  | OSPFGRPENABLE（使能OSPF进程组） | FALSE | 该参数在“OSPFENABLE”配置为“FALSE”时为可选参数。 |
  | **SET BFD** | BFDENABLE（BFD使能标志） | TRUE | 控制BFD全局使能或是全局去使能。本端规划。 |
  | **ADD AUTOSCALINGBFD** | TEMPLATENAME（模板名称） | VRF\_CC\_DATA | 在本端定义一个BFD模板。建议命名复用VRF实例名称，便于整个配置脚本的易读性和后续维护。 |
  |  | SERVICENAME（服务名称） | \_\_cslb\_service\_1\_\_ | 用于表示接口自动化配置服务模板名称。需要与配置UPCF基础数据中**ADD AUTOSCALINGSERVICE**命令配置的“服务名称（SERVICENAME）”参数保持一致。 |
  |  | BFDTYPE（BFD类型） | Static | 配置BFD类型，请根据LLD的路由设计进行配置。 |
  |  | IPVERSION（IP版本） | IPv4 | 与上述配置中的IP地址类型保持一致。 |
  |  | DESTADDR4（目的地址） | 10.10.34.1 | 指定下一跳的网关地址，请根据LLD的路由设计进行配置。 |
  | **ADD AUTOSCALINGSRROUTE** | 服务名称（SERVICENAME） | \_\_cslb\_service\_1\_\_ | 用于标识VPN实例名称，根据不同服务名称，填写对应VPN实例名称，应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | VPN实例名称（VRFNAME） | VRF\_CC\_DATA | 用于标识VPN实例名称，根据不同服务名称，填写对应VPN实例名称，应与**ADD L3VPNINST**中“VPN实例名称（VRFNAME）”一致。 |
  |  | 地址族（IPVERSION） | IPv4 | 本端规划。 |
  |  | 路由前缀IPv4（PREFIX4） | + 10.10.34.19 + 10.10.34.20 + 0.0.0.0 | 本端规划。 |
  |  | 路由掩码长度（MASKLENGTH） | 0 | 本端规划。 |
  |  | IPv4路由下一跳分配方式（NEXTHOPALLOCTYPE4） | CONFIG | 表示手动指定配置下一跳地址。 |
  |  | 路由下一跳IPv4（NEXTHOP4） | 10.10.34.1 | 指定下一跳的网关地址，参考LLD中的路由设计进行配置。 |
  |  | BFD使能标识（BFDENABLE） | TRUE | 开启BFD使能。 |
  |  | BFDTEMPLATENAME（BFD模板名称） | VRF\_CC\_DATA | 由**ADD AUTOSCALINGBFD**的“模板名称（TEMPLATENAME）”进行配置，并在此进行引用。 |

## 操作流程

配置CSLB的基础数据的流程如图1所示。

**图1** 配置CSLB基础数据流程图

## 操作步骤

1. 登录OM Portal Web MML界面，在“应用管理>MML”中选择“UPCF”网元。

   * USCDB侧的CSLB配置操作步骤和UPCF侧操作一致，相关数据参考表2。
   * 执行CSLB命令必须慎重，当配置参数有误，再进行修改会非常繁琐耗时。配置脚本执行完成后，如果发现数据配置有误，需要调整其中某个参数，由于各条命令之间存在索引关系，直接执行RMV和MOD命令修改无法成功，必须反过来依次删除已经添加的命令，再重新执行ADD命令添加正确的参数。
2. 配置CSLB基础数据前，关闭自动化配置。

   * 进行CSLB配置之前，需要先关闭自动化配置开关，确保CSLB的配置数据都配好之后，能够完整的加载到VNRS上。待配置完成后再打开自动化配置开关，使配置数据自动转换成交换机命令，在VNRS上生效。
   * 另由于自动化配置开关生效需要10s左右，不能直接将修改完成的脚本进行批量导入，建议逐条依次执行。

   ```
   SET AUTOCONFIG:SWITCHFLAG=FALSE;
   ```
3. 配置DBS的CSLB数据，用于FE与BE对接。

   ```
   /*创建数据平面VPN实例*/
   ADD L3VPNINST: VRFNAME="VRF_CC_DATA";
   /*设置VPN实例下的地址族*/
   ADD VPNINSTAF: VRFNAME="VRF_CC_DATA", AFTYPE=ipv4uni;
   /*增加接口*/
   ADD INTERFACE: IFNAME="Loopback13", IFADMINSTATUS=up;
   /*增加接口绑定VPN*/
   ADD IPBINDVPN: IFNAME="Loopback13", VRFNAME="VRF_CC_DATA";
   /*增加接口IP地址*/
   ADD IFIPV4ADDRESS: IFNAME="Loopback13", IFIPADDR="10.32.34.19", SUBNETMASK="255.255.255.255";
   /*设置BGP*/
   SET BGP: BGPENABLE=TRUE, ASNUM="64631";
   /*增加BGP VPN实例*/
   ADD BGPVRF: VRFNAME="VRF_CC_DATA", DEFAULTAFTYPE=ipv4uni, ROUTERID="10.32.34.19";
   /*修改BGP VPN地址族*/
   MOD BGPVRFAF: VRFNAME="VRF_CC_DATA", AFTYPE=ipv4uni, MAXIMUMLOADBALANCE=2;
   /*增加BGP对等体*/
   ADD BGPPEER:VRFNAME="VRF_CC_DATA",ADDRESSTYPE=ipv4,PEERADDR="10.10.34.19",REMOTEAS="100", LOCALIFNAME="Loopback13", EBGPMAXHOP=100;
   ADD BGPPEER:VRFNAME="VRF_CC_DATA",ADDRESSTYPE=ipv4,PEERADDR="10.10.34.20",REMOTEAS="100", LOCALIFNAME="Loopback13", EBGPMAXHOP=100;
   /*增加指定协议中的入口路由配置*/
   ADD IMPORTROUTE: VRFNAME="VRF_CC_DATA", AFTYPE=ipv4uni, IMPORTPROTOCOL=wlr;
   /*配置BFD全局属性*/
   SET BFD: BFDENABLE=TRUE, CONFIRM=Y;
   /*配置自动化配置参数*/
   ADD AUTOSCALINGSERVICE: SERVICENAME="__cslb_service_1__", VPNNAME="VRF_CC_DATA", AFTYPE=IPv4, IPALLOCTYPE4=USER_CONFIG, AUTOCFGIFTYPE=VNIC, VNICID=4, VLANID=1030, BEGINADDR4="10.0.30.2", ENDADDR4="10.0.30.254", MASKLEN=24, OSPFENABLE=FALSE, TPINENABLE=FALSE, TPOUTENABLE=FALSE, FLOWMODE=FLOW_MODE_TYPE_ROUTE, OSPFGRPENABLE=FALSE;
   /*增加BFD会话自动化配置模板*/
   ADD AUTOSCALINGBFD:TEMPLATENAME="VRF_CC_DATA", SERVICENAME="__cslb_service_1__", IPVERSION=IPv4, DESTADDR4="10.10.34.1", MINECHORXINT=500, DETECTMULTI=4, ONEARMECHO=TRUE, BFDTYPE=Static;
   /*增加静态路由自动化配置模板*/
   //添加明细路由//
   ADD AUTOSCALINGSRROUTE:SERVICENAME="__cslb_service_1__", IPVERSION=IPv4, PREFIX4="10.10.34.19", NEXTHOP4="10.10.34.1", MASKLENGTH=32, NEXTHOPALLOCTYPE4=CONFIG, VRFNAME="VRF_CC_DATA", PREFERENCE=60, TAG=0, BFDENABLE=TRUE, BFDTEMPLATENAME="VRF_CC_DATA";
   ADD AUTOSCALINGSRROUTE:SERVICENAME="__cslb_service_1__", IPVERSION=IPv4, PREFIX4="10.10.34.20", NEXTHOP4="10.10.34.1", MASKLENGTH=32, NEXTHOPALLOCTYPE4=CONFIG, VRFNAME="VRF_CC_DATA", PREFERENCE=60, TAG=0, BFDENABLE=TRUE, BFDTEMPLATENAME="VRF_CC_DATA";
   //添加默认路由//
   ADD AUTOSCALINGSRROUTE:SERVICENAME="__cslb_service_1__", IPVERSION=IPv4, PREFIX4="0.0.0.0", NEXTHOP4="10.10.34.1", MASKLENGTH=0, NEXTHOPALLOCTYPE4=CONFIG, VRFNAME="VRF_CC_DATA", PREFERENCE=60, TAG=0, BFDENABLE=TRUE, BFDTEMPLATENAME="VRF_CC_DATA";
   ```
4. 参考步骤3的配置，根据LLD网络平面规划，完成FE其余4G信令、5G信令、OM维护平面的CSLB数据配置。
5. 配置完成CSLB基础数据后，打开自动化配置。

   ```
   SET AUTOCONFIG:SWITCHFLAG=TRUE;
   ```
6. 登录OM Portal Web MML界面，在“应用管理>MML”中选择“USCDB”网元。
7. 配置CSLB基础数据前，关闭自动化配置。

   ```
   SET AUTOCONFIG:SWITCHFLAG=FALSE;
   ```
8. 配置DSG的CSLB数据，用于BE与FE对接。

   ```
   /*创建数据平面VPN实例*/
   ADD L3VPNINST: VRFNAME="VRF_CC_DATA";
   /*设置VPN实例下的地址族*/
   ADD VPNINSTAF: VRFNAME="VRF_CC_DATA", AFTYPE=ipv4uni;
   /*增加接口*/
   ADD INTERFACE: IFNAME="Loopback9", IFADMINSTATUS=up;
   /*增加接口绑定VPN*/
   ADD IPBINDVPN: IFNAME="Loopback9", VRFNAME="VRF_CC_DATA";
   /*增加接口IP地址*/
   ADD IFIPV4ADDRESS: IFNAME="Loopback9", IFIPADDR="10.32.34.19", SUBNETMASK="255.255.255.255";
   /*设置BGP*/
   SET BGP: BGPENABLE=TRUE, ASNUM="64631";
   /*增加BGP VPN实例*/
   ADD BGPVRF: VRFNAME="VRF_CC_DATA", DEFAULTAFTYPE=ipv4uni, ROUTERID="10.32.34.19";
   /*修改BGP VPN地址族*/
   MOD BGPVRFAF: VRFNAME="VRF_CC_DATA", AFTYPE=ipv4uni, MAXIMUMLOADBALANCE=2;
   /*增加BGP对等体*/
   ADD BGPPEER:VRFNAME="VRF_CC_DATA",ADDRESSTYPE=ipv4,PEERADDR="10.10.34.19",REMOTEAS="100", LOCALIFNAME="Loopback9", EBGPMAXHOP=100;
   ADD BGPPEER:VRFNAME="VRF_CC_DATA",ADDRESSTYPE=ipv4,PEERADDR="10.10.34.20",REMOTEAS="100", LOCALIFNAME="Loopback9", EBGPMAXHOP=100;
   /*增加指定协议中的入口路由配置*/
   ADD IMPORTROUTE: VRFNAME="VRF_CC_DATA", AFTYPE=ipv4uni, IMPORTPROTOCOL=wlr;
   /*配置BFD全局属性*/
   SET BFD: BFDENABLE=TRUE, CONFIRM=Y;
   /*配置自动化配置参数*/
   ADD AUTOSCALINGSERVICE: SERVICENAME="__cslb_service_1__", VPNNAME="VRF_CC_DATA", AFTYPE=IPv4, IPALLOCTYPE4=USER_CONFIG, AUTOCFGIFTYPE=VNIC, VNICID=4, VLANID=1028, BEGINADDR4="10.0.28.2", ENDADDR4="10.0.28.254", MASKLEN=24, OSPFENABLE=FALSE, TPINENABLE=FALSE, TPOUTENABLE=FALSE, FLOWMODE=FLOW_MODE_TYPE_ROUTE, OSPFGRPENABLE=FALSE;
   /*增加BFD会话自动化配置模板*/
   ADD AUTOSCALINGBFD:TEMPLATENAME="VRF_CC_DATA", SERVICENAME="__cslb_service_1__", IPVERSION=IPv4, DESTADDR4="10.10.34.1", MINECHORXINT=500, DETECTMULTI=4, ONEARMECHO=TRUE, BFDTYPE=Static;
   /*增加静态路由自动化配置模板*/
   //添加明细路由//
   ADD AUTOSCALINGSRROUTE:SERVICENAME="__cslb_service_1__", IPVERSION=IPv4, PREFIX4="10.10.34.19", NEXTHOP4="10.10.34.1", MASKLENGTH=32, NEXTHOPALLOCTYPE4=CONFIG, VRFNAME="VRF_CC_DATA", PREFERENCE=60, TAG=0, BFDENABLE=TRUE, BFDTEMPLATENAME="VRF_CC_DATA";
   ADD AUTOSCALINGSRROUTE:SERVICENAME="__cslb_service_1__", IPVERSION=IPv4, PREFIX4="10.10.34.20", NEXTHOP4="10.10.34.1", MASKLENGTH=32, NEXTHOPALLOCTYPE4=CONFIG, VRFNAME="VRF_CC_DATA", PREFERENCE=60, TAG=0, BFDENABLE=TRUE, BFDTEMPLATENAME="VRF_CC_DATA";
   //添加默认路由//
   ADD AUTOSCALINGSRROUTE:SERVICENAME="__cslb_service_1__", IPVERSION=IPv4, PREFIX4="0.0.0.0", NEXTHOP4="10.10.34.1", MASKLENGTH=0, NEXTHOPALLOCTYPE4=CONFIG, VRFNAME="VRF_CC_DATA", PREFERENCE=60, TAG=0, BFDENABLE=TRUE, BFDTEMPLATENAME="VRF_CC_DATA";
   ```
9. 参考步骤8的配置，根据LLD网络平面规划，完成BE其余维护平面、数据导入导出、营帐平面的CSLB数据配置。
10. 配置完成CSLB基础数据后，打开自动化配置。

    ```
    SET AUTOCONFIG:SWITCHFLAG=TRUE;
    ```

## 验证方法

1. 执行命令**LST INTERFACE**命令，检查子接口是否生成。

   子接口的接口名格式为EthernetX/0/Y.Z，其中：Z取值是**ADD AUTOSCALINGSERVICE**配置中的“VLANID”值。

   子接口必须是某个存在的接口的子接口，EthernetX/0/Y接口在软件安装完成后已存在。

   * 子接口生成正常，请执行2。
   * 子接口生成异常，请联系华为技术支持工程师处理（例如检查软件安装是否正常等）。
2. 以IPv4场景为例，执行命令**LST IFIPV4ADDRESS**，检查对应子接口上是否获取到IP地址。

   本步骤的显示结果中的子接口与1中生成的子接口是否完全一致，且子接口均已存在IP地址。

   * 是，请执行7。
   * 否，请执行3。
3. 执行**LST AUTOSCALINGSERVICE**，检查VLAN ID是否与LLD文档规划值一致。
   * 是，请联系华为技术支持工程师。
   * 否，执行4。
4. 执行**SET AUTOCONFIG**，关闭自动化配置开关。
5. 找到步骤1中查询出的VLANID配置错误的子接口，执行RMV INTERFACE将配置错误的子接口删除。
6. 执行**MOD AUTOSCALINGSERVICE**，参考LLD文档修改“VLANID”值。

   “SERVICENAME”、“AFTYPE”、“IPALLOCTYPE4”取值不改变，但必须填写。“VLANID”填写正确的值。
7. 执行**SET AUTOCONFIG**，打开自动化配置开关。重新执行1进行验证。
8. 执行**PING**命令，在VNF上检查VNF外联口IP与DC-GW接口IP之间是否路由可达。
   * 是，请执行9。
   * 否，请联系华为技术支持工程师处理。
9. 执行**PING**命令，检查VNF BGP本端IP与BGPPEER IP之间是否路由可达。
   * 是，请执行10。
   * 否，请联系华为技术支持工程师处理。
10. 执行**DSP BGPPEERINFO**命令，检查BGP对等体条数是否正确及BGP对等体状态是否为Established。

    本步骤的显示结果中的BGP对等体的条数与LST BGPPEER中查询的对等体的条数相等，且“对等体状态”为“Established”。

    * 是，调测结束。
    * 否，请联系华为技术支持工程师处理。

版权所有 © 华为技术有限公司
