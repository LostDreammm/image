---
id: ''
name: Sd接口(使用Diameter协议)策略控制特性配置（重定向）（2G/3G）
ne_type: UPCF
type: feature
description: TDF（Traffic Detection Function）是应用流量检测功能的执行实体，在3GPP TS 29.212和3GPP TS 29.213中定义，TDF和PCEF可以合设，也可以分开部署。合设是内置DPI功能，分开部署是外置DPI功能。UPCF与TDF通过Sd接口进行消息交互，完成用户使用的应用的检测和控制功能。UPCF与TDF配套使用可以实现对用户的应用进行流量累计、应用流QoS控制、应用流Gate控制、重定向等功能。当运营商需要基于用户的应用进行策略控制时，需要部署此特性。Sd接口（使用Diameter协议）策略控制示意图如图1所示。 **图1** Sd接口（使用Diameter协议）策略控制示意图 以未签约某特定应用套餐为例，用户包月上网，月流量为100M，具体场景如下： * 当流量未耗尽时带宽为1Mbit/s。 * 当流量耗尽时带宽为64kbit/s。 * 当用户开始使用某特定业务时，被重定向到某特定应用的签约网页，之后不再进行重定向。
risk_level: ''
doc_source: ["特性","特性部署","UPCF基础特性","WHFD-611059 Sd接口(使用Diameter协议)策略控制","WHFD-611059 Sd接口(使用Diameter协议)策略控制特性配置","Sd接口(使用Diameter协议)策略控制特性配置（重定向）（2G/3G）"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
TDF（Traffic Detection Function）是应用流量检测功能的执行实体，在3GPP TS 29.212和3GPP TS 29.213中定义，TDF和PCEF可以合设，也可以分开部署。合设是内置DPI功能，分开部署是外置DPI功能。UPCF与TDF通过Sd接口进行消息交互，完成用户使用的应用的检测和控制功能。UPCF与TDF配套使用可以实现对用户的应用进行流量累计、应用流QoS控制、应用流Gate控制、重定向等功能。当运营商需要基于用户的应用进行策略控制时，需要部署此特性。Sd接口（使用Diameter协议）策略控制示意图如图1所示。**图1** Sd接口（使用Diameter协议）策略控制示意图以未签约某特定应用套餐为例，用户包月上网，月流量为100M，具体场景如下：* 当流量未耗尽时带宽为1Mbit/s。* 当流量耗尽时带宽为64kbit/s。* 当用户开始使用某特定业务时，被重定向到某特定应用的签约网页，之后不再进行重定向。

## 必备事项
前提条件

操作员已了解WHFD-611059 Sd接口（使用Diameter协议）策略控制。
已完成配置UPCF与TDF的对接数据。
已在TDF侧配置预定义规则组：
* CheckABC\_1M：包含除某特定应用业务外的通用业务规则。业务带宽为1Mbit/s、检测某特定应用业务使用的规则、使用Facebook业务被重定向到某特定应用签约网页的规则。
* CheckABC\_64k：包含除某特定应用业务外的通用业务规则。业务带宽为64kbit/s、检测某特定应用业务使用的规则、使用Facebook业务被重定向到某特定应用签约网页的规则。
* IncludeABC\_1M：包含通用业务规则（包括某特定应用业务），业务带宽为1Mbit/s。
* IncludeABC\_64k：包含通用业务规则（包括某特定应用业务），业务带宽为64kbit/s。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    mod_pcefabiitem_list:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pcefabiitem_list_1:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pcefabiitem_list_2:
      type: items
      properties:
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYITEMID:
          name: '能力字典项ID'
          type: string
          enum:
          - IPSessAbort
          - IPSessRevalidation
          - UsageMonitor
          - R7ExtraEvent
          - BearerControlMode
          - R8QoS
          - MultipleServiceAPN
          - ProtoClassifierName
          - PredefinedRuleName
          - MonitorKeyCodecModeForR9
          - AccessNode
          - FBBAction
          - GxFailover
          - URLFiltering
          - TetheringControl
          - EventTriggerVersion
          - InstSubID
          - CiscoSCE
          - SecondaryPDP
          - NoEventTriggers
          - CarryARPInQosInfoAVPAtSession
          - RedirectionAbility
          - ResultCodeSwitch
          - ChangePolicyByRAR
          - TermSessionMode
          - ForcedMask
          - SubProfile
          - CiscoQoSGroupRule
          - AppDetectionAbility
          - FlowDirection
          - CombineRule
          - ReInsertRule
          - FlowDescriptionPosition
          - SubscriptionIDInCCA
          - SGWRestoreAbility
          - PRAAbility
          - RATTypeinSdSwitch
          - G4QosNegotiation
          - OriginRealmAndHost
          - MIGAction
          - CCGroup
          - DisconnectLink
          - BackfillQoS
          - DirectLinkFaultSwitchDRA
          - CarryCommandQoS
          - OriginStateId
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABLITYVALUE:
          name: '能力字典项值'
          type: string
          enum:
          - ASR/ASA
          - RARWithRelCause
          - UnsupportedRevalidation
          - SupportedRevalidation
          - UsageMonitorHuawei
          - UsageMonitorPreR9
          - UsageMonitor3GPPR9
          - UsageMonitorHuaweiExQtaInst
          - UsageMonitor3GPPR9Enhanced
          - UnsupportedR7ExtraEvent
          - SupportedR7ExtraEvent
          - DeriveBCMUEOnly
          - UnsupportedBCM
          - UnsupportedR8QoS
          - SupportedR8QoS
          - SupportedR7ToR8QoS
          - UnsupportedMultipleServiceAPN
          - SupportedMultipleServiceAPN
          - UnsupportedProClassifierName
          - SupportedProClassifierName
          - UnsupportedPredefinedRuleName
          - SupportedPredefinedRuleName
          - FourBytesHex
          - MaxFourBytesHex
          - ASCIIMode
          - UnsupportedAccessNode
          - SupportedAccessNode
          - UnsupportedFBBAction
          - SupportedFBBAction
          - UnsupportedGxFailover
          - SupportedGxFailover
          - UnsupportedURLFiltering
          - SupportedURLFiltering
          - UnsupportedTetheringControl
          - SupportedTetheringControl
          - R940
          - R970
          - Msisdn
          - Imsi
          - Nai
          - All
          - UnsupportedCiscoSCE
          - SupportedCiscoSCE
          - UnsupportedSecPDP
          - AppendPostfixToRule
          - CreateDynamicRule
          - UnsupportedNoEventTriggers
          - SupportedNoEventTriggers
          - NotCarryARPAVP
          - CarryARPAVP
          - UnsupportedRCSwitch
          - SupportedRCSwitch
          - UnsupportedSFD
          - SupportedSFD
          - SupportedSFDOnly
          - SupportedRedirectOnly
          - SupportNULL
          - FailedCCAAndRAR
          - SuccessedCCAAndRAR
          - CCA
          - FailedCCA
          - UnsupportedChangePolicyByRAR
          - SupportedChangePolicyByRAR
          - UnsupportedForcedMask
          - SupportedForcedMask
          - UnsupportedSubProfile
          - SupportedSubProfile
          - SupportedHWSubProfile
          - UnsupportQoSGroupRule
          - SupportQoSGroupRule
          - UnsupportedAppDetection
          - SupportedAppDetection
          - UnsupportedFlowDirection
          - SupportedFlowDirection
          - UnsupportedCombineRule
          - SupportedCombineRule
          - NotReInsertRule
          - ReInsertRule
          - ControledByR8QoS
          - WithinFlowInformation
          - WithinRuleDefinition
          - UnsupportedSubscriptionIDInCCA
          - SupportedSubscriptionIDInCCA
          - UnsupportedSGWRestore
          - SupportedSGWRestore
          - UnsupportedPRA
          - SupportedPRA
          - SupportRatType
          - Support3gppRatType
          - UnsupportedG4QoSNegotiation
          - NotMoreThanFirstMessage
          - NotMoreThanPreMessage
          - NotMoreThanReqQoSfor4G
          - FillLastMessageQoS
          - LastMsgQoSNegWithPolicyQoS
          - NotMoreThanCCRIUQoS
          - FromPeerCfg
          - FromMessage
          - UnsupportMIGAction
          - SupportMIGAction
          - UnsupportedCCGroup
          - SupportedCCGroup
          - UnsupportDisconnectLink
          - SupportDisconnectLink
          - UnsupportedBackfillQoS
          - SupportedBackfillQoS
          - UnsupportedSwitchDRA
          - SupportedSwitchDRA
          - UnsupportedCarryCommandQoS
          - SupportedCarryCommandQoS
          - UnsupportedOriginStateId
          - SupportedOriginStateId
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ppcefcat_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFCATID:
          name: '对端PCEF类别标识'
          type: integer
          minimum: 1
          maximum: 16
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFCAT:
          name: '对端PCEF类别'
          type: string
          minLength: 0
          maxLength: 16
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        TIMEOUTPROCESS:
          name: '会话超时后处理方式'
          type: string
          enum:
          - ReleaseSingleSession
          - ReleaseAllSession
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ReleaseSingleSession
        TERMINALPROCESS:
          name: 'CCR_T会话释放处理方式'
          type: string
          enum:
          - ReleaseSingleSession
          - ReleaseAllSession
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ReleaseSingleSession
        TSAFAILDPROCESS:
          name: 'TSA返回失败后处理方式'
          type: string
          enum:
          - ReleaseSingleSession
          - ReleaseAllSession
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ReleaseSingleSession
        ISAPN:
          name: '设置APN'
          type: string
          enum:
          - NO
          - YES
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: NO
        APNID:
          name: 'APN标识'
          type: integer
          minimum: 0
          maximum: 319
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_ppcef_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFID:
          name: '对端PCEF标识'
          type: integer
          minimum: 0
          maximum: 1023
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PN:
          name: '对端名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PT:
          name: '协议类型'
          type: string
          enum:
          - DIAMETER
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '对端域名'
          type: string
          minLength: 0
          maxLength: 64
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '对端主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DASWITCH:
          name: '审计开关'
          type: string
          enum:
          - OFF
          - ON
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PCEFCAT:
          name: '对端PCEF类别'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DATIME:
          name: '设备间审计时长 （m）'
          type: integer
          minimum: 720
          maximum: 1440
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SKA:
          name: '业务保活时长 （s）'
          type: integer
          minimum: 0
          maximum: 3600
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: 90@90
    add_peer_list:
      type: items
      properties:
        PCRFID:
          name: 'PCRF标识'
          type: integer
          minimum: 1
          maximum: 1
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PEERID:
          name: '对端标识'
          type: integer
          minimum: 0
          maximum: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PT:
          name: '对端类型'
          type: string
          enum:
          - DRA
          - TDF
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PN:
          name: '对端名称'
          type: string
          minLength: 0
          maxLength: 128
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DN:
          name: '对端域名'
          type: string
          minLength: 0
          maxLength: 64
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HN:
          name: '对端主机名'
          type: string
          minLength: 0
          maxLength: 127
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        DASWITCH:
          name: '审计开关'
          type: string
          enum:
          - GxON
          - RxON
          - SdON
          - SyON
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ABILITYDICTID:
          name: '能力字典ID'
          type: integer
          minimum: 0
          maximum: 127
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PEERCAT:
          name: '对端类别'
          type: string
          minLength: 0
          maxLength: 16
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        FAILEDNTYIF:
          name: '审计失败通知的接口'
          type: string
          enum:
          - Sy
          - N28
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: Sy-1&N28-1
        ISBSF:
          name: '是否BSF对端'
          type: string
          enum:
          - FALSE
          - TRUE
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: FALSE
        PLSMODE:
          name: '对端链路选择方式'
          type: string
          enum:
          - MASTER_SLAVE
          - ROUND_ROBIN
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ROUND_ROBIN
    add_psub_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRMSISDN:
          name: 'USRMSISDN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATE:
          name: 'USRSTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRPAIDTYPE:
          name: 'USRPAIDTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSTATION:
          name: 'USRSTATION'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRCONTACTMETHOD:
          name: 'USRCONTACTMETHOD'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRBILLCYCLEDATE:
          name: 'USRBILLCYCLEDATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        USRSUBNETTYPE:
          name: 'USRSUBNETTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_psrv_list:
      type: items
      properties:
        USRIDENTIFIER:
          name: 'USRIDENTIFIER'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVNAME:
          name: 'SRVNAME'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVUSAGESTATE:
          name: 'SRVUSAGESTATE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SRVROAMINGTYPE:
          name: 'SRVROAMINGTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - mod_pcefabiitem_list:
    - ABILITYDICTID: 67
      ABILITYITEMID: R8QoS
      ABLITYVALUE: UnsupportedR8QoS
    mod_pcefabiitem_list_1:
    - ABILITYDICTID: 67
      ABILITYITEMID: UsageMonitor
      ABLITYVALUE: UsageMonitor3GPPR9
    mod_pcefabiitem_list_2:
    - ABILITYDICTID: 67
      ABILITYITEMID: MonitorKeyCodecModeForR9
      ABLITYVALUE: ASCIIMode
    add_ppcefcat_list:
    - PCRFID: 1
      PCEFCATID: 5
      PCEFCAT: 'PCEF'
      TIMEOUTPROCESS: ReleaseSingleSession
      TERMINALPROCESS: ReleaseSingleSession
      TSAFAILDPROCESS: ReleaseSingleSession
      ISAPN: NO
      APNID: ''
    add_ppcef_list:
    - PCRFID: 1
      PCEFID: 1
      PN: 'pcef'
      PT: DIAMETER
      DN: 'huawei.com'
      HN: 'pcef.huawei.com'
      DASWITCH: OFF
      ABILITYDICTID: 67
      PCEFCAT: 'PCEF'
      DATIME: ''
      SKA: 90@90
    add_peer_list:
    - PCRFID: 1
      PEERID: 2
      PT: TDF
      PN: 'pdf'
      DN: 'huawei.com'
      HN: 'tdf.huawei.com'
      DASWITCH: SdON-1
      ABILITYDICTID: 63
      PEERCAT: 'TDF'
      FAILEDNTYIF: Sy-1&N28-1
      ISBSF: FALSE
      PLSMODE: ROUND_ROBIN
    add_psub_list:
    - USRIDENTIFIER: 46010381012****
      USRMSISDN: '12345678901'
      USRSTATE: Normal
      USRPAIDTYPE: 'NULL'
      USRSTATION: Master
      USRCONTACTMETHOD: SMS
      USRBILLCYCLEDATE: 'NULL'
      USRSUBNETTYPE: MBB
    add_psrv_list:
    - USRIDENTIFIER: 46010381012****
      SRVNAME: TDF_Service
      SRVUSAGESTATE: Normal
      SRVROAMINGTYPE: 'NULL'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 修改对端PCEF能力字典项。

#### 1.1 登录“UPCF MML命令”界面。

#### 1.2 执行**MOD PCEFABIITEM**，调整PCRF对端PCEF能力字典，设置对端能力为不支持R8标准的QoS。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”默认设置为“67”。实际的值可以通过如下方式查询：

#### 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。

#### 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。

#### 1.3 执行**MOD PCEFABIITEM**，调整PCRF对端PCEF能力字典，设置对端能力为支持基于3GPP R9标准的Usage Monitoring机制。

#### 当配置的FUP业务需使用3GPP R9标准的Usage Monitoring机制时，才需配置“UsageMonitor3GPPR9”的能力，否则，略过此步骤。

#### 命令举例：

```jinja2
{%- set MOD_PCEFABIITEM=getValueList('MOD PCEFABIITEM') -%}
{%- if MOD_PCEFABIITEM -%}
    {%- for item in mod_pcefabiitem_list_1 -%}
        MOD PCEFABIITEM:
        {#- --- 必选参数 --- -#}
        ABILITYDICTID={{item.ABILITYDICTID}},
        ABILITYITEMID={{item.ABILITYITEMID}},
        {#- --- 可选参数 --- -#}
        {%- if item.ABLITYVALUE is not none -%}
            ABLITYVALUE={{item.ABLITYVALUE}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

#### 1.4 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，设置Monitor Key以哪种字节长度处理。

#### Monitor Key的长度处理方式有如下三种：

#### FourBytesHex：MonitorKey按照十六进制4字节处理。

#### MaxFourBytesHex：MonitorKey按照十六进制最大4字节处理。

#### ASCIIMode：MonitorKey按照ASCII码处理。

#### 命令举例：

```jinja2
{%- for item in mod_pcefabiitem_list_2 -%}
    MOD PCEFABIITEM:
    {#- --- 必选参数 --- -#}
    ABILITYDICTID={{item.ABILITYDICTID}},
    ABILITYITEMID={{item.ABILITYITEMID}},
    {#- --- 可选参数 --- -#}
    {%- if item.ABLITYVALUE is not none -%}
        ABLITYVALUE={{item.ABLITYVALUE}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 2 配置对端类别。

#### 2.1 登录“UPCF MML命令”界面。

#### 2.2 执行**ADD PPCEFCAT**，增加对端PCEF类别定义。

#### 命令举例：

```jinja2
{%- for item in add_ppcefcat_list -%}
    ADD PPCEFCAT:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    PCEFCATID={{item.PCEFCATID}},
    PCEFCAT="{{item.PCEFCAT}}",
    {#- --- 可选参数 --- -#}
    {%- if item.TIMEOUTPROCESS is not none -%}
        TIMEOUTPROCESS={{item.TIMEOUTPROCESS}},
    {%- endif -%}
    {%- if item.TERMINALPROCESS is not none -%}
        TERMINALPROCESS={{item.TERMINALPROCESS}},
    {%- endif -%}
    {%- if item.TSAFAILDPROCESS is not none -%}
        TSAFAILDPROCESS={{item.TSAFAILDPROCESS}},
    {%- endif -%}
    {%- if item.ISAPN is not none -%}
        ISAPN={{item.ISAPN}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：ISAPN=YES 时必选 --- -#}
    {%- if item.ISAPN == 'YES' -%}
        APNID={{item.APNID}},
    {%- endif -%}
    ;
{%- endfor -%}
```

#### 2.3 执行**ADD PPCEF**和**ADD PEER**，给对端指定对端PCEF类别。

#### 命令举例：

```jinja2
{%- for item in add_ppcef_list -%}
    ADD PPCEF:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    PCEFID={{item.PCEFID}},
    PT={{item.PT}},
    HN="{{item.HN}}",
    {#- --- 可选参数 --- -#}
    {%- if item.PN is not none -%}
        PN="{{item.PN}}",
    {%- endif -%}
    {%- if item.PCEFCAT is not none -%}
        PCEFCAT="{{item.PCEFCAT}}",
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：PT=DIAMETER 时必选 --- -#}
    {%- if item.PT == 'DIAMETER' -%}
        DN="{{item.DN}}",
    {%- endif -%}
    {#- --- 条件必选：PT=DIAMETER 时必选 --- -#}
    {%- if item.PT == 'DIAMETER' -%}
        ABILITYDICTID={{item.ABILITYDICTID}},
    {%- endif -%}
    {#- --- 条件必选：DASWITCH=ON 时必选 --- -#}
    {%- if item.DASWITCH == 'ON' -%}
        DATIME={{item.DATIME}},
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：PT=DIAMETER 时可选 --- -#}
    {%- if item.PT == 'DIAMETER' -%}
        {%- if item.DASWITCH is not none -%}
            DASWITCH={{item.DASWITCH}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：PT=DIAMETER 时可选 --- -#}
    {%- if item.PT == 'DIAMETER' -%}
        {%- if item.SKA is not none -%}
            SKA={{item.SKA}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

```jinja2
{%- for item in add_peer_list -%}
    ADD PEER:
    {#- --- 必选参数 --- -#}
    PCRFID={{item.PCRFID}},
    PEERID={{item.PEERID}},
    PT={{item.PT}},
    DN="{{item.DN}}",
    HN="{{item.HN}}",
    {#- --- 可选参数 --- -#}
    {%- if item.PN is not none -%}
        PN="{{item.PN}}",
    {%- endif -%}
    {%- if item.DASWITCH is not none -%}
        DASWITCH={{item.DASWITCH}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：PT=TDF 时必选 --- -#}
    {%- if item.PT == 'TDF' -%}
        ABILITYDICTID={{item.ABILITYDICTID}},
    {%- endif -%}
    {#- --- 条件必选：PT=TDF 时必选 --- -#}
    {%- if item.PT == 'TDF' -%}
        PEERCAT="{{item.PEERCAT}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：PT=DRA 时可选 --- -#}
    {%- if item.PT == 'DRA' -%}
        {%- if item.FAILEDNTYIF is not none -%}
            FAILEDNTYIF={{item.FAILEDNTYIF}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：PT=DRA 时可选 --- -#}
    {%- if item.PT == 'DRA' -%}
        {%- if item.ISBSF is not none -%}
            ISBSF={{item.ISBSF}},
        {%- endif -%}
    {%- endif -%}
    {#- --- 条件可选：PT=DRA 时可选 --- -#}
    {%- if item.PT == 'DRA' -%}
        {%- if item.PLSMODE is not none -%}
            PLSMODE={{item.PLSMODE}},
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 3 登录UPCF WebUI界面。

### 4 配置配额。

### 导航入口为“业务管理 > 业务 > 配额”。

### 配额的数据规划如表2所示，详细参数说明请参见配额参数表。

### **表2** 配额

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 配额 | 基本信息 | 名称 | Quota\_Service |

### |  |  | 配额管理归属 | UPCC |

### |  |  | 配额类型 | 流量 |

### |  |  | 类型 | 业务级 |

### |  |  | 监控键值 | 101 |

### |  |  | 值(KB) | 102400 |

### |  |  | 分片类型 | 值 |

### |  |  | 分片(KB) | 10240 |

### |  | 复位设置 | 结帐模式 | 自然日历 |

### |  |  | 复位周期类型 | 月 |

### |  |  | 复位日期 | 1 |

### |  |  | 复位时间 | 01:00:00 |

### |  |  | 剩余额处理方式 | 清零 |

### 5 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

### 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

### 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 条件组的数据规划如表3所示，详细参数说明请参见条件组参数表。

### **表3** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | CG\_Service1 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_Service1 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | Quota\_Service  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Normal  说明：  “Normal”：表示配额消耗没有耗尽。 |

### | 条件组2 | 基本信息 | 名称 | CG\_Service2 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_Service2 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | Quota\_Service  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示配额耗尽。 |

### | 条件组3 | 基本信息 | 名称 | CG\_Service3 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | C\_Service3 |

### |  |  | 对象属性 | * 对象：IPSession * 属性：TDFApplicationIdentifier |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | ABC |

### |  | 条件2 | 名称 | C\_Service4 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | Quota\_Service  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Normal  说明：  “Normal”：表示配额消耗没有耗尽。 |

### | 条件组4 | 基本信息 | 名称 | CG\_Service4 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | C\_Service5 |

### |  |  | 对象属性 | * 对象：IPSession * 属性：TDFApplicationIdentifier |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | ABC |

### |  | 条件2 | 名称 | C\_Service6 |

### |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |

### |  |  | 对象实例 | Quota\_Service  说明：  已在配额中定义。 |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示配额耗尽。 |

### 6 配置动作组。

### 导航入口为“策略管理 > 策略 > 动作组”。

### 动作组的数据规划如表4所示，详细参数说明请参见动作组参数表。

### **表4** 动作组

### | 类别 | 参数 |  |  | 取值样例 |

### | --- | --- | --- | --- | --- |

### | 动作组 | 基本信息 | 名称 |  | AG\_Service |

### |  | 动作 | 动作 |  | UsageReport |

### |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |

### 7 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 规则的数据规划如表5所示，详细参数说明请参见规则参数表。

### **表5** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | Rule\_CheckABC\_1M |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined Group |

### |  |  | 预定义组名 | CheckABC\_1M |

### |  |  | 目的PEER | TDF |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Service1  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | Rule\_CheckABC\_64k |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined Group |

### |  |  | 预定义组名 | CheckABC\_64k |

### |  |  | 目的PEER | TDF |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Service2  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |

### | 规则3 | 基本信息 | 名称 | Rule\_IncludeABC\_1M |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined Group |

### |  |  | 预定义组名 | IncludeABC\_1M |

### |  |  | 目的PEER | TDF |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Service3  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |

### | 规则4 | 基本信息 | 名称 | Rule\_IncludeABC\_64k |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined Group |

### |  |  | 预定义组名 | IncludeABC\_64k |

### |  |  | 目的PEER | TDF |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Service4  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |

### | 规则5 | 基本信息 | 名称 | Rule\_UsageReport\_1M |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined Group |

### |  |  | 预定义组名 | IncludeABC\_1M |

### |  |  | 目的PEER | TDF |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Service1  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |

### | 规则6 | 基本信息 | 名称 | Rule\_UsageReport\_64k |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | Predefined Group |

### |  |  | 预定义组名 | IncludeABC\_64k |

### |  |  | 目的PEER | TDF |

### |  |  | EDR | OFF |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_Service2  说明：  已在条件组中定义。 |

### |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |

### 8 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表6所示，详细参数说明请参见策略参数表。

### **表6** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略1 | 基本信息 | 名称 | Policy\_Service1 |

### |  | 触发器 | 名称 | IPCANSessionEstablish |

### |  | 规则 | 名称 | * Rule\_CheckABC\_1M * Rule\_CheckABC\_64k 说明：  已在规则中定义。 |

### | 策略2 | 基本信息 | 名称 | Policy\_Service2 |

### |  | 触发器 | 名称 | ApplicationStart |

### |  | 规则 | 名称 | * Rule\_IncludeABC\_1M * Rule\_IncludeABC\_64k 说明：  已在规则中定义。 |

### | 策略3 | 基本信息 | 名称 | Policy\_Service3 |

### |  | 触发器 | 名称 | UsageReport |

### |  | 规则 | 名称 | * Rule\_UsageReport\_1M * Rule\_UsageReport\_64k 说明：  已在规则中定义。 |

### 9 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

### 业务的数据规划如表7所示，详细参数说明请参见业务参数表。

### **表7** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务 | 基本信息 | 名称 | TDF\_Service |

### |  |  | 类型 | VALUE\_ADDED\_SERVICE |

### |  |  | 是否记入基本配额 | 是 |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | * Policy\_Service1 * Policy\_Service2 * Policy\_Service3 说明：  已在策略中定义。 |

### |  | 配额 | 名称 | Quota\_Service  说明：  已在配额中定义。 |

### 10 登录“UPCF 业务管理”窗口。

### 11 发放业务。

#### 11.1 执行**ADD PSUB**增加一个用户。

#### “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psub_list的变量区（command: ADD PSUB） -#}
<!-- MISSING_MACRO: command=ADD PSUB list_name=add_psub_list step_id=11.1 -->
```

#### 11.2 执行**ADD PSRV**给用户签约业务。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_psrv_list的变量区（command: ADD PSRV） -#}
<!-- MISSING_MACRO: command=ADD PSRV list_name=add_psrv_list step_id=11.2 -->
```

