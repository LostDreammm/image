# Sd接口(使用Diameter协议)策略控制特性配置（重定向）（2G/3G）

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

#### 操作场景

TDF（Traffic Detection Function）是应用流量检测功能的执行实体，在3GPP TS 29.212和3GPP TS 29.213中定义，TDF和PCEF可以合设，也可以分开部署。合设是内置DPI功能，分开部署是外置DPI功能。UPCF与TDF通过Sd接口进行消息交互，完成用户使用的应用的检测和控制功能。UPCF与TDF配套使用可以实现对用户的应用进行流量累计、应用流QoS控制、应用流Gate控制、重定向等功能。当运营商需要基于用户的应用进行策略控制时，需要部署此特性。Sd接口（使用Diameter协议）策略控制示意图如图1所示。

**图1** Sd接口（使用Diameter协议）策略控制示意图

以未签约某特定应用套餐为例，用户包月上网，月流量为100M，具体场景如下：

* 当流量未耗尽时带宽为1Mbit/s。
* 当流量耗尽时带宽为64kbit/s。
* 当用户开始使用某特定业务时，被重定向到某特定应用的签约网页，之后不再进行重定向。

#### 对系统的影响

UPCF建立一个Sd会话占用的系统资源相当于建立一个Gx会话占用的系统资源。比如假设UPCF支持120万Gx会话，如果UPCF已经建立了30万Sd会话，则UPCF支持建立的Gx会话数将降低到90万。

#### 必备事项

**前提条件**

操作员已了解WHFD-611059 Sd接口（使用Diameter协议）策略控制。

已完成配置UPCF与TDF的对接数据。

已在TDF侧配置预定义规则组：

* CheckABC\_1M：包含除某特定应用业务外的通用业务规则。业务带宽为1Mbit/s、检测某特定应用业务使用的规则、使用Facebook业务被重定向到某特定应用签约网页的规则。
* CheckABC\_64k：包含除某特定应用业务外的通用业务规则。业务带宽为64kbit/s、检测某特定应用业务使用的规则、使用Facebook业务被重定向到某特定应用签约网页的规则。
* IncludeABC\_1M：包含通用业务规则（包括某特定应用业务），业务带宽为1Mbit/s。
* IncludeABC\_64k：包含通用业务规则（包括某特定应用业务），业务带宽为64kbit/s。

**数据**

根据应用场景，参考业务拆解总体原则，分解的业务配置关系如图2所示，详细解释如表1所示。

**图2** 业务配置关系图

**表1** 配置关系解释

| 名称 | 需求分解项 | 基本原则 |
| --- | --- | --- |
| 业务TDF\_Service | 此业务包括策略和配额。 | * 策略：未签约某特定应用优惠套餐的用户上线、检测到某特定应用业务应用和在流量消耗的过程中使用，触发器为IPCANSessionEstablish、ApplicationStart和UsageReport。 * 配额：用户包月套餐的配额。 |
| 配额Quota\_Service | * 业务级配额为“100MB”，复位周期为按月复位。 * 复位时间为每月1号“01:00:00”。 * 剩余配额处理方式为“清零”。 | - |
| 策略Policy\_Service1 | 此策略在未签约某特定应用优惠套餐的用户上线时使用，触发器为IPCANSessionEstablish。包含的规则为：  * Rule\_CheckABC\_1M * RUle\_CheckABC\_64k | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配并下发策略给TDF。 |
| 策略Policy\_Service2 | 此策略在未签约某特定应用优惠套餐的用户上线后检测到某特定应用业务应用时使用，触发器为ApplicationStart。包含的规则为：  * Rule\_IncludeABC\_1M * Rule\_IncludeABC\_64k |  |
| 策略Policy\_Service3 | 此策略在未签约某特定应用优惠套餐的用户在流量消耗的过程中使用，触发器为UsageReport。包含的规则为：  * Rule\_UsageReport\_1M * Rule\_UsageReport\_64k |  |
| 规则Rule\_CheckABC\_1M | 未签约某特定应用优惠套餐的用户上线且配额未耗尽时，下发此规则，如果检测到某特定应用，则将用户重定向。  * 条件：配额未耗尽。 * 动作：   + QoSAction：上下行带宽为1Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 * 预定义规则组：CheckABC\_1M。 | * 条件中“对象属性”的配置：   + 当使用配额状态（对应于**LST PQUOTA**中的“Status”）做条件控制时，条件“对象属性”选用对象Quota下的QuotaStatus属性。   + 当使用业务状态（对应于**LST PSRV**中的“Usage level”）做条件控制时，条件“对象属性”选用对象Subscription下的UsageStatus属性。 说明：  因配额阈值只能配置为整数，故当阈值设置不能满足场景需求时，条件“对象属性”可选用对象Quota下的QuotaBalance或QuotaConsumption属性。 * 若对端为华为GGSN，不管用户需求是否需要改变计费策略，均需配置动作ChargingAction。“RatingGroup”的取值需与在线/离线计费系统（如OCS）协商一致。 |
| 规则Rule\_CheckABC\_64k | 未签约某特定应用优惠套餐的用户上线且配额耗尽时，下发此规则，如果检测到某特定应用，则将用户重定向。  * 条件：配额耗尽。 * 动作：   + QoSAction：上下行带宽为64kbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 * 预定义规则组：CheckABC\_64k。 |  |
| 规则Rule\_IncludeABC\_1M | 当未签约某特定应用优惠套餐的用户上线且配额未耗尽，TDF检测到用户使用某特定应用业务时，下发此规则，删除重定向。  * 条件：   + 配额未耗尽。   + IPSession：TDFApplicationIdentifier为ABC。 * 动作：   + QoSAction：上下行带宽为1Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 * 预定义规则组：IncludeABC\_1M。 |  |
| 规则Rule\_IncludeABC\_64k | 当未签约某特定应用优惠套餐的用户上线且配额耗尽，TDF检测到用户使用某特定应用业务时，下发此预规则。  * 条件：   + 配额耗尽。   + IPSession：TDFApplicationIdentifier为ABC。 * 动作：   + QoSAction：上下行带宽为64kbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 * 预定义规则组：IncludeABC\_64k。 |  |
| 规则Rule\_UsageReport\_1M | 未签约Facebook优惠套餐的用户在流量消耗且配额未耗尽时，下发此规则。  * 条件：配额未耗尽。 * 动作：   + QoSAction：上下行带宽为1Mbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 * 预定义规则组：IncludeFacebook\_1M。 |  |
| 规则Rule\_UsageReport\_64k | 未签约某特定应用优惠套餐的用户在流量消耗且配额耗尽时，下发此规则。  * 条件：配额耗尽。 * 动作：   + QoSAction：上下行带宽为64kbit/s。   + ChargingAction：“RatingGroup”为1（1代表不计费）。 * 预定义规则组：IncludeABC\_64k。 |  |

#### 操作流程

此特性的配置流程图如图3所示。

**图3** 业务配置流程图

#### 操作步骤

1. 修改对端PCEF能力字典项。
   1. 登录“UPCF MML命令”界面。
   2. 执行**MOD PCEFABIITEM**，调整PCRF对端PCEF能力字典，设置对端能力为不支持R8标准的QoS。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=R8QoS, ABLITYVALUE=UnsupportedR8QoS;
      ```

      在2G/3G网络中，UPCF与华为GGSN对接时，“ABILITYDICTID”默认设置为“67”。实际的值可以通过如下方式查询：
      * 当UPCF与PCEF直连时，“能力字典ID”可以通过**LST PPCEF**命令查询。
      * 当UPCF与PCEF通过DRA准直连时，“能力字典ID”可以通过**LST PDHOSTCFG**查询。
   3. 执行**MOD PCEFABIITEM**，调整PCRF对端PCEF能力字典，设置对端能力为支持基于3GPP R9标准的Usage Monitoring机制。

      当配置的FUP业务需使用3GPP R9标准的Usage Monitoring机制时，才需配置“UsageMonitor3GPPR9”的能力，否则，略过此步骤。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=UsageMonitor, ABLITYVALUE=UsageMonitor3GPPR9;	
      ```
   4. 执行**MOD PCEFABIITEM**，调整对端PCEF能力字典，设置Monitor Key以哪种字节长度处理。

      Monitor Key的长度处理方式有如下三种：
      * FourBytesHex：MonitorKey按照十六进制4字节处理。
      * MaxFourBytesHex：MonitorKey按照十六进制最大4字节处理。
      * ASCIIMode：MonitorKey按照ASCII码处理。

      命令举例：

      ```
      MOD PCEFABIITEM: ABILITYDICTID=67, ABILITYITEMID=MonitorKeyCodecModeForR9, ABLITYVALUE=ASCIIMode;	
      ```
2. 配置对端类别。
   1. 登录“UPCF MML命令”界面。
   2. 执行**ADD PPCEFCAT**，增加对端PCEF类别定义。

      命令举例：

      ```
      ADD PPCEFCAT: PCRFID=1, PCEFCATID=5, PCEFCAT="PCEF", TIMEOUTPROCESS=ReleaseSingleSession, TERMINALPROCESS=ReleaseSingleSession, TSAFAILDPROCESS=ReleaseSingleSession, ISAPN=NO;
      ADD PPCEFCAT: PCRFID=1, PCEFCATID=8, PCEFCAT="TDF", TIMEOUTPROCESS=ReleaseSingleSession, TERMINALPROCESS=ReleaseSingleSession, TSAFAILDPROCESS=ReleaseSingleSession, ISAPN=NO;
      ```
   3. 执行**ADD PPCEF**和**ADD PEER**，给对端指定对端PCEF类别。

      命令举例：

      ```
      ADD PPCEF: PCRFID=1, PCEFID=1, PN="pcef", PT=DIAMETER, DN="huawei.com", HN="pcef.huawei.com", DASWITCH=OFF, ABILITYDICTID=67, PCEFCAT="PCEF";
      ADD PEER: PCRFID=1, PEERID=2, PT=TDF, PN="pdf", DN="huawei.com", HN="tdf.huawei.com", DASWITCH=SdON-1, ABILITYDICTID=63, PEERCAT="TDF";
      ```
3. 登录UPCF WebUI界面。
4. 配置配额。

   导航入口为“业务管理 > 业务 > 配额”。

   配额的数据规划如表2所示，详细参数说明请参见配额参数表。

   **表2** 配额

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 配额 | 基本信息 | 名称 | Quota\_Service |
   |  |  | 配额管理归属 | UPCC |
   |  |  | 配额类型 | 流量 |
   |  |  | 类型 | 业务级 |
   |  |  | 监控键值 | 101 |
   |  |  | 值(KB) | 102400 |
   |  |  | 分片类型 | 值 |
   |  |  | 分片(KB) | 10240 |
   |  | 复位设置 | 结帐模式 | 自然日历 |
   |  |  | 复位周期类型 | 月 |
   |  |  | 复位日期 | 1 |
   |  |  | 复位时间 | 01:00:00 |
   |  |  | 剩余额处理方式 | 清零 |
5. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   条件组的数据规划如表3所示，详细参数说明请参见条件组参数表。

   **表3** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_Service1 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_Service1 |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Quota\_Service  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Normal  说明：  “Normal”：表示配额消耗没有耗尽。 |
   | 条件组2 | 基本信息 | 名称 | CG\_Service2 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_Service2 |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Quota\_Service  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示配额耗尽。 |
   | 条件组3 | 基本信息 | 名称 | CG\_Service3 |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | C\_Service3 |
   |  |  | 对象属性 | * 对象：IPSession * 属性：TDFApplicationIdentifier |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | ABC |
   |  | 条件2 | 名称 | C\_Service4 |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Quota\_Service  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Normal  说明：  “Normal”：表示配额消耗没有耗尽。 |
   | 条件组4 | 基本信息 | 名称 | CG\_Service4 |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | C\_Service5 |
   |  |  | 对象属性 | * 对象：IPSession * 属性：TDFApplicationIdentifier |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | ABC |
   |  | 条件2 | 名称 | C\_Service6 |
   |  |  | 对象属性 | * 对象：Quota * 属性：QuotaStatus |
   |  |  | 对象实例 | Quota\_Service  说明：  已在配额中定义。 |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | Exhaust  说明：  “Exhaust”：表示配额耗尽。 |
6. 配置动作组。

   导航入口为“策略管理 > 策略 > 动作组”。

   动作组的数据规划如表4所示，详细参数说明请参见动作组参数表。

   **表4** 动作组

   | 类别 | 参数 |  |  | 取值样例 |
   | --- | --- | --- | --- | --- |
   | 动作组 | 基本信息 | 名称 |  | AG\_Service |
   |  | 动作 | 动作 |  | UsageReport |
   |  |  | 动作元素 | MonitorKey | * 值类型：Value * 值：101 |
7. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   规则的数据规划如表5所示，详细参数说明请参见规则参数表。

   **表5** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | Rule\_CheckABC\_1M |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Predefined Group |
   |  |  | 预定义组名 | CheckABC\_1M |
   |  |  | 目的PEER | TDF |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Service1  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |
   | 规则2 | 基本信息 | 名称 | Rule\_CheckABC\_64k |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Predefined Group |
   |  |  | 预定义组名 | CheckABC\_64k |
   |  |  | 目的PEER | TDF |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Service2  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |
   | 规则3 | 基本信息 | 名称 | Rule\_IncludeABC\_1M |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Predefined Group |
   |  |  | 预定义组名 | IncludeABC\_1M |
   |  |  | 目的PEER | TDF |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Service3  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |
   | 规则4 | 基本信息 | 名称 | Rule\_IncludeABC\_64k |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Predefined Group |
   |  |  | 预定义组名 | IncludeABC\_64k |
   |  |  | 目的PEER | TDF |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Service4  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |
   | 规则5 | 基本信息 | 名称 | Rule\_UsageReport\_1M |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Predefined Group |
   |  |  | 预定义组名 | IncludeABC\_1M |
   |  |  | 目的PEER | TDF |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Service1  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |
   | 规则6 | 基本信息 | 名称 | Rule\_UsageReport\_64k |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | Predefined Group |
   |  |  | 预定义组名 | IncludeABC\_64k |
   |  |  | 目的PEER | TDF |
   |  |  | EDR | OFF |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_Service2  说明：  已在条件组中定义。 |
   |  | 动作组 | 动作组 | AG\_Service  说明：  已在动作组中定义。 |
8. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   策略的数据规划如表6所示，详细参数说明请参见策略参数表。

   **表6** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略1 | 基本信息 | 名称 | Policy\_Service1 |
   |  | 触发器 | 名称 | IPCANSessionEstablish |
   |  | 规则 | 名称 | * Rule\_CheckABC\_1M * Rule\_CheckABC\_64k 说明：  已在规则中定义。 |
   | 策略2 | 基本信息 | 名称 | Policy\_Service2 |
   |  | 触发器 | 名称 | ApplicationStart |
   |  | 规则 | 名称 | * Rule\_IncludeABC\_1M * Rule\_IncludeABC\_64k 说明：  已在规则中定义。 |
   | 策略3 | 基本信息 | 名称 | Policy\_Service3 |
   |  | 触发器 | 名称 | UsageReport |
   |  | 规则 | 名称 | * Rule\_UsageReport\_1M * Rule\_UsageReport\_64k 说明：  已在规则中定义。 |
9. 配置业务。

   导航入口为“业务管理 > 业务 > 业务”。

   完成业务配置后，可以配置套餐，即对一组业务进行逻辑组合，统一包装。用户可以订购套餐，订购了套餐即把该套餐下的所有业务都订购，套餐的配置步骤请参见套餐。

   业务的数据规划如表7所示，详细参数说明请参见业务参数表。

   **表7** 业务

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务 | 基本信息 | 名称 | TDF\_Service |
   |  |  | 类型 | VALUE\_ADDED\_SERVICE |
   |  |  | 是否记入基本配额 | 是 |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值可任意取值。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | * Policy\_Service1 * Policy\_Service2 * Policy\_Service3 说明：  已在策略中定义。 |
   |  | 配额 | 名称 | Quota\_Service  说明：  已在配额中定义。 |
10. 登录“UPCF 业务管理”窗口。
11. 发放业务。
    1. 执行**ADD PSUB**增加一个用户。

       “USRIDENTIFIER”的参数类型受软参VRM\_SUBSRCIPTIONIDTYPE（系统支持的用户类型）控制，默认为“IMSI”。

       ```
       ADD PSUB:USRIDENTIFIER="46010381012****", USRMSISDN="12345678901", USRSTATE=Normal, USRPAIDTYPE=NULL, USRSTATION=Master, USRCONTACTMETHOD=SMS, USRBILLCYCLEDATE=NULL, USRSUBNETTYPE=MBB;
       ```
    2. 执行**ADD PSRV**给用户签约业务。

       ```
       ADD PSRV: USRIDENTIFIER="46010381012****", SRVNAME="TDF_Service", SRVUSAGESTATE=Normal, SRVROAMINGTYPE=NULL;
       ```

#### 任务示例

**脚本**

CLI脚本

版权所有 © 华为技术有限公司
