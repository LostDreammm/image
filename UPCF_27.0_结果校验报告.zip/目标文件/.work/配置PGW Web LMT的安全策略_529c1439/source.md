# 配置PGW Web LMT的安全策略

* 操作场景
* 对系统的影响
* 必备事项
* 操作步骤

#### 操作场景

当USCDB与业务发放系统均完成硬件数据和基础数据的配置后，需要配置PGW Web LMT的安全策略。

PGW Web LMT的安全策略包括以下两个方面：

* 完善的密码安全措施，通过限制登录次数和返回固定错误消息等方式防止非授权人员进行密码暴力破解、非授权人员非法接入系统和密码遭盗窃。
* 用户登录PGW Web LMT时的安全性检查和配置，用于防止非法用户登录PGW Web LMT，保证系统的安全访问。

#### 对系统的影响

该操作对系统正常运行无影响。

#### 必备事项

**前提条件**

向系统管理员获取OM Portal和PGW Web LMT帐号的密码。

**数据**

该操作无需准备数据。

#### 操作步骤

1. 使用admin帐号登录PGW Web LMT MML命令界面。用户的默认密码请参见USCDB应用用户默认帐号。
2. 执行**SET SECPOLICY**命令，设置PGW Web LMT系统的安全策略。

   ```
   SET SECPOLICY: OPLCK=TRUE, TRYTIME=1, CLEAR=TRUE, INTERVAL=10, AUTOUNLCK=TRUE, LCKTIME=30, SECURITY=TRUE, FSTLOG=TRUE, HISRECORD=5, MINLEN=8, COMPLEX=CHAR-1&NOID-0&NOORD-0, CNUMS=3, CHARTYPE=UPPER-1&LOWER-1, TIMEMOD=TRUE, VALIDDAY=90, PROMPTDAY=5;
   ```

   执行**MOD OPR**命令可设置单个用户的安全策略信息。

版权所有 © 华为技术有限公司
