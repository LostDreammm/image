# SMF侧业务配置

* 操作场景
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

## 操作场景

根据整体方案设计，SMF侧需配置两个预定义规则：

* 规则名“Predefined1”：关键参数为5QI=5，ARP=2，MFBR=100Mbit/s。
* 规则名“Predefined2”：关键参数为5QI=5，ARP=2，MFBR=1Mbit/s。

## 必备事项

前提条件

* 请仔细阅读UNC特性之《WSFD-109101 PCC基本功能》。
* 完成加载License（如果有需求，请联系华为技术支持工程师）。
* 已通过学习SM策略E2E实现原理、业务配置方法及E2E业务调测了解了SM策略的配置原理及方法。

数据

PCF通过预定义规则下发规则标识时，SMF侧需规划表1中的数据。

**表1** 数据规划

| 类别 | 参数名称 | 取值样例 | 获取方法 | 说明 |
| --- | --- | --- | --- | --- |
| **ADD URR** | 使用量上报规则名称（URRNAME） | * urr\_QoS2 * urr\_QoS3 | 本端规划 | 存在多条记录时，该参数不能重复。 |
|  | URR标识（URRID） | * 2（对应“urr\_QoS2”） * 3（对应“urr\_QoS3”） | 与对端协商 | 该参数需要与UPF上的URR标识保持一致。 |
|  | 使用量上报模式（USAGERPTMODE） | QOS | 固定取值 | - |
| **ADD QOSPROP** | QOSPROPNAME（QoS属性名称） | * qosprop\_5qi5\_arp2\_100 * qosprop\_5qi5\_arp2\_1 | 本端规划 | 存在多条记录时，不能重复。 |
|  | EMPCAP（QoS抢占能力） | DISABLE | 本端规划 | 该业务可以抢占已经分配给其他低优先级业务流的资源时，设置为ENABLE。此处以不抢占为例。 |
|  | EMPVUL（QoS被抢占设置） | ENABLE | 本端规划 | 其他高优先级业务不能抢占本业务流的资源时，设置为DISABLE。此处以被抢占为例。 |
|  | MBRUPLKVALUE（最大上行比特率） | * 100000 * 1000 | 本端规划 | 此处数据仅为举例，请根据业务模型进行规划。  创建专有QoSFlow/专有承载时，以SMF上此处配置的为准。 |
|  | MBRDNLKVALUE（最大下行比特率） | * 100000 * 1000 | 本端规划 |  |
|  | ARPVALUE（分配保留优先级） | 2 | 本端规划 | “QOSTYPE”为“QOS\_FLOW\_PARA”时需要规划。 |
|  | FQI（5G QoS标识） | 5 | 本端规划 |  |
|  | QOSURRNAME（QoS使用量上报规则名称） | * urr\_QoS2 * urr\_QoS3 | 已配置数据中获取 | 使用**ADD URR**定义的URRNAME。 |
| ****ADD PCCPOLICYGRP**** | PCC策略组名称（PCCPOLICYGRPNM） | * pccfuppolicy\_100M * pccfuppolicy\_1M | 本端规划 | 存在多条记录时，该参数不能重复。 |
|  | QoS属性名称（QOSPROPNAME） | * qosprop\_5qi5\_arp2\_100 * qosprop\_5qi5\_arp2\_1 | 本端规划 | 使用**ADD QOSPROP**定义的**QOSPROPNAME**。 |
| ****ADD RULE**** | 规则名称（RULENAME） | * Predefined1 * Predefined2 | 本端规划 | 存在多条数据时，该参数+策略类型不能完全相同。 |
|  | 策略类型（POLICYTYPE） | PCC | 本端规划 | 需根据业务策略选择相应的策略类型。 |
|  | 全局优先级（PRIORITY） | 10 | 本端规划 | 值越小，优先级越高。 |
|  | 策略名称（POLICYNAME） | * pccfuppolicy\_100M * pccfuppolicy\_1M | 已配置数据中获取 | 使用**ADD PCCPOLICYGRP**定义的“PCCPOLICYGRPNM”。 |

## 操作流程

此特性的配置流程图如图1所示。

**图1** UNC（SMF）侧业务配置流程图

## 操作步骤

1. 登录UNC CSP OM Portal，进入“MML命令行-UNC”窗口。
2. 开启License。

   该步骤为预定义规则（组）场景下的必选配置。执行SET LICENSESWITCH命令设置基于使用量特性对应的License开关。

   ```
   SET LICENSESWITCH:LICITEM="LKV2FUPSAT01",SWITCH=ENABLE;
   ```
3. 打开PCC功能开关。

   步骤为预定义规则（组）场景下的必选配置。预定义规则（组）场景下，策略下发都涉及PCF网元配置，因此需打开此开关。

   ```
   SET PCCFUNC: HOMEPCCSWITCH=ENABLE;
   ```
4. （条件可选）使能APN PCC开关。

   该步骤主要用于使能或关闭指定APN/DNN用户的动态PCC功能。例如当前网络中有两个数据APN，分别为APN1和APN2，可通过配置此命令对APN1与APN2做业务隔离。

   ```
   SET APNPCCFUNC: APN="cmnet", HOMEPCCSWITCH=ENABLE, ROAMPCCSWITCH=ENABLE, VISITPCCSWITCH=ENABLE;
   ```

   针对多APN组网复杂的场景，建议配置此命令。
5. 配置QoS URR。

   该步骤为预定义规则（组）场景下的可选配置，只有在基于使用量上报/QoS控制/计费控制场景才需配置，此处根据需求描述需配置QoS URR。

   ```
   ADD URR:URRNAME="urr_QoS2", URRID=2, USAGERPTMODE=QOS;
   ADD URR:URRNAME="urr_QoS3", URRID=3, USAGERPTMODE=QOS;
   ```
6. 配置QoS参数。

   该步骤为预定义规则（组）场景下的可选配置。只有在需要对用户进行带宽控制或建立专有QoS Flow时，才需配置。须配置配额耗尽前、耗尽后两种场景的带宽控制策略。

   //用户从国内接入网络时，即PCF下发预定义规则predefined1场景，此处5QI/ARP取值参考SMF（UNC）侧业务设计规划分别取5和2。

   ```
   ADD QOSPROP: QOSPROPNAME="qosprop_5qi5_arp2_100", MBRUPLKVALUE=100000, MBRDNLKVALUE=100000, QOSTYPE=QOS_FLOW_PARA, ARPVALUE=2, FQI=5, QOSURRNAME="urr_QoS2";
   ```

   //用户从国外（漫游区）的地方接入网络时，即PCF下发预定义规则predefined2场景，此处5QI/ARP取值参考SMF（UNC）侧业务设计规划分别取5和2。

   ```
   ADD QOSPROP: QOSPROPNAME="qosprop_5qi5_arp2_1", MBRUPLKVALUE=1000, MBRDNLKVALUE=1000, QOSTYPE=QOS_FLOW_PARA, ARPVALUE=2, FQI=5, QOSURRNAME="urr_QoS3";
   ```
7. 配置PCC策略组。

   该步骤为预定义规则（组）场景下的必选配置。配置PCC策略组的目的是用于关联QoS URR策略。此处“URRGROUPNAME”参数使用ADD URRGROUP定义的“URRGROUPNAME”。

   //用户从国内接入网络时，即PCF下发预定义规则predefined1场景。

   ```
   ADD PCCPOLICYGRP:PCCPOLICYGRPNM="pccfuppolicy_100M", QOSPROPNAME="qosprop_5qi5_arp2_100";
   ```

   //用户从国外（漫游区）的地方接入网络时，即PCF下发预定义规则predefined2场景。

   ```
   ADD PCCPOLICYGRP:PCCPOLICYGRPNM="pccfuppolicy_1M", QOSPROPNAME="qosprop_5qi5_arp2_1";
   ```
8. 配置预定义规则。

   该步骤为预定义规则（组）场景下的必选配置。主要用于关联PCC策略组。此处预定义规则名称、数量都须与PCF侧定义的保持一致。

   ```
   ADD RULE:RULENAME="Predefined1",POLICYTYPE=PCC,PRIORITY=10,POLICYNAME="pccfuppolicy_100M";
   ADD RULE:RULENAME="Predefined2",POLICYTYPE=PCC,PRIORITY=10,POLICYNAME="pccfuppolicy_1M";
   ```

## 任务示例

任务描述

配置规则Predefined1、Predefined2。

脚本

业务导入脚本：SMF MML

业务回退脚本：SMF MML Deleting

版权所有 © 华为技术有限公司
