---
id: ''
name: SMF侧业务配置
ne_type: UPCF
type: feature
description: 根据整体方案设计，SMF侧需配置两个预定义规则：  * 规则名“Predefined1”：关键参数为5QI=5，ARP=2，MFBR=100Mbit/s。 * 规则名“Predefined2”：关键参数为5QI=5，ARP=2，MFBR=1Mbit/s。
risk_level: ''
doc_source: ["特性","功能专题","UPCF 5G PCC之SM策略解决方案专题","典型业务场景E2E方案设计","基于位置区域的带宽差异化控制方案（预定义）","E2E业务配置","SMF侧业务配置"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
根据整体方案设计，SMF侧需配置两个预定义规则：* 规则名“Predefined1”：关键参数为5QI=5，ARP=2，MFBR=100Mbit/s。* 规则名“Predefined2”：关键参数为5QI=5，ARP=2，MFBR=1Mbit/s。

## 必备事项
前提条件

* 请仔细阅读UNC特性之《WSFD-109101 PCC基本功能》。
* 完成加载License（如果有需求，请联系华为技术支持工程师）。
* 已通过学习SM策略E2E实现原理、业务配置方法及E2E业务调测了解了SM策略的配置原理及方法。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    set_licenseswitch_list:
      type: items
      properties:
        LICITEM:
          name: 'LICITEM'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        SWITCH:
          name: 'SWITCH'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_pccfunc_list:
      type: items
      properties:
        HOMEPCCSWITCH:
          name: 'HOMEPCCSWITCH'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    set_apnpccfunc_list:
      type: items
      properties:
        APN:
          name: 'APN'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        HOMEPCCSWITCH:
          name: 'HOMEPCCSWITCH'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ROAMPCCSWITCH:
          name: 'ROAMPCCSWITCH'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        VISITPCCSWITCH:
          name: 'VISITPCCSWITCH'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    add_urr_list:
      type: items
      properties:
        URRNAME:
          name: '使用量上报规则名称'
          type: string
          required: false
          description: '存在多条记录时，该参数不能重复。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        URRID:
          name: 'URR标识'
          type: string
          required: false
          description: '该参数需要与UPF上的URR标识保持一致。'
          data_source: '与对端协商'
          pattern: ''
          default: ''
        USAGERPTMODE:
          name: '使用量上报模式'
          type: string
          required: false
          description: '-'
          data_source: '固定取值'
          pattern: ''
          default: ''
    add_qosprop_list:
      type: items
      properties:
        QOSPROPNAME:
          name: 'QoS属性名称'
          type: string
          required: false
          description: '存在多条记录时，不能重复。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        MBRUPLKVALUE:
          name: '最大上行比特率'
          type: string
          required: false
          description: '此处数据仅为举例，请根据业务模型进行规划。  创建专有QoSFlow/专有承载时，以SMF上此处配置的为准。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        MBRDNLKVALUE:
          name: '最大下行比特率'
          type: string
          required: false
          description: ''
          data_source: '本端规划'
          pattern: ''
          default: ''
        QOSTYPE:
          name: 'QOSTYPE'
          type: string
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ARPVALUE:
          name: '分配保留优先级'
          type: string
          required: false
          description: '“QOSTYPE”为“QOS_FLOW_PARA”时需要规划。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        FQI:
          name: '5G QoS标识'
          type: string
          required: false
          description: ''
          data_source: '本端规划'
          pattern: ''
          default: ''
        QOSURRNAME:
          name: 'QoS使用量上报规则名称'
          type: string
          required: false
          description: '使用**ADD URR**定义的URRNAME。'
          data_source: '已配置数据中获取'
          pattern: ''
          default: ''
        EMPCAP:
          name: 'QoS抢占能力'
          type: string
          required: false
          description: '该业务可以抢占已经分配给其他低优先级业务流的资源时，设置为ENABLE。此处以不抢占为例。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        EMPVUL:
          name: 'QoS被抢占设置'
          type: string
          required: false
          description: '其他高优先级业务不能抢占本业务流的资源时，设置为DISABLE。此处以被抢占为例。'
          data_source: '本端规划'
          pattern: ''
          default: ''
    add_pccpolicygrp_list:
      type: items
      properties:
        PCCPOLICYGRPNM:
          name: 'PCC策略组名称'
          type: string
          required: false
          description: '存在多条记录时，该参数不能重复。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        QOSPROPNAME:
          name: 'QoS属性名称'
          type: string
          required: false
          description: '使用**ADD QOSPROP**定义的**QOSPROPNAME**。'
          data_source: '本端规划'
          pattern: ''
          default: ''
    add_rule_list:
      type: items
      properties:
        RULENAME:
          name: '规则名称'
          type: string
          required: false
          description: '存在多条数据时，该参数+策略类型不能完全相同。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        POLICYTYPE:
          name: '策略类型'
          type: string
          required: false
          description: '需根据业务策略选择相应的策略类型。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        PRIORITY:
          name: '全局优先级'
          type: string
          required: false
          description: '值越小，优先级越高。'
          data_source: '本端规划'
          pattern: ''
          default: ''
        POLICYNAME:
          name: '策略名称'
          type: string
          required: false
          description: '使用**ADD PCCPOLICYGRP**定义的“PCCPOLICYGRPNM”。'
          data_source: '已配置数据中获取'
          pattern: ''
          default: ''
  examples:
  - set_licenseswitch_list:
    - LICITEM: LKV2FUPSAT01
      SWITCH: ENABLE
    set_pccfunc_list:
    - HOMEPCCSWITCH: ENABLE
    set_apnpccfunc_list:
    - APN: cmnet
      HOMEPCCSWITCH: ENABLE
      ROAMPCCSWITCH: ENABLE
      VISITPCCSWITCH: ENABLE
    add_urr_list:
    - URRNAME: urr_QoS2
      URRID: '2'
      USAGERPTMODE: QOS
    add_qosprop_list:
    - QOSPROPNAME: qosprop_5qi5_arp2_100
      MBRUPLKVALUE: '100000'
      MBRDNLKVALUE: '100000'
      QOSTYPE: QOS_FLOW_PARA
      ARPVALUE: '2'
      FQI: '5'
      QOSURRNAME: urr_QoS2
      EMPCAP: DISABLE
      EMPVUL: ENABLE
    - QOSPROPNAME: qosprop_5qi5_arp2_1
      MBRUPLKVALUE: '1000'
      MBRDNLKVALUE: '1000'
      QOSTYPE: QOS_FLOW_PARA
      ARPVALUE: '2'
      FQI: '5'
      QOSURRNAME: urr_QoS3
      EMPCAP: ''
      EMPVUL: ''
    add_pccpolicygrp_list:
    - PCCPOLICYGRPNM: pccfuppolicy_100M
      QOSPROPNAME: qosprop_5qi5_arp2_100
    - PCCPOLICYGRPNM: pccfuppolicy_1M
      QOSPROPNAME: qosprop_5qi5_arp2_1
    add_rule_list:
    - RULENAME: Predefined1
      POLICYTYPE: PCC
      PRIORITY: '10'
      POLICYNAME: pccfuppolicy_100M
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录UNC CSP OM Portal，进入“MML命令行-UNC”窗口。

### 2 开启License。

### 该步骤为预定义规则（组）场景下的必选配置。执行SET LICENSESWITCH命令设置基于使用量特性对应的License开关。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该set_licenseswitch_list的变量区（command: SET LICENSESWITCH） -#}
<!-- MISSING_MACRO: command=SET LICENSESWITCH list_name=set_licenseswitch_list step_id=2 -->
```

### 3 打开PCC功能开关。

### 步骤为预定义规则（组）场景下的必选配置。预定义规则（组）场景下，策略下发都涉及PCF网元配置，因此需打开此开关。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该set_pccfunc_list的变量区（command: SET PCCFUNC） -#}
<!-- MISSING_MACRO: command=SET PCCFUNC list_name=set_pccfunc_list step_id=3 -->
```

### 4 （条件可选）使能APN PCC开关。

### 该步骤主要用于使能或关闭指定APN/DNN用户的动态PCC功能。例如当前网络中有两个数据APN，分别为APN1和APN2，可通过配置此命令对APN1与APN2做业务隔离。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该set_apnpccfunc_list的变量区（command: SET APNPCCFUNC） -#}
<!-- MISSING_MACRO: command=SET APNPCCFUNC list_name=set_apnpccfunc_list step_id=4 -->
```

### 针对多APN组网复杂的场景，建议配置此命令。

### 5 配置QoS URR。

### 该步骤为预定义规则（组）场景下的可选配置，只有在基于使用量上报/QoS控制/计费控制场景才需配置，此处根据需求描述需配置QoS URR。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_urr_list的变量区（command: ADD URR） -#}
<!-- MISSING_MACRO: command=ADD URR list_name=add_urr_list step_id=5 -->
```

### 6 配置QoS参数。

### 该步骤为预定义规则（组）场景下的可选配置。只有在需要对用户进行带宽控制或建立专有QoS Flow时，才需配置。须配置配额耗尽前、耗尽后两种场景的带宽控制策略。

#### 6.1 //用户从国内接入网络时，即PCF下发预定义规则predefined1场景，此处5QI/ARP取值参考SMF（UNC）侧业务设计规划分别取5和2。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_qosprop_list的变量区（command: ADD QOSPROP） -#}
<!-- MISSING_MACRO: command=ADD QOSPROP list_name=add_qosprop_list step_id=6.1 -->
```

### 7 配置PCC策略组。

### 该步骤为预定义规则（组）场景下的必选配置。配置PCC策略组的目的是用于关联QoS URR策略。此处“URRGROUPNAME”参数使用ADD URRGROUP定义的“URRGROUPNAME”。

#### 7.1 //用户从国内接入网络时，即PCF下发预定义规则predefined1场景。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_pccpolicygrp_list的变量区（command: ADD PCCPOLICYGRP） -#}
<!-- MISSING_MACRO: command=ADD PCCPOLICYGRP list_name=add_pccpolicygrp_list step_id=7.1 -->
```

### 8 配置预定义规则。

### 该步骤为预定义规则（组）场景下的必选配置。主要用于关联PCC策略组。此处预定义规则名称、数量都须与PCF侧定义的保持一致。

```jinja2
{#- 需人工查询macro中是否存在该command并且包含parameters参数的命令，确认后人工填写jinja模板并优化该add_rule_list的变量区（command: ADD RULE） -#}
<!-- MISSING_MACRO: command=ADD RULE list_name=add_rule_list step_id=8 -->
```

