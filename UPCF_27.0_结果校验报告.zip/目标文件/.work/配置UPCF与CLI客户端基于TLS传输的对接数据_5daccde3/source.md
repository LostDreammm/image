# 配置UPCF与CLI客户端基于TLS传输的对接数据

* 操作场景
* 必备事项
* 操作步骤
* 验证方法

## 操作场景

UPCF可以与CLI客户端对接，支持用户通过CLI/SCLI接口实现UPCF的策略数据配置。为保证系统安全，推荐使用SCLI接口。

SCLI接口是基于TLS传输的安全的CLI接口。

## 必备事项

前提条件

* 已完成软件安装。
* 已完成基础数据配置。
* CLI侧已完成基础数据配置。
* UPCF与CLI客户端的网络连接正常。
* 已经获得运营商规划的UPCF与CLI的对接IP地址。

数据

配置前规划的对接数据如表1所示。

**表1** 对接数据

| 类别 | 参数名称 | 取值样例 | 说明 |
| --- | --- | --- | --- |
| **ADD PMSVPN** | VPNINDEX（VPN索引） | 1 | 本端规划，取值范围内不允许重复。 |
|  | VPNNAME（VPN名称） | PMS\_VPN | 全网规划，由运营商提供。 |
| **ADD PMSDEVADDR** | DEVAID（设备地址标识） | 3 | 本端规划，取值范围内不允许重复。 |
|  | VPNINDEX（VPN索引） | 1 | 网元安装完成后，由运营商对已部署的VPN进行统一规划。 |
|  | IPVER（IP版本） | IPV4 | 全网规划，由运营商提供。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。 |
|  | IPV4地址（IP） | 10.1.0.1 | 全网规划，由运营商提供。 |
|  | DESCRIPTION（描述） | PMS IP | 全网规划，由运营商提供。 |
| **MOD PMSPMGRPORT** | ENABLEPORT（端口激活状态） | ACTIVE | 全网规划，由运营商提供。 |
|  | ALIVETIME（保活时长） | 10 | 全网规划，由运营商提供。 |
| **MOD PMSSSP** | SCP（系统配置参数） | SYSPARAMETER | 在此场景下固定配置为“SYSPARAMETER”。 |
|  | SPN（参数名） | VRM\_CLIWORKMODE | 在此场景下固定配置为“VRM\_CLIWORKMODE”。 |
|  | SPV（参数值） | 1 | 在此场景下固定配置为“1”。 |
| **MOD PMSFUNC** | TYPE（配置类型） | Server | 全网规划，由运营商提供。 |
|  | ITEMN（配置项名称） | sslEnabledProtocols | 全网规划，由运营商提供。 |
|  | VALUE（配置项值） | TLSv1.2 | 在此场景下固定配置为“TLSv1.2”。 |
| **MOD PMSFUNC** | TYPE（配置类型） | Server | 全网规划，由运营商提供。 |
|  | ITEMN（配置项名称） | ciphers | 全网规划，由运营商提供。 |
|  | VALUE（配置项值） | TLS\_ECDHE\_RSA\_WITH\_AES\_256\_GCM\_SHA384 | 全网规划，由运营商提供。 |
| **MOD PMSFUNC** | TYPE（配置类型） | Server | 全网规划，由运营商提供。 |
|  | ITEMN（配置项名称） | certForSCLI | 全网规划，由运营商提供。 |
|  | CERTSCENE（证书应用场景） | UPCF\_PMS\_certForSCLI | 全网规划，由运营商提供。 |

## 操作步骤

1. 登录OM Portal界面，在“应用管理>MML”中选择“UPCF”网元。
2. 执行**ADD PMSVPN**命令增加UPCF与CLI对接的VPN地址。

   ```
   ADD PMSVPN: VPNINDEX=VPN索引, VPNNAME=VPN名称;
   ```
3. 执行**ADD PMSDEVADDR**命令增加UPCF与CLI对接的IP地址。

   以参数“IPVER”值为“IPV4”为例：

   ```
   ADD PMSDEVADDR: DEVAID=设备地址标识, VPNINDEX=VPN索引, IPVER=IPV4, IP=IPV4地址, DESCRIPTION=描述;
   ```
4. 执行**MOD PMSPMGRPORT**命令激活端口。

   ```
   MOD PMSPMGRPORT: ENABLEPORT=端口激活状态, ALIVETIME=保活时长;
   ```
5. 执行**MOD PMSSSP**命令将软参“VRM\_CLIWORKMODE”取值设置为“1”。

   ```
   MOD PMSSSP: SCP=SYSPARAMETER, SPN=VRM_CLIWORKMODE, SPV=1;
   ```
6. 执行**MOD PMSFUNC**命令配置TLS协议版本、加密套件和证书应用场景。

   命令举例：

   ```
   /*配置最新的TLS协议版本*/
   MOD PMSFUNC: TYPE=Server, ITEMN=sslEnabledProtocols, VALUE="TLSv1.2";
   /*配置加密套件，需与对端协商后获取*/
   MOD PMSFUNC: TYPE=Server, ITEMN=ciphers, VALUE="TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384";
   /*配置证书应用场景，SCLI接口服务端证书为UPCF_PMS_certForSCLI*/
   MOD PMSFUNC: TYPE=Server, ITEMN=certForSCLI, CERTSCENE=UPCF_PMS_certForSCLI;
   ```
7. 执行**MOD PMSFUNC**命令配置TLS协议版本、加密套件和证书应用场景后，需要重启PMS服务后才能生效：（登录“UPCF MML命令”界面，执行**RST MSPROCESS**命令重启PMS服务。）

   ```
   DSP MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_PcfPms";
   RST MSPROCESS: PROCOBJECT=PROCNAME, PROCNAME="CELL_PcfPms";
   ```
8. 下面介绍UPCF Web UI系统用于对接CLI客户端的用户帐号配置方法：

   1. 选择导航栏上的“安全管理 > 权限 > 系统用户”，显示系统用户查询主界面。
   2. 单击工具栏上的“增加”，弹出“增加系统用户”对话框。
   3. 在“基本信息”页签，配置“系统用户”的基本信息，选择“用户类别”为“CLI用户”，如图1所示。

      **图1** 增加系统用户
   4. 在“增加系统用户”对话框，单击“确定”完成用户账户的配置。

## 验证方法

1. 检查UPCF的CLI连接。
   1. 根据规划数据在对端使用telnet命令（telnet命令格式：telnet ip 端口）访问PMS的CLI服务端。
      * 可以访问CLI服务端=> UPCF-CLI连接正常，检查完成。
      * 无法访问CLI服务端=> b
   2. 检查网络连接。

      联系基础设施层维护人员，检查基础设施层是否存在网络故障。
      * 是 => 由基础设施层维护人员处理网络故障。
      * 否 => 联系华为技术支持处理。
2. 检查UPCF的SCLI连接。

   联系对端完成SCLI客户端证书加载后，按照上面检查UPCF的CLI连接的方法进行验证。

版权所有 © 华为技术有限公司
