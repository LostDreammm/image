---
id: ''
name: 配置UPCF与CLI客户端基于TLS传输的对接数据
ne_type: UPCF
type: feature
description: UPCF可以与CLI客户端对接，支持用户通过CLI/SCLI接口实现UPCF的策略数据配置。为保证系统安全，推荐使用SCLI接口。  SCLI接口是基于TLS传输的安全的CLI接口。
risk_level: ''
doc_source: ["网络部署","初始配置","初始配置","初始配置与调测（SDN）","配置UPCF对接数据","配置UPCF与CLI客户端基于TLS传输的对接数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
UPCF可以与CLI客户端对接，支持用户通过CLI/SCLI接口实现UPCF的策略数据配置。为保证系统安全，推荐使用SCLI接口。SCLI接口是基于TLS传输的安全的CLI接口。

## 必备事项
前提条件

* 已完成软件安装。
* 已完成基础数据配置。
* CLI侧已完成基础数据配置。
* UPCF与CLI客户端的网络连接正常。
* 已经获得运营商规划的UPCF与CLI的对接IP地址。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    add_pmsvpn_list:
      type: items
      properties:
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNNAME:
          name: 'VPN名称'
          type: string
          minLength: 0
          maxLength: 32
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    add_pmsdevaddr_list:
      type: items
      properties:
        DEVAID:
          name: '设备地址标识'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '本端规划，取值范围内不允许重复。'
          data_source: ''
          pattern: ''
          default: ''
        VPNINDEX:
          name: 'VPN索引'
          type: integer
          minimum: 0
          maximum: 31
          required: true
          description: '网元安装完成后，由运营商对已部署的VPN进行统一规划。'
          data_source: ''
          pattern: ''
          default: ''
        IPVER:
          name: 'IP版本'
          type: string
          enum:
          - IPV4
          - IPV6
          required: true
          description: '全网规划，由运营商提供。  只有当“IPVER”为“IPV4”时，才会规划IPv4地址。  当“IPVER”为“IPV6”时，此处规划的参数应为IPv6地址。'
          data_source: ''
          pattern: ''
          default: ''
        IP:
          name: 'IPV4地址'
          type: string
          maxLength: 15
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        DESCRIPTION:
          name: '描述'
          type: string
          minLength: 0
          maxLength: 32
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        IPV6:
          name: 'IPV6地址'
          type: string
          maxLength: 39
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_pmspmgrport_list:
      type: items
      properties:
        ENABLEPORT:
          name: '端口激活状态'
          type: string
          enum:
          - ACTIVE
          - INACTIVE
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        ALIVETIME:
          name: '保活时长'
          type: integer
          minimum: 1
          maximum: 20160
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    mod_pmsssp_list:
      type: items
      properties:
        SCP:
          name: '系统配置参数'
          type: string
          enum:
          - SYSPARAMETER
          required: true
          description: '在此场景下固定配置为“SYSPARAMETER”。'
          data_source: ''
          pattern: ''
          default: ''
        SPN:
          name: '参数名'
          type: string
          enum:
          - VRM_PPMWORKMODE
          - VRM_PMWORKMODE
          - VRM_4AWORKMODE
          - VRM_CLIMODIFYCTRL
          - VRM_MAXQUOTANUMPERSERVICE
          - VRM_CHKSOAPUSERSWITCH
          - VRM_PMSCRLPOLICY
          - VRM_CLIWORKMODE
          - VRM_SETPMSDOMAIN
          - VRM_PMSOPTLOGSW
          - VRM_VOLTEGLOBALDATA
          - VRM_PMSSFTPCLIENTACSWITCH
          - VRM_MAXSRVZONENUMPERAREA
          - VRM_PMSCHKINVALIDCH
          - VRM_SSHWORKMODE
          - VRM_PMSSSHSRVACSWITCH
          required: true
          description: '在此场景下固定配置为“VRM_CLIWORKMODE”。'
          data_source: ''
          pattern: ''
          default: ''
        SPV:
          name: '参数值'
          type: integer
          minimum: 0
          maximum: 2147483647
          required: true
          description: '在此场景下固定配置为“1”。'
          data_source: ''
          pattern: ''
          default: ''
    mod_pmsfunc_list:
      type: items
      properties:
        TYPE:
          name: '配置类型'
          type: string
          enum:
          - FtpConfig
          - WebUI
          - MbeanConfig
          - Server
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        ITEMN:
          name: '配置项名称'
          type: string
          enum:
          - mode
          - lockTimeout
          - checkVerifyCode
          - sessionTimeout
          - diskLowValue
          - diskHighValue
          - sslEnabledProtocols
          - ciphers
          - cert
          - certForPM
          - certForSCLI
          - logFileFormat
          - xssCheckSwitch
          - cliVerifySwitch
          - sqlCheckSwitch
          - pmsWebSwitch
          - certForRest
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        VALUE:
          name: '配置项值'
          type: string
          minLength: 0
          maxLength: 512
          required: false
          description: '在此场景下固定配置为“TLSv1.2”。'
          data_source: ''
          pattern: ''
          default: ''
    mod_pmsfunc_list_1:
      type: items
      properties:
        TYPE:
          name: '配置类型'
          type: string
          enum:
          - FtpConfig
          - WebUI
          - MbeanConfig
          - Server
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        ITEMN:
          name: '配置项名称'
          type: string
          enum:
          - mode
          - lockTimeout
          - checkVerifyCode
          - sessionTimeout
          - diskLowValue
          - diskHighValue
          - sslEnabledProtocols
          - ciphers
          - cert
          - certForPM
          - certForSCLI
          - logFileFormat
          - xssCheckSwitch
          - cliVerifySwitch
          - sqlCheckSwitch
          - pmsWebSwitch
          - certForRest
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        VALUE:
          name: '配置项值'
          type: string
          minLength: 0
          maxLength: 512
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
    mod_pmsfunc_list_2:
      type: items
      properties:
        TYPE:
          name: '配置类型'
          type: string
          enum:
          - FtpConfig
          - WebUI
          - MbeanConfig
          - Server
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        ITEMN:
          name: '配置项名称'
          type: string
          enum:
          - mode
          - lockTimeout
          - checkVerifyCode
          - sessionTimeout
          - diskLowValue
          - diskHighValue
          - sslEnabledProtocols
          - ciphers
          - cert
          - certForPM
          - certForSCLI
          - logFileFormat
          - xssCheckSwitch
          - cliVerifySwitch
          - sqlCheckSwitch
          - pmsWebSwitch
          - certForRest
          required: true
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        CERTSCENE:
          name: '证书应用场景'
          type: string
          enum:
          - UPCF_PMS_Lcert
          - 'NULL'
          - UPCF_PMS_certForPM
          - UPCF_PMS_certForSCLI
          - UPCF_PMS_certForRest
          required: false
          description: '全网规划，由运营商提供。'
          data_source: ''
          pattern: ''
          default: ''
        VALUE:
          name: '配置项值'
          type: string
          minLength: 0
          maxLength: 512
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    rst_msprocess_list:
      type: items
      properties:
        PROCOBJECT:
          name: '操作对象'
          type: string
          enum:
          - PROCNAME
          - PROCID
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROCNAME:
          name: '进程类型'
          type: string
          minLength: 1
          maxLength: 31
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        MEID:
          name: '网元ID'
          type: string
          minLength: 0
          maxLength: 40
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        PROCID:
          name: '进程ID'
          type: string
          minLength: 1
          maxLength: 100
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - add_pmsvpn_list:
    - VPNINDEX: 1
      VPNNAME: 'PMS_VPN'
    add_pmsdevaddr_list:
    - DEVAID: 3
      VPNINDEX: 1
      IPVER: IPV4
      IP: '10.1.0.1'
      DESCRIPTION: 'PMS IP'
      IPV6: ''
    mod_pmspmgrport_list:
    - ENABLEPORT: ACTIVE
      ALIVETIME: 10
    mod_pmsssp_list:
    - SCP: SYSPARAMETER
      SPN: VRM_CLIWORKMODE
      SPV: 1
    mod_pmsfunc_list:
    - TYPE: Server
      ITEMN: sslEnabledProtocols
      VALUE: 'TLSv1.2'
    mod_pmsfunc_list_1:
    - TYPE: Server
      ITEMN: ciphers
      VALUE: 'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384'
    mod_pmsfunc_list_2:
    - TYPE: Server
      ITEMN: certForSCLI
      CERTSCENE: UPCF_PMS_certForSCLI
      VALUE: ''
    rst_msprocess_list:
    - PROCOBJECT: PROCNAME
      PROCNAME: 'CELL_PcfPms'
      MEID: ''
      PROCID: ''
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录OM Portal界面，在“应用管理>MML”中选择“UPCF”网元。

### 2 执行**ADD PMSVPN**命令增加UPCF与CLI对接的VPN地址。

```jinja2
{%- for item in add_pmsvpn_list -%}
    ADD PMSVPN:
    {#- --- 必选参数 --- -#}
    VPNINDEX={{item.VPNINDEX}},
    VPNNAME="{{item.VPNNAME}}",
    ;
{%- endfor -%}
```

### 3 执行**ADD PMSDEVADDR**命令增加UPCF与CLI对接的IP地址。

### 以参数“IPVER”值为“IPV4”为例：

```jinja2
{%- for item in add_pmsdevaddr_list -%}
    ADD PMSDEVADDR:
    {#- --- 必选参数 --- -#}
    DEVAID={{item.DEVAID}},
    VPNINDEX={{item.VPNINDEX}},
    IPVER={{item.IPVER}},
    {#- --- 可选参数 --- -#}
    {%- if item.DESCRIPTION is not none -%}
        DESCRIPTION="{{item.DESCRIPTION}}",
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：IPVER=IPV4 时必选 --- -#}
    {%- if item.IPVER == 'IPV4' -%}
        IP="{{item.IP}}",
    {%- endif -%}
    {#- --- 条件必选：IPVER=IPV6 时必选 --- -#}
    {%- if item.IPVER == 'IPV6' -%}
        IPV6="{{item.IPV6}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 4 执行**MOD PMSPMGRPORT**命令激活端口。

```jinja2
{%- for item in mod_pmspmgrport_list -%}
    MOD PMSPMGRPORT:
    {#- --- 可选参数 --- -#}
    {%- if item.ENABLEPORT is not none -%}
        ENABLEPORT={{item.ENABLEPORT}},
    {%- endif -%}
    {%- if item.ALIVETIME is not none -%}
        ALIVETIME={{item.ALIVETIME}},
    {%- endif -%}
    ;
{%- endfor -%}
```

### 5 执行**MOD PMSSSP**命令将软参“VRM\_CLIWORKMODE”取值设置为“1”。

```jinja2
{%- for item in mod_pmsssp_list -%}
    MOD PMSSSP:
    {#- --- 必选参数 --- -#}
    SCP={{item.SCP}},
    SPN={{item.SPN}},
    SPV={{item.SPV}},
    ;
{%- endfor -%}
```

### 6 执行**MOD PMSFUNC**命令配置TLS协议版本、加密套件和证书应用场景。

### 命令举例：

### /*配置最新的TLS协议版本*/

```jinja2
{%- for item in mod_pmsfunc_list -%}
    MOD PMSFUNC:
    {#- --- 必选参数 --- -#}
    TYPE={{item.TYPE}},
    ITEMN={{item.ITEMN}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：ITEMN=mode 时必选 --- -#}
    {%- if item.ITEMN == 'mode' -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=lockTimeout/checkVerifyCode/sessionTimeout 时必选 --- -#}
    {%- elif item.ITEMN in ['lockTimeout', 'checkVerifyCode', 'sessionTimeout'] -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=diskLowValue/diskHighValue 时必选 --- -#}
    {%- elif item.ITEMN in ['diskLowValue', 'diskHighValue'] -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=sslEnabledProtocols/ciphers/logFileFormat/xssCheckSwitch/cliVerifySwitch/sqlCheckSwitch/pmsWebSwitch 时必选 --- -#}
    {%- elif item.ITEMN in ['sslEnabledProtocols', 'ciphers', 'logFileFormat', 'xssCheckSwitch', 'cliVerifySwitch', 'sqlCheckSwitch', 'pmsWebSwitch'] -%}
        VALUE="{{item.VALUE}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### /*配置加密套件，需与对端协商后获取*/

```jinja2
{%- for item in mod_pmsfunc_list_1 -%}
    MOD PMSFUNC:
    {#- --- 必选参数 --- -#}
    TYPE={{item.TYPE}},
    ITEMN={{item.ITEMN}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：ITEMN=mode 时必选 --- -#}
    {%- if item.ITEMN == 'mode' -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=lockTimeout/checkVerifyCode/sessionTimeout 时必选 --- -#}
    {%- elif item.ITEMN in ['lockTimeout', 'checkVerifyCode', 'sessionTimeout'] -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=diskLowValue/diskHighValue 时必选 --- -#}
    {%- elif item.ITEMN in ['diskLowValue', 'diskHighValue'] -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=sslEnabledProtocols/ciphers/logFileFormat/xssCheckSwitch/cliVerifySwitch/sqlCheckSwitch/pmsWebSwitch 时必选 --- -#}
    {%- elif item.ITEMN in ['sslEnabledProtocols', 'ciphers', 'logFileFormat', 'xssCheckSwitch', 'cliVerifySwitch', 'sqlCheckSwitch', 'pmsWebSwitch'] -%}
        VALUE="{{item.VALUE}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### /*配置证书应用场景，SCLI接口服务端证书为UPCF_PMS_certForSCLI*/

```jinja2
{%- for item in mod_pmsfunc_list_2 -%}
    MOD PMSFUNC:
    {#- --- 必选参数 --- -#}
    TYPE={{item.TYPE}},
    ITEMN={{item.ITEMN}},
    {#- --- 可选参数 --- -#}
    {%- if item.CERTSCENE is not none -%}
        CERTSCENE={{item.CERTSCENE}},
    {%- endif -%}
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：ITEMN=mode 时必选 --- -#}
    {%- if item.ITEMN == 'mode' -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=lockTimeout/checkVerifyCode/sessionTimeout 时必选 --- -#}
    {%- elif item.ITEMN in ['lockTimeout', 'checkVerifyCode', 'sessionTimeout'] -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=diskLowValue/diskHighValue 时必选 --- -#}
    {%- elif item.ITEMN in ['diskLowValue', 'diskHighValue'] -%}
        VALUE="{{item.VALUE}}",
    {#- --- 条件必选：ITEMN=sslEnabledProtocols/ciphers/logFileFormat/xssCheckSwitch/cliVerifySwitch/sqlCheckSwitch/pmsWebSwitch 时必选 --- -#}
    {%- elif item.ITEMN in ['sslEnabledProtocols', 'ciphers', 'logFileFormat', 'xssCheckSwitch', 'cliVerifySwitch', 'sqlCheckSwitch', 'pmsWebSwitch'] -%}
        VALUE="{{item.VALUE}}",
    {%- endif -%}
    ;
{%- endfor -%}
```

### 7 执行**MOD PMSFUNC**命令配置TLS协议版本、加密套件和证书应用场景后，需要重启PMS服务后才能生效：（登录“UPCF MML命令”界面，执行**RST MSPROCESS**命令重启PMS服务。）

```jinja2
{%- for item in rst_msprocess_list -%}
    RST MSPROCESS:
    {#- --- 必选参数 --- -#}
    PROCOBJECT={{item.PROCOBJECT}},
    {#- --- 条件必选参数 --- -#}
    {#- --- 条件必选：PROCOBJECT=PROCNAME 时必选 --- -#}
    {%- if item.PROCOBJECT == 'PROCNAME' -%}
        PROCNAME="{{item.PROCNAME}}",
    {%- endif -%}
    {#- --- 条件必选：PROCOBJECT=PROCID 时必选 --- -#}
    {%- if item.PROCOBJECT == 'PROCID' -%}
        PROCID="{{item.PROCID}}",
    {%- endif -%}
    {#- --- 条件可选参数 --- -#}
    {#- --- 条件可选：PROCOBJECT=PROCNAME/PROCID 时可选 --- -#}
    {%- if item.PROCOBJECT in ['PROCNAME', 'PROCID'] -%}
        {%- if item.MEID is not none -%}
            MEID="{{item.MEID}}",
        {%- endif -%}
    {%- endif -%}
    ;
{%- endfor -%}
```

### 8 下面介绍UPCF Web UI系统用于对接CLI客户端的用户帐号配置方法：

#### 8.1 选择导航栏上的“安全管理 > 权限 > 系统用户”，显示系统用户查询主界面。

#### 8.2 单击工具栏上的“增加”，弹出“增加系统用户”对话框。

#### 8.3 在“基本信息”页签，配置“系统用户”的基本信息，选择“用户类别”为“CLI用户”，如图1所示。

##### 8.3.1 **图1** 增加系统用户

#### 8.4 在“增加系统用户”对话框，单击“确定”完成用户账户的配置。

