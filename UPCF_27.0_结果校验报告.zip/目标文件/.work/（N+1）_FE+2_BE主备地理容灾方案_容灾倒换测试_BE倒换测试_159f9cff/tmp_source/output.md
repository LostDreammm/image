---
id: ''
name: BE倒换测试
ne_type: UPCF
type: feature
description: 在主用UPCF和容灾UPCF的数据同步完成后，需要进行BE倒换测试，确保容灾系统的功能正常。  **故障场景**  当出现以下情况时，需要进行BE倒换操作，使容灾局BE接管主用局BE进行业务处理，接管后的消息流如图1所示：  * 主用UPCF的BE侧USDMU3故障，无法处理业务。 * 主用UPCF一对DRU（Data Routing Unit）节点或一对DSU（Data Service Unit）节点同时故障。  当主用UPCF故障恢复后，可以进行BE倒换操作，使主用BE恢复业务处理。  **图1** 接管BE后的消息流
risk_level: ''
doc_source: ["特性","功能专题","UPCF容灾方案","PCF容灾方案","容灾部署","（N+1）*FE+2*BE主备地理容灾方案","容灾倒换测试","BE倒换测试"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
在主用UPCF和容灾UPCF的数据同步完成后，需要进行BE倒换测试，确保容灾系统的功能正常。**故障场景**当出现以下情况时，需要进行BE倒换操作，使容灾局BE接管主用局BE进行业务处理，接管后的消息流如图1所示：* 主用UPCF的BE侧USDMU3故障，无法处理业务。* 主用UPCF一对DRU（Data Routing Unit）节点或一对DSU（Data Service Unit）节点同时故障。当主用UPCF故障恢复后，可以进行BE倒换操作，使主用BE恢复业务处理。**图1** 接管BE后的消息流

## 必备事项
前提条件

* 主用UPCF和容灾UPCF之间的数据一致。
* 承载网的质量要求：单向延时<50ms、抖动<10ms、丢包率<0.1%。
* 在主用UPCF节点加载3天内不要进行容灾恢复。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties:
    is_scenario_takeover_be:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '**接管BE操作步骤**'
      data_source: ''
      pattern: ''
      default: TRUE
    mod_cluster_list:
      type: items
      properties:
        CID:
          name: 'Cluster标识'
          type: integer
          minimum: 0
          maximum: 4096
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ROLE:
          name: '主备标识'
          type: string
          enum:
          - ACTIVE
          - REDUNDANCY
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_cluster_list_1:
      type: items
      properties:
        CID:
          name: 'Cluster标识'
          type: integer
          minimum: 0
          maximum: 4096
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ROLE:
          name: '主备标识'
          type: string
          enum:
          - ACTIVE
          - REDUNDANCY
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_scenario_restore_be:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '**恢复BE操作步骤**'
      data_source: ''
      pattern: ''
      default: TRUE
    mod_cluster_list_2:
      type: items
      properties:
        CID:
          name: 'Cluster标识'
          type: integer
          minimum: 0
          maximum: 4096
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ROLE:
          name: '主备标识'
          type: string
          enum:
          - ACTIVE
          - REDUNDANCY
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    mod_cluster_list_3:
      type: items
      properties:
        CID:
          name: 'Cluster标识'
          type: integer
          minimum: 0
          maximum: 4096
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
        ROLE:
          name: '主备标识'
          type: string
          enum:
          - ACTIVE
          - REDUNDANCY
          required: false
          description: ''
          data_source: ''
          pattern: ''
          default: ''
    is_optional_stop_takeover:
      type: string
      enum:
      - TRUE
      - FALSE
      required: true
      description: '执行**STP TAKEOVER**命令停止容灾BE的接管。'
      data_source: ''
      pattern: ''
      default: TRUE
    stp_takeover_list:
      type: items
      properties:
        SERVICETYPE:
          name: '业务类型'
          type: string
          maxLength: 128
          required: true
          description: ''
          data_source: ''
          pattern: ''
          default: ''
  examples:
  - is_scenario_takeover_be: TRUE
    mod_cluster_list:
    - CID: 0
      ROLE: REDUNDANCY
    mod_cluster_list_1:
    - CID: 0
      ROLE: ACTIVE
    is_scenario_restore_be: TRUE
    mod_cluster_list_2:
    - CID: 0
      ROLE: REDUNDANCY
    mod_cluster_list_3:
    - CID: 0
      ROLE: ACTIVE
    is_optional_stop_takeover: TRUE
    stp_takeover_list:
    - SERVICETYPE: 'UPCF-SESSION'
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 **接管BE操作步骤**

#### 1.1 运营商工程师停止业务发放系统业务。

#### 1.2 修改主用UPCF配置。

##### 1.2.1 登录“USCDB MML命令”界面。

##### 1.2.2 执行**MOD CLUSTER**命令将所有Cluster的“主备标识”设置为“REDUNDANCY”。

```jinja2
{%- if is_scenario_takeover_be -%}
    {%- for item in mod_cluster_list -%}
        MOD CLUSTER:
        {#- --- 必选参数 --- -#}
        CID={{item.CID}},
        {#- --- 可选参数 --- -#}
        {%- if item.ROLE is not none -%}
            ROLE={{item.ROLE}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 1.2.3 登录“UPCF MML命令”界面。

##### 1.2.4 根据数据规划，确定主用BE故障时主用FE访问BE的优先级，并执行**MOD DBSRLOCATION**命令修改主用FE访问BE的优先级。优先级的关系，在数据规划阶段确定，容灾接管前后的访问优先级关系，请参见容灾系统中网元是如何通信的。

##### 1.2.5 执行**STR DBSROUTING**命令，使FE自动选择到正常的最高优先的BE局点。

#### 1.3 修改容灾UPCF配置。

##### 1.3.1 登录“USCDB MML命令”界面。

##### 1.3.2 执行**MOD CLUSTER**命令将所有Cluster的“主备标识”设置为“ACTIVE”。

```jinja2
{%- if is_scenario_takeover_be -%}
    {%- for item in mod_cluster_list_1 -%}
        MOD CLUSTER:
        {#- --- 必选参数 --- -#}
        CID={{item.CID}},
        {#- --- 可选参数 --- -#}
        {%- if item.ROLE is not none -%}
            ROLE={{item.ROLE}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 1.3.3 登录“UPCF MML命令”界面。

##### 1.3.4 根据数据规划，确定主用BE故障时容灾FE访问BE的优先级，并执行**MOD DBSRLOCATION**命令修改容灾FE访问BE的优先级。优先级的关系，在数据规划阶段确定，容灾接管前后的访问优先级关系，请参见容灾系统中网元是如何通信的。

##### 1.3.5 执行**STR DBSROUTING**命令，使FE自动选择到正常的最高优先的BE局点。

#### 1.4 华为工程师与运营商工程师一起完成开户、销户、查询、基本业务验证、重新启动业务发放，并得到运营商认可。

### 2 **恢复BE操作步骤**

#### 2.1 运营商工程师停止业务发放系统业务。

#### 2.2 修改容灾UPCF配置。

##### 2.2.1 登录“USCDB MML命令”界面。

##### 2.2.2 执行**MOD CLUSTER**命令将所有Cluster的“主备标识”设置为“REDUNDANCY”。

```jinja2
{%- if is_scenario_restore_be -%}
    {%- for item in mod_cluster_list_2 -%}
        MOD CLUSTER:
        {#- --- 必选参数 --- -#}
        CID={{item.CID}},
        {#- --- 可选参数 --- -#}
        {%- if item.ROLE is not none -%}
            ROLE={{item.ROLE}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 2.2.3 登录“UPCF MML命令”界面。

##### 2.2.4 根据数据规划，确定容灾接管前容灾FE访问BE的优先级，并执行**MOD DBSRLOCATION**命令修改容灾FE访问BE的优先级。优先级的关系，在数据规划阶段确定，容灾接管前后的访问优先级关系，请参见容灾系统中网元是如何通信的。

##### 2.2.5 执行**STR DBSROUTING**命令，使FE自动选择到正常的最高优先的BE局点。

#### 2.3 修改主用UPCF配置。

##### 2.3.1 登录“USCDB MML命令”界面。

##### 2.3.2 执行**MOD CLUSTER**命令将所有Cluster的“主备标识”设置为“ACTIVE”。

```jinja2
{%- if is_scenario_restore_be -%}
    {%- for item in mod_cluster_list_3 -%}
        MOD CLUSTER:
        {#- --- 必选参数 --- -#}
        CID={{item.CID}},
        {#- --- 可选参数 --- -#}
        {%- if item.ROLE is not none -%}
            ROLE={{item.ROLE}},
        {%- endif -%}
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 2.3.3 执行**STP TAKEOVER**命令停止容灾BE的接管。

```jinja2
{%- if is_optional_stop_takeover and is_scenario_restore_be -%}
    {%- for item in stp_takeover_list -%}
        STP TAKEOVER:
        {#- --- 必选参数 --- -#}
        SERVICETYPE="{{item.SERVICETYPE}}",
        ;
    {%- endfor -%}
{%- endif -%}
```

##### 如果启动了Gx会话和Sd会话备份和恢复功能，当主用BE故障全部恢复及主用BE和容灾BE的数据一致性校验完成之后，需要手工停止容灾BE的接管。否则，跳过此步骤。

##### 容灾BE的接管状态可通过执行**DSP TAKEOVER**命令查看。

##### 2.3.4 登录“UPCF MML命令”界面。

##### 2.3.5 根据数据规划，确定容灾接管前主用FE访问BE的优先级，并执行**MOD DBSRLOCATION**命令修改主用FE访问BE的优先级。优先级的关系，在数据规划阶段确定，容灾接管前后的访问优先级关系，请参见容灾系统中网元是如何通信的。

##### 2.3.6 执行**STR DBSROUTING**命令，使FE自动选择到正常的最高优先的BE局点。

#### 2.4 运营商工程师修改业务发放系统连接配置，使其访问主用的业务发放IP地址。

#### 2.5 华为工程师与运营商工程师一起完成开户、销户、查询、基本业务验证，并得到运营商认可。

