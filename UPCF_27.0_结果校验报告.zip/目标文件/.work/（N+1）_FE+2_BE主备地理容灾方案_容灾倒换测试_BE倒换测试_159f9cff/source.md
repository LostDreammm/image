# BE倒换测试

* 操作场景
* 必备事项
* 操作流程
* 操作步骤

#### 操作场景

在主用UPCF和容灾UPCF的数据同步完成后，需要进行BE倒换测试，确保容灾系统的功能正常。

**故障场景**

当出现以下情况时，需要进行BE倒换操作，使容灾局BE接管主用局BE进行业务处理，接管后的消息流如图1所示：

* 主用UPCF的BE侧USDMU3故障，无法处理业务。
* 主用UPCF一对DRU（Data Routing Unit）节点或一对DSU（Data Service Unit）节点同时故障。

当主用UPCF故障恢复后，可以进行BE倒换操作，使主用BE恢复业务处理。

**图1** 接管BE后的消息流

#### 必备事项

**前提条件**

* 主用UPCF和容灾UPCF之间的数据一致。
* 承载网的质量要求：单向延时<50ms、抖动<10ms、丢包率<0.1%。
* 在主用UPCF节点加载3天内不要进行容灾恢复。

**数据**

FE访问BE的优先级，根据数据规划确定。

#### 操作流程

**接管BE操作流程**

接管BE的流程如图2所示。

**图2** 接管BE流程

**恢复BE操作流程**

恢复BE的流程如图3所示。

**图3** 恢复BE流程

#### 操作步骤

**接管BE操作步骤**

1. 运营商工程师停止业务发放系统业务。
2. 修改主用UPCF配置。

   1. 登录“USCDB MML命令”界面。
   2. 执行**MOD CLUSTER**命令将所有Cluster的“主备标识”设置为“REDUNDANCY”。

      **MOD CLUSTER: CID=0, ROLE=REDUNDANCY;**
   3. 登录“UPCF MML命令”界面。
   4. 根据数据规划，确定主用BE故障时主用FE访问BE的优先级，并执行**MOD DBSRLOCATION**命令修改主用FE访问BE的优先级。优先级的关系，在数据规划阶段确定，容灾接管前后的访问优先级关系，请参见容灾系统中网元是如何通信的。
   5. 执行**STR DBSROUTING**命令，使FE自动选择到正常的最高优先的BE局点。
3. 修改容灾UPCF配置。

   1. 登录“USCDB MML命令”界面。
   2. 执行**MOD CLUSTER**命令将所有Cluster的“主备标识”设置为“ACTIVE”。

      **MOD CLUSTER: CID=0, ROLE=ACTIVE;**
   3. 登录“UPCF MML命令”界面。
   4. 根据数据规划，确定主用BE故障时容灾FE访问BE的优先级，并执行**MOD DBSRLOCATION**命令修改容灾FE访问BE的优先级。优先级的关系，在数据规划阶段确定，容灾接管前后的访问优先级关系，请参见容灾系统中网元是如何通信的。
   5. 执行**STR DBSROUTING**命令，使FE自动选择到正常的最高优先的BE局点。
4. 华为工程师与运营商工程师一起完成开户、销户、查询、基本业务验证、重新启动业务发放，并得到运营商认可。

**恢复BE操作步骤**

1. 运营商工程师停止业务发放系统业务。
2. 修改容灾UPCF配置。

   1. 登录“USCDB MML命令”界面。
   2. 执行**MOD CLUSTER**命令将所有Cluster的“主备标识”设置为“REDUNDANCY”。

      **MOD CLUSTER: CID=0, ROLE=REDUNDANCY;**
   3. 登录“UPCF MML命令”界面。
   4. 根据数据规划，确定容灾接管前容灾FE访问BE的优先级，并执行**MOD DBSRLOCATION**命令修改容灾FE访问BE的优先级。优先级的关系，在数据规划阶段确定，容灾接管前后的访问优先级关系，请参见容灾系统中网元是如何通信的。
   5. 执行**STR DBSROUTING**命令，使FE自动选择到正常的最高优先的BE局点。
3. 修改主用UPCF配置。

   1. 登录“USCDB MML命令”界面。
   2. 执行**MOD CLUSTER**命令将所有Cluster的“主备标识”设置为“ACTIVE”。

      **MOD CLUSTER: CID=0, ROLE=ACTIVE;**
   3. 执行**STP TAKEOVER**命令停止容灾BE的接管。

      **STP TAKEOVER: SERVICETYPE="UPCF-SESSION";**

      * 如果启动了Gx会话和Sd会话备份和恢复功能，当主用BE故障全部恢复及主用BE和容灾BE的数据一致性校验完成之后，需要手工停止容灾BE的接管。否则，跳过此步骤。
      * 容灾BE的接管状态可通过执行**DSP TAKEOVER**命令查看。
   4. 登录“UPCF MML命令”界面。
   5. 根据数据规划，确定容灾接管前主用FE访问BE的优先级，并执行**MOD DBSRLOCATION**命令修改主用FE访问BE的优先级。优先级的关系，在数据规划阶段确定，容灾接管前后的访问优先级关系，请参见容灾系统中网元是如何通信的。
   6. 执行**STR DBSROUTING**命令，使FE自动选择到正常的最高优先的BE局点。
4. 运营商工程师修改业务发放系统连接配置，使其访问主用的业务发放IP地址。
5. 华为工程师与运营商工程师一起完成开户、销户、查询、基本业务验证，并得到运营商认可。

版权所有 © 华为技术有限公司
