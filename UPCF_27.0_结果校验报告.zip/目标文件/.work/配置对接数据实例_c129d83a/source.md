# 配置对接数据实例

* 操作场景
* 必备事项
* 任务示例

#### 操作场景

该任务指导工程师在UPCF开局时，通过OM portal完成对接数据的配置。

本实例的配置场景如下：

* 支持100万并发会话-400万静态用户。
* 实现UPCF容灾局的容灾组网对接。

#### 必备事项

**前提条件**

* 已完成网元安装。
* 已完成基础数据配置。
* UPCF需对接的对端设备已完成基础数据配置。
* UPCF主备容灾局的数据层VLAN已互通。

**数据**

执行操作前需要根据工程设计输出和运营商统一规划信息规划参数取值。

#### 任务示例

**任务描述**

完成UPCF对接数据的配置，使UPCF与其他网元互通正常。

**脚本**

```
配置容灾局USCDB-82的容灾数据
/*登录到容灾局USCDB MML命令界面*/
/*配置远端主用局USCDB的Location信息数据*/
ADD RLOCATION:RLOCID=81,RMT="USCDB",LP=1, REDUNFLAG=Yes;

/*配置远端主用局UPCF的Location信息数据*/
ADD RLOCATION:RLOCID=231,RMT="UPCF",LP=1, REDUNFLAG=No;

/*配置远端主用局USCDB的DSG数据*/
ADD RDSG:RLOCID=81,RDSGMID=17, RDSGST="UPCF";
ADD RDSG:RLOCID=81,RDSGMID=18, RDSGST="UPCF";

/*配置远端主用局UPCF的DSG数据*/
ADD RDSG:RLOCID=231,RDSGMID=1, RDSGST="UPCF", RDSGTYPE=DBS;
ADD RDSG:RLOCID=231,RDSGMID=2, RDSGST="UPCF", RDSGTYPE=DBS;
ADD RDSG:RLOCID=231,RDSGMID=3, RDSGST="UPCF", RDSGTYPE=DBS;
ADD RDSG:RLOCID=231,RDSGMID=4, RDSGST="UPCF", RDSGTYPE=DBS;

/*配置远端主用局USCDB的网元IP数据*/
ADD RIPADDR:RLOCID=81,ID=3,IPVER=IPV4, IPV4IP1="192.168.200.30",IPV4IP2="192.168.200.31", RDPUST="UPCF";

/*配置远端主用局UPCF的网元IP数据*/
ADD RIPADDR:RLOCID=231,ID=1,IPVER=IPV4,IPV4IP1="192.168.200.36",IPV4IP2="192.168.200.37",RDPUST="UPCF";

/*增加订阅通知*/
ADD NOTIFYCFG: FETYPE="UPCF", REMOTEID=1, FEID=10, INFTYPE=MCI, SYNCHROSWITCH=ASYNC, LOCATIONID=231;

/*激活链路*/
ACT IPDISP:;

配置容灾局UPCF-232的容灾数据
/*登录到容灾局UPCF MML命令界面*/
/*配置远端主用局USCDB的Location信息数据*/
ADD DBSRLOCATION: RLOCID=81, RMT=USCDB, LP=1;

/*配置远端主用局USCDB的DSG数据*/
ADD DBSRDSG:RLOCID=81,RDSGMID=17, RDPUST="UPCF";
ADD DBSRDSG:RLOCID=81,RDSGMID=18, RDPUST="UPCF";

/*配置远端主用局USCDB的网元IP数据*/
ADD DBSRIPADDR:RLOCID=81,ID=3,IPVER=IPV4,IPV4IP1="192.168.200.30",IPV4IP2="192.168.200.31",RDPUST="UPCF";

/*激活链路*/
ACT DBSIPDISP:;

配置容灾局UPCF对接数据
参考配置UPCF对接数据,根据网设规划和现网实际网元部署情况，完成容灾局与各网元对接即可。(主用容灾UPCF与其他网元对接时，配置相互独立，即可看做单局点与网元对接即可。)

/*配置UPCF与网管服务器的对接数据*/
```

具体步骤请参见配置UPCF与网管服务器的对接数据。

版权所有 © 华为技术有限公司
