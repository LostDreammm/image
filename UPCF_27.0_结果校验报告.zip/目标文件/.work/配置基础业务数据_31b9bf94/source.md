# 配置基础业务数据

* 操作场景
* 对系统的影响
* 必备事项
* 操作流程
* 操作步骤
* 任务示例

## 操作场景

用户在N15接口上线后，UPCF需要向AMF下发订阅用户进出高铁的事件，AMF判断用户进出高铁专网区域时会上报事件，UPCF会基于AMF上报的信息向NWDAF订阅用户属性分析任务。NWDAF基于用户特征分析用户属性并通知给UPCF。

本章以高铁专网PRA区域标识为900004为例进行配置，场景信息说明如下：

* 用户从N15接口上线，UPCF订阅N15接口的PRA\_CH事件。
* 用户进入高铁专网PRA区域，UPCF订阅N23接口的RAIL\_USR\_CHAR\_ANALYSIS事件。
* 用户进入高铁专网PRA区域，UPCF下发N15会话的延迟释放指示标记。
* 用户类别为公网用户，UPCF下发公网RFSP策略。

## 对系统的影响

本特性对系统无影响。

## 必备事项

前提条件

* 已完成配置UPCF与AMF的对接数据，且开启设备间N15会话审计。

  ```
  /*配置样例如下*/ 
  SET SBIDEVAUDIT: SBITYPE=N15, DATIME=240, TIMEOUTNUM=3;
  ```
* 已完成配置UPCF与NWDAF的对接数据，且开启设备间N23会话审计。

  ```
  /*配置样例如下*/ 
  SET SBIDEVAUDIT: SBITYPE=N23, PERIODICDATIME=30;
  ```
* 已执行**MOD INSP**命令，开启高铁选频功能。

  ```
  /*开启高铁选频功能*/
  MOD INSP: INSPN=VRM_HSRCTRLSW, INSPV=1;
  ```
* 已执行**MOD COMPATSWITCH**命令，设置N15接口的rfsp按照增量下发方式处理。

  ```
  /*设置N15接口的rfsp按照增量下发方式处理*/
  MOD COMPATSWITCH: SWNAME=N15RfspSW, SWVALUE=0;
  ```
* 已完成加载License：82404376 LRM0PCFN23AM123 N23接口（使用HTTP协议）策略控制（AM-PCF）。
* 已登录UPCF WebUI界面。

数据

根据应用场景，分解的业务配置关系如图1所示，详细解释如表1所示。

**图1** 业务配置关系

**表1** 配置关系解释

| 名称 | 需求分解 | 基本原则 |
| --- | --- | --- |
| 用户的基础业务 | 此用户业务包含3个业务：   * N23\_UeChar\_Service01：表示PRA订阅业务。 * N23\_UeChar\_Service02：表示订阅N23事件分析业务。 * N23\_UeChar\_Service03：表示公网选频业务。 | * 定义一个PRA订阅的业务，向AMF下发PRA\_CH订阅事件。 * 定义一个N23事件分析业务，向NWDAF请求RAIL\_USR\_CHAR\_ANALYSIS订阅事件。 * 定义一个公网用户选频业务，当用户为公网用户时，向AMF下发公网RFSP策略。 |
| 动态用户组N23\_UeChar\_SubGroup | 匹配此动态用户组的一类用户上线时，均可使用动态用户组签约的业务，包含：   * N23\_UeChar\_Service01 * N23\_UeChar\_Service02 * N23\_UeChar\_Service03 | - |
| 业务N23\_UeChar\_Service01 | 此业务包括一个策略：N23\_UeChar\_Policy01。 | - |
| 业务N23\_UeChar\_Service02 | 此业务包括一个策略：N23\_UeChar\_Policy02。 | - |
| 业务N23\_UeChar\_Service03 | 此业务包括一个策略：N23\_UeChar\_Policy03。 | - |
| 策略N23\_UeChar\_Policy01 | 此策略在用户上线和用户位置区域状态发生改变时被调用，触发器为AMPolicyCreateRequest和AMPresenceReportingAreaChange，包含规则：N23\_UeChar\_Rule01。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配，匹配成功后下发规则给AMF。 |
| 策略N23\_UeChar\_Policy02 | 此策略在用户上线和用户位置区域状态发生改变时被调用，触发器为AMPolicyCreateRequest和AMPresenceReportingAreaChange，包含规则：N23\_UeChar\_Rule02和N23\_UeChar\_Rule03。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配，匹配成功后发送N23订阅事件给NWDAF，并透传会话延迟释放标记给AMF。 |
| 策略N23\_UeChar\_Policy03 | 此策略仅在公网用户上线时被调用，触发器为AMPolicyCreateRequest，包含规则：N23\_UeChar\_Rule04。 | 当触发器定义的事件发生时，UPCF才会进行相应的规则匹配，匹配成功后下发规则给AMF。 |
| 规则N23\_UeChar\_Rule01 | * 条件组：无。 * 5G动作：  PresenceInfo（praId=900004） | 用于下发高铁专网PRA区域标识，praId由运营商统一提供。 |
| 规则N23\_UeChar\_Rule02 | * 条件组：    + PRA的标识为900004（AmPolicySession.PraInArea=900004）   + N23会话需要等待延迟释放（NwdafSession.UeCharWaitEndFlag=True、NwdafSession.UeCharEndFlag=False） * 5G动作：  CmdN23EventSubscription（event=RAIL\_USR\_CHAR\_ANALYSIS，crhSubInd=False，associatedPraInfos引用praId=900004的PresenceInfo动作类型） | * 定义基于用户进入位置区域为条件时，“对象属性”选用对象“AmPolicySession”下的“PraInArea”属性。 * 定义基于N23会话延迟释放标记为条件时，“对象属性”选用对象“NwdafSession”下的“UeCharWaitEndFlag”和“UeCharEndFlag”属性。 * 为了将区域标识为900004的PRA状态传递给NWDAF，CmdN23EventSubscription动作还需配置引用5G动作类型“PresenceInfo”。 |
| 规则N23\_UeChar\_Rule03 | * 条件组：  N15会话需要等待延迟释放（AmPolicySession.WaitEndFlag=True） * 5G动作：  AmPolicyAction（waitEndFlag=AmPolicySession.WaitEndFlag，endFlag=AmPolicySession.EndFlag） | 定义基于N15会话延迟释放标记为条件时，“对象属性”选用对象“AmPolicySession”下的“WaitEndFlag”属性。 |
| 规则N23\_UeChar\_Rule04 | * 条件组：  用户为公网用户（NwdafSession.UserType=PublicUser） * 5G动作：  AmPolicyAction（rfsp=200） | 定义基于用户的类别为条件时，“对象属性”选用对象“NwdafSession”下的“UserType”属性。 |

## 操作流程

该应用场景的配置流程图如图2所示。

**图2** 业务配置流程图

## 操作步骤

1. 登录UPCF WebUI界面。
2. 配置PRA。

   导航入口为“位置管理 > 位置 > PRA”。

   PRA数据规划如表2所示，详细参数说明请参见PRA参数表。

   **表2** PRA

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | PRA | 基本信息 | 标识 | 900004  说明：  此标识码由运营商统一提供。 |
3. 配置条件组。

   导航入口为“策略管理 > 策略 > 条件组”。

   * 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。
   * 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

   需要配置条件组，条件组的数据规划如表3所示。

   **表3** 条件组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 条件组1 | 基本信息 | 名称 | CG\_UeChar01 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_UeChar01 |
   |  |  | 对象属性 | * 对象：AmPolicySession * 属性：PraInArea |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | 900004 |
   | 条件组2 | 基本信息 | 名称 | CG\_UeChar02 |
   |  |  | 关系 | AND |
   |  | 条件1 | 名称 | C\_UeChar02 |
   |  |  | 对象属性 | * 对象：NwdafSession * 属性：UeCharWaitEndFlag |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | True |
   |  | 条件2 | 名称 | C\_UeChar03 |
   |  |  | 对象属性 | * 对象：NwdafSession * 属性：UeCharEndFlag |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | False |
   | 条件组3 | 基本信息 | 名称 | CG\_UeChar03 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_UeChar04 |
   |  |  | 对象属性 | * 对象：AmPolicySession * 属性：WaitEndFlag |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | True |
   | 条件组4 | 基本信息 | 名称 | CG\_UeChar04 |
   |  |  | 关系 | AND |
   |  | 条件 | 名称 | C\_UeChar05 |
   |  |  | 对象属性 | * 对象：NwdafSession * 属性：UserType |
   |  |  | 操作符 | Equal |
   |  |  | 右值类型 | Value |
   |  |  | 右值 | PublicUser |
4. 配置5G动作组。

   导航入口为“策略管理 > 策略 > 5G动作组”。

   需要配置如下动作和动作组，动作组的数据规划如表4所示。

   **表4** 5G动作组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 5G动作组1 | 基本信息 | 名称 | AG\_UeChar\_PresInfo |
   |  |  | 类型 | PresenceInfo |
   |  | 属性 | praId | * 类型：Value * 值：900004 说明：  已在PRA配置中定义。 |
   | 5G动作组2 | 基本信息 | 名称 | AG\_UeChar\_AmPolicy01 |
   |  |  | 类型 | AmPolicyAction |
   |  | 属性 | praInfos | * 类型：Reference ActionGroup * 值：AG\_UeChar\_PresInfo 说明：  已在5G动作组中定义。 |
   | 5G动作组3 | 基本信息 | 名称 | AG\_UeChar\_CmdN23 |
   |  |  | 类型 | CmdN23EventSubscription |
   |  | 属性 | event | * 类型：Value * 值：RAIL\_USR\_CHAR\_ANALYSIS |
   |  |  | crhSubInd | * 类型：Value * 值：False |
   |  |  | associatedPraInfos | * 类型：Reference ActionGroup * 值：AG\_UeChar\_PresInfo 说明：  已在5G动作组中定义。 |
   | 5G动作组4 | 基本信息 | 名称 | AG\_UeChar\_AmPolicy02 |
   |  |  | 类型 | AmPolicyAction |
   |  | 属性 | cmdN23EventSubscription | * 类型：Reference ActionGroup * 值：AG\_UeChar\_CmdN23 说明：  已在5G动作组中定义。 |
   | 5G动作组5 | 基本信息 | 名称 | AG\_UeChar\_AmPolicy03 |
   |  |  | 类型 | AmPolicyAction |
   |  | 属性 | waitEndFlag | * 类型：Object Attribute * 值：AmPolicySession.WaitEndFlag |
   |  |  | endFlag | * 类型：Object Attribute * 值：AmPolicySession.EndFlag |
   | 5G动作组6 | 基本信息 | 名称 | AG\_UeChar\_AmPolicy04 |
   |  |  | 类型 | AmPolicyAction |
   |  | 属性 | rfsp | * 类型：Value * 值：200 |
5. 配置规则。

   导航入口为“策略管理 > 策略 > 规则”。

   规则的数据规划如表5所示。

   **表5** 规则

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 规则1 | 基本信息 | 名称 | N23\_UeChar\_Rule01 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Amf Pcc Rule |
   |  | 5G动作组 | 5G动作组 | AG\_UeChar\_AmPolicy01  说明：  已在5G动作组中定义。 |
   | 规则2 | 基本信息 | 名称 | N23\_UeChar\_Rule02 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Amf Pcc Rule |
   |  | 条件组 | 关系 | OR  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | * CG\_UeChar01 * CG\_UeChar02 说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | AG\_UeChar\_AmPolicy02  说明：  已在5G动作组中定义。 |
   | 规则3 | 基本信息 | 名称 | N23\_UeChar\_Rule03 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Amf Pcc Rule |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_UeChar03  说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | AG\_UeChar\_AmPolicy03  说明：  已在5G动作组中定义。 |
   | 规则4 | 基本信息 | 名称 | N23\_UeChar\_Rule04 |
   |  |  | 操作类型 | Change Rule |
   |  |  | 类型 | 5G Amf Pcc Rule |
   |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |
   |  |  | 条件组 | CG\_UeChar04  说明：  已在条件组中定义。 |
   |  | 5G动作组 | 5G动作组 | AG\_UeChar\_AmPolicy04  说明：  已在5G动作组中定义。 |
6. 配置策略。

   导航入口为“策略管理 > 策略 > 策略”。

   策略的数据规划如表6所示。

   **表6** 策略

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 策略1 | 基本信息 | 名称 | N23\_UeChar\_Policy01 |
   |  |  | 类型 | N15 Policy |
   |  | 触发器 | 名称 | * AMPolicyCreateRequest * AMPresenceReportingAreaChange |
   |  | 规则 | 名称 | N23\_UeChar\_Rule01  说明：  已在规则中定义。 |
   | 策略2 | 基本信息 | 名称 | N23\_UeChar\_Policy02 |
   |  |  | 类型 | N15 Policy |
   |  | 触发器 | 名称 | * AMPolicyCreateRequest * AMPresenceReportingAreaChange |
   |  | 规则 | 名称 | * N23\_UeChar\_Rule02 * N23\_UeChar\_Rule03 说明：  已在规则中定义。 |
   | 策略3 | 基本信息 | 名称 | N23\_UeChar\_Policy03 |
   |  |  | 类型 | N15 Policy |
   |  | 触发器 | 名称 | AMPolicyCreateRequest |
   |  | 规则 | 名称 | N23\_UeChar\_Rule04  说明：  已在规则中定义。 |
7. 配置业务。

   导航入口为“业务管理 > 业务 > 业务”。

   业务的数据规划如表7所示。

   **表7** 业务

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 业务1 | 基本信息 | 名称 | N23\_UeChar\_Service01 |
   |  |  | 类型 | VALUE\_ADDED\_SERVICE |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值取默认值“0”。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | N23\_UeChar\_Policy01  说明：  已在策略中定义。 |
   | 业务2 | 基本信息 | 名称 | N23\_UeChar\_Service02 |
   |  |  | 类型 | VALUE\_ADDED\_SERVICE |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值取默认值“0”。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | N23\_UeChar\_Policy02  说明：  已在策略中定义。 |
   | 业务3 | 基本信息 | 名称 | N23\_UeChar\_Service03 |
   |  |  | 类型 | VALUE\_ADDED\_SERVICE |
   |  |  | 激活方式 | PCEF |
   |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值取默认值“0”。 |
   |  |  | QoS模式 | 替换 |
   |  |  | 签约后才能使用 | 是 |
   |  | 策略 | 名称 | N23\_UeChar\_Policy03  说明：  已在策略中定义。 |
8. 配置用户组。

   导航入口为“用户管理 > 用户 > 用户组”。

   动态用户组的数据规划如表8所示，详细参数说明请参见动态用户组参数表。

   **表8** 动态用户组

   | 类别 | 参数 |  | 取值样例 |
   | --- | --- | --- | --- |
   | 用户组 | 基本信息 | 名称 | N23\_UeChar\_SubGroup |
   |  |  | 类型 | 动态 |
   |  |  | 优先级 | 0 |
   |  |  | 应用类型 | 缺省方式 |
   |  | 业务 | 名称 | * N23\_UeChar\_Service01 * N23\_UeChar\_Service02 * N23\_UeChar\_Service03 说明：  已在业务中定义。 |

## 任务示例

任务描述

配置业务。

脚本

CLI脚本

版权所有 © 华为技术有限公司
