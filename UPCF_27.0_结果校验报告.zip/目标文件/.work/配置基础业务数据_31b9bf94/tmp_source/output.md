---
id: ''
name: 配置基础业务数据
ne_type: UPCF
type: feature
description: 用户在N15接口上线后，UPCF需要向AMF下发订阅用户进出高铁的事件，AMF判断用户进出高铁专网区域时会上报事件，UPCF会基于AMF上报的信息向NWDAF订阅用户属性分析任务。NWDAF基于用户特征分析用户属性并通知给UPCF。  本章以高铁专网PRA区域标识为900004为例进行配置，场景信息说明如下：  * 用户从N15接口上线，UPCF订阅N15接口的PRA\_CH事件。 * 用户进入高铁专网PRA区域，UPCF订阅N23接口的RAIL\_USR\_CHAR\_ANALYSIS事件。 * 用户进入高铁专网PRA区域，UPCF下发N15会话的延迟释放指示标记。 * 用户类别为公网用户，UPCF下发公网RFSP策略。
risk_level: ''
doc_source: ["特性","特性部署","UPCF增值特性","WHFD-611133 N23接口（使用HTTP协议）策略控制（AM-PCF）","WHFD-611133 N23接口（使用HTTP协议）策略控制（AM-PCF）特性配置","配置基础业务数据"]
refs: []
metadata:
  DepOnLiveCfg: false
allowed-tools: []
---
<!-- @mml:block=annotations -->
```text
## 操作场景
用户在N15接口上线后，UPCF需要向AMF下发订阅用户进出高铁的事件，AMF判断用户进出高铁专网区域时会上报事件，UPCF会基于AMF上报的信息向NWDAF订阅用户属性分析任务。NWDAF基于用户特征分析用户属性并通知给UPCF。本章以高铁专网PRA区域标识为900004为例进行配置，场景信息说明如下：* 用户从N15接口上线，UPCF订阅N15接口的PRA\_CH事件。* 用户进入高铁专网PRA区域，UPCF订阅N23接口的RAIL\_USR\_CHAR\_ANALYSIS事件。* 用户进入高铁专网PRA区域，UPCF下发N15会话的延迟释放指示标记。* 用户类别为公网用户，UPCF下发公网RFSP策略。

## 必备事项
前提条件

* 已完成配置UPCF与AMF的对接数据，且开启设备间N15会话审计。

  ```
  /*配置样例如下*/ 
  SET SBIDEVAUDIT: SBITYPE=N15, DATIME=240, TIMEOUTNUM=3;
  ```
* 已完成配置UPCF与NWDAF的对接数据，且开启设备间N23会话审计。

  ```
  /*配置样例如下*/ 
  SET SBIDEVAUDIT: SBITYPE=N23, PERIODICDATIME=30;
  ```
* 已执行**MOD INSP**命令，开启高铁选频功能。

  ```
  /*开启高铁选频功能*/
  MOD INSP: INSPN=VRM_HSRCTRLSW, INSPV=1;
  ```
* 已执行**MOD COMPATSWITCH**命令，设置N15接口的rfsp按照增量下发方式处理。

  ```
  /*设置N15接口的rfsp按照增量下发方式处理*/
  MOD COMPATSWITCH: SWNAME=N15RfspSW, SWVALUE=0;
  ```
* 已完成加载License：82404376 LRM0PCFN23AM123 N23接口（使用HTTP协议）策略控制（AM-PCF）。
* 已登录UPCF WebUI界面。
```

## 2 输入参数变量定义
<!-- @mml:block=params -->
```yaml
schemas:
  properties: {}
  examples: []
```

## 3 命令模板定义
<!-- @mml:block=ADD -->

### 1 登录UPCF WebUI界面。

### 2 配置PRA。

### 导航入口为“位置管理 > 位置 > PRA”。

### PRA数据规划如表2所示，详细参数说明请参见PRA参数表。

### **表2** PRA

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | PRA | 基本信息 | 标识 | 900004  说明：  此标识码由运营商统一提供。 |

### 3 配置条件组。

### 导航入口为“策略管理 > 策略 > 条件组”。

#### 3.1 当业务的使用需要设置控制条件时，需要配置条件组。若某规则不配置条件组，表示在同一业务里其他条件都匹配不上时，才触发此规则。

#### 3.2 条件组是一个或多个条件的组合。条件组中的各条件之间可以是“与”的关系，也可以是“或”的关系。条件之间的与/或关系由参数“关系”的取值决定。

### 需要配置条件组，条件组的数据规划如表3所示。

### **表3** 条件组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 条件组1 | 基本信息 | 名称 | CG\_UeChar01 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_UeChar01 |

### |  |  | 对象属性 | * 对象：AmPolicySession * 属性：PraInArea |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | 900004 |

### | 条件组2 | 基本信息 | 名称 | CG\_UeChar02 |

### |  |  | 关系 | AND |

### |  | 条件1 | 名称 | C\_UeChar02 |

### |  |  | 对象属性 | * 对象：NwdafSession * 属性：UeCharWaitEndFlag |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | True |

### |  | 条件2 | 名称 | C\_UeChar03 |

### |  |  | 对象属性 | * 对象：NwdafSession * 属性：UeCharEndFlag |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | False |

### | 条件组3 | 基本信息 | 名称 | CG\_UeChar03 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_UeChar04 |

### |  |  | 对象属性 | * 对象：AmPolicySession * 属性：WaitEndFlag |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | True |

### | 条件组4 | 基本信息 | 名称 | CG\_UeChar04 |

### |  |  | 关系 | AND |

### |  | 条件 | 名称 | C\_UeChar05 |

### |  |  | 对象属性 | * 对象：NwdafSession * 属性：UserType |

### |  |  | 操作符 | Equal |

### |  |  | 右值类型 | Value |

### |  |  | 右值 | PublicUser |

### 4 配置5G动作组。

### 导航入口为“策略管理 > 策略 > 5G动作组”。

### 需要配置如下动作和动作组，动作组的数据规划如表4所示。

### **表4** 5G动作组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 5G动作组1 | 基本信息 | 名称 | AG\_UeChar\_PresInfo |

### |  |  | 类型 | PresenceInfo |

### |  | 属性 | praId | * 类型：Value * 值：900004 说明：  已在PRA配置中定义。 |

### | 5G动作组2 | 基本信息 | 名称 | AG\_UeChar\_AmPolicy01 |

### |  |  | 类型 | AmPolicyAction |

### |  | 属性 | praInfos | * 类型：Reference ActionGroup * 值：AG\_UeChar\_PresInfo 说明：  已在5G动作组中定义。 |

### | 5G动作组3 | 基本信息 | 名称 | AG\_UeChar\_CmdN23 |

### |  |  | 类型 | CmdN23EventSubscription |

### |  | 属性 | event | * 类型：Value * 值：RAIL\_USR\_CHAR\_ANALYSIS |

### |  |  | crhSubInd | * 类型：Value * 值：False |

### |  |  | associatedPraInfos | * 类型：Reference ActionGroup * 值：AG\_UeChar\_PresInfo 说明：  已在5G动作组中定义。 |

### | 5G动作组4 | 基本信息 | 名称 | AG\_UeChar\_AmPolicy02 |

### |  |  | 类型 | AmPolicyAction |

### |  | 属性 | cmdN23EventSubscription | * 类型：Reference ActionGroup * 值：AG\_UeChar\_CmdN23 说明：  已在5G动作组中定义。 |

### | 5G动作组5 | 基本信息 | 名称 | AG\_UeChar\_AmPolicy03 |

### |  |  | 类型 | AmPolicyAction |

### |  | 属性 | waitEndFlag | * 类型：Object Attribute * 值：AmPolicySession.WaitEndFlag |

### |  |  | endFlag | * 类型：Object Attribute * 值：AmPolicySession.EndFlag |

### | 5G动作组6 | 基本信息 | 名称 | AG\_UeChar\_AmPolicy04 |

### |  |  | 类型 | AmPolicyAction |

### |  | 属性 | rfsp | * 类型：Value * 值：200 |

### 5 配置规则。

### 导航入口为“策略管理 > 策略 > 规则”。

### 规则的数据规划如表5所示。

### **表5** 规则

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 规则1 | 基本信息 | 名称 | N23\_UeChar\_Rule01 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Amf Pcc Rule |

### |  | 5G动作组 | 5G动作组 | AG\_UeChar\_AmPolicy01  说明：  已在5G动作组中定义。 |

### | 规则2 | 基本信息 | 名称 | N23\_UeChar\_Rule02 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Amf Pcc Rule |

### |  | 条件组 | 关系 | OR  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | * CG\_UeChar01 * CG\_UeChar02 说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_UeChar\_AmPolicy02  说明：  已在5G动作组中定义。 |

### | 规则3 | 基本信息 | 名称 | N23\_UeChar\_Rule03 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Amf Pcc Rule |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_UeChar03  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_UeChar\_AmPolicy03  说明：  已在5G动作组中定义。 |

### | 规则4 | 基本信息 | 名称 | N23\_UeChar\_Rule04 |

### |  |  | 操作类型 | Change Rule |

### |  |  | 类型 | 5G Amf Pcc Rule |

### |  | 条件组 | 关系 | AND  说明：  当规则中只有一个条件组时，“关系”可设置为任意值。 |

### |  |  | 条件组 | CG\_UeChar04  说明：  已在条件组中定义。 |

### |  | 5G动作组 | 5G动作组 | AG\_UeChar\_AmPolicy04  说明：  已在5G动作组中定义。 |

### 6 配置策略。

### 导航入口为“策略管理 > 策略 > 策略”。

### 策略的数据规划如表6所示。

### **表6** 策略

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 策略1 | 基本信息 | 名称 | N23\_UeChar\_Policy01 |

### |  |  | 类型 | N15 Policy |

### |  | 触发器 | 名称 | * AMPolicyCreateRequest * AMPresenceReportingAreaChange |

### |  | 规则 | 名称 | N23\_UeChar\_Rule01  说明：  已在规则中定义。 |

### | 策略2 | 基本信息 | 名称 | N23\_UeChar\_Policy02 |

### |  |  | 类型 | N15 Policy |

### |  | 触发器 | 名称 | * AMPolicyCreateRequest * AMPresenceReportingAreaChange |

### |  | 规则 | 名称 | * N23\_UeChar\_Rule02 * N23\_UeChar\_Rule03 说明：  已在规则中定义。 |

### | 策略3 | 基本信息 | 名称 | N23\_UeChar\_Policy03 |

### |  |  | 类型 | N15 Policy |

### |  | 触发器 | 名称 | AMPolicyCreateRequest |

### |  | 规则 | 名称 | N23\_UeChar\_Rule04  说明：  已在规则中定义。 |

### 7 配置业务。

### 导航入口为“业务管理 > 业务 > 业务”。

### 业务的数据规划如表7所示。

### **表7** 业务

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 业务1 | 基本信息 | 名称 | N23\_UeChar\_Service01 |

### |  |  | 类型 | VALUE\_ADDED\_SERVICE |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值取默认值“0”。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | N23\_UeChar\_Policy01  说明：  已在策略中定义。 |

### | 业务2 | 基本信息 | 名称 | N23\_UeChar\_Service02 |

### |  |  | 类型 | VALUE\_ADDED\_SERVICE |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值取默认值“0”。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | N23\_UeChar\_Policy02  说明：  已在策略中定义。 |

### | 业务3 | 基本信息 | 名称 | N23\_UeChar\_Service03 |

### |  |  | 类型 | VALUE\_ADDED\_SERVICE |

### |  |  | 激活方式 | PCEF |

### |  |  | 优先级 | 0  说明：  运营商统一规划，用于设置该业务在互斥组中的优先级。当此业务不需配置相关互斥组时，此值取默认值“0”。 |

### |  |  | QoS模式 | 替换 |

### |  |  | 签约后才能使用 | 是 |

### |  | 策略 | 名称 | N23\_UeChar\_Policy03  说明：  已在策略中定义。 |

### 8 配置用户组。

### 导航入口为“用户管理 > 用户 > 用户组”。

### 动态用户组的数据规划如表8所示，详细参数说明请参见动态用户组参数表。

### **表8** 动态用户组

### | 类别 | 参数 |  | 取值样例 |

### | --- | --- | --- | --- |

### | 用户组 | 基本信息 | 名称 | N23\_UeChar\_SubGroup |

### |  |  | 类型 | 动态 |

### |  |  | 优先级 | 0 |

### |  |  | 应用类型 | 缺省方式 |

### |  | 业务 | 名称 | * N23\_UeChar\_Service01 * N23\_UeChar\_Service02 * N23\_UeChar\_Service03 说明：  已在业务中定义。 |

