# 从自带空间备份源恢复内存数据库

* 操作场景
* 对系统的影响
* 必备事项
* 操作步骤

#### 操作场景

如果无法从Master节点和虚拟机硬盘恢复内存数据库，或者恢复内存数据库后数据仍有问题，则可以从自带空间中的备份文件向内存数据库进行加载，恢复内存数据库。

从自带空间备份源加载时恢复的是历史备份数据文件，不包括历史备份数据到当前最新数据的增量Redo。因此，需要注意此种恢复方式只可用于已确认当前数据已损坏，需要恢复备份数据的应急恢复场景，请务必在华为技术支持指导下操作。

#### 对系统的影响

* 恢复内存数据库过程中业务不可用，操作前请联系华为技术支持确认。
* 从自带空间中的备份文件加载恢复内存数据库时，会导致从开始备份文件到执行恢复操作相隔的时间，内存库存储的用户数据丢失。此操作为高危操作，操作前请联系华为技术支持。
* 从自带空间加载数据覆盖本地最新的备份文件前，系统将最新的备份文件拷贝到DRU/DSU所在容器的/opt/uscdb/SNP\_BKP目录下，会占用磁盘空间。

#### 必备事项

**前提条件**

网关类型为DMA的DPU模块所在Pod对应的虚拟机用于备份的硬盘空间中已经有内存数据库备份文件。

**数据**

该操作无需准备数据。

#### 操作步骤

1. 登录“USCDB MML命令”界面。
2. 执行**MOD INSP**命令，修改参数的取值来设置加载源。

   * “INSPT”取值为“FE”。
   * “INSPN”取值为“LDRSOURCE”。
   * “INSPV”取值为“5”。
   * “FETYPEN”根据异常节点所属“业务类型”进行取值，可以通过**LST NODE**查看节点所属“业务类型”。

   ```
   MOD INSP: INSPT=FE, INSPN=LDRSOURCE, INSPV=5, FETYPEN="网元类型";
   ```

   为防止用户误设置，当软参“LDRSOURCE”设置为“5”、“6”或“7”时会上报“ALM-10026 加载数据源软参LDRSOURCE已被设置为高危加载源值”告警进行提示，直到软参LDRSOURCE被修改为不是这三个值时告警自动恢复。
3. 执行**MOD INSP**命令关闭内存数据库的校验开关。

   需要关闭的校验开关如下：
   * FWDVFYSWT（正向校验开关）
   * REVVFYSWT（反向校验开关）
   * FWDRTVFYSWT（正向路由校验开关）
   * REVRTVFYSWT（反向路由校验开关）

   参数具体取值如下：

   * “INSPT”取值为“FE”。
   * “INSPN”取值分别为“FWDVFYSWT”、“REVVFYSWT”、“FWDRTVFYSWT”和“REVRTVFYSWT”。
   * “INSPV”取值为“0”。
   * “FETYPEN”根据异常节点所属“业务类型”进行取值，可以通过**LST NODE**命令查看节点所属“业务类型”。

   ```
   MOD INSP: INSPT=FE, INSPN=FWDVFYSWT, INSPV=0, FETYPEN="网元类型";
   MOD INSP: INSPT=FE, INSPN=REVVFYSWT, INSPV=0, FETYPEN="网元类型";
   MOD INSP: INSPT=FE, INSPN=FWDRTVFYSWT, INSPV=0, FETYPEN="网元类型";
   MOD INSP: INSPT=FE, INSPN=REVRTVFYSWT, INSPV=0, FETYPEN="网元类型";
   ```
4. 当局点为主备局点时，分别在主备局点执行**LST INSP**命令，查询此时的“REDUNDANCYSWITCH（容灾开关）”软参取值是否为“1”，并记录此时取值。

   ```
   LST INSP: INSPT=FE, INSPN=REDUNDANCYSWITCH;
   ```

   * 是 => 6
   * 否 => 5
5. 分别在主备局点执行**MOD INSP**命令修改“REDUNDANCYSWITCH（容灾开关）”的取值为“1”。

   参数具体取值如下：
   * “INSPT”取值为“FE”。
   * “INSPN”取值分别为“REDUNDANCYSWITCH”。
   * “INSPV”取值为“1”。
   * “FETYPEN”取值分别为异常节点所属“业务类型”和“USCDB”，可以通过**LST NODE**命令查看节点所属“业务类型”。

   ```
   MOD INSP: INSPT=FE, INSPN=REDUNDANCYSWITCH, INSPV=1, FETYPEN="网元类型";
   MOD INSP: INSPT=FE, INSPN=REDUNDANCYSWITCH, INSPV=1, FETYPEN="USCDB";
   ```
6. 执行**RST MODULE**命令将指定节点重新加载。

   ```
   RST MODULE: MID=Master模块号, MT=模块类型;
   RST MODULE: MID=Slave模块号, MT=模块类型;
   ```

   * 使用此恢复方式时，同一个Cluster中的Master和Slave节点必须同时重启加载才能生效。
   * 单个DRU/DSU节点的加载时长大约为3min。
   * 如需加载数据到对应模块的缓存中，请在节点复位完成后再次执行**RST MODULE**命令重启该模块。需重启的模块类型根据FE的具体场景决定。
7. 待接近加载完成的时间时，执行**DSP NODE**命令查看节点的数据加载状态。

   * 恢复时长受FE业务模型、局点容量和网络带宽的影响。从自带空间恢复的总时长 = 文件读取时长 + 文件传输时长 + 各模块中间处理环节耗时 +文件加载时长。
   * 此处以一组数据计算单平面恢复时长的参考值：
     + DRU 3GB，DSU 9GB节点内存库大小，备份文件大小分别约为1GB和3GB。DRU/DSU的比例为1:3，每个DSU开户100W，对于3000W的局点大概部署30个DSU Cluster，10个DRU Cluster。磁盘IO带宽（MB/s）约 80MB，网络带宽（1Gb网卡）为1Gb/s，即128MB/s。
     + 文件读取时长 = (30\*3 + 10\*1)\*1024 / 80 = 1280s。DMA与DPU之间文件传输时长 = (30\*3 + 10\*1)\*1024 / 128 = 800s。每个文件在各模块中间处理环节耗时40秒，共30\*40 = 1200s。节点加载时间预留180s。从自带空间恢复的总时长 = 1280 + 800 + 1200 + 180 = 3460s = 58min。

   ```
   DSP NODE:;
   ```

   查看各节点的“节点状态”信息：

   * 如果为“初始化”、“加载中”、“加载完毕 ”或“初始化完成”表示节点还处在数据加载状态。
   * 如果为“Master”或“Slave”表示节点的数据已经加载完。
8. 执行**DSP LOADINFO**命令确认节点的“加载源”为“自带空间”，并且检查“加载的最后一个redolog文件名称”和“加载的最后一条redolog的时间”与预期加载的一致。

   ```
   DSP LOADINFO:;
   ```
9. 执行**MOD INSP**命令打开内存数据库的校验开关。参数具体取值如下：

   * “INSPT”取值为“FE”。
   * “INSPN”取值分别为“FWDVFYSWT”、“REVVFYSWT”、“FWDRTVFYSWT”和“REVRTVFYSWT”。
   * “INSPV”取值为“1”。
   * “FETYPEN”根据异常节点所属“业务类型”进行取值，可以通过**LST NODE**查看节点所属“业务类型”。

   ```
   MOD INSP: INSPT=FE, INSPN=FWDVFYSWT, INSPV=1, FETYPEN="网元类型";
   MOD INSP: INSPT=FE, INSPN=REVVFYSWT, INSPV=1, FETYPEN="网元类型";
   MOD INSP: INSPT=FE, INSPN=FWDRTVFYSWT, INSPV=1, FETYPEN="网元类型";
   MOD INSP: INSPT=FE, INSPN=REVRTVFYSWT, INSPV=1, FETYPEN="网元类型";
   ```
10. 执行**MOD INSP**命令恢复节点数据加载源的默认值。参数具体取值如下：

    * “INSPT”取值为“FE”。
    * “INSPN”取值为“LDRSOURCE”。
    * “INSPV”取值为“0”。
    * “FETYPEN”根据异常节点所属“业务类型”进行取值，可以通过**LST NODE**查看节点所属“业务类型”。

    ```
    MOD INSP: INSPT=FE, INSPN=LDRSOURCE, INSPV=0, FETYPEN="网元类型";
    ```
11. 执行**MOD INSP**命令，还原“REDUNDANCYSWITCH（容灾开关）”软参取值。参数具体取值如下：

    * “INSPT”取值为“FE”。
    * “INSPN”取值分别为“REDUNDANCYSWITCH”。
    * “INSPV”取值为4中查询的软参取值。
    * “FETYPEN”根据异常节点所属“业务类型”进行取值，可以通过**LST NODE**查看节点所属“业务类型”。

    ```
    MOD INSP: INSPT=FE, INSPN=REDUNDANCYSWITCH, INSPV=VALUE, FETYPEN="网元类型";
    ```

    ```
    MOD INSP: INSPT=FE, INSPN=REDUNDANCYSWITCH, INSPV=VALUE, FETYPEN="USCDB";
    ```

版权所有 © 华为技术有限公司
